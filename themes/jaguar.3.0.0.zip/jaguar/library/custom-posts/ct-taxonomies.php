<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Custom taxonomies for custom posts
*****************************************************
*/

/*
*****************************************************
*      ACTIONS AND FILTERS
*****************************************************
*/
//ACTIONS
//Registering taxonomies
add_action( 'init', 'wm_create_taxonomies', 0 );
/*
The init action occurs after the theme's functions file has been included, so if you're looking for terms directly in the functions file, you're doing so before they've actually been registered.
*/





/*
*****************************************************
*      TAXONOMIES FUNCTION
*****************************************************
*/
/*
* Custom taxonomies registration
*/
if ( ! function_exists( 'wm_create_taxonomies' ) ) {
	function wm_create_taxonomies() {
		$slugSlidesCategory    = ( wm_option( 'general-permalink-slides' ) ) ? ( wm_option( 'general-permalink-slides' ) . '/category' ) : ( 'slides/category' );
		$slugPortfolioCategory = ( wm_option( 'general-permalink-portfolio-category' ) ) ? ( wm_option( 'general-permalink-portfolio-category' ) ) : ( 'portfolio/category' );
		$slugTeamPosition      = ( wm_option( 'general-permalink-team' ) ) ? ( wm_option( 'general-permalink-team' ) . '/position' ) : ( 'team/position' );
		$slugTeamDepartment    = ( wm_option( 'general-permalink-team-department' ) ) ? ( wm_option( 'general-permalink-team-department' ) . '/department' ) : ( 'team/department' );

		//Slides categories
		register_taxonomy( 'wm-tax-cats-slides', 'wm_slides', array(
			'hierarchical'      => true,
			'show_in_nav_menus' => false,
			'show_ui'           => true,
			'query_var'         => 'slides-cats',
			'rewrite'           => array( 'slug' => $slugSlidesCategory ),
			'labels'            => array(
				'name'          => __( 'Slides categories', 'jaguar_domain_adm' ),
				'singular_name' => __( 'Slides category', 'jaguar_domain_adm' ),
				'search_items'  => __( 'Search categories', 'jaguar_domain_adm' ),
				'all_items'     => __( 'All categories', 'jaguar_domain_adm' ),
				'parent_item'   => __( 'Parent category', 'jaguar_domain_adm' ),
				'edit_item'     => __( 'Edit category', 'jaguar_domain_adm' ),
				'update_item'   => __( 'Update category', 'jaguar_domain_adm' ),
				'add_new_item'  => __( 'Add new category', 'jaguar_domain_adm' ),
				'new_item_name' => __( 'New category title', 'jaguar_domain_adm' )
			)
		) );

		//Portfolio categories
		register_taxonomy( 'wm-tax-cats-portfolio', 'wm_portfolio', array(
			'hierarchical'      => true,
			'show_in_nav_menus' => false,
			'show_ui'           => true,
			'query_var'         => 'portfolio-cats',
			'rewrite'           => array( 'slug' => $slugPortfolioCategory ),
			'labels'            => array(
				'name'          => __( 'Portfolio categories', 'jaguar_domain_adm' ),
				'singular_name' => __( 'Portfolio category', 'jaguar_domain_adm' ),
				'search_items'  => __( 'Search categories', 'jaguar_domain_adm' ),
				'all_items'     => __( 'All categories', 'jaguar_domain_adm' ),
				'parent_item'   => __( 'Parent category', 'jaguar_domain_adm' ),
				'edit_item'     => __( 'Edit category', 'jaguar_domain_adm' ),
				'update_item'   => __( 'Update category', 'jaguar_domain_adm' ),
				'add_new_item'  => __( 'Add new category', 'jaguar_domain_adm' ),
				'new_item_name' => __( 'New category title', 'jaguar_domain_adm' )
			)
		) );

		//Team positions and departments
		if ( 'disable' != wm_option( 'general-role-team' ) ) {
			register_taxonomy( 'wm-tax-positions-team', 'wm_team', array(
				'hierarchical'      => false,
				'show_in_nav_menus' => false,
				'show_ui'           => true,
				'query_var'         => 'team-position',
				'rewrite'           => array( 'slug' => $slugTeamPosition ),
				'labels'            => array(
					'name'                       => __( 'Position', 'jaguar_domain_adm' ),
					'singular_name'              => __( 'Position', 'jaguar_domain_adm' ),
					'search_items'               => __( 'Search positions', 'jaguar_domain_adm' ),
					'all_items'                  => __( 'All positions', 'jaguar_domain_adm' ),
					'edit_item'                  => __( 'Edit position', 'jaguar_domain_adm' ),
					'update_item'                => __( 'Update position', 'jaguar_domain_adm' ),
					'add_new_item'               => __( 'Add new position', 'jaguar_domain_adm' ),
					'new_item_name'              => __( 'New position title', 'jaguar_domain_adm' ),
					'separate_items_with_commas' => __( 'A job position of this team member', 'jaguar_domain_adm' )
				)
			) );
			register_taxonomy( 'wm-tax-departments-team', 'wm_team', array(
				'hierarchical'      => true,
				'show_in_nav_menus' => false,
				'show_ui'           => true,
				'query_var'         => 'team-department',
				'rewrite'           => array( 'slug' => $slugTeamDepartment ),
				'labels'            => array(
					'name'          => __( 'Departments', 'jaguar_domain_adm' ),
					'singular_name' => __( 'Department', 'jaguar_domain_adm' ),
					'search_items'  => __( 'Search departments', 'jaguar_domain_adm' ),
					'all_items'     => __( 'All departments', 'jaguar_domain_adm' ),
					'parent_item'   => __( 'Parent department', 'jaguar_domain_adm' ),
					'edit_item'     => __( 'Edit department', 'jaguar_domain_adm' ),
					'update_item'   => __( 'Update department', 'jaguar_domain_adm' ),
					'add_new_item'  => __( 'Add new department', 'jaguar_domain_adm' ),
					'new_item_name' => __( 'New department title', 'jaguar_domain_adm' )
				)
			) );
		}
	}
} // /wm_create_taxonomies

?>