<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Predefined widget areas
*****************************************************
*/

//Widget areas
$widgetAreas = array(

	array(
		'name'          => __( 'General Sidebar', 'jaguar_domain_adm' ),
		'id'            => 'default',
		'description'   => '[widgets area=default /] ' . __( 'The default sidebar widget area.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget %1$s %2$s">',
		'after_widget'  => '</div> <!-- /widget -->',
		'before_title'  => '<h3 class="widget-heading">',
		'after_title'   => '</h3>'
	),

	array(
		'name'          => __( 'Footer Widgets', 'jaguar_domain_adm' ),
		'id'            => 'footer-widgets',
		'description'   => __( 'Flexible layout, maximum 5 widgets.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget %1$s %2$s">',
		'after_widget'  => '</div> <!-- /widget -->',
		'before_title'  => '<h3 class="widget-heading">',
		'after_title'   => '</h3>'
	),

	array(
		'name'          => __( 'Sitemap / Archives', 'jaguar_domain_adm' ),
		'id'            => 'sitemap',
		'description'   => __( 'Sitemap / Archives page widget area. Flexible layout, maximum 3 widgets.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget sitemap-item %1$s %2$s">',
		'after_widget'  => '</div> <!-- /sitemap-item -->',
		'before_title'  => '<h5>',
		'after_title'   => '</h5>'
	),

	array(
		'name'          => __( 'Error 404 Page', 'jaguar_domain_adm' ),
		'id'            => 'page-404',
		'description'   => __( 'Error 404 page widget area below error explanation. Flexible layout, maximum 5 widgets.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget %1$s %2$s">',
		'after_widget'  => '</div> <!-- /widget -->',
		'before_title'  => '<h3 class="widget-heading">',
		'after_title'   => '</h3>'
	),

	array(
		'name'          => __( 'Portfolio Item Page', 'jaguar_domain_adm' ),
		'id'            => 'portfolio-detail',
		'description'   => __( 'Widgets area below portfolio item content. Flexible layout, maximum 5 widgets.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget %1$s %2$s">',
		'after_widget'  => '</div> <!-- /widget -->',
		'before_title'  => '<h3 class="widget-heading">',
		'after_title'   => '</h3>'
	),

	array(
		'name'          => __( 'Top Bar', 'jaguar_domain_adm' ),
		'id'            => 'top-bar-widgets',
		'description'   => __( 'Flexible layout, maximum 2 widgets. Recommended widgets are Custom menu, Text or Search.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget %1$s %2$s">',
		'after_widget'  => '</div> <!-- /widget -->',
		'before_title'  => '<h3 class="widget-heading">',
		'after_title'   => '</h3>'
	)

);

if ( ! wm_option( 'layout-menu-special' ) )
	array_push( $widgetAreas, array(
		'name'          => __( 'Special Menu Area', 'jaguar_domain_adm' ),
		'id'            => 'contact-section-widgets',
		'description'   => __( 'Special animated information area in main menu section. Used for contact information by default. Flexible layout, maximum 3 widgets.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget %1$s %2$s">',
		'after_widget'  => '</div> <!-- /widget -->',
		'before_title'  => '<h3 class="widget-heading">',
		'after_title'   => '</h3>'
		) );

if ( 'widgets' === wm_option( 'layout-status' ) )
	array_push( $widgetAreas, array(
		'name'          => __( 'Header Right', 'jaguar_domain_adm' ),
		'id'            => 'header-right',
		'description'   => __( 'Right side of the website header. Takes only 1 widget.', 'jaguar_domain_adm' ),
		'before_widget' => '<div class="widget %1$s %2$s">',
		'after_widget'  => '</div> <!-- /widget -->',
		'before_title'  => '<h3 class="widget-heading">',
		'after_title'   => '</h3>'
		) );

?>