<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Post meta boxes
*****************************************************
*/

/**
 * @version  2.9
 */

/*
* Meta settings options for posts
*
* Has to be set up as function to pass the custom taxonomies array.
* Custom taxonomies are hooked onto 'init' action which is executed after the theme's functions file has been included.
* So if you're looking for taxonomy terms directly in the functions file, you're doing so before they've actually been registered.
* Meta box generator, which uses these settings options, is hooked onto 'add_meta_boxes' which is executed after 'init' action.
*/
if ( ! function_exists( 'wm_meta_post_options' ) ) {
	function wm_meta_post_options() {
		global $post, $sidebarPosition;

		$postId = ( $post ) ? ( $post->ID ) : ( null );
		$prefix = '';

		if ( ! $postId && isset( $_GET['post'] ) )
			$postId = absint( $_GET['post'] );

		$metaPostOptions = array(

			//General settings
			array(
				"type" => "section-open",
				"section-id" => "general-section",
				"title" => __( 'General', 'jaguar_domain_adm' )
			)
		);

		if ( is_active_sidebar( 'top-bar-widgets' ) )
			array_push( $metaPostOptions,
				array(
					"type" => "checkbox",
					"id" => $prefix."no-top-bar",
					"label" => __( 'Disable top bar', 'jaguar_domain_adm' ),
					"desc" => __( 'Disables top bar widget area on this page', 'jaguar_domain_adm' ),
					"value" => "true"
				)
			);

		if ( ! wm_option( 'seo-breadcrumbs' ) )
			array_push( $metaPostOptions,
				array(
					"type" => "checkbox",
					"id" => $prefix."breadcrumbs",
					"label" => __( 'Disable breadcrumbs', 'jaguar_domain_adm' ),
					"desc" => __( 'Disables breadcrumbs navigation on this page', 'jaguar_domain_adm' ),
					"value" => "true"
				)
			);

		if ( ! wm_option( 'blog-disable-bio' ) )
			array_push( $metaPostOptions,
				array(
					"type" => "checkbox",
					"id" => $prefix."author",
					"label" => __( 'Disable author details', 'jaguar_domain_adm' ),
					"desc" => __( 'Disables author information below the post content', 'jaguar_domain_adm' ),
					"value" => "true"
				)
			);

		if (
				wm_option( 'contact-share-facebook' )
				|| wm_option( 'contact-share-twitter' )
				|| wm_option( 'contact-share-googleplus' )
				|| wm_option( 'contact-share-pinterest' )
			)
			array_push( $metaPostOptions,
				array(
					"type" => "checkbox",
					"id" => $prefix."no-sharing",
					"label" => __( 'Disable share buttons', 'jaguar_domain_adm' ),
					"desc" => __( 'Disables sharing buttons for this post only', 'jaguar_domain_adm' ),
					"value" => "true"
				)
			);

		if ( is_active_sidebar( 'top-bar-widgets' ) || ! wm_option( 'seo-breadcrumbs' ) || ! wm_option( 'blog-disable-bio' ) )
			array_push( $metaPostOptions,
				array(
					"type" => "hr"
				)
			);

		array_push( $metaPostOptions,
					array(
						"type" => "checkbox",
						"id" => $prefix."no-heading",
						"label" => __( 'Disable main heading', 'jaguar_domain_adm' ),
						"desc" => __( 'Hides post main heading - the title', 'jaguar_domain_adm' ),
						"value" => "true"
					),
					array(
						"type" => "space"
					),
					array(
						"type" => "textarea",
						"id" => $prefix."subheading",
						"label" => __( 'Post subtitle', 'jaguar_domain_adm' ),
						"desc" => __( 'If defined, the specially styled subtitle will be displayed', 'jaguar_domain_adm' ),
						"default" => "",
						"rows" => 3
					),
				array(
					"type" => "section-close"
				),



				//Gallery settings
				array(
					"type" => "section-open",
					"section-id" => "gallery-section",
					"title" => __( 'Gallery', 'jaguar_domain_adm' ),
				),
					array(
						"type" => "patterns",
						"id" => $prefix."gallery-images",
						"label" => __( 'Exclude gallery images', 'jaguar_domain_adm' ),
						"desc" => __( 'Exclude images from image gallery shortcode used in the post content', 'jaguar_domain_adm' ),
						"options" => wm_get_post_images( -1, $postId ),
						"field" => "checkbox",
						"default" => ""
					),
					array(
						"type" => "space"
					),
					array(
						"type" => "checkbox",
						"id" => $prefix."gallery",
						"label" => __( 'Display excluded images below the post', 'jaguar_domain_adm' ),
						"desc" => __( 'Displays these excluded images in a new gallery below the post content', 'jaguar_domain_adm' ),
						"value" => "true"
					),
					array(
						"type" => "space"
					),
					array(
						"type" => "slider",
						"id" => $prefix."gallery-columns",
						"label" => __( 'Gallery columns', 'jaguar_domain_adm' ),
						"desc" => __( 'Set the number of columns for the gallery below the post content', 'jaguar_domain_adm' ),
						"default" => 3,
						"min" => 3,
						"max" => 6,
						"step" => 1,
						"validate" => "absint"
					),
				array(
					"type" => "section-close"
				),



				//Sidebar settings
				array(
					"type" => "section-open",
					"section-id" => "sidebar-section",
					"title" => __( 'Sidebar', 'jaguar_domain_adm' )
				),
					array(
						"type" => "select",
						"id" => $prefix."sidebar",
						"label" => __( 'Choose a sidebar', 'jaguar_domain_adm' ),
						"desc" => __( 'Select a widget area used as a sidebar for this page (if not set, the dafault theme settings will apply)', 'jaguar_domain_adm' ),
						"options" => wm_widget_areas(),
						"default" => ""
					),
					array(
						"type" => "layouts",
						"id" => $prefix."layout",
						"label" => __( 'Sidebar position', 'jaguar_domain_adm' ),
						"desc" => __( 'Choose a sidebar position on the page (set the first one to use the theme default settings)', 'jaguar_domain_adm' ),
						"options" => $sidebarPosition,
						"default" => ""
					),
				array(
					"type" => "section-close"
				)

			);

		return $metaPostOptions;
	}
} // /wm_meta_post_options



if ( ! function_exists( 'wm_meta_post_options_formats' ) ) {
	function wm_meta_post_options_formats() {
		global $post;

		$postId = ( $post ) ? ( $post->ID ) : ( null );
		$prefix = '';

		if ( ! $postId && isset( $_GET['post'] ) )
			$postId = absint( $_GET['post'] );

		if ( ! $postId )
			$postId = '{{{post_id}}}';

		$metaPostOptions = array(

			//gallery post
			array(
				"id" => "post-format-gallery",
				"type" => "inside-wrapper-open"
			),
				array(
					"type" => "box",
					"content" => '
						<h4>' . __( 'Gallery post format', 'jaguar_domain_adm' ) . '</h4>
						<p>' . __( 'This is basically a standard post, but when you place an image gallery into the post content, you can mark it as a gallery post (a special icon will be assigned to a post). You can even use "Gallery" tab above to create a gallery at the end of the post content. Do not forget to set featured image.', 'jaguar_domain_adm' ) . '</p>
						<a class="button-primary thickbox js-post-id" href="' . get_admin_url() . 'media-upload.php?post_id=' . $postId . '&TB_iframe=1">' . __( 'Add images to post', 'jaguar_domain_adm' ) . '</a>
						'
				),
			array(
				"conditional" => array(
					"field" => "post_format",
					"custom" => array( "input", "name", "radio" ),
					"post-format" => "gallery",
					"value" => "gallery"
					),
				"id" => "post-format-gallery",
				"type" => "inside-wrapper-close"
			),

			//link post
			array(
				"id" => "post-format-link",
				"type" => "inside-wrapper-open"
			),
				array(
					"type" => "box",
					"content" => '<h4>' . __( 'Link post format', 'jaguar_domain_adm' ) . '</h4>' . __( 'Please place the URL address of the link into the excerpt field (you might need to enable it in <em>"Screen options"</em> in upper right corner of the screen). You can place the link description into the post content. Link will be applied on the post title in list of posts.', 'jaguar_domain_adm' )
				),
			array(
				"conditional" => array(
					"field" => "post_format",
					"custom" => array( "input", "name", "radio" ),
					"post-format" => "link",
					"value" => "link"
					),
				"id" => "post-format-link",
				"type" => "inside-wrapper-close"
			),

			//quote post
			array(
				"id" => "post-format-quote",
				"type" => "inside-wrapper-open"
			),
				array(
					"type" => "box",
					"content" => '<h4>' . __( 'Quote post format', 'jaguar_domain_adm' ) . '</h4>' . __( 'Please place the quoted text into the excerpt field (you might need to enable it in <em>"Screen options"</em> in upper right corner of the screen). Place the quote author into the post content (this way you can use visual editor for basic stylings, links). Quote will be displayed in the posts list without the post title.', 'jaguar_domain_adm' )
				),
			array(
				"conditional" => array(
					"field" => "post_format",
					"custom" => array( "input", "name", "radio" ),
					"post-format" => "quote",
					"value" => "quote"
					),
				"id" => "post-format-quote",
				"type" => "inside-wrapper-close"
			),

			//status post
			array(
				"id" => "post-format-status",
				"type" => "inside-wrapper-open"
			),
				array(
					"type" => "box",
					"content" => '<h4>' . __( 'Status post format', 'jaguar_domain_adm' ) . '</h4>' . __( 'Please place the status into the post content. Status posts will be displayed in the posts list and can be displayed also in the website header. Post title will not be displayed. Status post should be a short text, similar to Facebook statuses or tweets on Twitter.com.', 'jaguar_domain_adm' )
				),
			array(
				"conditional" => array(
					"field" => "post_format",
					"custom" => array( "input", "name", "radio" ),
					"post-format" => "status",
					"value" => "status"
					),
				"id" => "post-format-status",
				"type" => "inside-wrapper-close"
			),

			//video post
			array(
				"id" => "post-format-video",
				"type" => "inside-wrapper-open"
			),
				array(
					"type" => "box",
					"content" => '
						<h4>' . __( 'Video post format', 'jaguar_domain_adm' ) . '</h4>' . sprintf( __( 'Please place the video URL into the excerpt field (check the <a%s>list of supported video portals</a>) or you can also insert a <a%s>WordPress <code>&#91;video]</code> shortcode</a>. You can place the video description into post content. Video will be displayed also in the posts list with full post content.', 'jaguar_domain_adm' ), ' href="http://codex.wordpress.org/Embeds#Can_I_Use_Any_URL_With_This.3F" target="_blank"', ' href="http://codex.wordpress.org/Video_Shortcode" target="_blank"' )
				),
			array(
				"conditional" => array(
					"field" => "post_format",
					"custom" => array( "input", "name", "radio" ),
					"post-format" => "video",
					"value" => "video"
					),
				"id" => "post-format-video",
				"type" => "inside-wrapper-close"
			),

			//audio post
			array(
				"id" => "post-format-audio",
				"type" => "inside-wrapper-open"
			),
				array(
					"type" => "box",
					"content" => '
						<h4>' . __( 'Audio post format', 'jaguar_domain_adm' ) . '</h4>' . sprintf( __( 'Please place the audio URL into the excerpt field (check the <a%s>list of supported audio portals</a>) or you can also insert a <a%s>WordPress <code>&#91;audio]</code> shortcode</a>. You can place the audio description into post content. Audio will be displayed also in the posts list with full post content.', 'jaguar_domain_adm' ), ' href="http://codex.wordpress.org/Embeds#Can_I_Use_Any_URL_With_This.3F" target="_blank"', ' href="http://codex.wordpress.org/Audio_Shortcode" target="_blank"' )
				),
			array(
				"conditional" => array(
					"field" => "post_format",
					"custom" => array( "input", "name", "radio" ),
					"post-format" => "audio",
					"value" => "audio"
					),
				"id" => "post-format-audio",
				"type" => "inside-wrapper-close"
			)

		);

		return $metaPostOptions;
	}
} // /wm_meta_post_options_formats

?>