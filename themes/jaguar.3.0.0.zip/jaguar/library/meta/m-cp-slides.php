<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Slides custom post meta boxes
*
* CONTENT:
* - 1) Meta box form
* - 2) Add meta box
*****************************************************
*/






/*
*****************************************************
*      1) META BOX FORM
*****************************************************
*/
	/**
	 * Meta box form fields
	 */
	if ( ! function_exists( 'wm_slides_meta_fields' ) ) {
		function wm_slides_meta_fields() {
			global $post;

			$prefix = 'slide-';
			$postId = ( $post ) ? ( $post->ID ) : ( null );

			if ( ! $postId && isset( $_GET['post'] ) )
				$postId = absint( $_GET['post'] );

			if ( ! $postId )
				$postId = '{{{post_id}}}';

			$metaFields = array(

				//General settings
				array(
					"type" => "section-open",
					"section-id" => "general",
					"title" => __( 'Slide settings', 'jaguar_domain_adm' )
				),
					array(
						"type" => "box",
						"content" => '<p>' . __( 'Use featured image area to upload the slide image.', 'jaguar_domain_adm' ) . '</p><a class="button-primary thickbox button-set-featured-image js-post-id" href="' . get_admin_url() . 'media-upload.php?post_id=' . $postId . '&type=image&TB_iframe=1">' . __( 'Set featured image', 'jaguar_domain_adm' ) . '</a>'
					),
					array(
						"type" => "checkbox",
						"id" => $prefix."no-title",
						"label" => __( 'Hide title', 'jaguar_domain_adm' ),
						"desc" => __( 'Disables slide title', 'jaguar_domain_adm' ),
						"value" => "true"
					),
					array(
						"type" => "space"
					),
					array(
						"type" => "text",
						"id" => $prefix."link",
						"label" => __( 'Link to more information on the topic', 'jaguar_domain_adm' ),
						"desc" => __( 'When left blank, no link will be applied', 'jaguar_domain_adm' ),
						"validate" => "url"
					),
					array(
						"type" => "text",
						"id" => $prefix."button-text",
						"label" => __( 'Link button text', 'jaguar_domain_adm' ),
						"desc" => __( 'Text of the more information link button in slide description area (if left blank no button will be displayed). Requires link to be set.', 'jaguar_domain_adm' )
					),
					array(
						"type" => "textarea",
						"id" => $prefix."description",
						"label" => __( 'Slide description', 'jaguar_domain_adm' ),
						"desc" => __( 'Additional slide description text', 'jaguar_domain_adm' ),
						"default" => "",
						"cols" => 80,
						"rows" => 4
					),

					array(
						"type" => "heading4",
						"content" => __( 'Slide animation', 'jaguar_domain_adm' )
					),
					array(
						"type" => "select",
						"id" => $prefix."animation",
						"label" => __( 'Slide text animation', 'jaguar_domain_adm' ),
						"desc" => __( 'Select the slide text animation effect', 'jaguar_domain_adm' ),
						"options" => array(
							'fade'   => __( 'Fading', 'jaguar_domain_adm' ),
							'top'    => __( 'Top', 'jaguar_domain_adm' ),
							'right'  => __( 'Right', 'jaguar_domain_adm' ),
							'bottom' => __( 'Bottom', 'jaguar_domain_adm' ),
							'left'   => __( 'Left', 'jaguar_domain_adm' )
							),
						"default" => "fade"
					),
				array(
					"type" => "section-close"
				)

			);

			return $metaFields;
		}
	} // /wm_slides_meta_fields





/*
*****************************************************
*      2) ADD META BOX
*****************************************************
*/
	/**
	 * Generate metabox
	 */
	if ( ! function_exists( 'wm_slides_generate_metabox' ) ) {
		function wm_slides_generate_metabox() {
			$wm_slides_META = new WM_Meta_Box( array(
				//where the meta box appear: normal (default), advanced, side
				'context'        => 'normal',
				//meta fields setup array
				'fields'         => wm_slides_meta_fields(),
				//meta box id, unique per meta box
				'id'             => 'wm-metabox-wm_slides-meta',
				//post types
				'pages'          => array( 'wm_slides' ),
				//order of meta box: high (default), low
				'priority'       => 'high',
				//tabbed meta box interface?
				'tabs'           => false,
				//meta box title
				'title'          => __( 'Slide settings', 'jaguar_domain_adm' ),
			) );
		}
	} // /wm_slides_generate_metabox

	add_action( 'init', 'wm_slides_generate_metabox', 9999 ); //Has to be hooked to the end of init for taxonomies lists in metaboxes

?>