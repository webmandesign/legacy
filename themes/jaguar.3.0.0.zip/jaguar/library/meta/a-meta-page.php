<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Page meta boxes
*****************************************************
*/

/*
* Meta settings options for pages
*
* Has to be set up as function to pass the custom taxonomies array.
* Custom taxonomies are hooked onto 'init' action which is executed after the theme's functions file has been included.
* So if you're looking for taxonomy terms directly in the functions file, you're doing so before they've actually been registered.
* Meta box generator, which uses these settings options, is hooked onto 'add_meta_boxes' which is executed after 'init' action.
*/
if ( ! function_exists( 'wm_meta_page_options' ) ) {
	function wm_meta_page_options() {
		global $post, $portfolioLayout, $sidebarPosition;

		$postId   = ( $post ) ? ( $post->ID ) : ( null );
		$prefix   = '';
		$prefixBg = 'background-';

		if ( ! $postId && isset( $_GET['post'] ) )
			$postId = absint( $_GET['post'] );

		//Other page settings
		$metaPageOptions = array(

			//Contact settings
			array(
				"type" => "section-open",
				"section-id" => "contact-section",
				"title" => __( 'Contact', 'jaguar_domain_adm' ),
				"exclude" => array( '', 'default', 'blog-page', 'pagetpl-about.php', 'pagetpl-portfolio.php', 'pagetpl-sitemap.php', 'pagetpl-widgetized.php' )
			),
				array(
					"type" => "text",
					"id" => $prefix."contact-map-url",
					"label" => __( 'Map URL', 'jaguar_domain_adm' ),
					"desc" => __( 'Map link obtained from Google Maps (or leave blank and map will set the location on the address below)', 'jaguar_domain_adm' ),
					"validate" => "url"
				),
				array(
					"type" => "slider",
					"id" => $prefix."contact-map-zoom",
					"label" => __( 'Map zoom', 'jaguar_domain_adm' ),
					"desc" => __( 'Map zoom on location', 'jaguar_domain_adm' ),
					"default" => 10,
					"min" => 5,
					"max" => 19,
					"step" => 1,
					"validate" => "absint"
				),
				array(
					"type" => "hr"
				),
				array(
					"type" => "heading4",
					"content" => __( 'Address', 'jaguar_domain_adm' )
					),
				array(
					"type" => "paragraph",
					"content" => __( 'The address will be displayed on the page and also used as map location (if no map URL set).', 'jaguar_domain_adm' )
					),
				array(
					"type" => "text",
					"id" => $prefix."contact-name",
					"label" => __( 'Name', 'jaguar_domain_adm' ),
					"desc" => __( 'Your name or the name of your company', 'jaguar_domain_adm' )
				),
				array(
					"type" => "text",
					"id" => $prefix."contact-address1",
					"label" => __( 'Address line 1', 'jaguar_domain_adm' ),
					"desc" => __( 'First address line', 'jaguar_domain_adm' )
				),
				array(
					"type" => "text",
					"id" => $prefix."contact-address2",
					"label" => __( 'Address line 2', 'jaguar_domain_adm' ),
					"desc" => __( 'Second address line', 'jaguar_domain_adm' )
				),
				array(
					"type" => "text",
					"id" => $prefix."contact-city",
					"label" => __( 'City', 'jaguar_domain_adm' ),
					"desc" => __( 'Enter city or town name here', 'jaguar_domain_adm' )
				),
				array(
					"type" => "text",
					"id" => $prefix."contact-code",
					"label" => __( 'Postal code', 'jaguar_domain_adm' ),
					"desc" => __( 'Enter the postal code here', 'jaguar_domain_adm' )
				),
				array(
					"type" => "text",
					"id" => $prefix."contact-country",
					"label" => __( 'Country', 'jaguar_domain_adm' ),
					"desc" => __( 'Enter country / state here', 'jaguar_domain_adm' )
				),
				array(
					"type" => "text",
					"id" => $prefix."contact-email",
					"label" => __( 'Email', 'jaguar_domain_adm' ),
					"desc" => __( 'Enter email address here (JavaScript antispam filter will be applied on the address)', 'jaguar_domain_adm' )
				),
				array(
					"type" => "textarea",
					"id" => $prefix."contact-phone",
					"label" => __( 'Phones', 'jaguar_domain_adm' ),
					"desc" => __( 'Enter phone numbers here', 'jaguar_domain_adm' ),
					"default" => "",
					"rows" => 3
				),
			array(
				"type" => "section-close"
			),



			//Portfolio settings
			array(
				"type" => "section-open",
				"section-id" => "portfolio-section",
				"title" => __( 'Portfolio', 'jaguar_domain_adm' ),
				"exclude" => array( '', 'default', 'blog-page', 'pagetpl-about.php', 'pagetpl-contact.php', 'pagetpl-sitemap.php', 'pagetpl-widgetized.php' )
			),
				array(
					"type" => "text",
					"id" => $prefix."portfolio-title",
					"label" => __( 'Portfolio list title', 'jaguar_domain_adm' ),
					"desc" => __( 'Set the title text for portfolio items list section on the page', 'jaguar_domain_adm' )
				),
				array(
					"type" => "select",
					"id" => $prefix."portfolio-cat",
					"label" => __( 'Portfolio main category', 'jaguar_domain_adm' ),
					"desc" => __( 'Select whether to display all portfolio items or just those from specific main category (only first level categories can be chosen)', 'jaguar_domain_adm' ),
					"options" => wm_tax_array( array(
								'allCountPost' => 'wm_portfolio',
								'allText'      => __( 'All projects', 'jaguar_domain_adm' ),
								'parentsOnly'  => true,
								'tax'          => 'wm-tax-cats-portfolio',
							) ),
					"default" => "0"
				),
				array(
					"type" => "select",
					"id" => $prefix."portfolio-ordering",
					"label" => __( 'Portfolio order', 'jaguar_domain_adm' ),
					"desc" => __( 'Choose how portfolio items are being displayed', 'jaguar_domain_adm' ),
					"options" => array(
						''       => __( 'Newest first', 'jaguar_domain_adm' ),
						'oldest' => __( 'Oldest first', 'jaguar_domain_adm' ),
						'name'   => __( 'Alphabetically', 'jaguar_domain_adm' ),
						'random' => __( 'Random ordering', 'jaguar_domain_adm' )
						)
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."portfolio-filterable",
					"label" => __( 'Filterable list', 'jaguar_domain_adm' ),
					"desc" => __( 'Enable filterable portfolio items. Note that all portfolio items (from the category if set previously) will be listed on the page with no pagination applied.', 'jaguar_domain_adm' )
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."portfolio-show-filter",
					"label" => __( 'Do not hide filter categories', 'jaguar_domain_adm' ),
					"desc" => __( 'Filter categories are being displayed all the time', 'jaguar_domain_adm' )
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "slider",
					"id" => $prefix."portfolio-count",
					"label" => __( 'Number of portfolio items', 'jaguar_domain_adm' ),
					"desc" => __( 'This will affect the number of portfolio items listed on the page. Set "-1" to display all items, set "0" to use default WordPress settings.', 'jaguar_domain_adm' ),
					"default" => get_option( 'posts_per_page' ),
					"min" => -1,
					"max" => 32,
					"step" => 1,
					"validate" => "int"
				),
				array(
					"type" => "layouts",
					"id" => $prefix."portfolio-layout",
					"label" => __( 'Portfolio layout', 'jaguar_domain_adm' ),
					"desc" => __( 'Choose, how the portfolio list will be displayed', 'jaguar_domain_adm' ),
					"options" => $portfolioLayout,
					"default" => ""
				),
				array(
					"type" => "hr"
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."portfolio-no-catlist",
					"label" => __( 'Disable portfolio categories', 'jaguar_domain_adm' ),
					"desc" => __( 'You can hide portfolio list categories for non-filterable list', 'jaguar_domain_adm' )
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."portfolio-no-pagination",
					"label" => __( 'Disable portfolio pagination', 'jaguar_domain_adm' ),
					"desc" => __( 'You can hide pagination for non-filterable portfolio list (like for example pagination makes little sense on random portfolio list)', 'jaguar_domain_adm' )
				),
				array(
					"type" => "hr"
				),
				array(
					"type" => "select",
					"id" => $prefix."portfolio-widget-area",
					"label" => __( 'Widget area below portfolio', 'jaguar_domain_adm' ),
					"desc" => __( 'If set, displays a widget area below the portfolio items list', 'jaguar_domain_adm' ),
					"options" => wm_widget_areas(),
					"default" => ""
				),
			array(
				"type" => "section-close"
			),



			//Widget Areas section
			array(
				"type" => "section-open",
				"section-id" => "widgetized-section",
				"title" => __( 'Widget Areas', 'jaguar_domain_adm' ),
				"exclude" => array( '', 'default', 'blog-page', 'pagetpl-about.php', 'pagetpl-contact.php', 'pagetpl-portfolio.php', 'pagetpl-sitemap.php' ) // '' is page template value when creating new page
			),
				array(
					"type" => "additems",
					"id" => $prefix."widget-areas",
					"label" => __( 'Add widget areas displayed on this page', 'jaguar_domain_adm' ),
					"desc" => __( 'Press [+] button to add a new widget area and select the area from dropdown list', 'jaguar_domain_adm' ),
					"default" => "",
					"field" => "select",
					"options" => wm_widget_areas()
				),
			array(
				"type" => "section-close"
			),



			//General settings
			array(
				"type" => "section-open",
				"section-id" => "general-section",
				"title" => __( 'General', 'jaguar_domain_adm' ),
				"exclude" => array()
			),
				array(
					"conditional" => array(
						"field" => "page_template",
						"value" => "pagetpl-about.php"
						),
					"type" => "select",
					"id" => $prefix."team-department",
					"label" => __( 'Team department', 'jaguar_domain_adm' ),
					"desc" => __( 'Select whether to display staff from all departments or just specific team', 'jaguar_domain_adm' ),
					"options" => wm_tax_array( array(
							'allCountPost' => 'wm_team',
							'allText'      => __( 'All staff', 'jaguar_domain_adm' ),
							'tax'          => 'wm-tax-departments-team',
						) )
				)
		);

		if ( is_active_sidebar( 'top-bar-widgets' ) )
			array_push( $metaPageOptions,
				array(
					"type" => "checkbox",
					"id" => $prefix."no-top-bar",
					"label" => __( 'Disable top bar', 'jaguar_domain_adm' ),
					"desc" => __( 'Disables top bar widget area on this page', 'jaguar_domain_adm' ),
					"value" => "true"
				)
			);

		if ( ! wm_option( 'seo-breadcrumbs' ) )
			array_push( $metaPageOptions,
				array(
					"type" => "checkbox",
					"id" => $prefix."breadcrumbs",
					"label" => __( 'Disable breadcrumbs', 'jaguar_domain_adm' ),
					"desc" => __( 'Disables breadcrumbs navigation on this page', 'jaguar_domain_adm' ),
					"value" => "true"
				)
			);

		if ( is_active_sidebar( 'top-bar-widgets' ) || ! wm_option( 'seo-breadcrumbs' ) )
			array_push( $metaPageOptions,
				array(
					"type" => "hr"
				)
			);

		array_push( $metaPageOptions,
				array(
					"type" => "checkbox",
					"id" => $prefix."no-heading",
					"label" => __( 'Disable main heading', 'jaguar_domain_adm' ),
					"desc" => __( 'Hides page main heading - the title', 'jaguar_domain_adm' ),
					"value" => "true"
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "textarea",
					"id" => $prefix."subheading",
					"label" => __( 'Page subtitle', 'jaguar_domain_adm' ),
					"desc" => __( 'If defined, the specially styled subtitle will be displayed', 'jaguar_domain_adm' ),
					"default" => "",
					"rows" => 3
				),
			array(
				"type" => "section-close"
			),



			//Slider settings
			array(
				"type" => "section-open",
				"section-id" => "slider-section",
				"title" => __( 'Slider', 'jaguar_domain_adm' ),
				"exclude" => array()
			),
				array(
					"type" => "select",
					"id" => $prefix."slider-type",
					"label" => __( 'Enable slider', 'jaguar_domain_adm' ),
					"desc" => __( 'Select a slider type from the dropdown list below', 'jaguar_domain_adm' ),
					"options" => array(
						'none'       => __( '- no slider -', 'jaguar_domain_adm' ),
						'simple'     => __( 'Simple Slider', 'jaguar_domain_adm' ),
						'roundabout' => __( 'Roundabout Slider', 'jaguar_domain_adm' ),
						'nivo'       => __( 'Nivo Slider', 'jaguar_domain_adm' ),
						'kwicks'     => __( 'Kwicks Accordion', 'jaguar_domain_adm' ),
						'video'      => __( 'Video', 'jaguar_domain_adm' ),
						'static'     => __( 'Static featured image', 'jaguar_domain_adm' ),
						'custom'     => __( 'Custom slider', 'jaguar_domain_adm' ),
						),
					"default" => "none"
				),

					array(
						"id" => $prefix."slider-settings",
						"type" => "inside-wrapper-open"
					),

						array(
							"conditional" => array(
								"field" => $prefix."slider-type",
								"value" => "static"
								),
							"type" => "text",
							"id" => $prefix."slider-url",
							"label" => __( 'Static featured image custom link', 'jaguar_domain_adm' ),
							"desc" => __( 'Enter a slider more link when static featured image is used', 'jaguar_domain_adm' ),
							"default" => "",
							"size" => "",
							"maxlength" => "",
							"validate" => "url"
						),

						array(
							"conditional" => array(
								"field" => $prefix."slider-type",
								"value" => "video"
								),
							"type" => "text",
							"id" => $prefix."slider-video-url",
							"label" => __( 'Video URL', 'jaguar_domain_adm' ),
							"desc" => __( 'Enter full video URL (check the <a href="http://codex.wordpress.org/Embeds#Can_I_Use_Any_URL_With_This.3F" target="_blank">list of supported video portals</a>)', 'jaguar_domain_adm' ),
							"default" => "",
							"size" => "",
							"maxlength" => "",
							"validate" => "url"
						),

						array(
							"conditional" => array(
								"field" => $prefix."slider-type",
								"value" => "custom"
								),
							"type" => "text",
							"id" => $prefix."slider-custom-shortcode",
							"label" => __( 'Custom slider shortcode', 'jaguar_domain_adm' ),
							"desc" => __( 'Most of custom slider plugins let you display the slider using shortcode. Please, insert such slider shortcode into this text field. The slider will then be displayed in main slider area of the website.', 'jaguar_domain_adm' ),
						),

						array(
							"id" => $prefix."slider-settings-content",
							"type" => "inside-wrapper-open"
						),

							array(
								"conditional" => array(
									"field" => $prefix."slider-type",
									"value" => "roundabout"
									),
								"type" => "slider",
								"id" => $prefix."slider-roundabout-width",
								"label" => __( 'Slider width', 'jaguar_domain_adm' ),
								"desc" => __( 'Adjust Roundabout slider width', 'jaguar_domain_adm' ),
								"default" => 0,
								"min" => -200,
								"max" => 200,
								"step" => 1,
								"validate" => "int",
								"zero" => true
							),

							array(
								"id" => $prefix."slider-settings-standard",
								"type" => "inside-wrapper-open"
							),
								array(
									"type" => "slider",
									"id" => $prefix."slider-count",
									"label" => __( 'Number of slides', 'jaguar_domain_adm' ),
									"desc" => __( 'Maximum number of slides (items) to be displayed in the slider', 'jaguar_domain_adm' ),
									"default" => 3,
									"min" => 1,
									"max" => ( wm_option( 'slider-max-number' ) ) ? ( wm_option( 'slider-max-number' ) ) : ( 8 ),
									"step" => 1,
									"validate" => "absint"
								),
								array(
									"type" => "select",
									"id" => $prefix."slider-content",
									"label" => __( 'Slider content', 'jaguar_domain_adm' ),
									"desc" => __( 'Choose which content type will populate the slider', 'jaguar_domain_adm' ),
									"options" => array(
										'wm_slides' => __( 'Slides custom posts', 'jaguar_domain_adm' ),
										'gallery'   => __( 'Page image gallery', 'jaguar_domain_adm' )
										),
									"default" => "wm_slides"
								),
									array(
										"conditional" => array(
											"field" => $prefix."slider-content",
											"value" => "wm_slides"
											),
										"type" => "select",
										"id" => $prefix."slider-slides-cat",
										"label" => __( 'Slides category', 'jaguar_domain_adm' ),
										"desc" => __( 'Choose which slides category items will populate the slider', 'jaguar_domain_adm' ),
										"options" => wm_tax_array( array(
												'allCountPost' => 'wm_slides',
												'allText'      => __( 'All slides', 'jaguar_domain_adm' ),
												'tax'          => 'wm-tax-cats-slides',
											) ),
										"default" => 0
									),
									array(
										"conditional" => array(
											"field" => $prefix."slider-content",
											"value" => "gallery"
											),
										"type" => "patterns",
										"id" => $prefix."slider-gallery-images",
										"label" => __( 'Choose slider images', 'jaguar_domain_adm' ),
										"desc" => __( 'Select which images will be displayed in the slider (you may need to save/publish/update the post to see the images)', 'jaguar_domain_adm' ),
										"options" => wm_get_post_images( -1, $postId ),
										"field" => "checkbox",
										"default" => ""
									),
							array(
								"conditional" => array(
									"field" => $prefix."slider-type",
									"value" => "roundabout,nivo,kwicks,simple"
									),
								"id" => $prefix."slider-settings-standard",
								"type" => "inside-wrapper-close"
							),

						array(
							"conditional" => array(
								"field" => $prefix."slider-type",
								"value" => "roundabout,nivo,kwicks,simple,custom"
								),
							"id" => $prefix."slider-settings-content",
							"type" => "inside-wrapper-close"
						),

						array(
							"conditional" => array(
								"field" => $prefix."slider-type",
								"value" => "kwicks,nivo,roundabout,static,video,simple"
								),
							"type" => "select",
							"id" => $prefix."slider-image",
							"label" => __( 'Slider image size', 'jaguar_domain_adm' ),
							"desc" => __( 'Choose which image size should be used in slider', 'jaguar_domain_adm' ),
							"options" => array(
								'slide' => __( 'Default slider images', 'jaguar_domain_adm' ),
								'full'   => __( 'Full size images', 'jaguar_domain_adm' )
								),
							"default" => "slide"
						),

				array(
					"conditional" => array(
						"field" => $prefix."slider-type",
						"value" => "roundabout,nivo,kwicks,static,video,simple,custom"
						),
					"id" => $prefix."slider-settings",
					"type" => "inside-wrapper-close"
				),
			array(
				"type" => "section-close"
			),



			//Gallery settings
			array(
				"type" => "section-open",
				"section-id" => "gallery-section",
				"title" => __( 'Gallery', 'jaguar_domain_adm' ),
				"exclude" => array( 'blog-page', 'pagetpl-contact.php', 'pagetpl-portfolio.php', 'pagetpl-sitemap.php', 'pagetpl-widgetized.php' )
			),
				array(
					"type" => "patterns",
					"id" => $prefix."gallery-images",
					"label" => __( 'Exclude gallery images', 'jaguar_domain_adm' ),
					"desc" => __( 'Exclude images from image gallery shortcode used in the page content', 'jaguar_domain_adm' ),
					"options" => wm_get_post_images( -1, $postId ),
					"field" => "checkbox",
					"default" => ""
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."gallery",
					"label" => __( 'Display excluded images below the page', 'jaguar_domain_adm' ),
					"desc" => __( 'Displays these excluded images in a new gallery below the page content', 'jaguar_domain_adm' ),
					"value" => "true"
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "slider",
					"id" => $prefix."gallery-columns",
					"label" => __( 'Gallery columns', 'jaguar_domain_adm' ),
					"desc" => __( 'Set the number of columns for the gallery below the page content', 'jaguar_domain_adm' ),
					"default" => 3,
					"min" => 3,
					"max" => 6,
					"step" => 1,
					"validate" => "absint"
				),
			array(
				"type" => "section-close"
			),



			//Sidebar settings
			array(
				"type" => "section-open",
				"section-id" => "sidebar-section",
				"title" => __( 'Sidebar', 'jaguar_domain_adm' ),
				"exclude" => array( 'pagetpl-sitemap.php', 'pagetpl-widgetized.php' )
			),
				array(
					"type" => "select",
					"id" => $prefix."sidebar",
					"label" => __( 'Choose a sidebar', 'jaguar_domain_adm' ),
					"desc" => __( 'Select a widget area used as a sidebar for this page (if not set, the dafault theme settings will apply)', 'jaguar_domain_adm' ),
					"options" => wm_widget_areas(),
					"default" => ""
				),
				array(
					"type" => "layouts",
					"id" => $prefix."layout",
					"label" => __( 'Sidebar position', 'jaguar_domain_adm' ),
					"desc" => __( 'Choose a sidebar position on the page (set the first one to use the theme default settings)', 'jaguar_domain_adm' ),
					"options" => $sidebarPosition,
					"default" => ""
				),
			array(
				"type" => "section-close"
			)

		);

		if ( wm_option( 'cta-enable' ) && wm_option( 'cta-enable-override' ) )
			array_push( $metaPageOptions,

				//Call to action settings
				array(
					"type" => "section-open",
					"section-id" => "cta-section",
					"title" => __( 'Callout', 'jaguar_domain_adm' ),
					"exclude" => array()
				),
					array(
						"type" => "textarea",
						"id" => $prefix."cta-text",
						"label" => __( 'Text', 'jaguar_domain_adm' ),
						"desc" => __( 'Callout text (required for callout to be displayed)', 'jaguar_domain_adm' ),
						"default" => "",
						"cols" => 57,
						"rows" => 5
					),
					array(
						"type" => "text",
						"id" => $prefix."cta-btn-text",
						"label" => __( 'Button text', 'jaguar_domain_adm' ),
						"desc" => __( 'Callout button text (required for button to be displayed)', 'jaguar_domain_adm' ),
						"default" => ""
					),
					array(
						"type" => "text",
						"id" => $prefix."cta-btn-url",
						"label" => __( 'Button link', 'jaguar_domain_adm' ),
						"desc" => __( 'Callout button URL link', 'jaguar_domain_adm' ),
						"default" => ""
					),
					array(
						"type" => "select",
						"id" => $prefix."cta-btn-type",
						"label" => __( 'Button color', 'jaguar_domain_adm' ),
						"desc" => __( 'Choose what type of button is displayed', 'jaguar_domain_adm' ),
						"options" => array(
							''            => __( 'Link color button (default)', 'jaguar_domain_adm' ),
							'type-gray'   => __( 'Gray button', 'jaguar_domain_adm' ),
							'type-green'  => __( 'Green button', 'jaguar_domain_adm' ),
							'type-blue'   => __( 'Blue button', 'jaguar_domain_adm' ),
							'type-orange' => __( 'Orange button', 'jaguar_domain_adm' ),
							'type-red'    => __( 'Red button', 'jaguar_domain_adm' ),
							),
						"default" => ""
					),
				array(
					"type" => "section-close"
				)

			);

		if ( 'boxed' === wm_option( 'layout-boxed' ) )
			array_push( $metaPageOptions,

				//Design - website background settings
				array(
					"type" => "section-open",
					"section-id" => "design",
					"title" => __( 'Design', 'jaguar_domain_adm' ),
					"exclude" => array()
				),
					array(
						"type" => "image",
						"id" => $prefixBg."bg-img-url",
						"label" => __( 'Custom background image', 'jaguar_domain_adm' ),
						"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_adm' ),
						"default" => "",
						"validate" => "url"
					),
					array(
						"type" => "select",
						"id" => $prefixBg."bg-img-position",
						"label" => __( 'Background image position', 'jaguar_domain_adm' ),
						"desc" => __( 'Set background image position', 'jaguar_domain_adm' ),
						"options" => array(
							'50% 50%'   => __( 'Center', 'jaguar_domain_adm' ),
							'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_adm' ),
							'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_adm' ),
							'0 0'       => __( 'Left, top', 'jaguar_domain_adm' ),
							'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_adm' ),
							'0 100%'    => __( 'Left, bottom', 'jaguar_domain_adm' ),
							'100% 0'    => __( 'Right, top', 'jaguar_domain_adm' ),
							'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_adm' ),
							'100% 100%' => __( 'Right, bottom', 'jaguar_domain_adm' ),
							),
						"default" => '50% 0'
					),
					array(
						"type" => "select",
						"id" => $prefixBg."bg-img-repeat",
						"label" => __( 'Background image repeat', 'jaguar_domain_adm' ),
						"desc" => __( 'Set background image repeating', 'jaguar_domain_adm' ),
						"options" => array(
							'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_adm' ),
							'repeat'    => __( 'Tile the image', 'jaguar_domain_adm' ),
							'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_adm' ),
							'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_adm' )
							),
						"default" => 'no-repeat'
					),
					array(
						"type" => "radio",
						"id" => $prefixBg."bg-img-attachment",
						"label" => __( 'Background image attachment', 'jaguar_domain_adm' ),
						"desc" => __( 'Set background image attachment', 'jaguar_domain_adm' ),
						"options" => array(
							'fixed'  => __( 'Fixed position', 'jaguar_domain_adm' ),
							'scroll' => __( 'Move on scrolling', 'jaguar_domain_adm' )
							),
						"default" => 'fixed'
					),
					array(
						"type" => "checkbox",
						"id" => $prefixBg."bg-img-fit-window",
						"label" => __( 'Fit browser window width', 'jaguar_domain_adm' ),
						"desc" => __( 'Makes the image to scale to browser window width. Note that background image position and repeat options does not apply when this is checked.', 'jaguar_domain_adm' ),
						"value" => "true"
					),
				array(
					"type" => "section-close"
				)

			);

		return $metaPageOptions;
	}
} // /wm_meta_page_options

?>