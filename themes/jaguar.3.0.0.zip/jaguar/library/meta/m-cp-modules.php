<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Content Module custom post meta boxes
*
* CONTENT:
* - 1) Meta box form
* - 2) Add meta box
*****************************************************
*/





/*
*****************************************************
*      1) META BOX FORM
*****************************************************
*/
	/**
	 * Meta box form fields
	 */
	if ( ! function_exists( 'wm_modules_meta_fields' ) ) {
		function wm_modules_meta_fields() {
			global $post;

			$prefix = 'module-';
			$postId = ( $post ) ? ( $post->ID ) : ( null );

			if ( ! $postId && isset( $_GET['post'] ) )
				$postId = absint( $_GET['post'] );

			if ( ! $postId )
				$postId = '{{{post_id}}}';

			$iconPack = ( wm_option( 'design-icon-pack' ) ) ? ( 'img/icons/custom/' . wm_option( 'design-icon-pack' ) . '/' ) : ( 'img/icons/custom/faenza/' );

			$metaFields = array(

				//General settings
				array(
					"type" => "section-open",
					"section-id" => "general",
					"title" => __( 'Module settings', 'jaguar_domain_adm' )
				),
					array(
						"type" => "text",
						"id" => $prefix."link",
						"label" => __( 'Custom link to more information on the topic', 'jaguar_domain_adm' ),
						"desc" => __( 'When left blank, no link will be applied', 'jaguar_domain_adm' ),
						"validate" => "url"
					),
					array(
						"type" => "select",
						"id" => $prefix."type",
						"label" => __( 'Content type', 'jaguar_domain_adm' ),
						"desc" => __( 'Select a type of content module styling', 'jaguar_domain_adm' ),
						"options" => array(
							'content' => __( 'Content module', 'jaguar_domain_adm' ),
							'icon'    => __( 'Icon module', 'jaguar_domain_adm' )
							),
						"default" => "content"
					),
					array(
						"conditional" => array(
							"field" => $prefix."type",
							"value" => "icon"
							),
						"type" => "patterns",
						"id" => $prefix."icon",
						"label" => __( 'Icon', 'jaguar_domain_adm' ),
						"desc" => __( 'Choose an icon to use with this Icon module. Featured image is prioritized and will be used as an icon when Content type is set to "Icon module".', 'jaguar_domain_adm' ) . '<br /><a class="button-primary thickbox button-set-featured-image js-post-id" href="' . get_admin_url() . 'media-upload.php?post_id=' . $postId . '&type=image&TB_iframe=1">' . __( 'Set custom icon', 'jaguar_domain_adm' ) . '</a>',
						"options" => wm_get_image_files( $iconPack ),
						"default" => "",
						"repeat" => "no"
					),
				array(
					"type" => "section-close"
				),

			);

			return $metaFields;
		}
	} // /wm_modules_meta_fields





/*
*****************************************************
*      2) ADD META BOX
*****************************************************
*/
	/*
	* Generate metabox
	*/
	if ( ! function_exists( 'wm_modules_generate_metabox' ) ) {
		function wm_modules_generate_metabox() {
			$wm_modules_META = new WM_Meta_Box( array(
				//where the meta box appear: normal (default), advanced, side
				'context'        => 'normal',
				//meta fields setup array
				'fields'         => wm_modules_meta_fields(),
				//meta box id, unique per meta box
				'id'             => 'wm-metabox-wm_modules-meta',
				//post types
				'pages'          => array( 'wm_modules' ),
				//order of meta box: high (default), low
				'priority'       => 'high',
				//tabbed meta box interface?
				'tabs'           => true,
				//meta box title
				'title'          => __( 'Module settings', 'jaguar_domain_adm' ),
				//wrap the meta form around visual editor?
				'visual-wrapper' => true,
			) );
		}
	} // /wm_modules_generate_metabox

	add_action( 'init', 'wm_modules_generate_metabox', 9999 ); //Has to be hooked to the end of init for taxonomies lists in metaboxes

?>