<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Clients custom post meta boxes
*
* CONTENT:
* - 1) Meta box form
* - 2) Add meta box
*****************************************************
*/





/*
*****************************************************
*      1) META BOX FORM
*****************************************************
*/
	/**
	 * Meta box form fields
	 */
	if ( ! function_exists( 'wm_clients_meta_fields' ) ) {
		function wm_clients_meta_fields() {
			global $post;

			$prefix = 'client-';
			$postId = ( $post ) ? ( $post->ID ) : ( null );

			if ( ! $postId && isset( $_GET['post'] ) )
				$postId = absint( $_GET['post'] );

			if ( ! $postId )
				$postId = '{{{post_id}}}';

			$metaFields = array(

				//General settings
				array(
					"type" => "section-open",
					"section-id" => "general",
					"title" => __( 'Client info', 'jaguar_domain_adm' )
				),
					array(
						"type" => "box",
						"content" => '<p>' . __( 'Use featured image area to upload the clients logo.', 'jaguar_domain_adm' ) . '</p><a class="button-primary thickbox button-set-featured-image js-post-id" href="' . get_admin_url() . 'media-upload.php?post_id=' . $postId . '&type=image&TB_iframe=1">' . __( 'Set featured image', 'jaguar_domain_adm' ) . '</a>'
					),
					array(
						"type" => "text",
						"id" => $prefix."link",
						"label" => __( "URL of the client's website", 'jaguar_domain_adm' ),
						"desc" => __( 'When left blank, no link will be applied', 'jaguar_domain_adm' ),
						"validate" => "url"
					),
						array(
							"type" => "select",
							"id" => $prefix."link-action",
							"label" => __( 'Link action', 'jaguar_domain_adm' ),
							"desc" => __( 'Set the custom link action', 'jaguar_domain_adm' ),
							"options" => array(
								'_blank' => __( 'Open in new window/tab', 'jaguar_domain_adm' ),
								'_self'  => __( 'Open in the same window', 'jaguar_domain_adm' ),
								),
						),
				array(
					"type" => "section-close"
				)

			);

			return $metaFields;
		}
	} // /wm_clients_meta_fields





/*
*****************************************************
*      2) ADD META BOX
*****************************************************
*/
	/*
	* Generate metabox
	*/
	if ( ! function_exists( 'wm_clients_generate_metabox' ) ) {
		function wm_clients_generate_metabox() {
			$wm_logos_META = new WM_Meta_Box( array(
				//where the meta box appear: normal (default), advanced, side
				'context'        => 'normal',
				//meta fields setup array
				'fields'         => wm_clients_meta_fields(),
				//meta box id, unique per meta box
				'id'             => 'wm-metabox-wm_clients-meta',
				//post types
				'pages'          => array( 'wm_clients' ),
				//order of meta box: high (default), low
				'priority'       => 'high',
				//tabbed meta box interface?
				'tabs'           => false,
				//meta box title
				'title'          => __( 'Logo info', 'jaguar_domain_adm' ),
			) );
		}
	} // /wm_clients_generate_metabox

	add_action( 'init', 'wm_clients_generate_metabox', 9999 ); //Has to be hooked to the end of init for taxonomies lists in metaboxes

?>