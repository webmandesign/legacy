<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Portfolio custom post meta boxes
*
* CONTENT:
* - 1) Meta box form
* - 2) Add meta box
*****************************************************
*/

/**
 * @version  2.9
 */





/*
*****************************************************
*      1) META BOX FORM
*****************************************************
*/
	/**
	 * Meta box form fields
	 */
	if ( ! function_exists( 'wm_portfolio_meta_fields' ) ) {
		function wm_portfolio_meta_fields() {
			global $post;

			$postId   = ( $post ) ? ( $post->ID ) : ( null );
			$prefix   = 'portfolio-';
			$prefixBg = 'background-';

			if ( ! $postId && isset( $_GET['post'] ) )
				$postId = absint( $_GET['post'] );

			$postIdJs = ( ! $postId ) ? ( '{{{post_id}}}' ) : ( $postId );

			// Clients list
			if ( 'disable' != wm_option( 'general-role-clients' ) ) {
				$clientsList         = get_posts( array(
					'numberposts' => -1,
					'orderby'     => 'title',
					'order'       => 'ASC',
					'post_type'   => 'wm_clients'
					) );
				$clientsListArray    = array();
				$clientsListArray[0] = __( '- Select client -', 'jaguar_domain_adm' );
				foreach ( $clientsList as $client ) {
					$clientsListArray[$client->ID] = $client->post_title;
				}
			}

			$metaFields = array(

				//General settings
				array(
					"type" => "section-open",
					"section-id" => "general",
					"title" => __( 'General', 'jaguar_domain_adm' )
				),
					array(
						"type" => "paragraph",
						"content" => __( 'Do not forget to set the featured image.', 'jaguar_domain_adm' )
					),
					array(
						"type" => "select",
						"id" => $prefix."type",
						"label" => __( 'Portfolio type', 'jaguar_domain_adm' ),
						"desc" => __( 'Select a type of portfolio item styling', 'jaguar_domain_adm' ),
						"options" => array(
							'image'  => __( 'Single image', 'jaguar_domain_adm' ),
							'slider' => __( 'Image slider', 'jaguar_domain_adm' ),
							'video'  => __( 'Video', 'jaguar_domain_adm' ),
							'audio'  => __( 'Audio', 'jaguar_domain_adm' )
							),
						"default" => "image"
					),
					array(
						"conditional" => array(
							"field" => $prefix."type",
							"value" => "video"
							),
						"type" => "text",
						"id" => $prefix."video",
						"label" => __( 'Video URL', 'jaguar_domain_adm' ),
						"desc" => __( 'Enter a video URL (check the <a href="http://codex.wordpress.org/Embeds#Can_I_Use_Any_URL_With_This.3F" target="_blank">list of supported video portals</a>) or you can also insert a <a href="http://codex.wordpress.org/Video_Shortcode" target="_blank">WordPress <code>&#91;video]</code> shortcode</a>', 'jaguar_domain_adm' ),
					),
					array(
						"conditional" => array(
							"field" => $prefix."type",
							"value" => "audio"
							),
						"type" => "text",
						"id" => $prefix."audio",
						"label" => __( 'Audio URL (or shortcode)', 'jaguar_domain_adm' ),
						"desc" => __( 'This field supports <strong>SoundCloud</strong> audio URL (as of <a href="http://codex.wordpress.org/Embeds#Okay.2C_So_What_Sites_Can_I_Embed_From.3F" target="_blank">WordPress Embeds formats</a>) or you can also insert a <a href="http://codex.wordpress.org/Audio_Shortcode" target="_blank">WordPress <code>&#91;audio]</code> shortcode</a>.<br />Featured image will be displayed above the audio player when using <code>[audio]</code> shortcode.', 'jaguar_domain_adm' ),
					),
					array(
						"conditional" => array(
							"field" => $prefix."type",
							"value" => "slider"
							),
						"type" => "slider",
						"id" => $prefix."slider-duration",
						"label" => __( 'Slide display time', 'jaguar_domain_adm' ),
						"desc" => __( 'Time of slide being displayed (in miliseconds)', 'jaguar_domain_adm' ),
						"default" => 5000,
						"min" => 1000,
						"max" => 15000,
						"step" => 250,
						"validate" => "absint"
					),
					array(
						"conditional" => array(
							"field" => $prefix."type",
							"value" => "slider"
							),
						"type" => "patterns",
						"id" => $prefix."slider-gallery-images",
						"label" => __( 'Choose slider images', 'jaguar_domain_adm' ),
						"desc" => __( 'Select which images from gallery will be displayed in the slider (you may need to save/publish/update the post first to enable images selection)', 'jaguar_domain_adm' ) . '<br /><a class="button-primary thickbox js-post-id" href="' . get_admin_url() . 'media-upload.php?post_id=' . $postIdJs . '&TB_iframe=1">' . __( 'Add images', 'jaguar_domain_adm' ) . '</a>',
						"options" => wm_get_post_images( -1, $postId ),
						"field" => "checkbox",
						"default" => ""
					),
					array(
						"conditional" => array(
							"field" => $prefix."type",
							"value" => "slider"
							),
						"type" => "checkbox",
						"id" => $prefix."slider-full-images",
						"label" => __( 'Do not crop images', 'jaguar_domain_adm' ),
						"desc" => __( 'Keeps aspect ratio of slider images', 'jaguar_domain_adm' )
					),
					array(
						"conditional" => array(
							"field" => $prefix."type",
							"value" => "image,slider"
							),
						"type" => "checkbox",
						"id" => $prefix."no-zoom",
						"label" => __( 'Remove image zooming', 'jaguar_domain_adm' ),
						"desc" => __( 'Disables PrettyPhoto zooming effect on images', 'jaguar_domain_adm' )
					),
					array(
						"type" => "space"
					),

					array(
						"type" => "text",
						"id" => $prefix."link",
						"label" => __( 'Project URL link', 'jaguar_domain_adm' ),
						"desc" => __( 'When left blank, no link will be displayed', 'jaguar_domain_adm' )
					),
					array(
						"type" => "checkbox",
						"id" => $prefix."link-list",
						"label" => __( 'Use the link in portfolio list', 'jaguar_domain_adm' ),
						"desc" => __( 'Apply the project URL link directly on the item in portfolio list', 'jaguar_domain_adm' )
					),
					array(
						"type" => "space"
					),
			);

		if ( 'disable' != wm_option( 'general-role-clients' ) )
			array_push( $metaFields,
					array(
						"type" => "select",
						"id" => $prefix."client",
						"label" => __( 'Client', 'jaguar_domain_adm' ),
						"desc" => __( 'Select a client from the list below', 'jaguar_domain_adm' ),
						"options" => $clientsListArray
					)
				);

		array_push( $metaFields,
					array(
						"type" => "additems",
						"id" => $prefix."attributes",
						"label" => __( 'Portfolio attributes', 'jaguar_domain_adm' ),
						"desc" => __( 'Press [+] button to add an attribute, then type in the attribute name and value', 'jaguar_domain_adm' ),
						"default" => "",
						"field" => "attributes"
					),
				array(
					"type" => "section-close"
				)

			);

			if ( 'boxed' === wm_option( 'layout-boxed' ) )
				array_push( $metaFields,
					//Design settings
					array(
						"type" => "section-open",
						"section-id" => "design",
						"title" => __( 'Design', 'jaguar_domain_adm' )
					),
						array(
							"type" => "image",
							"id" => $prefixBg."bg-img-url",
							"label" => __( 'Custom background image', 'jaguar_domain_adm' ),
							"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_adm' ),
							"default" => "",
							"validate" => "url"
						),
						array(
							"type" => "select",
							"id" => $prefixBg."bg-img-position",
							"label" => __( 'Background image position', 'jaguar_domain_adm' ),
							"desc" => __( 'Set background image position', 'jaguar_domain_adm' ),
							"options" => array(
								'50% 50%'   => __( 'Center', 'jaguar_domain_adm' ),
								'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_adm' ),
								'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_adm' ),
								'0 0'       => __( 'Left, top', 'jaguar_domain_adm' ),
								'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_adm' ),
								'0 100%'    => __( 'Left, bottom', 'jaguar_domain_adm' ),
								'100% 0'    => __( 'Right, top', 'jaguar_domain_adm' ),
								'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_adm' ),
								'100% 100%' => __( 'Right, bottom', 'jaguar_domain_adm' ),
								),
							"default" => '50% 0'
						),
						array(
							"type" => "select",
							"id" => $prefixBg."bg-img-repeat",
							"label" => __( 'Background image repeat', 'jaguar_domain_adm' ),
							"desc" => __( 'Set background image repeating', 'jaguar_domain_adm' ),
							"options" => array(
								'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_adm' ),
								'repeat'    => __( 'Tile the image', 'jaguar_domain_adm' ),
								'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_adm' ),
								'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_adm' )
								),
							"default" => 'no-repeat'
						),
						array(
							"type" => "radio",
							"id" => $prefixBg."bg-img-attachment",
							"label" => __( 'Background image attachment', 'jaguar_domain_adm' ),
							"desc" => __( 'Set background image attachment', 'jaguar_domain_adm' ),
							"options" => array(
								'fixed'  => __( 'Fixed position', 'jaguar_domain_adm' ),
								'scroll' => __( 'Move on scrolling', 'jaguar_domain_adm' )
								),
							"default" => 'fixed'
						),
						array(
							"type" => "checkbox",
							"id" => $prefixBg."bg-img-fit-window",
							"label" => __( 'Fit browser window width', 'jaguar_domain_adm' ),
							"desc" => __( 'Makes the image to scale to browser window width. Note that background image position and repeat options does not apply when this is checked.', 'jaguar_domain_adm' ),
							"value" => "true"
						),
					array(
						"type" => "section-close"
					)
				);

			array_push( $metaFields,

				//Gallery
				array(
					"type" => "section-open",
					"section-id" => "gallery-section",
					"title" => __( 'Gallery', 'jaguar_domain_adm' )
				),
					array(
						"type" => "checkbox",
						"id" => $prefix."enable-gallery",
						"label" => __( 'Gallery below portfolio item preview', 'jaguar_domain_adm' ),
						"desc" => __( 'Displays gallery from attached images below portfolio item preview', 'jaguar_domain_adm' )
					),
					array(
						"type" => "checkbox",
						"id" => $prefix."gallery-image",
						"label" => __( 'Keep image proportions', 'jaguar_domain_adm' ),
						"desc" => __( 'Images will not be cropped, original proportions are kept', 'jaguar_domain_adm' ),
						"value" => "true"
					),
					array(
						"type" => "space"
					),
					array(
						"type" => "slider",
						"id" => $prefix."gallery-columns",
						"label" => __( 'Gallery columns', 'jaguar_domain_adm' ),
						"desc" => __( 'Set the number of columns for the gallery', 'jaguar_domain_adm' ),
						"default" => 3,
						"min" => 3,
						"max" => 6,
						"step" => 1,
						"validate" => "absint"
					),
				array(
					"type" => "section-close"
				),



				//List image
				array(
					"type" => "section-open",
					"section-id" => "custom-image",
					"title" => __( 'List image', 'jaguar_domain_adm' )
				),
					array(
						"type" => "image",
						"id" => $prefix."list-image",
						"label" => __( 'Custom image displayed in portfolio list', 'jaguar_domain_adm' ),
						"desc" => __( 'This setting will override the featured image (note that featured image needs to be set). Leave blank to use featured image in portfolio list. To keep the list layout use square images of minimum 720 &times; 720 px, please.<br />To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post.', 'jaguar_domain_adm' ),
						"default" => "",
						"validate" => "url"
					),
				array(
					"type" => "section-close"
				),



				//Other settings
				array(
					"type" => "section-open",
					"section-id" => "others",
					"title" => __( 'Others', 'jaguar_domain_adm' )
				),
					array(
						"type" => "checkbox",
						"id" => "no-heading",
						"label" => __( 'Disable main heading', 'jaguar_domain_adm' ),
						"desc" => __( 'Hides main heading - the title', 'jaguar_domain_adm' ),
						"value" => "true"
					),
					array(
						"type" => "space"
					),
					array(
						"type" => "textarea",
						"id" => "subheading",
						"label" => __( 'Subtitle (tagline)', 'jaguar_domain_adm' ),
						"desc" => __( 'If defined, the specially styled subtitle will be displayed', 'jaguar_domain_adm' ),
						"default" => "",
						"rows" => 3
					),
				array(
					"type" => "section-close"
				)

			);

			return $metaFields;
		}
	} // /wm_portfolio_meta_fields





/*
*****************************************************
*      2) ADD META BOX
*****************************************************
*/
	/*
	* Generate metabox
	*/
	if ( ! function_exists( 'wm_portfolio_generate_metabox' ) ) {
		function wm_portfolio_generate_metabox() {
			$wm_projects_META = new WM_Meta_Box( array(
				//where the meta box appear: normal (default), advanced, side
				'context'        => 'normal',
				//meta fields setup array
				'fields'         => wm_portfolio_meta_fields(),
				//meta box id, unique per meta box
				'id'             => 'wm-metabox-wm_portfolio-meta',
				//post types
				'pages'          => array( 'wm_portfolio' ),
				//order of meta box: high (default), low
				'priority'       => 'high',
				//tabbed meta box interface?
				'tabs'           => true,
				//meta box title
				'title'          => __( 'Portfolio item settings', 'jaguar_domain_adm' ),
				//wrap the meta form around visual editor?
				'visual-wrapper' => true,
			) );
		}
	} // /wm_portfolio_generate_metabox

	add_action( 'init', 'wm_portfolio_generate_metabox', 9999 ); //Has to be hooked to the end of init for taxonomies lists in metaboxes

?>