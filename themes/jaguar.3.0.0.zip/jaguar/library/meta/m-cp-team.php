<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Team custom post meta boxes
*
* CONTENT:
* - 1) Meta box form
* - 2) Add meta box
*****************************************************
*/





/*
*****************************************************
*      1) META BOX FORM
*****************************************************
*/
	/**
	 * Meta box form fields
	 */
	if ( ! function_exists( 'wm_team_meta_fields' ) ) {
		function wm_team_meta_fields() {
			$prefix = 'team-';
			$metaFields = array(

				//Social networks connections settings
				array(
					"type" => "section-open",
					"section-id" => "general",
					"title" => __( 'Member information', 'jaguar_domain_adm' )
				),
					array(
						"type" => "textarea",
						"id" => $prefix."description",
						"label" => __( 'Bio', 'jaguar_domain_adm' ),
						"desc" => __( 'Short biography or description text', 'jaguar_domain_adm' ),
						"default" => "",
						"cols" => 80,
						"rows" => 4
					),

					array(
						"type" => "heading4",
						"content" => __( 'Social connections', 'jaguar_domain_adm' )
					),
					array(
						"type" => "text",
						"id" => $prefix."facebook",
						"label" => __( 'Facebook', 'jaguar_domain_adm' ),
						"desc" => __( 'Link to Facebook profile', 'jaguar_domain_adm' ),
						"validate" => "url"
					),
					array(
						"type" => "text",
						"id" => $prefix."google",
						"label" => __( 'Google+', 'jaguar_domain_adm' ),
						"desc" => __( 'Link to Google+ profile', 'jaguar_domain_adm' ),
						"validate" => "url"
					),
					array(
						"type" => "text",
						"id" => $prefix."twitter",
						"label" => __( 'Twitter', 'jaguar_domain_adm' ),
						"desc" => __( 'Link to Twitter profile', 'jaguar_domain_adm' ),
						"validate" => "url"
					),
					array(
						"type" => "text",
						"id" => $prefix."website",
						"label" => __( 'Website', 'jaguar_domain_adm' ),
						"desc" => __( "Link to team member's website", 'jaguar_domain_adm' ),
					),
				array(
					"type" => "section-close"
				)

			);

			return $metaFields;
		}
	} // /wm_team_meta_fields





/*
*****************************************************
*      2) ADD META BOX
*****************************************************
*/
	/*
	* Generate metabox
	*/
	if ( ! function_exists( 'wm_team_generate_metabox' ) ) {
		function wm_team_generate_metabox() {
			$wm_staff_META = new WM_Meta_Box( array(
				//where the meta box appear: normal (default), advanced, side
				'context'        => 'normal',
				//meta fields setup array
				'fields'         => wm_team_meta_fields(),
				//meta box id, unique per meta box
				'id'             => 'wm-metabox-wm_team-meta',
				//post types
				'pages'          => array( 'wm_team' ),
				//order of meta box: high (default), low
				'priority'       => 'high',
				//tabbed meta box interface?
				'tabs'           => false,
				//meta box title
				'title'          => __( 'Staff info', 'jaguar_domain_adm' ),
			) );
		}
	} // /wm_team_generate_metabox

	add_action( 'init', 'wm_team_generate_metabox', 9999 ); //Has to be hooked to the end of init for taxonomies lists in metaboxes

?>