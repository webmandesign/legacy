<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Layouts
*****************************************************
*/

//Website layout
$websiteLayout = array(

	array(
		'name' => __( 'Boxed layout', 'jaguar_domain_panel' ),
		'id'   => 'boxed',
		'desc' => __( 'Boxed - website sections will be contained in a centered box', 'jaguar_domain_panel' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-boxed.png'
	),

	array(
		'name' => __( 'Full width layout', 'jaguar_domain_panel' ),
		'id'   => 'fullwidth',
		'desc' => __( 'Full width - website sections will spread across the whole browser window width', 'jaguar_domain_panel' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-full-width.png'
	),

);



//Sidebar positions
$sidebarPosition = array(

	array(
		'name' => __( 'Default theme settings', 'jaguar_domain_adm' ),
		'id'   => '',
		'desc' => __( 'Use default theme position of the sidebar', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-default.png'
	),

	array(
		'name' => __( 'Sidebar right', 'jaguar_domain_adm' ),
		'id'   => 'right',
		'desc' => __( 'Sidebar is aligned right from the page/post content', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-sidebar-right.png'
	),

	array(
		'name' => __( 'Sidebar left', 'jaguar_domain_adm' ),
		'id'   => 'left',
		'desc' => __( 'Sidebar is aligned left from the page/post content', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-sidebar-left.png'
	),

	array(
		'name' => __( 'No sidebar, full width', 'jaguar_domain_adm' ),
		'id'   => 'none',
		'desc' => __( 'No sidebar is displayed, the page content takes the full width of the website', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-sidebar-none.png'
	)

);



//Portfolio layout
$portfolioLayout = array(

	array(
		'name' => __( 'Default theme settings', 'jaguar_domain_adm' ),
		'id'   => '',
		'desc' => __( 'Use default theme portfolio layout', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-default.png'
	),

	array(
		'name' => __( 'One column', 'jaguar_domain_adm' ),
		'id'   => 'columns-1',
		'desc' => __( 'Large preview and item description', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-1.png'
	),

	array(
		'name' => __( 'Two columns', 'jaguar_domain_adm' ),
		'id'   => 'columns-2',
		'desc' => __( 'Two columns preview with basic info', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-2.png'
	),

	array(
		'name' => __( 'Three columns', 'jaguar_domain_adm' ),
		'id'   => 'columns-3',
		'desc' => __( 'Three columns preview with basic info', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-3.png'
	),

	array(
		'name' => __( 'Four columns', 'jaguar_domain_adm' ),
		'id'   => 'columns-4',
		'desc' => __( 'Four columns preview with basic info', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-4.png'
	)

);



//Portfolio single layout
$portfolioSingleLayout = array(

	array(
		'name' => __( 'Portfolio preview left', 'jaguar_domain_adm' ),
		'id'   => 'left',
		'desc' => __( 'First portfolio preview, then portfolio description', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-single-left.png'
	),

	array(
		'name' => __( 'Portfolio preview right', 'jaguar_domain_adm' ),
		'id'   => 'right',
		'desc' => __( 'First portfolio description, then portfolio preview', 'jaguar_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-single-right.png'
	),

);

?>