<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - General section
*****************************************************
*/

/**
 * @since    1.0
 * @version  3.0
 */

$prefix = 'general-';

$intallationJustDone = get_option( WM_THEME_SETTINGS . '-installed' );

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "general",
	"title" => __( 'General', 'jaguar_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "general",
		"list" => array(
			__( 'Basics', 'jaguar_domain_panel' ),
			__( 'Custom posts', 'jaguar_domain_panel' ),
			__( 'Widget areas', 'jaguar_domain_panel' ),
			__( 'Tracking', 'jaguar_domain_panel' ),
			__( 'Export / import', 'jaguar_domain_panel' )
			)
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "general-1",
		"title" => __( 'Basics', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Footer credits', 'jaguar_domain_panel' ),
			"class" => "first"
		),
			array(
				"type" => "textarea",
				"id" => $prefix."credits",
				"label" => __( 'Credits (copyright) text', 'jaguar_domain_panel' ),
				"desc" => __( 'Copyright text at the bottom of the website. You can use (C) to display &copy; sign, (R) for &reg;, (TM) for &trade; or YEAR for dynamic year.', 'jaguar_domain_panel' ),
				"default" => '(C) '.get_bloginfo('name'),
				"cols" => 60,
				"rows" => 3,
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Comments', 'jaguar_domain_panel' )
		),
			array(
				"type" => "warning",
				"content" => __( 'Please note that these settings will affect pages/posts/projects you create from now on. If there are comments already active for the existing pages/posts/projects, you will need to disable them manually. This is default WordPress behavior.', 'jaguar_domain_panel' )
			),
			array(
				"type" => "box",
				"content" => '<p><strong>' . __( 'To disable comments manually for each already created page/post/project you have 2 options:', 'jaguar_domain_panel' ) . '</strong></p><ol><li>' . __( 'On page/posts/projects list table in WordPress admin select all the affected pages/posts/projects and choose "Edit" from "Bulk action" dropdown above the table, and press [Apply] button. Then just disable the comments option. This will disable the comments for already created pages/posts/projects in a batch.', 'jaguar_domain_panel' ) . '</li><li>' . __( 'On page/post/project edit screen make sure the "Discussion" metabox is enabled in "Screen Options" (in upper right corner of the screen). Then just uncheck the checkboxes in that metabox.', 'jaguar_domain_panel' ) . '</li></ol>'
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."page-comments",
				"label" => __( 'Disallow page comments', 'jaguar_domain_panel' ),
				"desc" => __( 'Disables page comments and pingbacks only (even if global comments are enabled)', 'jaguar_domain_panel' ),
				"default" => "true"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."post-comments",
				"label" => __( 'Disallow post comments', 'jaguar_domain_panel' ),
				"desc" => __( 'Disables post comments and pingbacks only (even if global comments are enabled)', 'jaguar_domain_panel' )
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Search field', 'jaguar_domain_panel' )
		),
			array(
				"type" => "text",
				"id" => $prefix."search-placeholder",
				"label" => __( 'Search placeholder text', 'jaguar_domain_panel' ),
				"desc" => __( 'Search input field placeholder text', 'jaguar_domain_panel' ),
				"default" => __( 'Search term', 'jaguar_domain' )
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Others', 'jaguar_domain_panel' )
		),
			array(
				"type" => "select",
				"id" => $prefix."lightbox-img",
				"label" => __( 'Zoomed image size', 'jaguar_domain_panel' ),
				"desc" => __( 'Choose what image size should be displayed when portfolio or blog featured image is zoomed', 'jaguar_domain_panel' ),
				"options" => array(
					'full' => __( 'Full original size of the image', 'jaguar_domain_panel' ),
					'large' => __( 'Large image (can be set in Settings > Media)', 'jaguar_domain_panel' ),
					),
				"default" => "page"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."no-lightbox",
				"label" => __( "Disable theme's lightbox", 'jaguar_domain_panel' ),
				"desc" => __( 'Disables PrettyPhoto lightbox image zooming effect for the whole website', 'jaguar_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."tipsy",
				"label" => __( 'Disable Tipsy tooltips', 'jaguar_domain_panel' ),
				"desc" => __( 'Disables jQuery Tipsy tooltips', 'jaguar_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."valid-html",
				"label" => __( 'Make valid HTML code', 'jaguar_domain_panel' ),
				"desc" => __( 'Removes recommended, but invalid (according to W3C validator) meta tags from HTML head (whole Dublin core and X-UA-Compatible will be removed)', 'jaguar_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."no-help",
				"label" => __( 'Disable theme contextual help', 'jaguar_domain_panel' ),
				"desc" => __( 'Removes theme help from WordPress contextual help', 'jaguar_domain_panel' )
			),
			/*
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."no-update-notifier",
				"label" => __( 'Disable theme update notifier', 'jaguar_domain_panel' ),
				"desc" => __( 'The theme is using update notifier script that checks for new theme update connecting to WebMan server. If you notice slow response of WordPress admin, please try to disable update notifier as it is possible that your server can not connect and obtain correct theme version which causes the slowdown.', 'jaguar_domain_panel' )
			),
			*/
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."default-admin-menu",
				"label" => __( 'Do not rearrange WordPress admin menu', 'jaguar_domain_panel' ),
				"desc" => __( 'Some plugins may add an item to WordPress admin menu. Check this for best compatibility with the plugins. ', 'jaguar_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."gzip",
				"label" => __( 'Enable basic GZIP compression', 'jaguar_domain_panel' ),
				"desc" => __( 'GZIP compression will speed up your website load time, so it is recommended to turn it on (except when you use a plugin to apply it). Before enabling GZIP compression, please make sure your webhost (web server) supports this compression algorithm and it is enabled (you may get error note if the compression is not supported on your server).', 'jaguar_domain_panel' )
			),
			array(
				"type" => "hrtop"
			),
	array(
		"type" => "sub-section-close"
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "general-2",
		"title" => __( 'Custom posts', 'jaguar_domain_panel' )
	),
		array(
			"type" => "box",
			"content" => '<h4>' . __( 'In this section you can enable/disable several different custom post types or set their privilegues and permalink slugs.', 'jaguar_domain_panel' ) . '</h4><p>' . __( 'When setting permalinks, please use URL address allowed characters only.', 'jaguar_domain_panel' ) . '</p>' . __( 'Clients, Content Modules, Slides and Team custom posts are being redirected to homepage when visited directly. There is no need to display them individually.', 'jaguar_domain_panel' )
		),

		array(
			"type" => "heading3",
			"content" => __( 'Clients', 'jaguar_domain_panel' )
		),
		array(
			"id" => $prefix."logos-role-container",
			"type" => "inside-wrapper-open",
			"class" => "toggle box"
		),
			array(
				"type" => "select",
				"id" => $prefix."role-"."clients",
				"label" => __( 'Clients custom post', 'jaguar_domain_panel' ),
				"desc" => __( 'Choose how clients should be treated', 'jaguar_domain_panel' ),
				"options" => array(
					'disable' => __( 'Disable', 'jaguar_domain_panel' ),
					'post'    => __( 'As post', 'jaguar_domain_panel' ),
					'page'    => __( 'As page', 'jaguar_domain_panel' ),
					),
				"default" => "page"
			),
			array(
				"type" => "text",
				"id" => $prefix."permalink-clients",
				"label" => __( '"client" permalink', 'jaguar_domain_panel' ),
				"desc" => __( 'Although Clients posts are being redirected to homepage, you might want to change this in case the permalink colides with some plugins', 'jaguar_domain_panel' ),
				"default" => "client"
			),
		array(
			"id" => $prefix."logos-role-container",
			"type" => "inside-wrapper-close"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Content Modules', 'jaguar_domain_panel' )
		),
		array(
			"id" => $prefix."modules-role-container",
			"type" => "inside-wrapper-open",
			"class" => "toggle box"
		),
			array(
				"type" => "select",
				"id" => $prefix."role-"."modules",
				"label" => __( 'Content Modules custom post', 'jaguar_domain_panel' ),
				"desc" => __( 'Choose how content modules should be treated', 'jaguar_domain_panel' ),
				"options" => array(
					'post' => __( 'As post', 'jaguar_domain_panel' ),
					'page' => __( 'As page', 'jaguar_domain_panel' ),
					),
				"default" => "page"
			),
			array(
				"type" => "text",
				"id" => $prefix."permalink-modules",
				"label" => __( '"module" permalink', 'jaguar_domain_panel' ),
				"desc" => __( 'Although Content Modules posts are being redirected to homepage, you might want to change this in case the permalink colides with some plugins', 'jaguar_domain_panel' ),
				"default" => "module"
			),
		array(
			"id" => $prefix."modules-role-container",
			"type" => "inside-wrapper-close"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Portfolio', 'jaguar_domain_panel' )
		),
		array(
			"id" => $prefix."projects-role-container",
			"type" => "inside-wrapper-open",
			"class" => "toggle box"
		),
			array(
				"type" => "select",
				"id" => $prefix."role-"."portfolio",
				"label" => __( 'Portfolio custom post', 'jaguar_domain_panel' ),
				"desc" => __( 'Choose how the portfolio post should be treated', 'jaguar_domain_panel' ),
				"options" => array(
					'post'    => __( 'As post', 'jaguar_domain_panel' ),
					'page'    => __( 'As page', 'jaguar_domain_panel' ),
					),
				"default" => "page"
			),
			array(
				"type" => "text",
				"id" => $prefix."permalink-portfolio",
				"label" => __( '"portfolio" permalink', 'jaguar_domain_panel' ),
				"desc" => __( 'Portfolio posts permalink base - you might need to change this for localization purposes', 'jaguar_domain_panel' ),
				"default" => "portfolio"
			),
			array(
				"type" => "text",
				"id" => $prefix."permalink-portfolio-category",
				"label" => __( 'Portfolio "category" permalink', 'jaguar_domain_panel' ),
				"desc" => __( 'Portfolio categories permalink base - you might need to change this for localization purposes', 'jaguar_domain_panel' ),
				"default" => "portfolio/category"
			),
		array(
			"id" => $prefix."projects-role-container",
			"type" => "inside-wrapper-close"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Slides', 'jaguar_domain_panel' )
		),
		array(
			"id" => $prefix."slides-role-container",
			"type" => "inside-wrapper-open",
			"class" => "toggle box"
		),
			array(
				"type" => "select",
				"id" => $prefix."role-"."slides",
				"label" => __( 'Slides custom post', 'jaguar_domain_panel' ),
				"desc" => __( 'Choose how slides should be treated', 'jaguar_domain_panel' ),
				"options" => array(
					'post' => __( 'As post', 'jaguar_domain_panel' ),
					'page' => __( 'As page', 'jaguar_domain_panel' ),
					),
				"default" => "page"
			),
			array(
				"type" => "text",
				"id" => $prefix."permalink-slides",
				"label" => __( '"slide" permalink', 'jaguar_domain_panel' ),
				"desc" => __( 'Although Slides posts are being redirected to homepage, you might want to change this in case the permalink colides with some plugins', 'jaguar_domain_panel' ),
				"default" => "slide"
			),
		array(
			"id" => $prefix."slides-role-container",
			"type" => "inside-wrapper-close"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Team', 'jaguar_domain_panel' )
		),
		array(
			"id" => $prefix."staff-role-container",
			"type" => "inside-wrapper-open",
			"class" => "toggle box"
		),
			array(
				"type" => "select",
				"id" => $prefix."role-"."team",
				"label" => __( 'Team custom post', 'jaguar_domain_panel' ),
				"desc" => __( 'Choose how team custom post should be treated', 'jaguar_domain_panel' ),
				"options" => array(
					'disable' => __( 'Disable', 'jaguar_domain_panel' ),
					'post'    => __( 'As post', 'jaguar_domain_panel' ),
					'page'    => __( 'As page', 'jaguar_domain_panel' ),
					),
				"default" => "page"
			),
			array(
				"type" => "text",
				"id" => $prefix."permalink-team",
				"label" => __( '"team-member" permalink', 'jaguar_domain_panel' ),
				"desc" => __( 'Although Team posts are being redirected to homepage, you might want to change this in case the permalink colides with some plugins', 'jaguar_domain_panel' ),
				"default" => "team-member"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."team-description",
				"label" => __( 'Display team description text', 'jaguar_domain_panel' ),
				"desc" => __( 'Displays team member description text below the photo instead of in the tooltip when hovering. ', 'jaguar_domain_panel' )
			),
		array(
			"id" => $prefix."staff-role-container",
			"type" => "inside-wrapper-close"
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "general-3",
		"title" => __( 'Widget areas', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Adding a custom widget areas', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "info",
			"content" => __( 'In addition to predefined widget areas you can create custom ones directly from this Admin Panel, without any coding knowledge or editing theme files. To create a new widget area use the generator below.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "additems",
			"id" => $prefix."sidebars",
			"label" => __( 'Create additional widget areas', 'jaguar_domain_panel' ),
			"desc" => __( 'Press [+] button and enter the name for new widget area. If the widget area of the same name already exists, it will not be created again. To remove a custom widget area press [X] button preceding its name in the list. Note that renaming previously created widget area changes its ID and all widgets assigned to it will be lost! Do not forget to save the changes.', 'jaguar_domain_panel' ),
			"default" => __( 'Custom widget area', 'jaguar_domain_adm' )
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "general-4",
		"title" => __( 'Tracking', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Tracking codes or custom <abbr title="JavaScript">JS</abbr> scripts', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "textarea",
			"id" => $prefix."custom-head",
			"label" => __( 'HTML head', 'jaguar_domain_panel' ),
			"desc" => __( 'Custom scripts in HTML head. Can be used for tracking code placement. Please include a SCRIPT tag too.', 'jaguar_domain_panel' ),
			"default" => "",
			"class" => "code"
		),
		array(
			"type" => "textarea",
			"id" => $prefix."custom-footer",
			"label" => __( 'Page footer', 'jaguar_domain_panel' ),
			"desc" => __( 'Custom scripts at the end of the website HTML code just before closing BODY tag. Can be used for tracking code placement. Please include a SCRIPT tag too.', 'jaguar_domain_panel' ),
			"default" => "",
			"class" => "code"
		),
		array(
			"type" => "select",
			"id" => $prefix."no-logged",
			"label" => __( 'Do not track logged in users', 'jaguar_domain_panel' ),
			"desc" => __( 'Removes the above scripts when user is logged in with certain minimum user role, thus preventing the tracking of logged-in users.', 'jaguar_domain_panel' ),
			"options" => array(
				''                       => __( 'Track everyone', 'jaguar_domain_panel' ),
				'read'                   => __( 'Subscribers (and above) - all logged in users', 'jaguar_domain_panel' ),
				'delete_posts'           => __( 'Contributors (and above)', 'jaguar_domain_panel' ),
				'delete_published_posts' => __( 'Authors (and above)', 'jaguar_domain_panel' ),
				'read_private_pages'     => __( 'Editors (and above)', 'jaguar_domain_panel' ),
				'edit_dashboard'         => __( 'Administrators', 'jaguar_domain_panel' ),
				),
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "general-5",
		"title" => __( 'Export / import', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Theme settings export / import', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "settingsExporter",
			"id" => "settingsExporter",
			"label-export" => __( 'Export', 'jaguar_domain_panel' ),
			"desc-export" => __( 'To export the current settings copy and keep (save to external file) the settings string below', 'jaguar_domain_panel' ),
			"label-import" => __( 'Import', 'jaguar_domain_panel' ),
			"desc-import" => __( 'To import previously saved settings, insert the settings string below. Note that by importing new settings you will loose all current ones. Always keep the backup of current settings.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

	//THIS IS JUST TO LOAD THE WP3.5+ MEDIA UPLOADER SCRIPTS CORRECTLY
		array(
			"type" => "textarea",
			"id" => $prefix."wp35-media-uploader-helper",
			"label" => 'helper',
			"default" => '',
			"class" => 'hide',
			"editor" => true
		),

array(
	"type" => "section-close"
)

);

?>