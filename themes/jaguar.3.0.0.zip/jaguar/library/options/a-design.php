<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Design section
*****************************************************
*/

$loginLogoFile = ( wm_check_wp_version( '3.2' ) ) ? ( "logo-login.png" ) : ( "logo-login.gif" );
$loginLogoFile = ( wm_check_wp_version( '3.4' ) ) ? ( "wordpress-logo.png" ) : ( $loginLogoFile );

$prefix = 'design-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "design",
	"title" => __( 'Design', 'jaguar_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "design",
		"list" => array(
			__( 'Design', 'jaguar_domain_panel' ),
			__( 'Branding', 'jaguar_domain_panel' ),
			__( 'Login', 'jaguar_domain_panel' ),
			__( 'Fonts', 'jaguar_domain_panel' ),
			__( 'CSS styles', 'jaguar_domain_panel' )
			)
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "design-1",
		"title" => __( 'Design', 'jaguar_domain_panel' )
	),
		array(
			"type" => "help",
			"topic" => __( 'Why my changes are not being applied?', 'jaguar_domain_panel' ),
			"content" => __( 'Please note, that CSS styles are being cached (the theme sets this to 14 days interval). If your changes are not being applied, clean the browser cache first and reload the website. Or you can put WordPress into debug mode when the cache interval decreases to 30 seconds.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Website main color skin', 'jaguar_domain_panel' )
		),

		array(
			"type" => "skins",
			"id" => $prefix."color-scheme",
			"label" => __( 'Website color skins', 'jaguar_domain_panel' ),
			"desc" => __( 'It is recommended to set a website color scheme first to be used as a base for your additional design changes. When color scheme is changed, save the settings (note that you will loose any color and font changes made as these will be set to color skin values; you will need to reapply these changes again).', 'jaguar_domain_panel' ),
			"options" => wm_color_schemes(),
			"default" => "default.css"
		),
		array(
			"type" => "info",
			"content" => ( ! wm_option( 'design-color-scheme' ) ) ? ( '<strong>' . wm_skin_meta( wm_option( 'default.css' ), 'color-scheme' ) . ' ' . __( 'color scheme description', 'jaguar_domain_panel' ) . ':</strong><br />' . wm_skin_meta( 'default.css', 'description' ) ) : ( '<strong>' . wm_skin_meta( wm_option( 'design-color-scheme' ), 'color-scheme' ) . ' ' . __( 'color scheme description', 'jaguar_domain_panel' ) . ':</strong><br />' . wm_skin_meta( wm_option( 'design-color-scheme' ), 'description' ) . '<br />&mdash; by ' . wm_skin_meta( wm_option( 'design-color-scheme' ), 'author' ) )
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Basic colors', 'jaguar_domain_panel' )
		),
		array(
			"type" => "color",
			"id" => $prefix."link-color",
			"label" => __( 'Link color', 'jaguar_domain_panel' ),
			"desc" => __( 'The main link color. Will be used also on various other elements, like default button color for example.', 'jaguar_domain_panel' ),
			"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'link-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'link-color' ) ),
			"validate" => "color"
		),
		array(
			"type" => "space"
		),
		array(
			"type" => "heading4",
			"content" => __( 'Light background text colors', 'jaguar_domain_panel' )
		),
			array(
				"type" => "color",
				"id" => $prefix."color-bglight",
				"label" => __( 'Text color on light background', 'jaguar_domain_panel' ),
				"desc" => __( 'Default text color on light backgrounds', 'jaguar_domain_panel' ),
				"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'color-bglight' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'color-bglight' ) ),
				"validate" => "color"
			),
			array(
				"type" => "color",
				"id" => $prefix."color-bglight-headings",
				"label" => __( 'Headings color on light background', 'jaguar_domain_panel' ),
				"desc" => __( 'Default headings color on light backgrounds', 'jaguar_domain_panel' ),
				"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'color-bglight-headings' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'color-bglight-headings' ) ),
				"validate" => "color"
			),
		array(
			"type" => "space"
		),
		array(
			"type" => "heading4",
			"content" => __( 'Dark background text colors', 'jaguar_domain_panel' )
		),
			array(
				"type" => "color",
				"id" => $prefix."color-bgdark",
				"label" => __( 'Text color on dark background', 'jaguar_domain_panel' ),
				"desc" => __( 'Default text color on dark backgrounds', 'jaguar_domain_panel' ),
				"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'color-bgdark' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'color-bgdark' ) ),
				"validate" => "color"
			),
			array(
				"type" => "color",
				"id" => $prefix."color-bgdark-headings",
				"label" => __( 'Headings color on dark background', 'jaguar_domain_panel' ),
				"desc" => __( 'Default headings color on dark backgrounds', 'jaguar_domain_panel' ),
				"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'color-bgdark-headings' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'color-bgdark-headings' ) ),
				"validate" => "color"
			),
		array(
			"type" => "space"
		),
		array(
			"type" => "heading4",
			"content" => __( 'Automatic text color tweaking', 'jaguar_domain_panel' )
		),
		array(
			"type" => "slider",
			"id" => $prefix."color-treshold",
			"label" => __( 'Background color brightness treshold', 'jaguar_domain_panel' ),
			"desc" => __( 'Color brightness value when to switch between text colors (set above) depending on the background color brightness', 'jaguar_domain_panel' ),
			"default" => WM_COLOR_TRESHOLD,
			"min" => 1,
			"max" => 250,
			"step" => 1,
			"validate" => "absint"
		),
		array(
			"type" => "space"
		),
		array(
			"type" => "heading4",
			"content" => __( 'Elements colors', 'jaguar_domain_panel' )
		),

		//basic colors:
			array(
				"type" => "heading4",
				"content" => __( 'Define gray color', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-gray"
			),
			array(
				"id" => $prefix."set-gray",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."type-gray-bg-color",
					"label" => __( 'General gray color', 'jaguar_domain_panel' ),
					"desc" => __( 'Gray color used on special elements like buttons, message boxes, markers', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-gray-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-gray-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."type-gray-color",
					"label" => __( 'Text on gray color', 'jaguar_domain_panel' ),
					"desc" => __( 'Text color on gray background (will be set automatically if left blank)', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-gray-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-gray-color' ) ),
					"validate" => "color"
				),
			array(
				"id" => $prefix."set-gray",
				"type" => "inside-wrapper-close"
			),

			array(
				"type" => "heading4",
				"content" => __( 'Define green color', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-green"
			),
			array(
				"id" => $prefix."set-green",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."type-green-bg-color",
					"label" => __( 'General green color', 'jaguar_domain_panel' ),
					"desc" => __( 'Green color used on special elements like buttons, message boxes, markers', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-green-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-green-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."type-green-color",
					"label" => __( 'Text on green color', 'jaguar_domain_panel' ),
					"desc" => __( 'Text color on green background (will be set automatically if left blank)', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-green-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-green-color' ) ),
					"validate" => "color"
				),
			array(
				"id" => $prefix."set-green",
				"type" => "inside-wrapper-close"
			),

			array(
				"type" => "heading4",
				"content" => __( 'Define blue color', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-blue"
			),
			array(
				"id" => $prefix."set-blue",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."type-blue-bg-color",
					"label" => __( 'General blue color', 'jaguar_domain_panel' ),
					"desc" => __( 'Blue color used on special elements like buttons, message boxes, markers', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-blue-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-blue-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."type-blue-color",
					"label" => __( 'Text on blue color', 'jaguar_domain_panel' ),
					"desc" => __( 'Text color on blue background (will be set automatically if left blank)', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-blue-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-blue-color' ) ),
					"validate" => "color"
				),
			array(
				"id" => $prefix."set-blue",
				"type" => "inside-wrapper-close"
			),

			array(
				"type" => "heading4",
				"content" => __( 'Define orange color', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-orange"
			),
			array(
				"id" => $prefix."set-orange",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."type-orange-bg-color",
					"label" => __( 'General orange color', 'jaguar_domain_panel' ),
					"desc" => __( 'Orange color used on special elements like buttons, message boxes, markers', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-orange-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-orange-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."type-orange-color",
					"label" => __( 'Text on orange color', 'jaguar_domain_panel' ),
					"desc" => __( 'Text color on orange background (will be set automatically if left blank)', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-orange-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-orange-color' ) ),
					"validate" => "color"
				),
			array(
				"id" => $prefix."set-orange",
				"type" => "inside-wrapper-close"
			),

			array(
				"type" => "heading4",
				"content" => __( 'Define red color', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-red"
			),
			array(
				"id" => $prefix."set-red",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."type-red-bg-color",
					"label" => __( 'General red color', 'jaguar_domain_panel' ),
					"desc" => __( 'Red color used on special elements like buttons, message boxes, markers', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-red-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-red-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."type-red-color",
					"label" => __( 'Text on red color', 'jaguar_domain_panel' ),
					"desc" => __( 'Text color on red background (will be set automatically if left blank)', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'type-red-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'type-red-color' ) ),
					"validate" => "color"
				),
			array(
				"id" => $prefix."set-red",
				"type" => "inside-wrapper-close"
			),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Icons', 'jaguar_domain_panel' )
		),
		array(
			"type" => "select",
			"id" => $prefix."icon-scheme",
			"label" => __( 'Main website icons scheme', 'jaguar_domain_panel' ),
			"desc" => __( 'Depends on the color scheme used and background color set, you can choose between light and dark icon scheme (will affect message box and post formats icons)', 'jaguar_domain_panel' ),
			"options" => array(
				'light' => __( 'Light icon scheme', 'jaguar_domain_panel' ),
				'dark'  => __( 'Dark icon scheme', 'jaguar_domain_panel' ),
				),
			"default" => "dark"
		),
		array(
			"type" => "select",
			"id" => $prefix."icon-pack",
			"label" => __( 'Custom icons packs', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose preferred icons pack to use with icon modules (the theme contains just a selection of icons from each pack)', 'jaguar_domain_panel' ),
			"options" => array(
				'darkglass'   => __( 'DarkGlass icons pack', 'jaguar_domain_panel' ),
				'defaulticon' => __( 'DefaultIcon icons pack', 'jaguar_domain_panel' ),
				'faenza'      => __( 'Faenza icons pack', 'jaguar_domain_panel' ),
				'hydroxygen'  => __( 'HydroxyGen icons pack', 'jaguar_domain_panel' ),
				'nuovext'     => __( 'NuoveXT icons pack', 'jaguar_domain_panel' ),
				'tango'       => __( 'Tango icons pack', 'jaguar_domain_panel' ),
				'woofunction' => __( 'WooFunction icons pack', 'jaguar_domain_panel' )
				),
			"default" => "faenza"
		),
		array(
			"type" => "hr"
		),


		//backgrounds:

			//BODY background
			array(
				"type" => "heading3",
				"content" => __( 'HTML container background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-body"
			),
			array(
				"id" => $prefix."body-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "paragraph",
					"content" => __( 'This works only with boxed website layout. For full width layout set just Website container background.', 'jaguar_domain_panel' )
				),
				array(
					"type" => "color",
					"id" => $prefix."body-bg-color",
					"label" => __( 'HTML container background color', 'jaguar_domain_panel' ),
					"desc" => "",
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'body-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'body-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "image",
					"id" => $prefix."body-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."body-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."body-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."body-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."body-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."body-bg-container",
				"type" => "inside-wrapper-close"
			),



			//website container background
			array(
				"type" => "heading3",
				"content" => __( 'Website container background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-wrap"
			),
			array(
				"id" => $prefix."wrap-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "paragraph",
					"content" => __( 'When boxed layout used, this is the box background. Otherwise the background spreads full width of the browser window.', 'jaguar_domain_panel' )
				),
				array(
					"type" => "color",
					"id" => $prefix."wrap-bg-color",
					"label" => __( 'Website background color', 'jaguar_domain_panel' ),
					"desc" => __( 'For automatic text color try to match this background color to dominant color on applied background image', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'wrap-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'wrap-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."wrap-color",
					"label" => __( 'Website text color', 'jaguar_domain_panel' ),
					"desc" => __( 'Set this only if you need to override the automatic text color', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "color"
				),
				array(
					"type" => "slider",
					"id" => $prefix."wrap-shadow",
					"label" => __( 'Website container shadow transparency', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the transparency of website container shadow in % (100% = opaque, 0% = fully transparent / no border)', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( absint( wm_skin_meta( 'default.css', 'wrap-shadow' ) ) ) : ( absint( wm_skin_meta( wm_option( 'design-color-scheme' ), 'wrap-shadow' ) ) ),
					"min" => 0,
					"max" => 100,
					"step" => 1,
					"validate" => "absint",
					"zero" => true
				),
				array(
					"type" => "image",
					"id" => $prefix."wrap-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."wrap-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."wrap-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."wrap-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."wrap-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."wrap-bg-container",
				"type" => "inside-wrapper-close"
			),



			//header background
			array(
				"type" => "heading3",
				"content" => __( 'Header background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-header"
			),
			array(
				"id" => $prefix."header-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."header-bg-color",
					"label" => __( 'Website header background color', 'jaguar_domain_panel' ),
					"desc" => __( 'For automatic text color try to match this background color to dominant color on applied background image', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'header-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'header-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."header-color",
					"label" => __( 'Website header text color', 'jaguar_domain_panel' ),
					"desc" => __( 'Set this only if you need to override the automatic text color', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "color"
				),
				array(
					"type" => "image",
					"id" => $prefix."header-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."header-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."header-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."header-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."header-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."header-bg-container",
				"type" => "inside-wrapper-close"
			),



			//slider background
			array(
				"type" => "heading3",
				"content" => __( 'Slider background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-slider"
			),
			array(
				"id" => $prefix."slider-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."slider-bg-color",
					"label" => __( 'Slider container background color', 'jaguar_domain_panel' ),
					"desc" => "",
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'slider-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'slider-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "image",
					"id" => $prefix."slider-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."slider-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."slider-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."slider-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."slider-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."slider-bg-container",
				"type" => "inside-wrapper-close"
			),



			//call to action background
			array(
				"type" => "heading3",
				"content" => __( 'Callout background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-cta"
			),
			array(
				"id" => $prefix."cta-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."cta-bg-color",
					"label" => __( 'Callout background color', 'jaguar_domain_panel' ),
					"desc" => __( 'For automatic text color try to match this background color to dominant color on applied background image', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'cta-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'cta-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."cta-color",
					"label" => __( 'Callout text color', 'jaguar_domain_panel' ),
					"desc" => __( 'Set this only if you need to override the automatic text color', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "color"
				),
				array(
					"type" => "image",
					"id" => $prefix."cta-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."cta-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."cta-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."cta-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."cta-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."cta-bg-container",
				"type" => "inside-wrapper-close"
			),



			//main heading background
			array(
				"type" => "heading3",
				"content" => __( 'Main heading background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-main-heading"
			),
			array(
				"id" => $prefix."main-heading-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "paragraph",
					"content" => __( 'These styles will be applied also on widget titles.', 'jaguar_domain_panel' )
				),
				array(
					"type" => "color",
					"id" => $prefix."main-heading-bg-color",
					"label" => __( 'Main heading background color', 'jaguar_domain_panel' ),
					"desc" => __( 'For automatic text color try to match this background color to dominant color on applied background image', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'main-heading-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'main-heading-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."main-heading-color",
					"label" => __( 'Main heading text color', 'jaguar_domain_panel' ),
					"desc" => __( 'Set this only if you need to override the automatic text color', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "color"
				),
				array(
					"type" => "image",
					"id" => $prefix."main-heading-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."main-heading-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."main-heading-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."main-heading-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."main-heading-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."main-heading-bg-container",
				"type" => "inside-wrapper-close"
			),



			//clients background
			array(
				"type" => "heading3",
				"content" => __( 'Clients section background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-clients"
			),
			array(
				"id" => $prefix."clients-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."clients-bg-color",
					"label" => __( 'Clients / partners section background color', 'jaguar_domain_panel' ),
					"desc" => "",
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'clients-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'clients-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "image",
					"id" => $prefix."clients-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."clients-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."clients-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."clients-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."clients-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."clients-bg-container",
				"type" => "inside-wrapper-close"
			),



			//footer background
			array(
				"type" => "heading3",
				"content" => __( 'Footer background', 'jaguar_domain_panel' ),
				"id" => "heading-to-set-footer"
			),
			array(
				"id" => $prefix."footer-bg-container",
				"type" => "inside-wrapper-open",
				"class" => "toggle"
			),
				array(
					"type" => "color",
					"id" => $prefix."footer-bg-color",
					"label" => __( 'Website footer background color', 'jaguar_domain_panel' ),
					"desc" => __( 'For automatic text color try to match this background color to dominant color on applied background image', 'jaguar_domain_panel' ),
					"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'footer-bg-color' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'footer-bg-color' ) ),
					"validate" => "color"
				),
				array(
					"type" => "color",
					"id" => $prefix."footer-color",
					"label" => __( 'Website footer text color', 'jaguar_domain_panel' ),
					"desc" => __( 'Set this only if you need to override the automatic text color', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "color"
				),
				array(
					"type" => "image",
					"id" => $prefix."footer-bg-img-url",
					"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
					"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
					"default" => "",
					"validate" => "url"
				),
				array(
					"type" => "select",
					"id" => $prefix."footer-bg-img-position",
					"label" => __( 'Background image position', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
					"options" => array(
						'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
						'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
						'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
						'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
						'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
						'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
						'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
						'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
						'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
						),
					"default" => '50% 0'
				),
				array(
					"type" => "select",
					"id" => $prefix."footer-bg-img-repeat",
					"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
					"options" => array(
						'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
						'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
						'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
						'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
						),
					"default" => 'no-repeat'
				),
				array(
					"type" => "radio",
					"id" => $prefix."footer-bg-img-attachment",
					"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
					"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
					"options" => array(
						'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
						'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
						),
					"default" => 'scroll'
				),
				array(
					"type" => "patterns",
					"id" => $prefix."footer-bg-pattern",
					"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
					"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
					"options" => wm_get_image_files(),
					"default" => "",
					"class" => " toggle-patterns",
					"preview" => true
				),
				array(
					"type" => "hrtop"
				),
			array(
				"id" => $prefix."footer-bg-container",
				"type" => "inside-wrapper-close"
			),

		array(
			"type" => "sub-section-close"
		),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "design-2",
		"title" => __( 'Branding', 'jaguar_domain_panel' )
	),
		array(
			"type" => "help",
			"topic" => __( 'Why my changes are not being applied?', 'jaguar_domain_panel' ),
			"content" => __( 'Please note, that CSS styles are being cached (the theme sets this to 14 days interval). If your changes are not being applied, clean the browser cache first and reload the website. Or you can put WordPress into debug mode when the cache interval decreases to 30 seconds.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Website logo, favicon and touch icon', 'jaguar_domain_panel' )
		),
		array(
			"type" => "radio",
			"id" => $prefix."logo-type",
			"label" => __( 'Logo type', 'jaguar_domain_panel' ),
			"desc" => __( 'You can use image or text logo.', 'jaguar_domain_panel' ),
			"options" => array(
				'img'  => __( 'Use image logo', 'jaguar_domain_panel' ),
				'text' => __( 'Use website title from WordPress Settings', 'jaguar_domain_panel' ).' ("'.get_bloginfo('title').'")'
				),
			"default" => "img"
		),
		array(
			"type" => "slider",
			"id" => $prefix."logo-margin",
			"label" => __( 'Logo margin', 'jaguar_domain_panel' ),
			"desc" => __( 'Set the top and bottom logo margin size ("-1" sets the default logo margin)', 'jaguar_domain_panel' ),
			"default" => -1,
			"min" => -1,
			"max" => 100,
			"step" => 1,
			"validate" => "int",
			"zero" => true
		),
		array(
			"type" => "image",
			"id" => $prefix."logo-img-url",
			"label" => __( 'Custom logo image URL address', 'jaguar_domain_panel' ),
			"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
			"default" => "",
			"validate" => "url"
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "image",
			"id" => $prefix."favicon-url",
			"label" => __( 'Custom favicon (16x16, .ico format) URL address', 'jaguar_domain_panel' ),
			"desc" => __( 'Favicon will be displayed as bookmark icon or on browser tab or in browser address line', 'jaguar_domain_panel' ),
			"default" => "",
			"validate" => "url"
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "image",
			"id" => $prefix."touch-icon-url",
			"label" => __( 'Custom touch icon URL address', 'jaguar_domain_panel' ),
			"desc" => __( 'Touch icon will be displayed on smartphones or in Speed Dial of Opera browser', 'jaguar_domain_panel' ),
			"default" => "",
			"validate" => "url"
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'WordPress admin area customization', 'jaguar_domain_panel' )
		),
		array(
			"type" => "image",
			"id" => $prefix."admin-logo",
			"label" => __( 'Admin page logo', 'jaguar_domain_panel' ),
			"desc" => __( 'Maximum size is 20px &times; 20px. For WordPress older than version 3.3 the maximum image size is 16px &times; 16px', 'jaguar_domain_panel' ),
			"default" => "",
			"validate" => "url"
		),
		array(
			"type" => "textarea",
			"id" => $prefix."admin-footer",
			"label" => __( 'Admin custom footer text', 'jaguar_domain_panel' ),
			"desc" => __( 'Text (you can use inline HTML tags) will be inserted into Paragraph HTML tag of WordPress admin footer', 'jaguar_domain_panel' ),
			"default" => ""
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Theme admin panel branding', 'jaguar_domain_panel' )
		),
		array(
			"type" => "image",
			"id" => $prefix."panel-logo",
			"label" => __( 'Admin panel logo', 'jaguar_domain_panel' ),
			"desc" => __( 'Sets the logo displayed above admin panel main navigation', 'jaguar_domain_panel' ),
			"default" => "",
			"validate" => "url"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."panel-no-logo",
			"label" => __( 'Remove logo from admin panel', 'jaguar_domain_panel' ),
			"desc" => __( 'No logo will be displayed in theme admin panel', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "design-3",
		"title" => __( 'Login', 'jaguar_domain_panel' )
	),
		array(
			"type" => "help",
			"topic" => __( 'Why my changes are not being applied?', 'jaguar_domain_panel' ),
			"content" => __( 'Please note, that CSS styles are being cached (the theme sets this to 14 days interval). If your changes are not being applied, clean the browser cache first and reload the website. Or you can put WordPress into debug mode when the cache interval decreases to 30 seconds.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Login page customization', 'jaguar_domain_panel' )
		),
		array(
			"type" => "image",
			"id" => $prefix."login-logo",
			"label" => __( 'Login logo', 'jaguar_domain_panel' ),
			"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
			"default" => site_url() . "/wp-admin/images/" . $loginLogoFile,
			"validate" => "url"
		),
		array(
			"type" => "slider",
			"id" => $prefix."login-logo-height",
			"label" => __( 'Logo container height', 'jaguar_domain_panel' ),
			"desc" => __( 'Set the hight of login logo container in pixels', 'jaguar_domain_panel' ),
			"default" => 100,
			"min" => 60,
			"max" => 300,
			"step" => 5,
			"validate" => "absint"
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "heading4",
			"content" => __( 'Login page background', 'jaguar_domain_panel' )
		),
			array(
				"type" => "color",
				"id" => $prefix."login-bg-color",
				"label" => __( 'Page background color', 'jaguar_domain_panel' ),
				"desc" => "",
				"default" => "",
				"validate" => "color"
			),
			array(
				"type" => "image",
				"id" => $prefix."login-bg-img-url",
				"label" => __( 'Custom background image', 'jaguar_domain_panel' ),
				"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jaguar_domain_panel' ),
				"default" => "",
				"validate" => "url"
			),
			array(
				"type" => "select",
				"id" => $prefix."login-bg-img-position",
				"label" => __( 'Background image position', 'jaguar_domain_panel' ),
				"desc" => __( 'Set the background image position', 'jaguar_domain_panel' ),
				"options" => array(
					'50% 50%'   => __( 'Center', 'jaguar_domain_panel' ),
					'50% 0'     => __( 'Center horizontally, top', 'jaguar_domain_panel' ),
					'50% 100%'  => __( 'Center horizontally, bottom', 'jaguar_domain_panel' ),
					'0 0'       => __( 'Left, top', 'jaguar_domain_panel' ),
					'0 50%'     => __( 'Left, center vertically', 'jaguar_domain_panel' ),
					'0 100%'    => __( 'Left, bottom', 'jaguar_domain_panel' ),
					'100% 0'    => __( 'Right, top', 'jaguar_domain_panel' ),
					'100% 50%'  => __( 'Right, center vertically', 'jaguar_domain_panel' ),
					'100% 100%' => __( 'Right, bottom', 'jaguar_domain_panel' ),
					),
				"default" => '50% 0'
			),
			array(
				"type" => "select",
				"id" => $prefix."login-bg-img-repeat",
				"label" => __( 'Background image repeat', 'jaguar_domain_panel' ),
				"desc" => __( 'Set the background image repeating', 'jaguar_domain_panel' ),
				"options" => array(
					'no-repeat' => __( 'Do not repeat the image', 'jaguar_domain_panel' ),
					'repeat'    => __( 'Repeat the image', 'jaguar_domain_panel' ),
					'repeat-x'  => __( 'Tile horizontally', 'jaguar_domain_panel' ),
					'repeat-y'  => __( 'Tile vertically', 'jaguar_domain_panel' )
					),
				"default" => 'no-repeat'
			),
			array(
				"type" => "radio",
				"id" => $prefix."login-bg-img-attachment",
				"label" => __( 'Background image attachment', 'jaguar_domain_panel' ),
				"desc" => __( 'Set the background image attachment', 'jaguar_domain_panel' ),
				"options" => array(
					'scroll' => __( 'Move on scrolling', 'jaguar_domain_panel' ),
					'fixed'  => __( 'Fixed position', 'jaguar_domain_panel' )
					),
				"default" => 'scroll'
			),
			array(
				"type" => "patterns",
				"id" => $prefix."login-bg-pattern",
				"label" => __( 'Or: set background pattern', 'jaguar_domain_panel' ),
				"desc" => __( 'Patterns are prioritized over background image. For transparent patterns you can also set the background color.', 'jaguar_domain_panel' ),
				"options" => wm_get_image_files(),
				"default" => "",
				"class" => " toggle-patterns"
				),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading4",
			"content" => __( 'Form settings', 'jaguar_domain_panel' )
		),
			array(
				"type" => "color",
				"id" => $prefix."login-form-bg-color",
				"label" => __( 'Form background color', 'jaguar_domain_panel' ),
				"desc" => __( 'Label color will be set automatically', 'jaguar_domain_panel' ),
				"default" => "",
				"validate" => "color"
			),
			array(
				"type" => "color",
				"id" => $prefix."login-form-button-bg-color",
				"label" => __( 'Submit button color', 'jaguar_domain_panel' ),
				"desc" => __( 'Button text color will be set automatically', 'jaguar_domain_panel' ),
				"default" => "",
				"validate" => "color"
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading4",
			"content" => __( 'Links below login form settings', 'jaguar_domain_panel' )
		),
			array(
				"type" => "color",
				"id" => $prefix."login-link-color",
				"label" => __( 'Link text color', 'jaguar_domain_panel' ),
				"desc" => "",
				"default" => "",
				"validate" => "color"
			),
			array(
				"type" => "color",
				"id" => $prefix."login-link-bg-color",
				"label" => __( 'Link background color', 'jaguar_domain_panel' ),
				"desc" => "",
				"default" => "",
				"validate" => "color"
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading4",
			"content" => __( 'Messages settings', 'jaguar_domain_panel' )
		),
			array(
				"type" => "color",
				"id" => $prefix."login-message-bg-color",
				"label" => __( 'Messages background color', 'jaguar_domain_panel' ),
				"desc" => __( 'Message text color will be set automatically', 'jaguar_domain_panel' ),
				"default" => "",
				"validate" => "color"
			),
			array(
				"type" => "hrtop"
			),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "design-4",
		"title" => __( 'Fonts', 'jaguar_domain_panel' )
	),
		array(
			"type" => "help",
			"topic" => __( 'Why my changes are not being applied?', 'jaguar_domain_panel' ),
			"content" => __( 'Please note, that CSS styles are being cached (the theme sets this to 14 days interval). If your changes are not being applied, clean the browser cache first and reload the website. Or you can put WordPress into debug mode when the cache interval decreases to 30 seconds.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Font families', 'jaguar_domain_panel' )
		),
			array(
				"type" => "textarea",
				"id" => $prefix."font-custom",
				"label" => __( 'Custom font stylesheet link (HTML)', 'jaguar_domain_panel' ),
				"desc" => __( 'Use embedding LINK tag for custom font (obtained from <a href="http://www.google.com/webfonts" target="_blank">Google Web Fonts</a>, for example)', 'jaguar_domain_panel' ),
				"default" => ( wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'font-custom' ) ) : ( null ),
				"cols" => 70,
				"rows" => 8,
				"class" => "code"
			),
			array(
				"type" => "text",
				"id" => $prefix."font-primary",
				"label" => __( 'Primary font stack', 'jaguar_domain_panel' ),
				"desc" => __( 'Enter font names hierarchically separated by commas. Provide also the most basic fallback ("sans-serif" or "serif").', 'jaguar_domain_panel' ),
				"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'font-primary' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'font-primary' ) ),
				"size" => "",
				"maxlength" => ""
			),
			array(
				"type" => "text",
				"id" => $prefix."font-secondary",
				"label" => __( 'Secondary font stack', 'jaguar_domain_panel' ),
				"desc" => __( 'Enter font names hierarchically separated by commas. Provide also the most basic fallback ("sans-serif" or "serif").', 'jaguar_domain_panel' ),
				"default" => ( ! wm_option( 'design-color-scheme' ) ) ? ( wm_skin_meta( 'default.css', 'font-secondary' ) ) : ( wm_skin_meta( wm_option( 'design-color-scheme' ), 'font-secondary' ) ),
				"size" => "",
				"maxlength" => ""
			),

		array(
			"type" => "hr"
		),
		array(
			"type" => "heading3",
			"content" => __( 'Basic website font', 'jaguar_domain_panel' )
		),
			array(
				"type" => "select",
				"id" => $prefix."font-body-stack",
				"label" => __( 'Basic website font stack', 'jaguar_domain_panel' ),
				"desc" => __( 'Select previously set font stack for entire website', 'jaguar_domain_panel' ),
				"options" => array(
					"primary" => __( 'Primary font stack', 'jaguar_domain_panel' ),
					"secondary" => __( 'Secondary font stack', 'jaguar_domain_panel' )
					),
				"default" => "primary"
			),
			array(
				"type" => "slider",
				"id" => $prefix."font-body-size",
				"label" => __( 'Basic font size', 'jaguar_domain_panel' ),
				"desc" => __( 'Set the basic font size of the website (in pixels).', 'jaguar_domain_panel' ),
				"default" => 13,
				"min" => 9,
				"max" => 18,
				"step" => 1,
				"validate" => "absint"
			),

		array(
			"type" => "hr"
		),
		array(
			"type" => "heading3",
			"content" => __( 'Heading font', 'jaguar_domain_panel' )
		),
			array(
				"type" => "select",
				"id" => $prefix."font-heading-stack",
				"label" => __( 'Headings font stack', 'jaguar_domain_panel' ),
				"desc" => __( 'Select previously set font stack for website headings', 'jaguar_domain_panel' ),
				"options" => array(
					"primary" => __( 'Primary font stack', 'jaguar_domain_panel' ),
					"secondary" => __( 'Secondary font stack', 'jaguar_domain_panel' )
					),
				"default" => "secondary"
			),
			array(
				"type" => "slider",
				"id" => $prefix."font-heading-size",
				"label" => __( 'Headings sizes', 'jaguar_domain_panel' ),
				"desc" => __( 'Set the relative heading font size in % against the theme default sizes', 'jaguar_domain_panel' ),
				"default" => 100,
				"min" => 50,
				"max" => 200,
				"step" => 5,
				"validate" => "absint"
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Callout font', 'jaguar_domain_panel' )
		),
			array(
				"type" => "select",
				"id" => $prefix."font-cta-stack",
				"label" => __( 'Callout font stack', 'jaguar_domain_panel' ),
				"desc" => __( 'Select previously set font stack for call to action section', 'jaguar_domain_panel' ),
				"options" => array(
					"primary" => __( 'Primary font stack', 'jaguar_domain_panel' ),
					"secondary" => __( 'Secondary font stack', 'jaguar_domain_panel' )
					),
				"default" => "secondary"
			),
			array(
				"type" => "slider",
				"id" => $prefix."font-cta-size",
				"label" => __( 'Callout font size', 'jaguar_domain_panel' ),
				"desc" => __( 'Set the relative call to action font size in % against the theme default sizes', 'jaguar_domain_panel' ),
				"default" => 155,
				"min" => 50,
				"max" => 200,
				"step" => 5,
				"validate" => "absint"
			),
			array(
				"type" => "hrtop"
			),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "design-5",
		"title" => __( 'CSS styles', 'jaguar_domain_panel' )
	),
		array(
			"type" => "help",
			"topic" => __( 'Why my changes are not being applied?', 'jaguar_domain_panel' ),
			"content" => __( 'Please note, that CSS styles are being cached (the theme sets this to 14 days interval). If your changes are not being applied, clean the browser cache first and reload the website. Or you can put WordPress into debug mode when the cache interval decreases to 30 seconds.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Other CSS settings ', 'jaguar_domain_panel' )
		),
			array(
				"type" => "checkbox",
				"id" => $prefix."minimize-css",
				"label" => __( 'Minimize CSS', 'jaguar_domain_panel' ),
				"desc" => __( 'Compress the main CSS stylesheet file (speeds up website loading)', 'jaguar_domain_panel' ),
				"default" => "true"
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."no-css-cache",
				"label" => __( 'Disable theme CSS caching', 'jaguar_domain_panel' ),
				"desc" => __( 'By default the theme applies 14 days cache header on its main CSS stylesheet. You can disable it here.', 'jaguar_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."gzip-cssonly",
				"label" => __( 'Enable GZIP compression on main stylesheet file only', 'jaguar_domain_panel' ),
				"desc" => __( 'If your web host applies GZIP compression by default, you can disable the main GZIP compression in "General" theme options. However, as main CSS stylesheet is being inserted as PHP file (and automatic GZIP compression is usually not applied on such files, you can enable it here.<br />You do not need to enable this GZIP compression if the global one (in "General" theme options) is enabled for the theme.', 'jaguar_domain_panel' )
			),
			array(
				"type" => "hr"
			),

			array(
				"type" => "textarea",
				"id" => $prefix."custom-css",
				"label" => __( 'Custom CSS', 'jaguar_domain_panel' ),
				"desc" => __( 'Type in custom CSS styles. These styles will be added at the end of the main CSS stylesheet file.', 'jaguar_domain_panel' ),
				"default" => "",
				"cols" => 70,
				"rows" => 15,
				"class" => "code"
			),
			array(
				"type" => "hrtop"
			),
	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>