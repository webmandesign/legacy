<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Sliders section
*****************************************************
*/

$prefix = 'slider-';

$easingOptions = array(
	'none'             => __( 'No easing', 'jaguar_domain_panel' ),

	'easeInBack'       => __( 'Back In', 'jaguar_domain_panel' ),
	'easeOutBack'      => __( 'Back Out', 'jaguar_domain_panel' ),
	'easeInOutBack'    => __( 'Back In Out', 'jaguar_domain_panel' ),

	'easeInBounce'     => __( 'Bounce In', 'jaguar_domain_panel' ),
	'easeOutBounce'    => __( 'Bounce Out', 'jaguar_domain_panel' ),
	'easeInOutBounce'  => __( 'Bounce In Out', 'jaguar_domain_panel' ),

	'easeInCirc'       => __( 'Circ In', 'jaguar_domain_panel' ),
	'easeOutCirc'      => __( 'Circ Out', 'jaguar_domain_panel' ),
	'easeInOutCirc'    => __( 'Circ In Out', 'jaguar_domain_panel' ),

	'easeInCubic'      => __( 'Cubic In', 'jaguar_domain_panel' ),
	'easeOutCubic'     => __( 'Cubic Out', 'jaguar_domain_panel' ),
	'easeInOutCubic'   => __( 'Cubic In Out', 'jaguar_domain_panel' ),

	'easeInElastic'    => __( 'Elastic In', 'jaguar_domain_panel' ),
	'easeOutElastic'   => __( 'Elastic Out', 'jaguar_domain_panel' ),
	'easeInOutElastic' => __( 'Elastic In Out', 'jaguar_domain_panel' ),

	'easeInExpo'       => __( 'Expo In', 'jaguar_domain_panel' ),
	'easeOutExpo'      => __( 'Expo Out', 'jaguar_domain_panel' ),
	'easeInOutExpo'    => __( 'Expo In Out', 'jaguar_domain_panel' ),

	'easeInQuad'       => __( 'Quad In', 'jaguar_domain_panel' ),
	'easeOutQuad'      => __( 'Quad Out', 'jaguar_domain_panel' ),
	'easeInOutQuad'    => __( 'Quad In Out', 'jaguar_domain_panel' ),

	'easeInQuart'      => __( 'Quart In', 'jaguar_domain_panel' ),
	'easeOutQuart'     => __( 'Quart Out', 'jaguar_domain_panel' ),
	'easeInOutQuart'   => __( 'Quart In Out', 'jaguar_domain_panel' ),

	'easeInQuint'      => __( 'Quint In', 'jaguar_domain_panel' ),
	'easeOutQuint'     => __( 'Quint Out', 'jaguar_domain_panel' ),
	'easeInOutQuint'   => __( 'Quint In Out', 'jaguar_domain_panel' ),

	'easeInSine'       => __( 'Sine In', 'jaguar_domain_panel' ),
	'easeOutSine'      => __( 'Sine Out', 'jaguar_domain_panel' ),
	'easeInOutSine'    => __( 'Sine In Out', 'jaguar_domain_panel' )
);

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "slider",
	"title" => __( 'Slider', 'jaguar_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "slider",
		"list" => array(
			__( 'General', 'jaguar_domain_panel' ),
			__( 'Nivo Slider', 'jaguar_domain_panel' ),
			__( 'Kwicks Accordion', 'jaguar_domain_panel' ),
			__( 'Roundabout Slider', 'jaguar_domain_panel' ),
			__( 'Simple Slider', 'jaguar_domain_panel' )
			)
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "slider-1",
		"title" => __( 'General', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'General slider settings', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "slider",
			"id" => $prefix."max-number",
			"label" => __( 'Maximum number of slides', 'jaguar_domain_panel' ),
			"desc" => __( 'Set the maximum number of slides (note that more slides in slider means more time to load the page)', 'jaguar_domain_panel' ),
			"default" => 8,
			"min" => 1,
			"max" => 50,
			"step" => 1,
			"validate" => "absint"
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "slider-2",
		"title" => __( 'Nivo Slider', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Nivo Slider customization', 'jaguar_domain_panel' ),
			"class" => "first"
		),

		array(
			"type" => "slider",
			"id" => $prefix."nivo-"."pauseTime",
			"label" => __( 'Slide display time', 'jaguar_domain_panel' ),
			"desc" => __( 'Time of slide being displayed (in miliseconds)', 'jaguar_domain_panel' ),
			"default" => 5000,
			"min" => 500,
			"max" => 12000,
			"step" => 250,
			"validate" => "absint"
		),
		array(
			"type" => "slider",
			"id" => $prefix."nivo-"."animSpeed",
			"label" => __( 'Transition speed', 'jaguar_domain_panel' ),
			"desc" => __( 'Speed of transition effect between slides (in miliseconds)', 'jaguar_domain_panel' ),
			"default" => 400,
			"min" => 50,
			"max" => 2000,
			"step" => 50,
			"validate" => "absint"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."nivo-"."manualAdvance",
			"label" => __( 'Disable automatic animation', 'jaguar_domain_panel' ),
			"desc" => __( 'Only manual slide switching will be available', 'jaguar_domain_panel' ),
			"value" => "true"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."nivo-"."pauseOnHover",
			"label" => __( 'Pause on hover', 'jaguar_domain_panel' ),
			"desc" => __( 'Stop animation on mouse hovering the slider', 'jaguar_domain_panel' ),
			"value" => "true"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."nivo-"."randomStart",
			"label" => __( 'Start at random slide', 'jaguar_domain_panel' ),
			"desc" => __( 'Start animation on random slide', 'jaguar_domain_panel' ),
			"value" => "true"
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "select",
			"id" => $prefix."nivo-"."effect",
			"label" => __( 'Animation effect', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose Nivo slider animation effect', 'jaguar_domain_panel' ),
			"options" => array(
				'sliceDown'          => __( 'Slice down', 'jaguar_domain_panel' ),
				'sliceDownLeft'      => __( 'Slice down (right to left)', 'jaguar_domain_panel' ),
				'sliceUp'            => __( 'Slice up', 'jaguar_domain_panel' ),
				'sliceUpLeft'        => __( 'Slice up (right to left)', 'jaguar_domain_panel' ),
				'sliceUpDown'        => __( 'Slice up and down', 'jaguar_domain_panel' ),
				'sliceUpDownLeft'    => __( 'Slice up and down (right to left)', 'jaguar_domain_panel' ),
				'fold'               => __( 'Folding', 'jaguar_domain_panel' ),
				'fade'               => __( 'Fading', 'jaguar_domain_panel' ),
				'slideInRight'       => __( 'Slide in', 'jaguar_domain_panel' ),
				'slideInLeft'        => __( 'Slide in from right', 'jaguar_domain_panel' ),
				'boxRain'            => __( 'Rain', 'jaguar_domain_panel' ),
				'boxRainReverse'     => __( 'Rain reverse', 'jaguar_domain_panel' ),
				'boxRainGrow'        => __( 'Rain grow', 'jaguar_domain_panel' ),
				'boxRainGrowReverse' => __( 'Rain grow reverse', 'jaguar_domain_panel' ),
				'boxRandom'          => __( 'Random boxes', 'jaguar_domain_panel' ),
				'random'             => __( 'Random', 'jaguar_domain_panel' )
				),
			"default" => "sliceDown"
		),
		array(
			"type" => "slider",
			"id" => $prefix."nivo-"."slices",
			"label" => __( 'Slices count', 'jaguar_domain_panel' ),
			"desc" => __( 'Number of slices for "Slice" animations', 'jaguar_domain_panel' ),
			"default" => 8,
			"min" => 1,
			"max" => 16,
			"step" => 1,
			"validate" => "absint"
		),
		array(
			"type" => "slider",
			"id" => $prefix."nivo-"."boxCols",
			"label" => __( 'Box columns count', 'jaguar_domain_panel' ),
			"desc" => __( 'Horizontal number of boxes for "Rain" and "Boxes" animations', 'jaguar_domain_panel' ),
			"default" => 8,
			"min" => 1,
			"max" => 16,
			"step" => 1,
			"validate" => "absint"
		),
		array(
			"type" => "slider",
			"id" => $prefix."nivo-"."boxRows",
			"label" => __( 'Box rows count', 'jaguar_domain_panel' ),
			"desc" => __( 'Vertical number of boxes for "Rain" and "Boxes" animations', 'jaguar_domain_panel' ),
			"default" => 4,
			"min" => 1,
			"max" => 12,
			"step" => 1,
			"validate" => "absint"
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "checkbox",
			"id" => $prefix."nivo-"."controlNav",
			"label" => __( 'Enable navigation buttons', 'jaguar_domain_panel' ),
			"desc" => __( 'Use slides navigation buttons', 'jaguar_domain_panel' ),
			"value" => "true"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."nivo-"."directionNavHide",
			"label" => __( 'Hide navigation arrows', 'jaguar_domain_panel' ),
			"desc" => __( 'Displays prev/next slide navigation only when mouse hovers over the slider', 'jaguar_domain_panel' ),
			"value" => "true"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."nivo-"."directionNav",
			"label" => __( 'Disable navigation arrows', 'jaguar_domain_panel' ),
			"desc" => __( 'Do not use the default prev/next navigation', 'jaguar_domain_panel' ),
			"value" => "false"
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "slider-3",
		"title" => __( 'Kwicks Accordion', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Kwicks Accordion customization', 'jaguar_domain_panel' ),
			"class" => "first"
		),

		array(
			"type" => "slider",
			"id" => $prefix."kwicks-"."duration",
			"label" => __( 'Transition speed', 'jaguar_domain_panel' ),
			"desc" => __( 'Speed of transition effect between slides (in miliseconds)', 'jaguar_domain_panel' ),
			"default" => 400,
			"min" => 50,
			"max" => 2000,
			"step" => 50,
			"validate" => "absint"
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "slider",
			"id" => $prefix."kwicks-"."min",
			"label" => __( 'Minimal slide width', 'jaguar_domain_panel' ),
			"desc" => __( 'Shrunk slide width minimal in pixels', 'jaguar_domain_panel' ),
			"default" => 90,
			"min" => 50,
			"max" => 480,
			"step" => 10,
			"validate" => "absint"
		),
		array(
			"type" => "select",
			"id" => $prefix."kwicks-"."easing",
			"label" => __( 'Easing effect', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose Kwicks Accordion easing effect', 'jaguar_domain_panel' ),
			"options" => $easingOptions,
			"default" => "none"
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "slider-4",
		"title" => __( 'Roundabout Slider', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Roundabout Slider customization', 'jaguar_domain_panel' ),
			"class" => "first"
		),

		array(
			"type" => "slider",
			"id" => $prefix."roundabout-"."autoplayDuration",
			"label" => __( 'Slide display time', 'jaguar_domain_panel' ),
			"desc" => __( 'Time of slide being displayed (in miliseconds)', 'jaguar_domain_panel' ),
			"default" => 5000,
			"min" => 500,
			"max" => 12000,
			"step" => 250,
			"validate" => "absint"
		),
		array(
			"type" => "slider",
			"id" => $prefix."roundabout-"."duration",
			"label" => __( 'Transition speed', 'jaguar_domain_panel' ),
			"desc" => __( 'Speed of transition effect between slides (in miliseconds)', 'jaguar_domain_panel' ),
			"default" => 400,
			"min" => 50,
			"max" => 2000,
			"step" => 50,
			"validate" => "absint"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."roundabout-"."autoplay",
			"label" => __( 'Disable automatic animation', 'jaguar_domain_panel' ),
			"desc" => __( 'Only manual slide switching will be available', 'jaguar_domain_panel' ),
			"value" => "false"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."roundabout-"."autoplayPauseOnHover",
			"label" => __( 'Pause on mouse hover', 'jaguar_domain_panel' ),
			"desc" => __( 'Stops the automatic rotation when mouse hovers over slider', 'jaguar_domain_panel' ),
			"value" => "true"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."roundabout-"."reflect",
			"label" => __( 'Switch direction', 'jaguar_domain_panel' ),
			"desc" => __( 'Changes automatic rotation direction (left to right)', 'jaguar_domain_panel' ),
			"value" => "true"
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "select",
			"id" => $prefix."roundabout-"."shape",
			"label" => __( 'Animation effect', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose Roundabout slider animation effect', 'jaguar_domain_panel' ),
			"options" => array(
				'lazySusan'         => __( 'Lazy Susan', 'jaguar_domain_panel' ),
				//'waterWheel'      => __( 'Water Wheel', 'jaguar_domain_panel' ),
				'figure8'           => __( 'Figure 8', 'jaguar_domain_panel' ),
				'square'            => __( 'Square', 'jaguar_domain_panel' ),
				//'conveyorBeltLeft'  => __( 'Conveyor Belt (Left)', 'jaguar_domain_panel' ),
				//'conveyorBeltRight' => __( 'Conveyor Belt (Right)', 'jaguar_domain_panel' ),
				'diagonalRingLeft'  => __( 'Diagonal Ring (Left)', 'jaguar_domain_panel' ),
				'diagonalRingRight' => __( 'Diagonal Ring (Right)', 'jaguar_domain_panel' ),
				'rollerCoaster'     => __( 'Roller Coaster', 'jaguar_domain_panel' ),
				'tearDrop'          => __( 'Tear Drop', 'jaguar_domain_panel' ),
				//'theJuggler'        => __( 'The Juggler', 'jaguar_domain_panel' ),
				//'goodbyeCruelWorld' => __( 'Goodbye Cruel World', 'jaguar_domain_panel' )
				),
			"default" => "lazySusan"
		),
		array(
			"type" => "select",
			"id" => $prefix."roundabout-"."easing",
			"label" => __( 'Easing effect', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose Roundabout slider easing effect', 'jaguar_domain_panel' ),
			"options" => $easingOptions,
			"default" => "none"
		),
		array(
			"type" => "slider",
			"id" => $prefix."roundabout-"."tilt",
			"label" => __( 'Animation tilting', 'jaguar_domain_panel' ),
			"desc" => __( 'Sets the tilt of the slides during certain animation effects', 'jaguar_domain_panel' ),
			"default" => 0,
			"min" => -300,
			"max" => 300,
			"step" => 1,
			"validate" => "int",
			"zero" => true
		),
		array(
			"type" => "slider",
			"id" => $prefix."roundabout-"."minOpacity",
			"label" => __( 'The backmost slide opacity', 'jaguar_domain_panel' ),
			"desc" => __( 'Set the lowes transparency of the background slides in % against focused slide', 'jaguar_domain_panel' ),
			"default" => 40,
			"min" => 5,
			"max" => 100,
			"step" => 5,
			"validate" => "absint"
		),
		array(
			"type" => "slider",
			"id" => $prefix."roundabout-"."minScale",
			"label" => __( 'The backmost slide size', 'jaguar_domain_panel' ),
			"desc" => __( 'Set the smallest size of the background slides in % against focused slide', 'jaguar_domain_panel' ),
			"default" => 40,
			"min" => 5,
			"max" => 100,
			"step" => 5,
			"validate" => "absint"
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "checkbox",
			"id" => $prefix."roundabout-"."enableDrag",
			"label" => __( 'Enable dragging', 'jaguar_domain_panel' ),
			"desc" => __( 'Allows controlling the animation by dragging slides on touch screens', 'jaguar_domain_panel' ),
			"value" => "false"
		),
		array(
			"type" => "space"
		),
		array(
			"type" => "slider",
			"id" => $prefix."roundabout-"."dropDuration",
			"label" => __( 'Dragging transition speed', 'jaguar_domain_panel' ),
			"desc" => __( 'Speed of transitioning between slides (in miliseconds) when dragging', 'jaguar_domain_panel' ),
			"default" => 600,
			"min" => 50,
			"max" => 2000,
			"step" => 50,
			"validate" => "absint"
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "slider-5",
		"title" => __( 'Simple Slider', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Simple Slider customization', 'jaguar_domain_panel' ),
			"class" => "first"
		),

		array(
			"type" => "slider",
			"id" => $prefix."simple-"."slideDuration",
			"label" => __( 'Slide display time', 'jaguar_domain_panel' ),
			"desc" => __( 'Time of slide being displayed (in miliseconds)', 'jaguar_domain_panel' ),
			"default" => 5000,
			"min" => 500,
			"max" => 12000,
			"step" => 250,
			"validate" => "absint"
		),
		array(
			"type" => "slider",
			"id" => $prefix."simple-"."transitionTime",
			"label" => __( 'Transition speed', 'jaguar_domain_panel' ),
			"desc" => __( 'Speed of transition effect between slides (in miliseconds)', 'jaguar_domain_panel' ),
			"default" => 400,
			"min" => 50,
			"max" => 2000,
			"step" => 50,
			"validate" => "absint"
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>