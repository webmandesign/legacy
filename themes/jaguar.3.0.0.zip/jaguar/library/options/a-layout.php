<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Layout section
*****************************************************
*/

$prefix = 'layout-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "layout",
	"title" => __( 'Layout', 'jaguar_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "layout",
		"list" => array(
			__( 'Layout settings', 'jaguar_domain_panel' ),
			__( 'Website sections', 'jaguar_domain_panel' )
			)
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "layout-1",
		"title" => __( 'Layout settings', 'jaguar_domain_panel' )
	),

		array(
			"type" => "heading3",
			"content" => __( 'Main website layout', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "layouts",
			"id" => $prefix."boxed",
			"label" => __( 'Website layout', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose the website layout', 'jaguar_domain_panel' ),
			"options" => $websiteLayout,
			"default" => "boxed"
		),
		array(
			"type" => "slider",
			"id" => $prefix."boxed-padding",
			"label" => __( 'Box padding', 'jaguar_domain_panel' ),
			"desc" => __( 'Set the box padding size when boxed website layout used', 'jaguar_domain_panel' ),
			"default" => 60,
			"min" => 30,
			"max" => 120,
			"step" => 5,
			"validate" => "absint"
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Portfolio list layout', 'jaguar_domain_panel' )
		),
		array(
			"type" => "radio",
			"id" => $prefix."portfolio-description-content",
			"label" => __( 'Portfolio description', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose what type of portfolio item description to use when displaying portfolio items in single column view', 'jaguar_domain_panel' ),
			"options" => array(
				'' => __( 'Item description text', 'jaguar_domain_panel' ),
				'attributes' => __( 'Item attributes', 'jaguar_domain_panel' ),
				),
			"default" => ""
		),
		array(
			"type" => "layouts",
			"id" => $prefix."portfolio",
			"label" => __( 'Portfolio list layout', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose, how the portfolio archives will be displayed', 'jaguar_domain_panel' ),
			"options" => array_slice( $portfolioLayout, -4 ),
			"default" => "columns-4"
		),
		array(
			"type" => "select",
			"id" => $prefix."portfolio-sidebar",
			"label" => __( 'Sidebar on portfolio category page', 'jaguar_domain_panel' ),
			"desc" => __( 'Select a widget area used as a sidebar displayed on portfolio category page (if not set no sidebar is displayed)', 'jaguar_domain_panel' ),
			"options" => wm_widget_areas(),
			"default" => ""
		),
		array(
			"type" => "layouts",
			"id" => $prefix."portfolio-sidebar-position",
			"label" => __( 'Sidebar on portfolio category page position', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose a sidebar position on portfolio category page (set the first one to use the theme default settings - no sidebar)', 'jaguar_domain_panel' ),
			"options" => $sidebarPosition,
			"default" => ""
		),
		array(
			"type" => "slider",
			"id" => $prefix."portfolio-items-count",
			"label" => __( 'Portfolio category items number', 'jaguar_domain_panel' ),
			"desc" => __( 'Set the number of portfolio items displayed on portfolio category pages', 'jaguar_domain_panel' ),
			"default" => 12,
			"min" => 3,
			"max" => 100,
			"step" => 1,
			"validate" => "absint"
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Portfolio details layout', 'jaguar_domain_panel' )
		),
			array(
				"type" => "layouts",
				"id" => $prefix."portfolio-single",
				"label" => __( 'Portfolio single item layout', 'jaguar_domain_panel' ),
				"desc" => __( 'Choose, how the portfolio item detail page will be displayed', 'jaguar_domain_panel' ),
				"options" => $portfolioSingleLayout,
				"default" => "left"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."related-portfolio",
				"label" => __( 'Disable related items', 'jaguar_domain_panel' ),
				"desc" => __( 'Hides related portfolio items displayed on portfolio item detail page', 'jaguar_domain_panel' )
			),
		array(
			"type" => "hrtop"
		),

	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "layout-2",
		"title" => __( 'Website sections', 'jaguar_domain_panel' )
	),

		array(
			"type" => "heading3",
			"content" => __( 'Top bar', 'jaguar_domain_panel' ),
			"class" => "first"
		),
			array(
				"type" => "checkbox",
				"id" => $prefix."top-bar-fixed",
				"label" => __( 'Sticky top bar', 'jaguar_domain_panel' ),
				"desc" => __( 'Sticks the top bar to the top of the browser window even when scrolling', 'jaguar_domain_panel' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."top-bar-boxed",
				"label" => __( 'Boxed top bar', 'jaguar_domain_panel' ),
				"desc" => __( 'Place top bar inside website container box', 'jaguar_domain_panel' )
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Website header', 'jaguar_domain_panel' ),
			"class" => "first"
		),
			array(
				"type" => "select",
				"id" => $prefix."status",
				"label" => __( 'Status area', 'jaguar_domain_panel' ),
				"desc" => __( 'Status posts are being displayed in the right side of the website header. Choose how this area should be treated.', 'jaguar_domain_panel' ),
				"options" => array(
					'none' => __( 'Display nothing', 'jaguar_domain_panel' ),
					'status' => __( 'Display status posts', 'jaguar_domain_panel' ),
					'widgets' => __( 'Display "Header Right" widget area', 'jaguar_domain_panel' ),
					),
				"default" => 'status'
			),
			array(
				"type" => "slider",
				"id" => $prefix."status-margin",
				"label" => __( 'Status area margin', 'jaguar_domain_panel' ),
				"desc" => __( 'Set the top margin size for status posts area in header ("-1" sets default theme margin)', 'jaguar_domain_panel' ),
				"default" => -1,
				"min" => -1,
				"max" => 100,
				"step" => 1,
				"validate" => "int",
				"zero" => true
			),
			array(
				"type" => "text",
				"id" => $prefix."menu-special-title",
				"label" => __( 'Special menu area title', 'jaguar_domain_panel' ),
				"desc" => __( 'Enter the toggle button title of the special menu area (do not forget to assign widgets to "Special Menu Area" widget area)', 'jaguar_domain_panel' ),
				"default" => __( 'Contact', 'jaguar_domain' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."menu-special",
				"label" => __( 'Disable special menu area', 'jaguar_domain_panel' ),
				"desc" => __( 'Removes special menu area from website main menu area', 'jaguar_domain_panel' )
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Main heading, slider and callout order', 'jaguar_domain_panel' )
		),
			array(
				"type" => "select",
				"id" => $prefix."chs-positions",
				"label" => __( 'Website content header sections', 'jaguar_domain_panel' ),
				"desc" => __( 'Please choose the order of displaying the Callout, Main Heading and Slider sections', 'jaguar_domain_panel' ),
				"options" => array(
					'c-h-s' => __( 'Callout | Heading | Slider', 'jaguar_domain_panel' ),
					'c-s-h' => __( 'Callout | Slider | Heading', 'jaguar_domain_panel' ),

					'h-c-s' => __( 'Heading | Callout | Slider', 'jaguar_domain_panel' ),
					'h-s-c' => __( 'Heading | Slider | Callout', 'jaguar_domain_panel' ),

					's-c-h' => __( 'Slider | Callout | Heading', 'jaguar_domain_panel' ),
					's-h-c' => __( 'Slider | Heading | Callout', 'jaguar_domain_panel' ),
					),
				"default" => WM_HEADER_SECTIONS_POSITIONS
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Clients list', 'jaguar_domain_panel' )
		),
		array(
			"type" => "text",
			"id" => $prefix."clients-title",
			"label" => __( 'Clients section title', 'jaguar_domain_panel' ),
			"desc" => __( 'Enter the title for clients (or partners) list section', 'jaguar_domain_panel' )
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."clients",
			"label" => __( 'Disable clients section on the whole website', 'jaguar_domain_panel' ),
			"desc" => __( 'By default, clients list is displayed on homepage, pages, portfolio list and portfolio item detail pages', 'jaguar_domain_panel' )
		),
		array(
			"type" => "space"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."clients-home",
			"label" => __( 'No clients on homepage', 'jaguar_domain_panel' ),
			"desc" => __( 'Disable clients on homepage', 'jaguar_domain_panel' )
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."clients-subpages",
			"label" => __( 'No clients on pages', 'jaguar_domain_panel' ),
			"desc" => __( 'Disable clients on pages', 'jaguar_domain_panel' )
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."clients-portfolio",
			"label" => __( 'No clients on portfolio page', 'jaguar_domain_panel' ),
			"desc" => __( 'Disable clients on portfolio items list page', 'jaguar_domain_panel' )
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."clients-portfolio-detail",
			"label" => __( 'No clients on portfolio item page', 'jaguar_domain_panel' ),
			"desc" => __( 'Disable clients on portfolio item details page', 'jaguar_domain_panel' )
		),
		array(
			"type" => "hrtop"
		),

	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>