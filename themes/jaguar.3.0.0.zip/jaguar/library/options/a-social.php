<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Social links section
*****************************************************
*/

$prefix = 'contact-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "contact",
	"title" => __( 'Social links', 'jaguar_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "contact",
		"list" => array(
			__( 'Social networking', 'jaguar_domain_panel' ),
			__( 'Social sharing', 'jaguar_domain_panel' )
			)
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "contact-1",
		"title" => __( 'Social networking', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Social networking links', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "additems",
			"id" => $prefix."social",
			"label" => __( 'Social networking', 'jaguar_domain_panel' ),
			"desc" => __( 'Press [+] button to add new social networking link and enter the full URL into the field. The theme will automatically detect which icon to use with the link (if not recognized, link will not be displayed). For RSS feed link prepend the link with "rss:". The theme supports these social networks: deviantArt, Dribbble, Facebook, Flickr, Forrst, Google+, Instagram, LinkedIn, Twitter, Vimeo and YouTube.', 'jaguar_domain_panel' ),
			"default" => ""
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."social-new-tab",
			"label" => __( 'Open in new window', 'jaguar_domain_panel' ),
			"desc" => __( 'Opens social links in new browser window or tab', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."social-disable",
			"label" => __( 'Disable social networking links', 'jaguar_domain_panel' ),
			"desc" => __( 'Social networking links will not be displayed', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "contact-2",
		"title" => __( 'Social sharing', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Social share buttons on posts and portfolio items', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-facebook",
			"label" => __( 'Facebook sharing', 'jaguar_domain_panel' ),
			"desc" => __( 'Enable Facebook sharing button', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-twitter",
			"label" => __( 'Twitter sharing', 'jaguar_domain_panel' ),
			"desc" => __( 'Enable Twitter sharing button', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-googleplus",
			"label" => __( 'Google+ sharing', 'jaguar_domain_panel' ),
			"desc" => __( 'Enable Google+ sharing button', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-pinterest",
			"label" => __( 'Pinterest sharing', 'jaguar_domain_panel' ),
			"desc" => __( 'Enables this sharing button', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-no-portfolio",
			"label" => __( 'Disable on portfolio', 'jaguar_domain_panel' ),
			"desc" => __( 'Disable share buttons on portfolio item pages', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>