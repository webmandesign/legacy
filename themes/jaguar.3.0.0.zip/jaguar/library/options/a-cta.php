<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Callout (call to action) section
*****************************************************
*/

$prefix = 'cta-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "cta",
	"title" => __( 'Callout', 'jaguar_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "cta",
		"list" => array(
			__( 'Global callout', 'jaguar_domain_panel' )
			)
	),

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "cta-1",
		"title" => __( 'Callout', 'jaguar_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Callout area settings', 'jaguar_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "paragraph",
			"content" => __( 'Below are global callout options. They can be overridden when you set callout for a specific page.', 'jaguar_domain_panel' )
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."enable",
			"label" => __( 'Enable callout', 'jaguar_domain_panel' ),
			"desc" => __( 'Enables callout area on home page (for other website sections check the settings below)', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."enable-override",
			"label" => __( 'Enable callout overriding on pages', 'jaguar_domain_panel' ),
			"desc" => __( 'Adds page settings to override default callout texts and button', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."btn-disable",
			"label" => __( 'Disable button only', 'jaguar_domain_panel' ),
			"desc" => __( 'Removes button from callout area', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "textarea",
			"id" => $prefix."text",
			"label" => __( 'Text', 'jaguar_domain_panel' ),
			"desc" => __( 'Callout text', 'jaguar_domain_panel' ),
			"default" => "",
			"cols" => 57,
			"rows" => 5
		),
		array(
			"type" => "text",
			"id" => $prefix."btn-text",
			"label" => __( 'Button text', 'jaguar_domain_panel' ),
			"desc" => __( 'Callout button text', 'jaguar_domain_panel' ),
			"default" => ""
		),
		array(
			"type" => "text",
			"id" => $prefix."btn-url",
			"label" => __( 'Button link', 'jaguar_domain_panel' ),
			"desc" => __( 'Callout button URL link', 'jaguar_domain_panel' ),
			"default" => ""
		),
		array(
			"type" => "select",
			"id" => $prefix."btn-type",
			"label" => __( 'Button color', 'jaguar_domain_panel' ),
			"desc" => __( 'Choose what type of button is displayed', 'jaguar_domain_panel' ),
			"options" => array(
				''            => __( 'Link color button (default)', 'jaguar_domain_panel' ),
				'type-gray'   => __( 'Gray button', 'jaguar_domain_panel' ),
				'type-green'  => __( 'Green button', 'jaguar_domain_panel' ),
				'type-blue'   => __( 'Blue button', 'jaguar_domain_panel' ),
				'type-orange' => __( 'Orange button', 'jaguar_domain_panel' ),
				'type-red'    => __( 'Red button', 'jaguar_domain_panel' ),
				),
			"default" => ""
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "checkbox",
			"id" => $prefix."pages",
			"label" => __( 'On pages', 'jaguar_domain_panel' ),
			"desc" => __( 'By default, callout is only enabled on homepage. This will show it also on pages and subpages.', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."posts",
			"label" => __( 'On posts', 'jaguar_domain_panel' ),
			"desc" => __( 'By default, callout is only enabled on homepage. This will show it also on posts.', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."portfolio",
			"label" => __( 'On portfolio items', 'jaguar_domain_panel' ),
			"desc" => __( 'By default, callout is only enabled on homepage. This will show it also on portfolio items.', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."archives",
			"label" => __( 'On archives', 'jaguar_domain_panel' ),
			"desc" => __( 'By default, callout is only enabled on homepage. This will show it also on archives.', 'jaguar_domain_panel' ),
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>