<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* File prefixes used:
* a-            options array
* cp-           custom post
* ct-           custom taxonomies
* m-            meta box
* s-            slider content
* w-            widget
* no prefix     core function files
*
* Core functions
*****************************************************
*/

/**
 * @since    1.0
 * @version  3.0
 */



//Theme hooks
require_once( WM_HOOKS . 'hooks.php' );

//Slider generator functions
require_once( WM_SLIDERS . 's-simple.php' );
require_once( WM_SLIDERS . 's-nivo.php' );
require_once( WM_SLIDERS . 's-kwicks.php' );
require_once( WM_SLIDERS . 's-roundabout.php' );



/*
*****************************************************
*      ACTIONS AND FILTERS
*****************************************************
*/
	//ACTIONS
		//Registering theme styles and scripts
		add_action( 'init', 'wm_register_assets' );
		//Main content start
		/*
		* c = call to action
		* h = page / post heading
		* s = slider
		*
		* Default positions: 's-c-h'
		*/
		$beforeMainContentPositions = ( wm_option( 'layout-chs-positions' ) && 5 === strlen( wm_option( 'layout-chs-positions' ) ) ) ? ( explode( '-', wm_option( 'layout-chs-positions' ) ) ) : ( explode( '-', WM_HEADER_SECTIONS_POSITIONS ) );
		$beforeMainContentPositions = array_flip( $beforeMainContentPositions );

		add_action( 'wm_after_header', 'wm_call_to_action', $beforeMainContentPositions['c'] );
		add_action( 'wm_after_header', 'wm_heading', $beforeMainContentPositions['h'] );
		add_action( 'wm_after_header', 'wm_slider', $beforeMainContentPositions['s'] );
		add_action( 'wm_before_main_content', 'wm_display_breadcrumbs' );
		//Meta title
		add_filter( 'wp_title', 'wm_seo_title', 10, 2 );
		//Posts list
		add_action( 'wm_after_list', 'wm_pagination', 1 );
		//Post/page end
		add_action( 'wm_end_post', 'wm_display_gallery', 1 );
		add_action( 'wm_end_post', 'wm_post_parts', 10 );
		add_action( 'wm_after_post', 'wm_author_info', 10 );
		//Custom scripts
		add_action( 'wp_head', 'wm_scripts_header', 9998 ); //9998 for better compatibility with plugins
		add_action( 'wp_footer', 'wm_scripts_footer', 9998 ); //9998 for better compatibility with plugins
		//Feeds
		add_action( 'wp_head', 'wm_custom_feed', 10 );

	//FILTERS
		//Post/page end
		add_filter( 'wm_sharing', 'wm_social_share_buttons', 1 );
		//Password protected post
		add_filter( 'the_password_form', 'wm_password_form' );
		//Remove invalid HTML5 rel attribute
		add_filter( 'the_category', 'wm_remove_rel' );
		//Feed
		add_filter( 'pre_get_posts', 'wm_feed_exclude_post_formats' );
		add_filter( 'request', 'wm_feed_include_post_types' );
		//Media uploader image sizes
		add_filter( 'image_size_names_choose', 'wm_media_uploader_image_sizes' );
		//Gallery shortcode modifications (works with Jetpack Tiled Gallery too - that's why "1999")
			add_filter( 'post_gallery', 'wm_shortcode_gallery', 1999, 2 );
		//WordPress image with caption shortcode improvements
		// add_filter( 'img_caption_shortcode', 'wm_shortcode_image_caption', 10, 3 );





/*
*****************************************************
*      REGISTER STYLES AND SCRIPTS
*****************************************************
*/
	/**
	 * Registering theme styles and scripts
	 *
	 * @version  2.9
	 */
	if ( ! function_exists( 'wm_register_assets' ) ) {
		function wm_register_assets() {
			$protocol = ( is_ssl() ) ? ( 'https' ) : ( 'http' );

			//STYLES
				//frontend
				wp_register_style( 'wm-global', WM_ASSETS_THEME . 'css/style.css.php', false, WM_SCRIPTS_VERSION, 'screen' );
				if ( file_exists( get_stylesheet_directory() . '/assets/css/print.css' ) ) {
					wp_register_style( 'wm-print', get_stylesheet_directory_uri() . '/assets/css/print.css', false, WM_SCRIPTS_VERSION, 'print' );
				} else {
					wp_register_style( 'wm-print', WM_ASSETS_THEME . 'css/print.css', false, WM_SCRIPTS_VERSION, 'print' );
				}

				//for jquery plugins
				wp_register_style( 'prettyphoto', WM_ASSETS_THEME . 'css/prettyphoto/prettyphoto.css', false, WM_SCRIPTS_VERSION, 'screen' );
				wp_register_style( 'fancybox', WM_ASSETS_ADMIN . 'js/fancybox/jquery.fancybox.css', false, WM_SCRIPTS_VERSION, 'screen' );
				wp_register_style( 'color-picker', WM_ASSETS_ADMIN . 'css/colorpicker.css', false, WM_SCRIPTS_VERSION, 'screen' );
				wp_register_style( 'tipsy', WM_ASSETS_THEME . 'css/tipsy/tipsy.css', false, WM_SCRIPTS_VERSION, 'screen' );

				//sliders
				wp_register_style( 'simple-slider', WM_ASSETS_THEME . 'css/simple/simple.css', false, WM_SCRIPTS_VERSION, 'all' );
				wp_register_style( 'nivo', WM_ASSETS_THEME . 'css/nivo/nivo.css', false, WM_SCRIPTS_VERSION, 'all' );
				wp_register_style( 'kwicks', WM_ASSETS_THEME . 'css/kwicks/kwicks.css', false, WM_SCRIPTS_VERSION, 'all' );
				wp_register_style( 'roundabout', WM_ASSETS_THEME . 'css/roundabout/roundabout.css', false, WM_SCRIPTS_VERSION, 'all' );

				//other backend
				wp_register_style( 'wm-options-panel-white-label', WM_ASSETS_ADMIN . 'css/wm-options/wm-options-panel.css', false, WM_SCRIPTS_VERSION, 'screen' );
				wp_register_style( 'wm-options-panel-branded', WM_ASSETS_ADMIN . 'css/wm-options/wm-options-panel-branded.css', false, WM_SCRIPTS_VERSION, 'screen' );
				wp_register_style( 'wm-admin-addons', WM_ASSETS_ADMIN . 'css/admin-addon.css', false, WM_SCRIPTS_VERSION, 'screen' );
				wp_register_style( 'wm-admin-addons-38', WM_ASSETS_ADMIN . 'css/admin-addon-38.css', false, WM_SCRIPTS_VERSION, 'screen' );
				wp_register_style( 'wm-shortcodes-generator', WM_ASSETS_ADMIN . 'css/shortcodes/wm-shortcode-generator.css', array(), WM_SCRIPTS_VERSION, 'screen' );

			//SCRIPTS
				//backend
				wp_register_script( 'jquery-cookies', WM_ASSETS_ADMIN . 'js/jquery.cookies.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'easing', '//cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'drag', WM_ASSETS_THEME . 'js/jquery.dragdrop/jquery.event.drag-2.2.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'drop', WM_ASSETS_THEME . 'js/jquery.dragdrop/jquery.event.drop-2.2.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'fancybox', WM_ASSETS_ADMIN . 'js/fancybox/jquery.fancybox.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'color-picker', WM_ASSETS_ADMIN . 'js/colorpicker.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true);
				if ( ! wm_check_wp_version( '3.3' ) )
					wp_register_script( 'jquery-ui-slider', WM_ASSETS_ADMIN . 'js/jquery/jquery.ui.slider.min.js', array( 'jquery' ), '1.8.16', true );

				//other backend
				wp_register_script( 'wm-wp-admin', WM_ASSETS_ADMIN . 'js/wm-scripts.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'wm-options-panel', WM_ASSETS_ADMIN . 'js/wm-options-panel.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'wm-options-panel-tabs', WM_ASSETS_ADMIN . 'js/wm-options-panel-tabs.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );

				//sliders
				wp_register_script( 'simple-slider', WM_ASSETS_THEME . 'js/simple/simple.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'apply-simple-slider', WM_ASSETS_THEME . 'js/simple/apply-simple.js.php', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'nivo', WM_ASSETS_THEME . 'js/nivo/jquery.nivo.slider.pack.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'apply-nivo', WM_ASSETS_THEME . 'js/nivo/apply-nivo.js.php', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'kwicks', WM_ASSETS_THEME . 'js/kwicks/jquery.kwicks.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'apply-kwicks', WM_ASSETS_THEME . 'js/kwicks/apply-kwicks.js.php', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'roundabout', WM_ASSETS_THEME . 'js/roundabout/jquery.roundabout.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'roundabout-shapes', WM_ASSETS_THEME . 'js/roundabout/jquery.roundabout-shapes.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'apply-roundabout', WM_ASSETS_THEME . 'js/roundabout/apply-roundabout.js.php', array( 'jquery' ), WM_SCRIPTS_VERSION, true );

				//frontend
				wp_register_script( 'imagesloaded', WM_ASSETS_THEME . 'js/imagesloaded/jquery.imagesloaded.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'wm-theme-scripts', WM_ASSETS_THEME . 'js/scripts.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'prettyphoto', WM_ASSETS_THEME . 'js/prettyphoto/jquery.prettyPhoto.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'quicksand', WM_ASSETS_THEME . 'js/quicksand/quicksand.min.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'portfolio', WM_ASSETS_THEME . 'js/portfolio.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
				wp_register_script( 'tipsy', WM_ASSETS_THEME . 'js/tipsy/jquery.tipsy.js', array( 'jquery' ), WM_SCRIPTS_VERSION, true );
		}
	} // /wm_register_assets





/*
*****************************************************
*      VARIABLES
*****************************************************
*/
	/**
	 * Taxonomy list - returns array [slug => name]
	 *
	 * @param array args See below for options.
	 */
	if ( ! function_exists( 'wm_tax_array' ) ) {
		function wm_tax_array( $args = array() ) {
			$args = wp_parse_args( $args, array(
					'all'          => true, //whether to display "all" option
					'allCountPost' => 'post', //post type to count posts for "all" option, if left empty, the posts count will not be displayed
					'allText'      => __( 'All posts', 'jaguar_domain_adm' ), //"all" option text
					'hierarchical' => '1', //whether taxonomy is hierarchical
					'orderBy'      => 'name', //in which order the taxonomy titles should appear
					'parentsOnly'  => false, //will return only parent (highest level) categories
					'return'       => 'slug', //what to return as a value (slug, or term_id?)
					'tax'          => 'category', //taxonomy name
				) );

			$outArray = array();
			$terms    = get_terms( $args['tax'], 'orderby=' . $args['orderBy'] . '&hide_empty=0&hierarchical=' . $args['hierarchical'] );

			if ( $args['all'] ) {
				if ( ! $args['allCountPost'] ) {
					$allCount = '';
				} else {
					$readable = ( in_array( $args['allCountPost'], array( 'post', 'page' ) ) ) ? ( 'readable' ) : ( null );
					$allCount = wp_count_posts( $args['allCountPost'], $readable );
					$allCount = ' (' . absint( $allCount->publish ) . ')';
				}
				$outArray[''] = '- ' . $args['allText'] . $allCount . ' -';
			}

			if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( ! $args['parentsOnly'] ) {
						$outArray[$term->$args['return']] = $term->name;
						$outArray[$term->$args['return']] .= ( ! $args['allCountPost'] ) ? ( '' ) : ( ' (' . $term->count . ')' );
					} elseif ( $args['parentsOnly'] && ! $term->parent ) { //get only parent categories, no children
						$outArray[$term->$args['return']] = $term->name;
						$outArray[$term->$args['return']] .= ( ! $args['allCountPost'] ) ? ( '' ) : ( ' (' . $term->count . ')' );
					}
				}
			}

			return $outArray;
		}
	} // /wm_tax_array



	/**
	 * Pages list - returns array [post_name (slug) => name]
	 *
	 * @return  'post_name' OR 'ID'
	 */
	if ( ! function_exists( 'wm_pages' ) ) {
		function wm_pages( $return = 'post_name' ) {
			$pages       = get_pages();
			$outArray    = array();
			$outArray[0] = __( '- Select page -', 'jaguar_domain_adm' );

			foreach ( $pages as $page ) {
				$indents = $pagePath = '';
				$ancestors = get_post_ancestors( $page->ID );

				if ( ! empty( $ancestors ) ) {
					$indent = ( $page->post_parent ) ? ( '&ndash; ' ) : ( '' );
					$ancestors = array_reverse( $ancestors );
					foreach ( $ancestors as $ancestor ) {
						if ( 'post_name' == $return ) {
							$parent = get_page( $ancestor );
							$pagePath .= $parent->post_name . '/';
						}
						$indents .= $indent;
					}
				}

				$pagePath .= $page->post_name;
				$returnParam = ( 'post_name' == $return ) ? ( $pagePath ) : ( $page->ID );

				$outArray[$returnParam] = $indents . strip_tags( $page->post_title );
			}

			return $outArray;
		}
	} // /wm_pages



/*
* Get array of widget areas - returns array [id => name]
*/
if ( ! function_exists( 'wm_widget_areas' ) ) {
	function wm_widget_areas() {
		global $wp_registered_sidebars;
		$areas     = array();
		$areas[''] = __( '- Select area -', 'jaguar_domain_adm' );

		foreach ( $wp_registered_sidebars as $area ) {
			$areas[ $area['id'] ] = $area['name'];
		}

		asort( $areas );

		return $areas;
	}
} // /wm_widget_areas



/*
* Get color schemes
*/
if ( ! function_exists( 'wm_color_schemes' ) ) {
	function wm_color_schemes() {
		//empty item
		$colorSchemes = array();

		//get files
		$files = array();

		if ( $dir = @opendir( WM_SKINS ) ) {
			//this is the correct way to loop over the directory
			while ( false != ( $file = readdir( $dir ) ) ) {
				$files[] = $file;
			}
			closedir( $dir );
		}

		asort( $files );

		//create output array
		foreach ( $files as $file ) {
			if ( 5 < strlen( $file ) && 'css' == strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
				if ( wm_skin_meta( $file, 'color-scheme' ) && WM_THEME_NAME === wm_skin_meta( $file, 'package' ) ) {
					//$colorSchemes[$file] = wm_skin_meta( $file, 'color-scheme' );
					$fileName       = str_replace( array( '.css', '.CSS' ), '', $file );
					$previewImage   = WM_ASSETS_THEME . 'css/colors/preview/' . $fileName . '.png';
					$item           = array();
					$item['name']   = wm_skin_meta( $file, 'color-scheme' );
					$item['desc']   = wm_skin_meta( $file, 'color-scheme' ) . ' - ' . wm_skin_meta( $file, 'description' );
					$item['id']     = esc_attr( $fileName );
					$item['value']  = esc_attr( $file );
					$item['img']    = ( file_exists( WM_SKINS . '/preview/' . $fileName . '.png' ) ) ? ( $previewImage ) : ( WM_ASSETS_ADMIN . 'img/color-scheme.png' );
					$colorSchemes[] = $item;
				}
			}
		}

		return $colorSchemes;
	}
} // /wm_color_schemes



/*
* Get theme assets files
*
* $folder = TEXT [subfolder of theme assets folder - defaults to "img/patterns/"]
* $format = TEXT [file format to look for - defaults to ".png"]
*/
if ( ! function_exists( 'wm_get_image_files' ) ) {
	function wm_get_image_files( $folder = 'img/patterns/', $format = '.png' ) {
		//empty item
		$filesArray = array(
			array(
				'name' => __( '- None -', 'jaguar_domain_adm' ),
				'id'   => '',
				'img'  => ''
			)
		);

		//get files
		$files = array();

		if ( $dir = @opendir( get_template_directory() . '/assets/' . $folder ) ) {
			//this is the correct way to loop over the directory
			while ( false != ( $file = readdir( $dir ) ) ) {
				$files[] = $file;
			}
			closedir( $dir );
		}

		asort( $files );

		//create output array
		foreach ( $files as $file ) {
			if ( 5 < strlen( $file ) && 'png' == strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) ) {
				$fileName = str_replace( $format, '', strtolower( $file ) );
				$itemName = str_replace( array( '-', '_' ), ' ', $fileName );

				$item         = array();
				$item['name'] = ucwords( $itemName );
				$item['id']   = esc_attr( $fileName );
				$item['img']  = esc_url( WM_ASSETS_THEME . $folder . $file );
				$filesArray[] = $item;
			}
		}

		return $filesArray;
	}
} // /wm_get_image_files





/*
*****************************************************
*      GET/SAVE THEME/META OPTIONS
*****************************************************
*/
	/**
	 * Checks whether array value is "-1"
	 */
	if ( ! function_exists( 'wm_remove_negative_array' ) ) {
		function wm_remove_negative_array( $id ) {
			return ( -1 != $id );
		}
	} // /wm_remove_negative_array

	/**
	 * Checks whether array value is zero or negative
	 */
	if ( ! function_exists( 'wm_remove_zero_negative_array' ) ) {
		function wm_remove_zero_negative_array( $id ) {
			return ( 0 < intval( $id ) );
		}
	} // /wm_remove_zero_negative_array

	/**
	 * Checks whether array value is empty array
	 */
	if ( ! function_exists( 'wm_remove_empty_array' ) ) {
		function wm_remove_empty_array( $array ) {
			$arrayEmptyValuesOut = array_filter( $array );
			return ! empty( $arrayEmptyValuesOut );
		}
	} // /wm_remove_empty_array



	/**
	 * Get page ID by its slug
	 */
	if ( ! function_exists( 'wm_remove_recent_comments_style' ) ) {
		function wm_page_slug_to_id( $slug = null ) {
			$page = get_page_by_path( $slug );
			return ( $slug && $page ) ? ( $page->ID ) : ( null );
		}
	} // /wm_page_slug_to_id



	/**
	 * Get or echo the option
	 *
	 * @param  text name [option name]
	 * @param  text css ["css", "bgimg" - outputs CSS color or background image]
	 * @param  text print ["print" the value]
	 */
	function wm_option( $name, $css = null, $print = null ) {
		if ( ! isset( $name ) )
			return;

		global $themeOptions;

		$options = ( $themeOptions ) ? ( $themeOptions ) : ( get_option( WM_THEME_SETTINGS ) );
		$name    = WM_THEME_SETTINGS_PREFIX . $name;

		if ( ! isset( $options[$name] ) || ! $options[$name] )
			return;

		$array = ( is_array( $options[$name] ) ) ? ( true ) : ( false );

		//CSS output helper
		$color = ( is_string( $css ) && 5 <= strlen( $css ) && 'color' == substr( $css, 0, 5 ) ) ? ( '#' . str_replace( '#', '', stripslashes( $options[$name] ) ) ) : ( '' );
			$colorSuffix = ( $color && 5 < strlen( $css ) ) ? ( str_replace( 'color', '', $css ) ) : ( '' ); // use for example like "color !important"
		$bg = ( is_string( $css ) && 5 <= strlen( $css ) && 'bgimg' == substr( $css, 0, 5 ) ) ? ( 'url(' . esc_url( stripslashes( $options[$name] ) ) . ')' ) : ( '' );
			$bgSuffix = ( $bg && 5 < strlen( $css ) ) ? ( str_replace( 'bgimg', '', $css ) ) : ( '' ); // use for example for css positioning, repeat, ...

		//setting the output
		if ( $bg )
			$output = $bg . $bgSuffix;
		elseif ( $color )
			$output = $color . $colorSuffix;
		else
			$output = ( $array ) ? ( $options[$name] ) : ( stripslashes( $options[$name] ) );

		//output method
		if ( 'print' == $print )
			echo $output;
		else
			return $output;
	} // /wm_option



	/**
	 * Get the static option
	 *
	 * @param  text name [option name]
	 */
	if ( ! function_exists( 'wm_static_option' ) ) {
		function wm_static_option( $name ) {
			$options = get_option( WM_THEME_SETTINGS_STATIC );

			if ( isset( $options[$name] ) )
				return stripslashes( $options[$name] );
		}
	} // /wm_static_option



	/**
	 * Get or echo post/page meta option
	 *
	 * @param  text name [option name]
	 * @param  integer postId [specific post ID, else uses the current post ID]
	 * @param  text print ["print" the value]
	 */
	if ( ! function_exists( 'wm_meta_option' ) ) {
		function wm_meta_option( $name, $postId = null, $print = null ) {
			global $post;
			$postIdObj = ( $post ) ? ( $post->ID ) : ( null );
			$postId    = ( $postId ) ? ( absint( $postId ) ) : ( $postIdObj );

			if ( ! isset( $name ) || ! $postId )
				return;

			$meta = get_post_meta( $postId, WM_THEME_SETTINGS_META, true ); //TRUE = retrieve only the first value of a given key;
			$name = WM_THEME_SETTINGS_PREFIX . $name;

			if ( ! isset( $meta[$name] ) || ! $meta[$name] )
				return;

			$array = ( is_array( $meta[$name] ) ) ? ( true ) : ( false );

			if ( 'print' == $print )
				echo stripslashes( $meta[$name] );
			else
				return ( $array ) ? ( $meta[$name] ) : ( stripslashes( $meta[$name] ) );
		}
	} // /wm_meta_option



	/**
	 * Saves post/page meta (custom fields)
	 *
	 * @param  integer post_id [current post ID]
	 * @param  array options [options array to save]
	 */
	if ( ! function_exists( 'wm_save_meta' ) ) {
		function wm_save_meta( $post_id, $options ) {
			if ( ! isset( $options ) || ! is_array( $options ) || empty( $options ) || ! $post_id )
				return;

			$newMetaOptions = get_post_meta( $post_id, WM_THEME_SETTINGS_META, true );
			if ( ! $newMetaOptions || empty( $newMetaOptions ) )
				$newMetaOptions = array();

			foreach ( $options as $value ) {

				if ( isset( $value['id'] ) ) {
					$valId = WM_THEME_SETTINGS_PREFIX . $value['id'];

					if ( isset( $_POST[$valId] ) ) {

						if ( is_array( $_POST[$valId] ) && ! empty( $_POST[$valId] ) ) {
							$updVal = $_POST[$valId];
							if ( isset( $value['field'] ) && 'attributes' == $value['field'] ) {
								$updVal = array_filter( $updVal, 'wm_remove_empty_array' );
							} else {
								$updVal = array_filter( $updVal, 'strlen' ); //removes null array items
								$updVal = array_filter( $updVal, 'wm_remove_negative_array' ); //removes '-1' array items
							}
						} else {
							$updVal = stripslashes( $_POST[$valId] );
						} //if value is array or not

						if ( isset( $value['validate'] ) && 'url' == $value['validate'] ) {
							$updVal = esc_url( $updVal );
						} elseif ( isset( $value['validate'] ) && 'absint' == $value['validate'] ) {
							$updVal = absint( $updVal );
						} elseif ( isset( $value['validate'] ) && 'int' == $value['validate'] ) {
							$updVal = intval( $updVal );
						}

					} //if $_POST set

					if ( isset( $_POST[$valId] ) && $value['id'] )
						$newMetaOptions[$valId] = $updVal;
					else
						$newMetaOptions[$valId] = '';
				} //if value ID set

			} // /foreach options

			update_post_meta( $post_id, WM_THEME_SETTINGS_META, $newMetaOptions );
		}
	} // /wm_save_meta



	/**
	 * Get color scheme meta
	 *
	 * @param  text schemeFile [color scheme file name]
	 * @param  text meta [meta info title]
	 */
	if ( ! function_exists( 'wm_skin_meta' ) ) {
		function wm_skin_meta( $skinFile, $meta ) {
			if ( ! $skinFile || ! $meta || ! file_exists( WM_SKINS . $skinFile ) )
				return;

			global $skinAtts, $skinAttsStatic;

			$default_headers = $skinAttsStatic;
			$default_headers = array_merge( $default_headers, $skinAtts );

			$fileMeta = get_file_data( WM_SKINS . $skinFile, $default_headers );

			$out = '';

			if ( $fileMeta['color-scheme'] && WM_THEME_NAME === $fileMeta['package'] ) {
				if ( is_array( $meta ) && ! empty( $meta ) ) {
					$metaArray = $fileMeta[ $meta[0] ];
					$metaArray = explode( ', ', $metaArray );
					$out = array();
					foreach ( $metaArray as $metaValue ) {
						$keyValue = explode( ' = ', $metaValue );
						$out[ $keyValue[0] ] = $keyValue[1];
					}
					$out = ( isset( $out[ $meta[1] ] ) ) ? ( $out[ $meta[1] ] ) : ( null );
				} else {
					//$out = ( isset( $fileMeta[$meta] ) ) ? ( $fileMeta[$meta] ) : ( null );
					$out = $fileMeta[$meta];
				}
			}

			return $out;
		}
	} // /wm_skin_meta





/*
*****************************************************
*      WIDGET AREAS
*****************************************************
*/
/*
* Display widget area (sidebar)
*
* $defaultSidebar  = TEXT [widget area ID to fall back as default (if not set, the first widget area defined is used)]
* $class           = TEXT [CSS class added on area container]
* $restrictCount   = # [do not display the sidebar if the number of widgets contained is higher]
* $overrideSidebar = TEXT [if set, the default widget area can be overridden with this area]
* $print           = TEXT ["print" the value]
* $hasInner        = TEXT [whether it contains inner content wrapper]
*/
if ( ! function_exists( 'wm_sidebar' ) ) {
	function wm_sidebar( $defaultSidebar = WM_SIDEBAR_FALLBACK, $class = 'sidebar', $restrictCount = null, $overrideSidebar = null, $print = 'print', $hasInner = null ) {
		global $post, $wp_registered_sidebars, $_wp_sidebars_widgets;

		//restriction = 0 means any number of widgets allowed
		$restrictCount = ( isset( $restrictCount ) && $restrictCount ) ? ( absint( $restrictCount ) ) : ( 0 );
		//set the sidebar to display - default sidebar
		$sidebar       = ( isset( $defaultSidebar ) && $defaultSidebar ) ? ( $defaultSidebar ) : ( $wp_registered_sidebars[0]['id'] );
		//set the sidebar to display - override sidebar
		$sidebar       = ( isset( $overrideSidebar ) && $overrideSidebar ) ? ( $overrideSidebar ) : ( $sidebar );
		//fall back to default if the sidebar doesn't exist
		$sidebar       = ( ! in_array( $sidebar, array_keys( $wp_registered_sidebars ) ) ) ? ( WM_SIDEBAR_FALLBACK ) : ( $sidebar );
		//get all widgets in all widget areas into array
		$widgetsList   = wp_get_sidebars_widgets();

		/*
		//cut the widgets over the restricted amount
		if( count($widgetsList[$sidebar]) > $restrictCount ) {
			$slicedWidgets = array_slice( $widgetsList[$sidebar], 0, $restrictCount );
			$widgetsList[$sidebar] = $slicedWidgets;
			wp_set_sidebars_widgets($widgetsList);
		}
		*/

		//if there are some widgets in $sidebar AND no restrictions applied or the number of the widgets in $sidebar is not greater then restriction
		$out = '';

		if ( is_active_sidebar( $sidebar ) && ( 0 == $restrictCount || ( $restrictCount >= count( $widgetsList[$sidebar] ) ) ) ) {
			if ( $hasInner )
				$out .= '<div class="' . $sidebar . '-wrap wrap-widgets">' . "\r\n";

			$out .= '<section id="' . $sidebar . '" class="widgets count-' . sizeof( $widgetsList[$sidebar] ) . ' ' . $class . '">' . "\r\n";

			$out .= wm_start_sidebar(); //hook

			if ( function_exists( 'ob_start' ) && function_exists( 'ob_end_flush' ) ) {
				ob_start();
				dynamic_sidebar( $sidebar );
				$out .= ob_get_clean(); //output and clear the buffer
			}

			$out .= wm_end_sidebar(); //hook

			$out .= '<!-- /' . $sidebar . ' /widgets --></section>' . "\r\n";

			if ( $hasInner )
				$out .= '<!-- /wrap-widgets --></div>' . "\r\n";
		}

		//output
		if ( 'print' == $print )
			echo $out;
		else
			return $out;
	}
} // /wm_sidebar





/*
*****************************************************
*      BREADCRUMBS AND PAGINATION
*****************************************************
*/
	/**
	 * Pagination
	 *
	 * @since    1.0
	 * @version  3.0
	 *
	 * @param $atts = ARRAY [array of settings:
	 *   label_previous = TEXT ["Previous"]
	 *   label_next     = TEXT ["Next"]
	 *   before_output  = HTML [wrapper tag strat]
	 *   after_output   = HTML [wrapper tag end]
	 *	]
	 */
	if ( ! function_exists( 'wm_pagination' ) ) {
		function wm_pagination( $query = null, $atts = array() ) {
			$atts = wp_parse_args( $atts, array(
					'label_previous' => __( '&laquo; Prev', 'jaguar_domain' ),
					'label_next'     => __( 'Next &raquo;', 'jaguar_domain' ),
					'before_output'  => '<div class="pagination clearfix">',
					'after_output'   => '</div> <!-- /pagination -->',
					'print'          => true
				) );
			$atts = apply_filters( 'wmhook_pagination_atts', $atts );

			//WP-PageNavi plugin support (http://wordpress.org/plugins/wp-pagenavi/)
			if ( function_exists( 'wp_pagenavi' ) ) {
				//Set up WP-PageNavi attributes
					$atts_pagenavi = array(
							'echo' => false,
						);
					if ( $query ) {
						$atts_pagenavi['query'] = $query;
					}
					$atts_pagenavi = apply_filters( 'wmhook_wppagenavi_atts', $atts_pagenavi );

				//Output
					if ( $atts['print'] ) {
						echo $atts['before_output'] . wp_pagenavi( $atts_pagenavi ) . $atts['after_output'];
						return;
					} else {
						return $atts['before_output'] . wp_pagenavi( $atts_pagenavi ) . $atts['after_output'];
					}
			}

			global $wp_query;

			//Override global WordPress query if custom used
				if ( $query ) {
					$wp_query = $query;
				}

			//WordPress pagination settings
				$pagination = array(
						'prev_text' => $atts['label_previous'],
						'next_text' => $atts['label_next'],
					);

			//Output
				if ( 1 < $wp_query->max_num_pages ) {
					if ( $atts['print'] ) {
						echo $atts['before_output'] . paginate_links( $pagination ) . $atts['after_output'];
					} else {
						return $atts['before_output'] . paginate_links( $pagination ) . $atts['after_output'];
					}
				}
		}
	} // /wm_pagination



/*
* Breadcrumbs
*
* $args = ARRAY [array of settings:
	separator     = TEXT [">"]
	before_output = HTML [wrapper tag strat]
	after_output  = HTML [wrapper tag end]
	]
*/
if ( ! function_exists( 'wm_breadcrumbs' ) ) {
	function wm_breadcrumbs( $args = array() ) {
		global $post, $wp_query;

		$defaults = array(
			'separator'     => '&raquo;',
			'before_output' => '<div id="breadcrumbs"><div class="wrap-inner"><div class="section border-color">',
			'after_output'  => '<!-- /breadcrumbs --></div></div></div>'
			);
		$args      = wp_parse_args( $args, $defaults );
		$out       = '';

		$cats      = ( $post ) ? ( get_the_category() ) : ( array() );

		$parents   = ( isset( $post->ancestors ) ) ? ( $post->ancestors ) : ( null ); //get all parent pages in array
		$parents   = ( ! empty( $parents ) ) ? ( array_reverse( $parents ) ) : ( '' );  //flip the array

		$separator = ' <span class="separator">' . $args['separator'] . '</span> ';

		//Do not display breadcrumbs on homepage or main blog page
		if ( ! is_home() && ! is_front_page() ) {
		//no front page, nor home (posts list) page

			$out = $args['before_output'] . '<a href="' . get_bloginfo( 'url' ) . '" class="home-item">' . __( 'Home', 'jaguar_domain' ) . '</a>' . $separator;

			if ( is_category() ) {
			//output single cat name and its parents

				$catId    = intval( get_query_var('cat') );
				$parent   = get_category( $catId );
				$catsOut  = '';
				$blogPage = ( get_option( 'page_for_posts' ) ) ? ( '<a href="' . get_permalink( get_option( 'page_for_posts' ) ) . '">' . get_the_title( get_option( 'page_for_posts' ) ) . '</a>' . $separator ) : ( null );

				if ( is_wp_error( $parent ) )
					return $parent;
				if ( $parent->parent && ( $parent->parent != $parent->term_id ) )
					$catsOut .= get_category_parents( $parent->parent, true, $separator );

				$out .= $blogPage . $catsOut . '<span class="current-item">' . single_cat_title( '', FALSE ) . '</span>';;

			} elseif ( is_date() ) {
			//date archives

				$year      = get_the_time('Y');
				$month     = get_the_time('m');
				$monthname = get_the_time('F');
				$day       = get_the_time('d');
				$dayname   = get_the_time('l');

				if ( is_year() )
					$out .= '<span class="current-item">' . sprintf( __( 'Year %d archive', 'jaguar_domain' ), absint( $year ) ) . '</span>';
				if ( is_month() )
					$out .= '<a href="' . get_year_link( $year ) . '">' . $year . '</a>' . $separator . '<span class="current-item">' . sprintf( __( '%s archive', 'jaguar_domain' ), $monthname ) . '</span>';
				if ( is_day() )
					$out .= '<a href="' . get_year_link( $year ) . '">' . $year . '</a>' . $separator . '<a href="' . get_month_link( $year, $month ) . '">' . $monthname . '</a>' . $separator . '<span class="current-item">' . sprintf( __( 'Day %1$d, %2$s archive', 'jaguar_domain' ), $day, $dayname ) . '</span>';

			} elseif ( is_author() ) {
			//author archives

				$curauth = get_user_by( 'slug', get_query_var( 'author_name' ) );
				$out .= '<span class="current-item">' . sprintf( __( 'Posts by <em>%s</em>', 'jaguar_domain' ), $curauth->display_name ) . '</span>';

			} elseif ( is_tag() ) {
			//tag archives

				$out .= '<span class="current-item">' . sprintf( __( '<em>%s</em> tag archive', 'jaguar_domain' ), single_tag_title( '', false ) ) . '</span>';

			} elseif ( is_search() ) {
			//search results

				$out .= '<span class="current-item">' . sprintf( __( 'Search results for <em>"%s"</em>', 'jaguar_domain' ), get_search_query() ) . '</span>';

			} elseif ( is_tax( 'wm-tax-cats-portfolio' ) ) {
			//custom taxonomy

				$portfolioPage = '';
				$portfolioPageID = wm_option( 'seo-breadcrumbs-portfolio-page' );
				$portfolioPageID = wm_page_slug_to_id( $portfolioPageID );

				if ( $portfolioPageID )
					$portfolioPage = '<a href="' . get_permalink( $portfolioPageID ) . '">' . get_the_title( $portfolioPageID ) . '</a>' . $separator;

				$out .= $portfolioPage . '<span class="current-item">' . $wp_query->queried_object->name . '</span>';


			} elseif ( is_single() && ! empty( $cats ) ) {
			//single post with hierarchical categories

				$cat      = $cats[0];
				$catsOut  = '';
				$blogPage = ( get_option( 'page_for_posts' ) ) ? ( '<a href="' . get_permalink( get_option( 'page_for_posts' ) ) . '">' . get_the_title( get_option( 'page_for_posts' ) ) . '</a>' . $separator ) : ( null );

				if ( is_object( $cat ) ) {
					if ( 0 != $cat->parent ) {
						$catsOut = get_category_parents( $cat->term_id, true, $separator );
					} else {
						$catsOut = '<a href="' . get_category_link( $cat->term_id ) . '">' . $cat->name . '</a>' . $separator;
					}
				}

				$out .= $blogPage . $catsOut . '<span class="current-item">' . get_the_title() . '</span>';

			} elseif ( is_single() && 'wm_portfolio' == $post->post_type ) {
			//single portfolio

				$terms = get_the_terms( $post->ID , 'wm-tax-cats-portfolio' );
				if ( $terms && ! is_wp_error( $terms ) ) {
					foreach( $terms as $term ) {
						$cats[] = $term;
					}
				}

				$catsOut = $portfolioPage = '';
				$cat     = $cats[0];

				if ( is_object( $cat ) )
					$catsOut = '<a href="' . get_term_link( $cat->slug, 'wm-tax-cats-portfolio' ) . '">' . $cat->name . '</a>' . $separator;

				$portfolioPageID = wm_option( 'seo-breadcrumbs-portfolio-page' );
				$portfolioPageID = wm_page_slug_to_id( $portfolioPageID );

				if ( $portfolioPageID )
					$portfolioPage = '<a href="' . get_permalink( $portfolioPageID ) . '">' . get_the_title( $portfolioPageID ) . '</a>' . $separator;

				$out .= $portfolioPage . $catsOut . '<span class="current-item">' . get_the_title() . '</span>';

			} elseif ( is_single() ) {
			//single post

				$blogPage = ( get_option( 'page_for_posts' ) ) ? ( '<a href="' . get_permalink( get_option( 'page_for_posts' ) ) . '">' . get_the_title( get_option( 'page_for_posts' ) ) . '</a>' . $separator ) : ( null );

				$out .= $blogPage . '<span class="current-item">' . get_the_title() . '</span>';

			} elseif ( is_404() ) {
			//error 404 page

				$out .= '<span class="current-item">' . __( 'Page not found', 'jaguar_domain' ) . '</span>';

			} elseif ( is_page() ) {
			//page with hierarchical parent pages

				if ( $parents ) {
					foreach ( $parents as $parent ) {
						$out .= '<a href="' . get_permalink( $parent ) . '">' . get_the_title( $parent ) . '</a>' . $separator; // print all page parents
					}
				}
				$out .= '<span class="current-item">' . get_the_title() . '</span>';

			} else {
			//default

				$out .= '<span class="current-item">' . __( 'Archive', 'jaguar_domain' ) . '</span>';

			}

			//output
			echo $out . $args['after_output'];

		} elseif ( is_home() ) {
		//home (posts list) page

			//$title = ( wm_option( 'pages-default-archives-title' ) ) ? ( wm_option( 'pages-default-archives-title' ) ) : ( __( 'Archives', 'jaguar_domain' ) );
			$title = get_the_title( get_option( 'page_for_posts' ) );

			if ( get_option( 'page_on_front' ) )
				echo $args['before_output'] . '<a href="' . get_bloginfo( 'url' ) . '" class="home-item">' . __( 'Home', 'jaguar_domain' ) . '</a>' . $separator . '<span class="current-item">' . $title . '</span>' . $args['after_output'];

		}
	}
} // /wm_breadcrumbs

/*
* Display breadcrumbs
*/
if ( ! function_exists( 'wm_display_breadcrumbs' ) ) {
	function wm_display_breadcrumbs() {
		$postId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );
		if ( ! wm_option( 'seo-breadcrumbs' ) && ! wm_meta_option( 'breadcrumbs', $postId ) ) {

			if ( ( is_archive() || is_home() ) && wm_option( 'seo-breadcrumbs-archives' ) ) {
				return;
			} elseif ( is_404() && wm_option( 'seo-breadcrumbs-404' ) ) {
				return;
			} else {
				wm_breadcrumbs();
			}

		}
	}
} // /wm_display_breadcrumbs





/*
*****************************************************
*      PASSWORD PROTECTED POST
*****************************************************
*/
	/**
	 * Password protected post form
	 */
	if ( ! function_exists( 'wm_password_form' ) ) {
		function wm_password_form( $form ) {
			global $post;
			$label     = 'pwbox-' . ( ( empty( $post->ID ) ) ? ( rand() ) : ( $post->ID ) );
			$checkPage = ( wm_check_wp_version( 3.4 ) ) ? ( 'wp-login.php?action=postpass' ) : ( 'wp-pass.php' );
			$out       = '';

			$out = '
			<div class="msg type-red icon-box icon-warning">
			<form class="protected-post-form" action="' . get_option( 'siteurl' ) . '/' . $checkPage . '" method="post">
				<h4>' . apply_filters( 'wmhook_password_form_text', __( 'Enter password to view the content:', 'jaguar_domain' ) ) . '</h4>
				<p><input name="post_password" id="' . $label . '" type="password" size="20" /><input type="submit" name="Submit" id="submit" value="' . esc_attr__( 'Submit', 'jaguar_domain' ) . '" /></p>
			</form>
			</div>';

			return $out;
		}
	} // /wm_password_form





/*
*****************************************************
*      COMMENTS
*****************************************************
*/
	/**
	 * Prints comment/trackback
	 *
	 * $comment, $args, $depth - check WordPress codex for info
	 */
	if ( ! function_exists( 'wm_comment' ) ) {
		function wm_comment( $comment, $args, $depth ) {
			$GLOBALS['comment'] = $comment;

			switch ( $comment->comment_type ) {
				case 'pingback' :
				case 'trackback' :

				?>
				<li class="pingback">
					<p>
						<strong><?php _e( 'Pingback:', 'jaguar_domain' ); ?></strong>
						<?php comment_author_link(); ?>
						<?php
						if ( get_edit_comment_link() )
							echo '<a href="' . get_edit_comment_link() . '" class="btn edit-link">' . __( 'Edit', 'jaguar_domain' ) . '</a>';
						?>

					</p>
				<?php

				break;
				default :

				?>
				<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
					<article>

						<div class="gravatar"><?php
							$avatar_size = 50;
							echo get_avatar( $comment, $avatar_size );
						?></div> <!-- /gravatar -->

						<div class="comment-content">

							<div class="comment-heading">
								<p>
									<cite class="author vcard"><?php comment_author_link(); ?></cite>
									<span class="additional-text"><?php _e( 'says:', 'jaguar_domain' ); ?></span>
								</p>
								<p class="meta">
									<a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>" class="published-on">
										<time datetime="<?php comment_time( DATE_W3C ); ?>"><?php printf( __( '%1$s at %2$s', 'jaguar_domain' ), get_comment_date(), get_comment_time() ); ?></time>
									</a>
								</p>
							</div> <!-- /comment-heading -->

							<div class="comment-text border-color">
								<?php
								comment_text();

								if ( '0' == $comment->comment_approved )
									echo '<p class="awaiting"><em>' . __( 'Your comment is awaiting moderation.', 'jaguar_domain' ) . '</em></p>';

								comment_reply_link( array_merge( $args, array(
									'reply_text' => apply_filters( 'wmhook_comment_reply_text', __( 'Reply', 'jaguar_domain' ) ),
									'depth'      => $depth,
									'max_depth'  => $args['max_depth']
									) ) );
								if ( get_edit_comment_link() )
									echo '<p><a href="' . get_edit_comment_link() . '" class="btn edit-link">' . __( 'Edit', 'jaguar_domain' ) . '</a></p>';
								?>
							</div> <!-- /comment-text -->

						</div> <!-- /comment-content -->
					</article>
				<?php

				break;
			} // /switch
		}
	} // /wm_comment



	/**
	 * List pingbacks and trackback
	 *
	 * $tag = TEXT ["h2" heading wrapper tag]
	 */
	if ( ! function_exists( 'wm_pings' ) ) {
		function wm_pings( $tag = 'h2' ) {
			$haveTrackbacks = array();
			$haveTrackbacks = get_comments( array( 'type' => 'pings' ) );

			if ( ! empty( $haveTrackbacks ) ) {
				echo '<' . $tag . '>' . __( 'Pingbacks list', 'jaguar_domain' ) . '</' . $tag . '>';
				?>
				<ol class="commentlist pingbacks">
					<?php
					wp_list_comments( array(
						'type'     => 'pings',
						'callback' => 'wm_comment'
						) );
					?>
				</ol>
				<?php
			}
		}
	} // /wm_pings





/*
*****************************************************
*      CALL TO ACTION
*****************************************************
*/
	/**
	 * Prints call to action
	 */
	if ( ! function_exists( 'wm_call_to_action' ) ) {
		function wm_call_to_action() {
			global $post;

			$cta['enable']       = wm_option( 'cta-enable' );
			$cta['enable-pages'] = wm_option( 'cta-enable-override' );
			$cta['on-pages']     = wm_option( 'cta-pages' );
			$cta['on-posts']     = wm_option( 'cta-posts' );
			$cta['on-portfolio'] = wm_option( 'cta-portfolio' );
			$cta['on-archives']  = wm_option( 'cta-archives' );
			$cta['text']         = wm_option( 'cta-text' );
			$cta['btn-disable']  = wm_option( 'cta-btn-disable' );
			$cta['btn-text']     = wm_option( 'cta-btn-text' );
			$cta['btn-url']      = ( wm_option( 'cta-btn-url' ) ) ? ( wm_option( 'cta-btn-url' ) ) : ( '#' );
			$cta['btn-type']     = wm_option( 'cta-btn-type' );
			$cta['classes']      = ( ! $cta['btn-disable'] && $cta['btn-text'] ) ? ( '' ) : ( ' no-btn' );
			$isPortfolio         = ( isset( $post ) && $post && 'wm_portfolio' == $post->post_type ) ? ( true ) : ( false );

			$postId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );

			if ( ! $cta['enable'] || ( ! $cta['enable-pages'] && wm_meta_option( 'cta-text', $postId ) ) )
				return;

			if ( ! wm_meta_option( 'cta-text', $postId ) && ! is_front_page() && ! (
				( is_page() && $cta['on-pages'] ) ||
				( ( is_single() && $isPortfolio ) && $cta['on-portfolio'] ) ||
				( ( is_single() && ! $isPortfolio ) && $cta['on-posts'] ) ||
				( ( is_archive() || is_home() ) && $cta['on-archives'] )
				) && $cta['text'] )
				return;

			$cta['text'] = ( wm_meta_option( 'cta-text', $postId ) ) ? ( wm_meta_option( 'cta-text', $postId ) ) : ( $cta['text'] );

			if ( ! $cta['text'] )
				return;

			if ( wm_meta_option( 'cta-btn-text', $postId ) ) {
				$cta['btn-text']    = wm_meta_option( 'cta-btn-text', $postId );
				$cta['btn-disable'] = false;
				$cta['classes']     = '';
				$cta['btn-url']     = wm_meta_option( 'cta-btn-url', $postId );
				$cta['btn-type']    = wm_meta_option( 'cta-btn-type', $postId );
			}

			//CTA background color class
			$treshold   = ( wm_option( 'design-color-treshold' ) ) ? ( wm_option( 'design-color-treshold' ) ) : ( WM_COLOR_TRESHOLD );
			$classBgCTA = '';
			if ( wm_option( 'design-cta-bg-color' ) )
				$classBgCTA = ( $treshold > wm_color_brightness( wm_option( 'design-cta-bg-color' ) ) ) ? ( 'bg-dark' ) : ( 'bg-light' );
			$setBgCTA   = ( wm_css_background( 'design-cta-' ) ) ? ( ' set-bg' ) : ( '' );

			?>
			<div id="cta" class="<?php echo $classBgCTA . $setBgCTA; ?>"><div class="wrap-inner">
			<div class="cta section<?php echo $cta['classes']; ?>">
				<?php wm_before_cta(); ?>
				<?php if ( ! $cta['btn-disable'] && $cta['btn-text'] ) { ?>
				<a href="<?php echo esc_url( $cta['btn-url'] ); ?>" class="btn size-medium <?php echo $cta['btn-type']; ?>"><?php echo $cta['btn-text']; ?></a>
				<?php } ?>
				<div class="cta-text"><?php
				$cta['text'] = apply_filters( 'the_content', $cta['text'] );
				$cta['text'] = str_replace( ']]>', ']]&gt;', $cta['text'] );
				echo $cta['text'];
				?></div>
				<?php wm_after_cta(); ?>
			</div> <!-- /call-to-action -->
			</div></div>
			<?php
		}
	} // /wm_call_to_action





/*
*****************************************************
*      SLIDERS
*****************************************************
*/
	/**
	 * Slider type switch
	 */
	if ( ! function_exists( 'wm_slider' ) ) {
		function wm_slider() {
			global $paged, $page;

			if ( ( ! is_singular() && ! is_home() ) || 1 < $paged || 1 < $page )
				return;

			$out = $class = '';
			$postId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );

			//Slider animation type
			$sliderType = ( wm_meta_option( 'slider-type', $postId ) ) ? ( wm_meta_option( 'slider-type', $postId ) ) : ( 'none' );

			//Do not continue, if no slider type selected
			if ( 'none' == $sliderType )
				return;

			//number of slides
			$slidesCount = ( wm_meta_option( 'slider-count', $postId ) ) ? ( wm_meta_option( 'slider-count', $postId ) ) : ( 3 );

			//slider image size
			$imageSize = ( wm_meta_option( 'slider-image', $postId ) ) ? ( wm_meta_option( 'slider-image', $postId ) ) : ( 'slide' );

			//custom posts, post gallery or blog posts to populate slides
			$slidesContent = ( wm_meta_option( 'slider-content', $postId ) ) ? ( wm_meta_option( 'slider-content', $postId ) ) : ( 'wm_slides' );

			//set category only if custom posts or blog posts populate the slider
			$slidesCat = null;
			$slidesCat = ( 'wm_slides' == wm_meta_option( 'slider-content', $postId ) ) ? ( wm_meta_option( 'slider-slides-cat', $postId ) ) : ( $slidesCat );

			//choose slider type
			switch ( $sliderType ) {
				case 'nivo':

					$out .= wm_slider_nivo( $slidesCount, $slidesContent, $slidesCat, $imageSize );

					$class = '';

				break;
				case 'kwicks':

					$out .= wm_slider_kwicks( $slidesCount, $slidesContent, $slidesCat, $imageSize );

					$class = '';

				break;
				case 'roundabout':

					if ( 'slide' === $imageSize )
						$imageSize = 'portfolio';

					$out  .= wm_slider_roundabout( $slidesCount, $slidesContent, $slidesCat, $imageSize );

					$class = ' high';

				break;
				case 'simple':

					$out  .= wm_slider_simple( $slidesCount, $slidesContent, $slidesCat, $imageSize );

					$class = '';

				break;
				case 'video':

					if ( ! wm_meta_option( 'slider-video-url', $postId ) )
						return;

					$videoURL = esc_url( wm_meta_option( 'slider-video-url', $postId ) ) . '&amp;wmode=transparent';
					$width    = 960;
					$height   = $width / 16 * 9;

					$coverImage    = '';
					$hasCoverImage = ' no-cover';

					if ( has_post_thumbnail( $postId ) && get_post( get_post_thumbnail_id( $postId ) ) ) {
						//Post featured image used as video cover image
						$attachment    = get_post( get_post_thumbnail_id( $postId ) );
						$coverImage    = get_the_post_thumbnail( $postId, $imageSize, array( 'class' => 'video-cover' ) );
						$hasCoverImage = ' has-cover';
					}

					$out .= '<div id="video-slider" class="video-slider slider-content' . $hasCoverImage . '">';
					$out .= '<div class="video-container">' . apply_filters( 'the_content',  '[embed width="' . $width . '" height="' . $height . '"]' . $videoURL . '[/embed]' ) . '</div>' . $coverImage;
					$out .= '</div> <!-- /video-slider -->';

					$class = ' video';

				break;
				case 'static':

					if ( has_post_thumbnail( $postId ) && get_post( get_post_thumbnail_id( $postId ) ) ) {

						//Post featured image
						$attachment = get_post( get_post_thumbnail_id( $postId ) );
						$link = esc_url( wm_meta_option( 'slider-url', $postId ) );

						$out .= '<div id="static-slider" class="static-slider slider-content img-content">';
						$out .= ( $link ) ? ( '<a href="' . $link . '">' ) : ( '' );
						$out .=  get_the_post_thumbnail( $postId, $imageSize );
						$out .= ( $link ) ? ( '</a>' ) : ( '' );
						$content = '';
						$content .= ( $attachment->post_excerpt ) ? ( '<h2>' . wptexturize( $attachment->post_excerpt ) . '</h2>' ) : ( '' );
						$content .= ( $attachment->post_content ) ? ( '<div class="desc">' . wptexturize( $attachment->post_content ) . '</div>' ) : ( '' );
						if ( $content ) {
							$out .= '<div class="slider-caption-content">';
							$out .= apply_filters( 'the_content', $content );
							$out .= '</div>';
						}
						$out .= '</div> <!-- /static-slider -->';

						$class = '';

					}

				break;
				case 'custom':

					$out .= '<div class="custom-slider slider-content">';
					$out .= do_shortcode( wm_meta_option( 'slider-custom-shortcode', $postId ) );
					$out .= '</div>';

					$class = '';

				break;
				case 'none':
				break;
				default:
				break;
			} // /switch

			//slider background color class
			$treshold = ( wm_option( 'design-color-treshold' ) ) ? ( wm_option( 'design-color-treshold' ) ) : ( WM_COLOR_TRESHOLD );
			$classBgSlider = '';
			if ( wm_option( 'design-slider-bg-color' ) )
				$classBgSlider = ( $treshold > wm_color_brightness( wm_option( 'design-slider-bg-color' ) ) ) ? ( 'bg-dark' ) : ( 'bg-light' );
			$setBgSlider = ( wm_css_background( 'design-slider-' ) ) ? ( ' set-bg' ) : ( null );

			if ( $out )
				echo '<div id="slider" class="' . $classBgSlider . $setBgSlider . $class . '"><div class="wrap-inner"><section class="slider section">' . $out . '</section></div></div>';
		}
	} // /wm_slider





/*
*****************************************************
*      HEADER AND FOOTER FUNCTIONS
*****************************************************
*/
	/**
	 * Prints logo
	 */
	if ( ! function_exists( 'wm_logo' ) ) {
		function wm_logo() {
			$separator = ( wm_option( 'seo-meta-title-separator' ) ) ? ( ' ' . strip_tags( wm_option( 'seo-meta-title-separator' ) ) . ' ' ) : ( ' | ' );
			$description = ( get_bloginfo( 'description' ) ) ? ( get_bloginfo( 'name' ) . $separator . get_bloginfo( 'description' ) ) : ( get_bloginfo( 'name' ) );
			$logoType  = ( wm_option( 'design-logo-type' ) ) ? ( wm_option( 'design-logo-type' ) ) : ( 'img' );
			$logoURL   = ( wm_option( 'design-logo-img-url' ) ) ? ( wm_option( 'design-logo-img-url' ) ) : ( WM_ASSETS_THEME . 'img/logo-jaguar.png' );

			//SEO logo HTML tag
			if ( is_front_page() )
				$logoTag = 'h1';
			else
				$logoTag = 'div';

			//output
			$out  = '<' . $logoTag . ' class="logo ' . $logoType . '-only">';
			$out .= '<a href="' . home_url() . '" title="' . esc_attr( $description ) . '">';
			if ( 'text' === $logoType ) {
				$out .= get_bloginfo( 'name' );
			} else {
				$out .= '<img src="' . $logoURL . '" alt="' . esc_attr( apply_filters( 'wmhook_logo_image_alt', sprintf( __( '%s logo', 'jaguar_domain' ), trim( get_bloginfo( 'name' ) ) ) ) ) . '" title="' . esc_attr( $description ) . '" />
					<span class="invisible">' . get_bloginfo( 'name' ) . '</span>';
			}
			$out .= '</a>';
			$out .= '</' . $logoTag . '>';

			echo $out;
		}
	} // /wm_logo



	/**
	 * Prints favicon and touch icon
	 */
	if ( ! function_exists( 'wm_favicon' ) ) {
		function wm_favicon() {
			$out = '';

			if ( wm_option( 'design-touch-icon-url' ) ) {
				$out .= '<link rel="apple-touch-icon" href="' . esc_url( wm_option( 'design-touch-icon-url' ) ) . '" />' . "\r\n";
			}
			if ( wm_option( 'design-favicon-url' ) ) {
				$out .= '<link rel="shortcut icon" href="' . esc_url( wm_option( 'design-favicon-url' ) ) . '"/>' . "\r\n";
				$out .= '<link rel="icon" type="image/png" href="' . esc_url( wm_option( 'design-favicon-url' ) ) . '">' . "\r\n";
			}

			echo $out;
		}
	} // /wm_favicon



	/**
	 * Prints copyright text
	 */
	if ( ! function_exists( 'wm_credits' ) ) {
		function wm_credits() {
			$copyText = ( wm_option( 'general-credits' ) ) ? ( wm_option( 'general-credits' ) ) : ( '&copy; ' . get_bloginfo( 'name' ) );
			$copyText = str_replace( array( '(c)', '(C)' ), '&copy;', $copyText );
			$copyText = str_replace( array( '(r)', '(R)' ), '&reg;', $copyText );
			$copyText = str_replace( array( '(tm)', '(TM)', '(Tm)', '(tM)' ), '&trade;', $copyText );
			$copyText = str_replace( 'YEAR', date( 'Y' ), $copyText );
			?>
			<!-- CREDITS -->
			<div class="credits">
				<?php	echo $copyText; ?>
			</div> <!-- /credits -->
			<?php
		}
	} // /wm_credits





/*
*****************************************************
*      SEO FUNCTIONS
*****************************************************
*/
	/**
	 * SEO website title
	 */
	if ( ! function_exists( 'wm_seo_title' ) ) {
		function wm_seo_title( $title, $sep ) {
			global $page, $paged;

			$sep = ( wm_option( 'seo-meta-title-separator' ) ) ? ( ' ' . strip_tags( wm_option( 'seo-meta-title-separator' ) ) . ' ' ) : ( ' | ' );

			if ( is_feed() )
				return $title;

			if ( is_tag() ) {
			//tag archive

				$title = apply_filters( 'wmhook_meta_title_archive_tag', sprintf( __( 'Tag archive for "%s"', 'jaguar_domain' ), single_tag_title( '', false ) ) ) . $sep;

			} elseif ( is_search() ) {
			//search

				$title = apply_filters( 'wmhook_meta_title_search', sprintf( __( 'Search for "%s"', 'jaguar_domain' ), get_search_query() ) ) . $sep;

			} elseif ( is_archive() ) {
			//general archive

				$title = apply_filters( 'wmhook_meta_title_archive', sprintf( __( 'Archive for %s', 'jaguar_domain' ), $title ) ) . $sep;

			} elseif ( is_singular() && ! is_404() && ! is_front_page() && ! is_home() ) {
			//is page or post but not 404, front page nor home page post list

				$title = $title . $sep;

			} elseif ( is_404() ) {
			//404 page

				$title = apply_filters( 'wmhook_meta_title_404', __( 'Web page was not found', 'jaguar_domain' ) ) . $sep;

			} elseif ( is_home() && get_option( 'page_for_posts' ) ) {
			//post page (if set) - get the actual page title

				$title = get_the_title( get_option( 'page_for_posts' ) ) . $sep;

			}

			$title .= get_bloginfo( 'name' );

			//paginated
			if ( 1 < $paged )
				$title .= apply_filters( 'wmhook_meta_title_paged', sprintf( __( ' (page %s)', 'jaguar_domain' ), $paged ) );
			//article parts
			if ( 1 < $page )
				$title .= apply_filters( 'wmhook_meta_title_parted', sprintf( __( ' (part %s)', 'jaguar_domain' ), $page ) );

			return esc_attr( trim( $title ) );
		}
	} // /wm_seo_title



	/**
	 * SEO description
	 */
	if ( ! function_exists( 'wm_seo_desc' ) ) {
		function wm_seo_desc() {
			$out         = '';
			$description = ( wm_option( 'seo-description' ) ) ? ( wm_option( 'seo-description' ) ) : ( get_bloginfo( 'description' ) );

			if ( is_singular() && ! ( is_404() || is_home() || is_front_page() ) ) {
			//is page or post but not 404, front page nor home page post list

				wp_reset_query();
				if ( have_posts() ) {
					while ( have_posts() ) {
						the_post();
						$excerpt = strip_tags( get_the_excerpt( '' ) );
						$out .= $excerpt;
					}
				}
				wp_reset_query();

			}

			if ( ! $out || ' ' == $out )
				$out .= $description;

			return esc_attr( $out );
		}
	} // /wm_seo_desc



	/**
	 * SEO keywords
	 */
	if ( ! function_exists( 'wm_seo_keywords' ) ) {
		function wm_seo_keywords() {
			$out       = '';
			$separator = ', ';
			$keywords  = wm_option( 'seo-keywords' );

			if ( is_tag() ) {
			//tag archive

				$out .= single_tag_title( '', false );
				if ( $keywords )
					$out .= $separator . $keywords;

			} elseif ( is_archive() ) {
			//general archive

				$out .= wp_title( '', false ) . __( ' archive', 'jaguar_domain' );
				if ( $keywords )
					$out .= $separator . $keywords;

			} elseif ( is_singular() && ! is_404() ) {
			//is page or post but not 404
				global $post;

				if ( 'wm_portfolio' === $post->post_type ) {
					$terms = get_the_terms( $post->ID , 'wm-tax-cats-portfolio' );
					if ( $terms ) {
						foreach ( $terms as $term ) {
							$out .= $term->name . $separator . $keywords;
						}
					}
				}

				if ( get_the_category() && ! is_page() ) {
				//get post categories
					foreach ( get_the_category() as $categoryKeyword ) {
						$out .= $categoryKeyword->cat_name . $separator;
					}
				}
				if ( get_the_tags() && ! is_page() ) {
				//get post tags
					$i = 0;
					foreach ( get_the_tags() as $tagKeyword ) {
						if ( $i )
							$out .= $separator;
						$out .= $tagKeyword->name;
						++$i;
					}
				}

			}

			if ( ! $out || ' ' == $out )
				$out .= $keywords;

			return esc_attr( $out );
		}
	} // /wm_seo_keywords



	/**
	 * Prints header scripts (analytics)
	 */
	if ( ! function_exists( 'wm_scripts_header' ) ) {
		function wm_scripts_header() {
			$out    = '';

			//analitics
				if ( ! ( wm_option( 'general-no-logged' ) && is_user_logged_in() && current_user_can( wm_option( 'general-no-logged' ) ) ) ) {
					$out .= '<!-- Custom scripts -->' . "\r\n" . wm_option( 'general-custom-head' ) . "\r\n\r\n";
				}

			echo "\r\n\r\n" . $out;
		}
	} // /wm_scripts_header

	/**
	 * Prints footer scripts (analytics)
	 */
	if ( ! function_exists( 'wm_scripts_footer' ) ) {
		function wm_scripts_footer() {
			$out    = '';
			$pageId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );

			//analitics
				if ( ! ( wm_option( 'general-no-logged' ) && is_user_logged_in() && current_user_can( wm_option( 'general-no-logged' ) ) ) ) {
					$code = wm_option( 'general-custom-footer' );

					if ( is_page() && is_page_template( 'tpl-landing.php' ) )
						$code = wm_meta_option( 'landing-tracking' );

					$out .= '<!-- Custom scripts -->' . "\r\n" . $code . "\r\n\r\n";
				}

			//Roundabout slider tilt - needs to be set before the Roundabout slider apply script
				if ( is_page() && 'roundabout' === wm_meta_option( 'slider-type', $pageId ) ) {
					$out .= '<script>var roundaboutTilt = ' . ( intval( wm_meta_option( 'slider-roundabout-tilt', $pageId ) ) / 100 ) . ';</script>' . "\r\n\r\n";
				}

			//Social sharing buttons JS - output at the end as it is not so important, so can be loaded as last script
				$social = '';
				//Facebook
				if ( wm_option( 'contact-share-facebook' ) ) {
					$social .= '<!-- Facebook -->' . "\r\n" . '<div id="fb-root"></div>' . "\r\n" . '<script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1"; fjs.parentNode.insertBefore(js, fjs);}(document, \'script\', \'facebook-jssdk\'));</script>' . "\r\n\r\n";
				}
				//Twitter
				if ( wm_option( 'contact-share-twitter' ) ) {
					$social .= '<!-- Twitter -->' . "\r\n" . '<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>' . "\r\n\r\n";
				}
				//Google+
				if ( wm_option( 'contact-share-googleplus' ) ) {
					$social .= "<!-- Google+ -->\r\n<script>(function() {var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true; po.src = 'https://apis.google.com/js/plusone.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s); })();</script>" . "\r\n\r\n";
				}
				//Pinterest
				if ( wm_option( 'contact-share-pinterest' ) ) {
					$social .= '<!-- Pinterest -->' . "\r\n" . '<script type="text/javascript" src="//assets.pinterest.com/js/pinit.js"></script>' . "\r\n\r\n";
				}
				//social output
				if (
						$social
						&& is_single()
						&& ! wm_meta_option( 'no-sharing' )
						&& ! ( 'wm_portfolio' == get_post_type() && wm_option( 'contact-share-no-portfolio' ) )
					) {
					$out .= $social;
				}

			echo "\r\n\r\n" . $out;
		}
	} // /wm_scripts_footer





/*
*****************************************************
*      POST / PAGE FUNCTIONS
*****************************************************
*/
	/**
	 * H1 or H2 headings (on singular pages also checks for subtitle)
	 *
	 * @version  2.9
	 *
	 * $list    = TEXT [if set, outputs H2 instead of H1]
	 * $wrap    = HTML ["span" inside H1/H2 text wrapper]
	 */
	if ( ! function_exists( 'wm_heading' ) ) {
		function wm_heading( $list = null, $wrap = null ) {
			global $page, $paged, $wp_query;

			$blogPageId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );
			$subheading = wm_meta_option( 'subheading', $blogPageId );
			if ( ( is_archive() || is_search() ) && ! is_home() )
				$subheading = apply_filters( 'wmhook_heading_subtitle_items_found', __( 'Number of items found:', 'jaguar_domain' ) . ' ' . $wp_query->found_posts );

			//List title
			if ( isset( $list ) && $list ) {
				$out = '';

				if ( has_post_format( 'status' ) )
					$out .= ( get_the_title() ) ? ( get_the_title() ) : ( '' );
				else
					$out .= ( get_the_title() ) ? ( '<a href="' . get_permalink() . '">' . get_the_title() . '</a>' ) : ( '' );

				$titleSticky = '';
				if ( is_sticky() )
					$titleSticky = ' title="' . __( 'This is featured post', 'jaguar_domain' ) . '"';

				$output =  ( $out ) ? ( '<header class="post-title"' . $titleSticky . '><h2>' . $out . '</h2></header>' ) : ( '' );

				//output
				echo $output;
				return;
			}

			//Main H1 title
			$out = '';
			if ( is_singular() || $blogPageId ) {
			//post or page

				$title = ( isset( $wrap ) && $wrap ) ? ( '<' . $wrap . '>' . get_the_title( $blogPageId ) . '</' . $wrap . '>' ) : ( get_the_title( $blogPageId ) );
				if ( 1 < $page )
					$out .= ( $title ) ? ( '<a href="' . get_permalink() . '">' . $title . '</a> <small>' . sprintf( __( ' (part %s)', 'jaguar_domain' ), $page ) . '</small>' ) : ( '' );
				else
					$out .= ( $title ) ? ( $title ) : ( '' );

			} elseif ( is_day() ) {
			//dayly archives

				$out .= apply_filters( 'wmhook_heading_archives_daily', sprintf( __( 'Daily Archives: <span>%s</span>', 'jaguar_domain' ), get_the_date() ) );

			} elseif ( is_month() ) {
			//monthly archives

				$out .= apply_filters( 'wmhook_heading_archives_monthly', sprintf( __( 'Monthly Archives: <span>%s</span>', 'jaguar_domain' ), get_the_date( 'F Y' ) ) );

			} elseif ( is_year() ) {
			//yearly archives

				$out .= apply_filters( 'wmhook_heading_archives_yearly', sprintf( __( 'Yearly Archives: <span>%s</span>', 'jaguar_domain' ), get_the_date( 'Y' ) ) );

			} elseif ( is_author() ) {
			//author archive

				$userID = $wp_query->query_vars['author'];

				$out .= apply_filters( 'wmhook_heading_archives_author', sprintf( __( 'Posts by <span>%s</span>', 'jaguar_domain' ), get_the_author_meta( 'display_name', $userID ) ) );

			} elseif ( is_category() ) {
			//category archive

				$out .= apply_filters( 'wmhook_heading_archives_category', sprintf( __( 'Posts in <span>%s</span> Category', 'jaguar_domain' ), single_cat_title( '', false ) ) );

			} elseif ( is_tag() ) {
			//tag archive

				$out .= apply_filters( 'wmhook_heading_archives_tag', sprintf( __( 'Posts Tagged "<span>%s</span>"', 'jaguar_domain' ), single_tag_title( '', false ) ) );

			} elseif ( is_search() ) {
			//search

				$out .= apply_filters( 'wmhook_heading_search', sprintf( __( 'Search results for <span>%s</span>', 'jaguar_domain' ), get_search_query() ) );

			} elseif ( is_tax( 'wm-tax-cats-portfolio' ) ) {
			//custom taxonomy

				$portfolioPageID = wm_option( 'seo-breadcrumbs-portfolio-page' );
				$portfolioPageID = wm_page_slug_to_id( $portfolioPageID );

				$portfolioPage = ( $portfolioPageID ) ? ( get_the_title( $portfolioPageID ) . ' / ' ) : ( '' );

				$out .= $portfolioPage . $wp_query->queried_object->name;

			} else {
			//other situations

				$out .= ( wm_option( 'pages-default-archives-title' ) ) ? ( wm_option( 'pages-default-archives-title' ) ) : ( '' );

			}

			//paged
			$out .= ( 1 < $paged ) ? ( ' <small>(page ' . $paged . ')</small>' ) : ( '' );

			//post, page title and subtitle display
			$class = $classContainer = '';
			if ( wm_meta_option( 'no-heading', $blogPageId ) || ! $out ) {
				$class          = ( $subheading ) ? ( ' class="invisible"' ) : ( '' );
				$classContainer = ( ! $subheading ) ? ( ' invisible' ) : ( '' );
			}

			$subtitleH2 = ( $subheading ) ? ( '<h2 class="subtitle">' . strip_tags( $subheading ) . '</h2>' ) : ( '' );
			$wrapper    = ( $subtitleH2 ) ? ( '<hgroup>' ) : ( '' );
			$wrapperEnd = ( $wrapper ) ? ( '</hgroup>' ) : ( '' );

			//main heading background color class
			$treshold = ( wm_option( 'design-color-treshold' ) ) ? ( wm_option( 'design-color-treshold' ) ) : ( WM_COLOR_TRESHOLD );
			$classBgMainHeading = '';
			if ( wm_option( 'design-main-heading-bg-color' ) )
				$classBgMainHeading = ( $treshold > wm_color_brightness( wm_option( 'design-main-heading-bg-color' ) ) ) ? ( 'bg-dark' ) : ( 'bg-light' );
			$setBgMainHeading = ( wm_css_background( 'design-main-heading-' ) ) ? ( ' set-bg' ) : ( '' );

			$before = '<section id="main-heading" class="' . $classBgMainHeading . $setBgMainHeading . $classContainer . '"><div class="wrap-inner">';
			$after  = '</div></section>';

			//output
			echo $before . '<header class="section">' . $wrapper . '<h1' . $class . '>' . $out . '</h1>' . $subtitleH2 . $wrapperEnd . '</header>' . $after;
		}
	} // /wm_heading



	/**
	 * Thumbnail image
	 *
	 * @version  2.9
	 *
	 * $class = TEXT [image container additional CSS class name]
	 * $size  = TEXT [image size]
	 * $attr  = ARRAY [check WordPress codex on this]
	 * $post  = OBJECT [WordPress post object]
	 * $list  = TEXT [set this to use post permalink in Posts widget even on single post page]
	 */
	if ( ! function_exists( 'wm_thumb' ) ) {
		function wm_thumb( $class = null, $size = 'thumbnail', $attr = null, $post = null, $list = null, $print = true ) {
			global $post;

			$attrDefaults = array(
				'title'	=> '',
				);

			$attr = wp_parse_args( $attr, $attrDefaults );

			$theClass  = ( isset( $class ) && $class ) ? ( ' ' . esc_attr( $class ) ) : ( '' );
			$imageFull = ( has_post_thumbnail() ) ? ( get_the_post_thumbnail( null, $size, $attr ) ) : ( '' );
			$image     = preg_replace( '/(width|height)=\"\d*\"\s/', "", $imageFull );

			$out = '';
			if ( is_singular() && isset( $post->ID ) && ! $list ) {

				if ( $image ) {
					$largeImageUrl = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), wm_option( 'general-lightbox-img' ) );
					$out .= '<div class="image-container' . $theClass . '">';
					$out .= '<a href="' . $largeImageUrl[0] . '" data-modal>' . $image . '</a>';
					$out .= '</div>';
				}

			} else {

				if ( $image ) {
					$out .= '<div class="image-container' . $theClass . '">';
					$out .= '<a href="' . get_permalink() . '">' . $image . '</a>';
					$out .= '</div>';
				}

			}

			if ( $print ) {
				echo apply_filters( 'wmhook_thumbnail_html', $out );
			} else {
				return apply_filters( 'wmhook_thumbnail_html', $out );
			}
		}
	} // /wm_thumb



	/**
	 * Get all images attached to the post
	 *
	 * $numberposts = # [number of images to get (-1 = all)]
	 * $post_id     = # [specific post id, else current post id used]
	 * $size  = TEXT [image size]
	 */
	if ( ! function_exists( 'wm_get_post_images' ) ) {
		function wm_get_post_images( $numberposts = -1, $post_id = null, $size = null, $noFeatured = false ) {
			global $post;
			if ( ! $post_id && ! $post ) {
				return;
			}

			$post_id     = ( $post_id ) ? ( absint( $post_id ) ) : ( $post->ID );
			$size        = ( $size ) ? ( $size ) : ( 'widget' );
			$outputArray = array();

			$args = array(
					'numberposts'    => $numberposts,
					'post_parent'    => $post_id,
					'orderby'        => 'menu_order',
					'order'          => 'asc',
					'post_mime_type' => 'image',
					'post_type'      => 'attachment'
				);
			if ( $noFeatured ) {
				$args['exclude'] = get_post_thumbnail_id( $post_id );
			}
			$images = get_children( $args );

			if ( ! empty( $images ) ) {
				foreach ( $images as $attachment_id => $attachment ) {
					$imgUrlArray    = wp_get_attachment_image_src( $attachment_id, $size );
					$imgTitle       = trim( strip_tags( $attachment->post_title ) );
					$imgCaption     = trim( strip_tags( $attachment->post_excerpt ) );

					$entry          = array();
					$entry['name']  = ( $imgCaption ) ? ( esc_attr( $imgTitle . ' - ' . $imgCaption ) ) : ( esc_attr( $imgTitle ) );
					$entry['id']    = esc_attr( $attachment_id );
					$entry['img']   = $imgUrlArray[0];
					$entry['title'] = esc_attr( $imgTitle );
					$entry['alt']   = esc_attr( get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) );

					$outputArray[]  = $entry;
				}
			}

			return $outputArray;
		}
	} // /wm_get_post_images



	/**
	 * Media uploader image sizes
	 *
	 * $sizes = ARRAY [check WordPress codex on this]
	 */
	if ( ! function_exists( 'wm_media_uploader_image_sizes' ) ) {
		function wm_media_uploader_image_sizes( $sizes ) {
			$customSizes = array(
				'blog'   => __( 'Blog featured image', 'jaguar_domain_adm' ),
				'widget' => __( 'Small thumb', 'jaguar_domain_adm' )
				);

			return array_merge( $sizes, $customSizes );
		}
	} // /wm_media_uploader_image_sizes



	/**
	 * WP gallery improvements
	 *
	 * Improves WordPress [gallery] shortcode: removes inline CSS, changes HTML markup to  valid, makes it easier to remove images from gallery.
	 * $attr = ARRAY [check WordPress codex on this]
	 *
	 * Original source code from wp-includes/media.php
	 *
	 * @version  2.9
	 */
	if ( ! function_exists( 'wm_shortcode_gallery' ) ) {
		function wm_shortcode_gallery( $output, $attr ) {
			//Something else is overriding post_gallery, such as a Jetpack plugin's Tiled Gallery
				if ( ! empty( $output ) ) {
					return $output;
				}

			$post = get_post();

			static $instance = 0;
			$instance++;
			//WordPress passes $attr variable only to the filter, so the above needs to be reset

			$output = '';

			// We're trusting author input, so let's at least make sure it looks like a valid orderby statement
			if ( isset( $attr['orderby'] ) ) {
				$attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
				if ( ! $attr['orderby'] )
					unset( $attr['orderby'] );
			}

			extract( shortcode_atts( array(
				'order'      => 'ASC',
				'orderby'    => 'menu_order ID',
				'id'         => $post->ID,
				'itemtag'    => 'figure',
				'icontag'    => 'span',
				'captiontag' => 'span',
				'columns'    => 3,
				'size'       => 'portfolio',
				'include'    => '',
				'exclude'    => '',
				//custom theme additions:
				'portfolio'  => '', //whether this is portfolio item gallery (specially styled)
				'remove'     => '', //remove images by order number
				'class'      => '', //additional gallery item class
				// /custom theme additions
			), $attr ) );

			//custom theme additions:
			$excludeImages = wm_meta_option( 'gallery-images' );
			if ( is_array( $excludeImages ) && ! empty( $excludeImages ) ) {
				/*
				* WP3.5 generates multiple galleries per post with "ids" parameter (see above) that translates into "include".
				* That's why we need to manage that one too for the theme gallery improvements.
				* Basically, remove all the excluded images from "include" only when "ids" parameter set, otherwise leave include untouched.
				*/
				if ( isset( $attr['ids'] ) && ! empty( $attr['ids'] ) ) {
					$include = str_replace( ' ', '', $include );
					$includeRemove = explode( ',', $include );
					foreach ( $includeRemove as $key => $value ) {
						if ( in_array( $value, $excludeImages ) )
							unset( $includeRemove[$key] );
					}
					$include = implode( ',', $includeRemove );
				}

				$excludeImages = implode( ',', $excludeImages );
			}

			$exclude = ( $exclude ) ? ( $exclude ) : ( $excludeImages );
			$remove  = preg_replace( '/[^0-9,]+/', '', $remove );
			$remove  = ( $remove ) ? ( explode( ',', $remove ) ) : ( array() );
			$class   = ' ' . trim( $class );
			// /custom theme additions

			$id = intval($id);
			if ( 'RAND' == $order )
				$orderby = 'none';

			if ( !empty($include) ) {
				$include = preg_replace( '/[^0-9,]+/', '', $include ); //not in WP 3.5 but keeping it
				$_attachments = get_posts( array(
						'include'        => $include,
						'post_status'    => 'inherit',
						'post_type'      => 'attachment',
						'post_mime_type' => 'image',
						'order'          => $order,
						'orderby'        => $orderby
					) );

				$attachments = array();
				foreach ( $_attachments as $key => $val ) {
					$attachments[$val->ID] = $_attachments[$key];
				}
			} elseif ( !empty($exclude) ) {
				$exclude = preg_replace( '/[^0-9,]+/', '', $exclude ); //not in WP 3.5 but keeping it
				$attachments = get_children( array(
						'post_parent'    => $id,
						'exclude'        => $exclude,
						'post_status'    => 'inherit',
						'post_type'      => 'attachment',
						'post_mime_type' => 'image',
						'order'          => $order,
						'orderby'        => $orderby
					) );
			} else {
				$attachments = get_children( array(
						'post_parent'    => $id,
						'post_status'    => 'inherit',
						'post_type'      => 'attachment',
						'post_mime_type' => 'image',
						'order'          => $order,
						'orderby'        => $orderby
					) );
			}

			if ( empty( $attachments ) )
				return ''; //this will make the default WordPress function to take care of processing

			if ( is_feed() ) {
				$output = "\n";
				foreach ( $attachments as $att_id => $attachment )
					$output .= wp_get_attachment_link($att_id, $size, true) . "\n";
				return $output;
			}

			$itemtag = tag_escape($itemtag);
			$captiontag = tag_escape($captiontag);
			$columns = absint($columns);
			$float = is_rtl() ? 'right' : 'left';

			//custom theme additions:
				$wrapper    = ( 'li' == $itemtag ) ? ( '<ul>' ) : ( '' );
				$wrapperEnd = ( $wrapper ) ? ( '</ul>' ) : ( '' );
				$columns    = ( 3 > $columns || 9 < $columns ) ? ( 3 ) : ( $columns ); //only 3 to 9 columns allowed
			// /custom theme additions

			$selector = "gallery-{$instance}";
			$gallery_div = '';
			$size_class = sanitize_html_class( $size );
			$gallery_div = "<div id='$selector' class='gallery galleryid-{$id} gallery-columns-{$columns} gallery-columns gallery-size-{$size_class}'>" . $wrapper; //custom theme additions
			$output = apply_filters( 'gallery_style', $gallery_div );

			$i = $j = 0; //$i = every image from gallery, $j = only displayed images
			foreach ( $attachments as $id => $attachment ) {
				//$link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link($id, $size, false, false) : wp_get_attachment_link($id, $size, true, false);
				//$link = wp_get_attachment_link($id, $size, false, false);
				$fullImgSize = ( wm_option( 'general-lightbox-img' ) ) ? ( wm_option( 'general-lightbox-img' ) ) : ( 'full' );
				$fullImg     = wp_get_attachment_image_src( $id, $fullImgSize, false );
				$imageArray  = wp_get_attachment_image_src( $id, $size, false );
				$titleText   = array( ucfirst( $attachment->post_title ), $attachment->post_excerpt );
				$titleText   = esc_attr( implode( ' - ', array_filter( $titleText ) ) );
				$image       = '<img src="' . $imageArray[0] . '" alt="' . $titleText . '" title="' . $titleText . '" />';
				$link        = '<a href="' . $fullImg[0] . '" title="' . $titleText . '">' . $image . '</a>';
				$i++;

				if ( ! in_array( $i, $remove ) ) {
					if ( ++$j % $columns == 0 )
						$last = ' last';
					else
						$last = '';

					$last .= ( $j <= $columns ) ? ( ' first-row' ) : ( null );

					$output .= "<{$itemtag} class='gallery-item column col-1{$columns}$last$class'>";
					$output .= "<{$icontag} class='gallery-icon'>$link</{$icontag}>";
					if ( $captiontag && trim($attachment->post_excerpt) ) {
						$output .= "
							<{$captiontag} class='wp-caption-text gallery-caption'>
							" . apply_filters( 'the_content', $attachment->post_excerpt ) . "
							</{$captiontag}>";
					}
					$output .= "</{$itemtag}>";
					if ( $columns > 0 && $i % $columns == 0 )
						$output .= '';
				}
			}

			$output .= $wrapperEnd . "</div>\n"; //custom theme additions

			return $output;
		}
	} // /wm_shortcode_gallery

	/**
	 * Displays gallery
	 */
	if ( ! function_exists( 'wm_display_gallery' ) ) {
		function wm_display_gallery() {
			global $page, $numpages; //display only on the last page of paged post

			if ( wm_meta_option( 'gallery' ) && $numpages === $page ) {
				$columns = wm_meta_option( 'gallery-columns' );
				$images  = wm_meta_option( 'gallery-images' );
				$images  = ( is_array( $images ) && ! empty( $images ) ) ? ( implode( ',', $images ) ) : ( '' );

				echo do_shortcode( '[gallery columns="' . $columns . '" include="' . $images . '" link="file"]' );
			}
		}
	} // /wm_display_gallery



	/**
	 * WordPress image captions
	 *
	 * Improves WordPress image captions by removing inline styling.
	 */
	if ( ! function_exists( 'wm_shortcode_image_caption' ) ) {
		function wm_shortcode_image_caption( $out, $attr, $content = null ) {
			extract( shortcode_atts( array(
				'id'      => '',
				'align'   => 'alignnone',
				'width'   => '',
				'caption' => ''
				), $attr)
				);

			if ( 1 > (int) $width || empty($caption) )
				return $content;

			if ( $id )
				$id = 'id="' . esc_attr( $id ) . '" ';

			return '<div ' . $id . 'class="wp-caption caption-overlay ' . esc_attr( $align ) . '">' . do_shortcode( $content ) . '<p class="wp-caption-text border-color">' . $caption . '</p></div>';
		}
	} // /wm_shortcode_image_caption



	/**
	 * Excerpt
	 *
	 * $length_fn = FN [callback function setting the excerpt length]
	 * $more_fn   = FN [callback function setting the "..." string after excerpt]
	 */
	if ( ! function_exists( 'wm_excerpt' ) ) {
		function wm_excerpt( $length_fn = null, $more_fn = null ) {
			if ( $length_fn && is_callable( $length_fn ) )
				add_filter( 'excerpt_length', $length_fn, 999 );
			else
				add_filter( 'excerpt_length', 'wm_excerpt_length_blog', 999 );

			if ( $more_fn && is_callable( $more_fn ) )
				add_filter( 'excerpt_more', $more_fn );
			else
				add_filter( 'excerpt_more', 'wm_excerpt_more' );

			$excerpt = get_the_excerpt();
			$exc     = apply_filters( 'wptexturize', $excerpt );

			$out = '';
			if ( get_the_excerpt() ) {
				$out .= '<div class="excerpt"><p>';
				$out .= apply_filters( 'convert_chars', $exc );
				$out .= '</p></div>';
			}

			echo $out;
		}
	} // /wm_excerpt

	/**
	 * Different excerpt length callback functions
	 */
	if ( ! function_exists( 'wm_excerpt_length_blog' ) ) {
		function wm_excerpt_length_blog( $length ) {
			$defaultLength = ( wm_option( 'blog-excerpt-length' ) ) ? ( wm_option( 'blog-excerpt-length' ) ) : ( WM_DEFAULT_EXCERPT_LENGTH );
			$customLength  = ( wm_option( 'blog-excerpt-length' ) ) ? ( wm_option( 'blog-excerpt-length' ) ) : ( $defaultLength );
			return $customLength;
		}
	} // /wm_excerpt_length_blog

	if ( ! function_exists( 'wm_excerpt_length_short' ) ) {
		function wm_excerpt_length_short( $length ) {
			$customLength = ( wm_option( 'blog-excerpt-length-short' ) ) ? ( wm_option( 'blog-excerpt-length-short' ) ) : ( 25 );
			return $customLength;
		}
	} // /wm_excerpt_length_short

	if ( ! function_exists( 'wm_excerpt_length_very_short' ) ) {
		function wm_excerpt_length_very_short( $length ) {
			$customLength = ( wm_option( 'blog-excerpt-length-shortest' ) ) ? ( wm_option( 'blog-excerpt-length-shortest' ) ) : ( 10 );
			return $customLength;
		}
	} // /wm_excerpt_length_very_short

	/**
	 * Excerpt "more" callback function
	 */
	if ( ! function_exists( 'wm_excerpt_more' ) ) {
		function wm_excerpt_more( $more ) {
			return '&hellip;';
		}
	} // /wm_excerpt_more

	/**
	 * Displays excerpt
	 */
	if ( ! function_exists( 'wm_display_excerpt' ) ) {
		function wm_display_excerpt() {
			if ( is_single() && has_excerpt() )
				wm_excerpt( 'wm_excerpt_length_blog', null );
		}
	} // /wm_display_excerpt



	/**
	 * "Read more" button
	 *
	 * $print = TEXT ["print" the value]
	 */
	if ( ! function_exists( 'wm_more' ) ) {
		function wm_more( $print = null, $nobtn = null ) {
			$out = '<a href="' . get_permalink() . '" class="btn btn-more">' . apply_filters( 'wmhook_read_more_html', __( 'Read more &raquo;', 'jaguar_domain' ) ) . '</a>';

			if ( $nobtn )
				$out = '<a href="' . get_permalink() . '" class="more-link">' . apply_filters( 'wmhook_read_more_html', __( 'Read more &raquo;', 'jaguar_domain' ) ) . '</a>';

			if ( $print )
				echo $out;
			else
				return $out;
		}
	} // /wm_more



	/**
	 * Post meta info
	 *
	 * $positions = ARRAY [array of meta information positions]
	 */
	if ( ! function_exists( 'wm_meta' ) ) {
		function wm_meta( $positions = null, $class = null, $tag = 'footer' ) {
			if ( ( is_page() || is_front_page() || is_home() ) && ! $positions )
			  return;

			if ( ! $positions )
				$positions = array(
					'formaticon',
					'date',
					'comments',
					'cats',
					'author',
					'tags'
					);

			$out    = '';
			$format = ( get_post_format() ) ? ( get_post_format() ) : ( 'standard' );

			if ( ! empty( $positions ) ) {
				foreach ( $positions as $position ) {
					switch ( $position ) {
						case 'author':

							if ( ! wm_option( 'blog-disable-author' ) )
								$out .= '<span class="author vcard meta-item">' . apply_filters( 'wmhook_meta_text_author', sprintf( __( 'By %s', 'jaguar_domain' ), '<a href="' . get_author_posts_url( get_the_author_meta( 'ID' ) ) . '" rel="author">' . get_the_author() . '</a>' ) ) . '</span>';

						break;
						case 'cats':

							if ( ! wm_option( 'blog-disable-cats' ) )
								$out .= ( get_the_category_list( '' ) ) ? ( '<span class="categories meta-item">' . apply_filters( 'wmhook_meta_text_category', sprintf( __( 'In %s', 'jaguar_domain' ), get_the_category_list( ', ' ) ) ) . '</span>' ) : ( '' );

						break;
						case 'comments':

							if ( ! wm_option( 'blog-disable-comments-count' ) ) {
								$elementId = ( get_comments_number() ) ? ( '#comments' ) : ( '#respond' );
								$out      .= '<span class="comments meta-item"><a href="' . get_permalink() . $elementId . '">' . sprintf( __( 'Comments: %s', 'jaguar_domain' ), '<span class="comments-count" title="' . get_comments_number() . '">' . get_comments_number() . '</span>' ) . '</a></span>';
							}

						break;
						case 'date':

							if ( ! wm_option( 'blog-disable-date' ) )
								$out .= '<time datetime="' . get_the_date( DATE_W3C ) . '" class="date meta-item">' . get_the_date() . ', ' . get_the_time() . '</time>';

						break;
						case 'date-special':

							if ( ! wm_option( 'blog-disable-date' ) )
								$out .= '<time datetime="' . get_the_date( DATE_W3C ) . '" class="date meta-item">
									<span class="day">' . get_the_date( 'd' ) . '</span>
									<span class="month">' . get_the_time( 'M' ) . '</span>
									<span class="year">' . get_the_time( 'Y' ) . '</span>
									<span class="time">' . get_the_time() . '</span>
									</time>';

						break;
						case 'formaticon':

							$permalinkFormats = array( 'standard', 'gallery', 'image', 'link', 'video' );
							if ( 'link' === $format )
								$link = ( has_excerpt() ) ? ( esc_url( get_the_excerpt() ) ) : ( '#' );
							else
								$link = get_permalink();

							if ( ! wm_option( 'blog-disable-format' ) )
								$out .= ( in_array( $format, $permalinkFormats ) ) ? ( '<a href="' . $link . '" class="icon-format icon-format-' . $format . ' meta-item"></a>' ) : ( '<span class="icon-format icon-format-' . $format . ' meta-item"></span>' );

						break;
						case 'tags':

							if ( ! wm_option( 'blog-disable-tags' ) )
								$out .= ( get_the_tag_list( '', '', '' ) ) ? ( '<span class="tags meta-item">' . __( 'Tags: ', 'jaguar_domain' ) . get_the_tag_list( '', ', ', '' ) . '</span>' ) : ( '' );

						break;
						default:
						break;
					} // /switch
				} // /foreach

				$out = ( $out ) ? ( '<' . $tag . ' class="meta-article border-color">' . $out . '</' . $tag . '>' ) : ( '' );
			} // /if $position

			$sharing = apply_filters( 'wm_sharing', '' );

			echo apply_filters( 'wmhook_meta_html', $out ) . $sharing;
		}
	} // /wm_meta



	/**
	 * Post/page parts pagination
	 */
	if ( ! function_exists( 'wm_post_parts' ) ) {
		function wm_post_parts() {
			wp_link_pages( array(
				'before'         => '<p class="pagination post">',
				'after'          => '</p>',
				'next_or_number' => 'number',
				'pagelink'       => '<span class="page-numbers">' . __( 'Part', 'jaguar_domain' ) . ' %</span>',
			) );
		}
	} // /wm_post_parts



	/**
	 * Post author info
	 */
	if ( ! function_exists( 'wm_author_info' ) ) {
		function wm_author_info() {
			$authorDescription = get_the_author_meta( 'description' );

			if (
					$authorDescription &&
					is_single() &&
					'post' == get_post_type() &&
					! ( wm_meta_option( 'author' ) || wm_option( 'blog-disable-bio' ) )
				) {

				$authorDescription = explode( '<!--more-->', $authorDescription ); //allows using WordPress more tag to display short description on single posts and full info on author archives pages

				$authorName     = get_the_author_meta( 'display_name' );
				$authorWebsite  = ( get_the_author_meta( 'user_url' ) ) ? ( apply_filters( 'wmhook_authorbox_html_website', ' <a href="' . esc_url( get_the_author_meta( 'user_url' ) ) . '">[' . __( 'More about the author', 'jaguar_domain' ) . ']</a>' ) ) : ( '' );
				$authorPostsUrl = get_author_posts_url( get_the_author_meta( 'ID' ) );
				$authorAvatar   = get_avatar( get_the_author_meta( 'ID' ), apply_filters( 'wmhook_author_bio_avatar_size', 64 ) );

				$out = '<div class="bio border-color">';
				$out .= '<div class="avatar-container"><a href="' . $authorPostsUrl . '">' . $authorAvatar . '</a></div><h4 class="mt0"><small>' . apply_filters( 'wmhook_authorbox_text_by', __( 'By', 'jaguar_domain' ) ) . '</small> <a href="' . $authorPostsUrl . '">' . $authorName . '</a></h4>';

				$outSocial = '';
				if ( get_the_author_meta( 'facebook' ) )
					$outSocial .= '<a href="' . esc_url( get_the_author_meta( 'facebook' ) ) . '" title="' . $authorName . __( ' on Facebook', 'jaguar_domain' ) . '" class="facebook">Facebook</a>';
				if ( get_the_author_meta( 'googleplus' ) )
					$outSocial .= '<a href="' . esc_url( get_the_author_meta( 'googleplus' ) ) . '" title="' . $authorName . __( ' on Google+', 'jaguar_domain' ) . '" class="googleplus">Google+</a>';
				if ( get_the_author_meta( 'twitter' ) )
					$outSocial .= '<a href="' . esc_url( get_the_author_meta( 'twitter' ) ) . '" title="' . $authorName . __( ' on Twitter', 'jaguar_domain' ) . '" class="twitter">Twitter</a>';

				if ( $outSocial )
					$out .= '<div class="social-small">' . $outSocial . '</div>';

				$out .= '<div class="desc">' . do_shortcode( wptexturize( trim( $authorDescription[0] ) ) ) . $authorWebsite . '</div>';

				$out .= '</div> <!-- /author-details -->';

				echo $out;

			}
		}
	} // /wm_author_info



	/**
	 * Prints no content found message
	 */
	if ( ! function_exists( 'wm_not_found' ) ) {
		function wm_not_found() {
			$out = '<article class="not-found">';
			$out .= '<h2>' . __( 'No item found', 'jaguar_domain' ) . '</h2>';
			$out .= '<p>' . __( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related content.', 'jaguar_domain' ) . '</p>';
			$out .= '</article>';

			echo apply_filters( 'wmhook_not_fount_html', $out );
		}
	} // /wm_not_found





/*
*****************************************************
*      OTHER FUNCTIONS
*****************************************************
*/
	/**
	 * Check WordPress version
	 *
	 * $version = #FLOAT ["3.1" - at least this version]
	 */
	if ( ! function_exists( 'wm_check_wp_version' ) ) {
		function wm_check_wp_version( $version = '3.0' ) {
			global $wp_version;

			return version_compare( floatval( $wp_version ), $version, '>=' );
		}
	} // /wm_check_wp_version



	/**
	 * Prevent your email address from stealing (requires jQuery functions)
	 *
	 * $email  = TEXT [email address to encrypt]
	 * $method = TEXT ["wp" encrypt method]
	 */
	if ( ! function_exists( 'wm_nospam' ) ) {
		function wm_nospam( $email, $method = null ) {
			if ( ! isset( $email ) || ! $email )
				return;

			if ( 'wp' == $method ) {
				$email = antispambot( $email );
			} else {
				$email = strrev( $email );
				$email = preg_replace( '[@]', ']ta[', $email );
				$email = preg_replace( '[\.]', '/', $email );
			}

			return $email;
		}
	} // /wm_nospam



	/**
	 * CSS output minimizer
	 *
	 * $buffer = TEXT [code text to minimize]
	 */
	if ( ! function_exists( 'wm_minimize_css' ) ) {
		function wm_minimize_css( $buffer ) {
			$buffer = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer ); //remove css comments
			$buffer = str_replace( array( "\r\n", "\r", "\n", "\t", "  ", "    " ), '', $buffer ); //remove tabs, spaces, line breaks, etc.

			return $buffer;
		}
	} // /wm_minimize_css



	/**
	 * Custom avatar
	 *
	 * $avatar_defaults = ARRAY [default WordPress gravatars array]
	 */
	if ( ! function_exists( 'wm_custom_avatar' ) ) {
		function wm_custom_avatar( $avatar_defaults ) {
			$customAvatar = WM_ASSETS_THEME . 'img/gravatar.gif';
			$avatar_defaults[$customAvatar] = get_bloginfo( 'name' );

			return $avatar_defaults;
		}
	} // /wm_custom_avatar



	/**
	 * Get background CSS styles
	 *
	 * $optionBase = TEXT [wm_option base name (option full name minus function suffixes: bg-color, bg-img-url, bg-img-repeat, bg-img-attachment, bg-img-position, bg-pattern)]
	 */
	if ( ! function_exists( 'wm_css_background' ) ) {
		function wm_css_background( $optionBase = '' ) {
			$patternsSubfolder = 'img/patterns/';
			$patternFileFormat = '.png';

			//get background color
			$bgColor = ( wm_option( $optionBase . 'bg-color' ) ) ? ( '#' . wm_option( $optionBase . 'bg-color' ) ) : ( '' );

			//get background image
			if ( wm_option( $optionBase . 'bg-pattern' ) )
				$bgImg = ' url(' . esc_url( WM_ASSETS_THEME . $patternsSubfolder . wm_option( $optionBase . 'bg-pattern' ) . $patternFileFormat ) . ')';
			else
				$bgImg = ( wm_option( $optionBase . 'bg-img-url' ) ) ? ( ' url(' . esc_url( wm_option( $optionBase . 'bg-img-url' ) ) . ')' ) : ( '' );

			$bgImgRepeat     = ( wm_option( $optionBase . 'bg-img-repeat' ) ) ? ( ' ' . wm_option( $optionBase . 'bg-img-repeat' ) ) : ( '' );
			$bgImgAttachment = ( wm_option( $optionBase . 'bg-img-attachment' ) ) ? ( ' ' . wm_option( $optionBase . 'bg-img-attachment' ) ) : ( '' );
			$bgImgPosition   = ( wm_option( $optionBase . 'bg-img-position' ) ) ? ( ' ' . wm_option( $optionBase . 'bg-img-position' ) ) : ( '' );
			$bgImgParameters = $bgImgRepeat . $bgImgAttachment . $bgImgPosition;

			if ( wm_option( $optionBase . 'bg-pattern' ) )
				$bgImgParameters = ' repeat' . $bgImgAttachment;

			if ( $bgImg )
				$bgImg .= $bgImgParameters;

			if ( $bgColor || $bgImg )
				return ( $bgColor . $bgImg );
		}
	} // /wm_css_background



	/**
	 * Get background CSS styles from post meta
	 *
	 * $optionBase = TEXT [wm_meta_option base name (option full name minus function suffixes: bg-color, bg-img-url, bg-img-repeat, bg-img-attachment, bg-img-position, bg-pattern)]
	 */
	if ( ! function_exists( 'wm_css_background_meta' ) ) {
		function wm_css_background_meta( $optionBase = '' ) {
			$patternsSubfolder = 'img/patterns/';
			$patternFileFormat = '.png';
			$postId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );

			//get background color
			$bgColor = ( wm_meta_option( $optionBase . 'bg-color', $postId ) ) ? ( '#' . wm_meta_option( $optionBase . 'bg-color', $postId ) ) : ( '' );

			//get background image
			if ( wm_meta_option( $optionBase . 'bg-pattern', $postId ) )
				$bgImg = ' url(' . esc_url( WM_ASSETS_THEME . $patternsSubfolder . wm_meta_option( $optionBase . 'bg-pattern', $postId ) . $patternFileFormat ) . ')';
			else
				$bgImg = ( wm_meta_option( $optionBase . 'bg-img-url', $postId ) ) ? ( ' url(' . esc_url( wm_meta_option( $optionBase . 'bg-img-url', $postId ) ) . ')' ) : ( '' );

			$bgImgRepeat     = ( wm_meta_option( $optionBase . 'bg-img-repeat', $postId ) ) ? ( ' ' . wm_meta_option( $optionBase . 'bg-img-repeat', $postId ) ) : ( '' );
			$bgImgAttachment = ( wm_meta_option( $optionBase . 'bg-img-attachment', $postId ) ) ? ( ' ' . wm_meta_option( $optionBase . 'bg-img-attachment', $postId ) ) : ( '' );
			$bgImgPosition   = ( wm_meta_option( $optionBase . 'bg-img-position', $postId ) ) ? ( ' ' . wm_meta_option( $optionBase . 'bg-img-position', $postId ) ) : ( '' );
			$bgImgParameters = $bgImgRepeat . $bgImgAttachment . $bgImgPosition;

			if ( wm_meta_option( $optionBase . 'bg-pattern', $postId ) )
				$bgImgParameters = ' repeat' . $bgImgAttachment;

			if ( $bgImg )
				$bgImg .= $bgImgParameters;

			if ( $bgColor || $bgImg )
				return ( $bgColor . $bgImg );
		}
	} // /wm_css_background_meta



	/**
	 * Custom feed link
	 */
	if ( ! function_exists( 'wm_custom_feed' ) ) {
		function wm_custom_feed() {
			$customRSS = wm_social_links( array(
				'links'    => wm_option( 'contact-social' ),
				'networks' => array( 'rss' )
				 ) );

			$customRSS = $customRSS['rss'];

			if ( empty( $customRSS ) )
				return;

			if ( 1 < count( $customRSS ) )
				$i = 1;
			else
				$i = null;

			foreach ( $customRSS as $feed ) {
				$j = ( $i ) ? ( ' ' . $i ) : ( null );
				echo '<link rel="alternate" type="application/rss+xml" title="' . get_bloginfo( 'name' ) . __( ' feed', 'jaguar_domain' ) . $j . '" href="' . $feed . '" />' . "\r\n";
				$i++;
			}
		}
	} // /wm_custom_feed



	/**
	 * Remove invalid HTML5 rel attribute
	 */
	if ( ! function_exists( 'wm_remove_rel' ) ) {
		function wm_remove_rel( $link ) {
			return ( str_replace ( 'rel="category tag"', '', $link ) );
		}
	} // /wm_remove_rel



	/**
	 * Exclude post formats from feed
	 */
	if ( ! function_exists( 'wm_feed_exclude_post_formats' ) ) {
		function wm_feed_exclude_post_formats( &$wp_query ) {
			if ( $wp_query->is_feed() ) {

				//post formats to exclude by slug
				$formatsToExclude = array(
					'post-format-aside',
					'post-format-chat',
					'post-format-status'
					);

				//extra query to hack onto the $wp_query
				$extraQuery = array(
					'taxonomy' => 'post_format',
					'field'    => 'slug',
					'terms'    => $formatsToExclude,
					'operator' => 'NOT IN'
					);

				$query = $wp_query->get( 'tax_query' );

				if ( is_array( $query ) )
					$query = $query + $extraQuery;
				else
					$query = array( $extraQuery );

				$wp_query->set( 'tax_query', $query );
			}
		}
	} // /wm_feed_exclude_post_formats



	/**
	 * Include post types in feed
	 */
	if ( ! function_exists( 'wm_feed_include_post_types' ) ) {
		function wm_feed_include_post_types( $query ) {
			if ( isset( $query['feed'] ) && ! isset( $query['post_type'] ) )
				$query['post_type'] = array( 'post', 'wm_portfolio' );

			return $query;
		}
	} // /wm_feed_include_post_types



	/**
	 * Color brightness detection
	 *
	 * $hex = HEX [color hex string (either ffffff or fff, without "#")]
	 */
	if ( ! function_exists( 'wm_color_brightness' ) ) {
		function wm_color_brightness( $hex ) {
			$hex = preg_replace( "/[^0-9A-Fa-f]/", '', $hex );
			$rgb = array();

			if ( 6 == strlen( $hex ) ) {

				$color    = hexdec( $hex );
				$rgb['r'] = 0xFF & ( $color >> 0x10 );
				$rgb['g'] = 0xFF & ( $color >> 0x8 );
				$rgb['b'] = 0xFF & $color;

			} elseif ( 3 == strlen( $hex ) ) { //if shorthand notation, need some string manipulations

				$rgb['r'] = hexdec( str_repeat( substr( $hex, 0, 1 ), 2 ) );
				$rgb['g'] = hexdec( str_repeat( substr( $hex, 1, 1 ), 2 ) );
				$rgb['b'] = hexdec( str_repeat( substr( $hex, 2, 1 ), 2 ) );

			} else {
				return;
			}

			$brightness = ( ( $rgb['r'] * 299 ) + ( $rgb['g'] * 587 ) + ( $rgb['b'] * 114 ) ) / 1000; //returns value from 0 to 255

			return $brightness;
		}
	} // /wm_color_brightness



	/**
	 * Social share buttons
	 */
	if ( ! function_exists( 'wm_social_share_buttons' ) ) {
		function wm_social_share_buttons() {
			if ( ! is_single() || wm_meta_option( 'no-sharing' ) )
				return;

			$out = '';
			static $sharingLocation = 0;

			if ( wm_option( 'contact-share-facebook' ) )
				$out .= '<div class="share-button facebook"><div class="fb-like" data-href="' . get_permalink() . '" data-send="false" data-layout="button_count" data-width="80" data-show-faces="true"></div></div>';

			if ( wm_option( 'contact-share-twitter' ) )
				$out .= '<div class="share-button twitter"><a href="https://twitter.com/share" class="twitter-share-button" data-url="' . get_permalink() . '" data-lang="en">Tweet</a></div>';

			if ( wm_option( 'contact-share-googleplus' ) )
				$out .= '<div class="share-button googleplus"><div class="g-plusone" data-size="medium" data-href="' . get_permalink() . '"></div></div>';

			if ( wm_option( 'contact-share-pinterest' ) ) {
				$image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'medium' );
				$out .= '<div class="share-button pinterest"><a href="http://pinterest.com/pin/create/button/?url=' . urlencode( get_permalink() ) . '&media=' . urlencode( $image[0] ) . '&description=' . urlencode( get_the_excerpt() ) . '" class="pin-it-button" count-layout="horizontal" target="_blank"><img src="//assets.pinterest.com/images/PinExt.png" title="Pin It" alt="" /></a></div>';
			}

			if ( $out )
				return '<div class="social-share sharing-location-' . ++$sharingLocation . '">' . $out . '</div>';
		}
	} // /wm_social_share_buttons



	/**
	 * Displays social networks links
	 *
	 * $args = ARRAY [array of settings:
	 		class_container = TEXT [CSS classes applied on links container DIV]
			class_item      = TEXT [CSS classes applied on a link item]
			links           = ARRAY [array of links to process (for RSS link, prepend the link with "rss=")]
			networks        = ARRAY [array of accepted social networks names]
			]
	 */
	if ( ! function_exists( 'wm_social_links' ) ) {
		function wm_social_links( $args = array() ) {
			$defaults = array(
				'class_container' => 'container',
				'class_item'      => 'item',
				'links'           => array(),
				'networks'        => array()
				);
			$args = wp_parse_args( $args, $defaults );

			$customRSS = array();

			//do nothing if no links or networks set
			if ( ! is_array( $args['links'] ) || empty( $args['links'] ) || ! is_array( $args['networks'] ) || empty( $args['networks'] ) )
				return;

			$target = ( wm_option( 'contact-social-new-tab' ) ) ? ( ' target="_blank"' ) : ( null );

			$out = '';

			foreach ( $args['links'] as $socialLink ) {
				if ( 0 === strpos( $socialLink, 'rss:' ) ) {
				//RSS link

					$socialLink = str_replace( 'rss:', '', $socialLink );

					$out .= '<a href="' . esc_url( $socialLink ) . '"' . $target . ' class="ico-rss"><img alt="' . get_bloginfo( 'name' ) . __( ' RSS feed', 'jaguar_domain' ) . '" title="' . get_bloginfo( 'name' ) . __( ' RSS feed', 'jaguar_domain' ) . '" src="' . WM_ASSETS_THEME . 'img/icons/social/rss.png" /></a>';
					$customRSS[] = esc_url( $socialLink );

				} else {
				//other link

					$fullUrlSplit    = explode( '.', esc_url( $socialLink ) );
					$fullUrlSplit[0] = str_replace( array( 'http://', 'https://' ), '', $fullUrlSplit[0] );
					$fullUrlSplit    = implode( '/', $fullUrlSplit );
					$fullUrlSplit    = explode( '/', $fullUrlSplit );
					$networkName     = array_search( 'com', $fullUrlSplit );
					$networkName     = ( $networkName ) ? ( $fullUrlSplit[ $networkName - 1 ] ) : ( null );

					if ( $networkName ) {
						if ( 'google' === $networkName )
							$network = 'googleplus';
						else
							$network = $networkName;

						if ( isset( $network ) && $network && in_array( $network, $args['networks'] ) ) {
							$networkName = ( 'googleplus' === $network ) ? ( 'plus.google.com' ) : ( $network . '.com' );
							$out .= '<a href="' . esc_url( $socialLink ) . '"' . $target . ' class="ico-' . $network . ' ' . $args['class_item'] . '"><img alt="' . get_bloginfo( 'name' ) . __( ' on ', 'jaguar_domain' ) . ucfirst( $network ) . '" title="' . get_bloginfo( 'name' ) . __( ' on ', 'jaguar_domain' ) . $networkName . '" src="' . WM_ASSETS_THEME . 'img/icons/social/' . $network . '.png" /></a>';
						}
					}

				}
			}

			$output          = array();
			$output['links'] = ( $out ) ? ( '<div class="social-links ' . $args['class_container'] . '">' . $out . '</div>' ) : ( '' );
			$output['rss']   = ( isset( $customRSS ) ) ? ( $customRSS ) : ( null );

			return $output;
		}
	} // /wm_social_links

?>