/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Admin scripts
*
* @version  2.9
*
* CONTENT:
* - 1) Widgets
* - 2) Contextual help toggles
* - 3) Gallery settings
* - 4) Tipsy
* - 5) Setting post ID when adding a new post
*****************************************************
*/

jQuery(function() {



//open "View" button in new window
jQuery( '#view-post-btn a, .view a' ).attr( 'target', '_blank' );

//top of page link
jQuery( '.wm-wrap .separator.top a' ).click( function() {
		jQuery( 'html, body' ).animate({ scrollTop: 0 }, 400 );
		return false;
	} );



/*
*****************************************************
*      1) WIDGETS
*****************************************************
*/
	jQuery( '#widgets-right div.widgets-holder-wrap' ).addClass( 'closed' );
	jQuery( 'div[id*="wmcs-"]' ).prev( 'div.sidebar-name' ).addClass( 'custom-sidebar-name' );

	var $descriptions = jQuery( "#widgets-right .sidebar-description .description" );

	$descriptions.each( function( item ) {
		var $this     = jQuery( this ),
		    $thisText = $this.text();

		$thisText = $thisText.replace( "[", "<strong>Shortcode:</strong><br /><input type='text' onfocus='this.select();' readonly='readonly' value='[" );
		$thisText = $thisText.replace( "]", "]' class='widefat' /></p><p>" );

		$this.html( $thisText );
	} );



/*
*****************************************************
*      2) CONTEXTUAL HELP TOGGLES
*****************************************************
*/
	jQuery( 'div.contextual-help-tab-content.toggle-content, div.shortcode-help-content' ).hide();
	jQuery( 'div.shortcode-help-content' ).prev( 'h3' ).addClass( 'small-toggle-title' );

	jQuery( 'h2.contextual-help-tab-title.toggle-title, .small-toggle-title' ).click( function() {
		jQuery( this ).toggleClass( 'active' ).next( 'div.contextual-help-tab-content.toggle-content, div.shortcode-help-content' ).slideToggle().toggleClass( 'active' );
	} );



/*
*****************************************************
*      3) GALLERY SETTINGS
*****************************************************
*/
	jQuery( '#gallery-settings tbody tr:first-child' ).hide();
	jQuery( '#gallery-settings select#columns option[value="1"], #gallery-settings select#columns option[value="2"]' ).remove();



/*
*****************************************************
*      4) TIPSY
*****************************************************
*/
	if ( jQuery().tipsy ) {
		jQuery( '.tipsy' ).tipsy( {
				fade     : true,
				gravity  : 's',
				title    : 'title',
				offset   : 2,
				opacity  : 0.95,
				delayIn  : 500,
				delayOut : 0,
				fade     : false,
				html     : false
			} );
	} // /tipsy



/*
*****************************************************
*      5) SETTING POST ID WHEN ADDING A NEW POST
*****************************************************
*/
	if ( jQuery( 'body.post-new-php input#post_ID' ).length ) {
		var postIdToSet = jQuery( 'body.post-new-php input#post_ID' ).val();

		jQuery( '.js-post-id' ).each( function() {
				var $this        = jQuery( this ),
				    originalHref = $this.attr( 'href' );

				$this.attr( 'href', originalHref.replace( '{{{post_id}}}', postIdToSet ) );
			} );
	}



});