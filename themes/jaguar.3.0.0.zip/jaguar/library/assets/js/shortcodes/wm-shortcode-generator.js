/**
 * WebMan Shortcode Generator
 *
 * @version  1.1
 */



( function() {

	tinymce.PluginManager.add( 'wmShortcodes', function( editor, url ) {

		var url = ( 'undefined' === typeof wmShortcodesAssetsURL ) ? ( '' ) : ( wmShortcodesAssetsURL ),
		    wmShortcodesMenuArray   = new Array(),
		    wmShortcodesHelper      = ( 'undefined' === typeof wmShortcodesArray ) ? ( [{name:'Shortcode',code:'',class:'shortcode'}] ) : ( wmShortcodesArray );

		//Set the menu button items (default)
			for ( var i in wmShortcodesHelper ) {
				wmShortcodesMenuArray[i] = {
						text    : wmShortcodesHelper[i]['name'],
						id      : 'wm' + ( '0' + i ).slice( -2 ) + '_' + wmShortcodesHelper[i]['class'],
						class   : wmShortcodesHelper[i]['class'],
						onclick : function( wholeMenuButton ) {
								var menuId = wholeMenuButton.srcElement.id;

								menuId = parseInt( menuId.substring( 2, 4 ) );

								//Retrieve the shortcode content based on menu button item ID pressed
								if ( '' != editor.selection.getContent() ) {

									var shortcodeOutput = wmShortcodesHelper[menuId]['code'].replace( '{{content}}', editor.selection.getContent() );

									editor.selection.setContent( shortcodeOutput );

								} else {

									var shortcodeOutput = wmShortcodesHelper[menuId]['code'].replace( '{{content}}', 'TEXT' );

									editor.selection.setContent( shortcodeOutput );

								}
							}
					};
			}



		//Shortcode Generator Button
			editor.addButton( 'wm_shortcodes_list', {

				type  : 'menubutton',
				text  : '[s]',
				title : 'Shortcode',
				id    : 'wm_shortcodes_list',
				icon  : false,
				menu  : wmShortcodesMenuArray

			} );

	} );

} )();