<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Basic theme setup
*****************************************************
*/

/**
 * @version  2.9
 */



/*
*****************************************************
*      ACTIONS AND FILTERS
*****************************************************
*/
	//ACTIONS
		//Adding assets into HTML head
		add_action( 'wp_enqueue_scripts', 'wm_site_assets', 998 );
		//Blog page query modification
		add_action( 'pre_get_posts', 'wm_home_query', 1 );

	//FILTERS
		//Remove <p> tag from excerpt:
		remove_filter( 'the_excerpt', 'wpautop' );
		//WordPress header additions
		add_filter( 'wp_head', 'wm_head_styles', 9998 );
		//BODY classes
		add_filter( 'body_class', 'wm_body_classes' );
		//Next/prev post
		add_action( 'wmhook_portfolio_item_next_prev', 'wm_prevnext_post', 5 );





/*
*****************************************************
*      SECURITY
*****************************************************
*/
	//Generic login error messages
	if ( ! function_exists( 'wm_login_generic_message' ) ) {
		function wm_login_generic_message() {
			return __( 'It seems something went wrong...', 'jaguar_domain_adm' );
		}
	} // /wm_login_generic_message

	//Hide login errors
	if ( wm_option( 'security-login-error' ) )
		add_filter( 'login_errors', 'wm_login_generic_message' );

	//Remove WP version from HTML header
	if ( wm_option( 'security-wp-version' ) )
		remove_action( 'wp_head', 'wp_generator' );

	//Rremove Windows Live Writer support
	if ( wm_option( 'security-live-writer' ) )
		remove_action( 'wp_head', 'wlwmanifest_link' );





/*
*****************************************************
*      THEME SUPPORT
*****************************************************
*/
	//Post formats
	add_theme_support( 'post-formats', array( 'gallery', 'link', 'quote', 'status', 'video', 'audio' ) );

	//Feed links
	$customRSS = wm_social_links( array(
		'links'    => wm_option( 'contact-social' ),
		'networks' => array( 'rss' )
		 ) );
	if ( ! $customRSS['rss'] )
		add_theme_support( 'automatic-feed-links' );

	//Custom menus
	add_theme_support( 'menus' );
	//register menus
	register_nav_menus( array(
		'main-navigation'   => __( 'Main navigation', 'jaguar_domain_adm' ),
		'footer-navigation' => __( 'Footer navigation', 'jaguar_domain_adm' )
		) );

	//Thumbnails support
	add_theme_support( 'post-thumbnails' ); //thumbs just for posts in categories
	//image sizes (x, y, crop)
	//frontend image sizes
	add_image_size( 'blog', 720, 200, true );
	add_image_size( 'portfolio', 720, 720, true );
	add_image_size( 'portfolio-no-crop', 720, 9999, false );
	add_image_size( 'widget', 50, 50, true );
	add_image_size( 'logo', 80, 60, false );
	//slider image size
	add_image_size( 'slide', WM_SLIDER_IMAGE_WIDTH, WM_SLIDER_IMAGE_HEIGHT, true );





/*
*****************************************************
*      LOCALIZATION
*****************************************************
*/
	load_theme_textdomain( $shortname . '_domain', WM_LANGUAGES );
	if( is_admin() ) {
		load_theme_textdomain( $shortname . '_domain_adm', WM_LANGUAGES . '/admin' );
		load_theme_textdomain( $shortname . '_domain_help', WM_LANGUAGES . '/help' );
	}
	if( is_admin() && current_user_can( 'switch_themes' ) )
		load_theme_textdomain( $shortname . '_domain_panel', WM_LANGUAGES . '/wm-admin-panel' );





/*
*****************************************************
*      OTHERS
*****************************************************
*/
	/**
	 * Frontend HTML head assets
	 *
	 * @version  2.9
	 */
	if ( ! function_exists( 'wm_site_assets' ) ) {
		function wm_site_assets() {
			global $post;

			//styles
			if ( ! wm_option( 'general-no-lightbox' ) )
				wp_enqueue_style( 'prettyphoto' );

			if ( ! wm_option( 'general-tipsy' ) )
				wp_enqueue_style( 'tipsy' );

			if( isset( $post ) && 'wm_portfolio' === $post->post_type && 'slider' === wm_meta_option( 'portfolio-type' ) )
				wp_enqueue_style( 'simple-slider' );

			wp_enqueue_style( 'wm-global' );
			wp_enqueue_style( 'wm-print' );

			//scripts
			if ( ! wm_option( 'general-no-lightbox' ) )
				wp_enqueue_script( 'prettyphoto' );
			if ( ! wm_option( 'general-tipsy' ) )
				wp_enqueue_script( 'tipsy' );

			if ( isset( $post ) && 'pagetpl-portfolio.php' == get_post_meta( $post->ID, '_wp_page_template', TRUE ) && wm_meta_option( 'portfolio-filterable' ) ) {
				wp_enqueue_script( 'quicksand' );
				wp_enqueue_script( 'portfolio' );
			}

			if( isset( $post ) && 'wm_portfolio' === $post->post_type && 'slider' === wm_meta_option( 'portfolio-type' ) )
				wp_enqueue_script( 'simple-slider' );

			wp_enqueue_script( 'wm-theme-scripts' );
			if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
				wp_enqueue_script( 'comment-reply', false, false, false, true ); //true to put it into footer
		}
	} // /wm_site_assets



	/**
	 * BODY classes
	 */
	if ( ! function_exists( 'wm_body_classes' ) ) {
		function wm_body_classes( $classes ) {
			global $post, $paged, $page;

			if ( ! isset( $paged ) )
				$paged = 0;
			if ( ! isset( $page ) )
				$page = 0;

			$paginated = false;
			if ( 1 < $paged || 1 < $page )
				$paginated = true;

			//variables needed
				//post ID
				$postId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );
				//top panel display boolean variable
				$isTopBar = is_active_sidebar( 'top-bar-widgets' ) && ! ( ! is_archive() && ! is_search() && wm_meta_option( 'no-top-bar', $postId ) ) && ! is_page_template( 'tpl-landing.php' ) && ! is_page_template( 'tpl-construction.php' );

			//body classes
				$bodyClass = array();

				//boxed layout?
					if ( 'boxed' === wm_option( 'layout-boxed' ) ) {
						$bodyClass[] = 'boxed';
					} else {
						$bodyClass[] = 'no-boxed';
					}

				//icon scheme
					if ( wm_option( 'design-icon-scheme' ) ) {
						$bodyClass[] = wm_option( 'design-icon-scheme' ) . '-icon-scheme';
					} else {
						$bodyClass[] = 'dark-icon-scheme';
					}

				//top bar
					if (
							is_active_sidebar( 'top-bar-widgets' )
							&& ! wm_meta_option( 'no-top-bar', $postId )
							&& wm_option( 'layout-top-bar-fixed' )
						) {
						$bodyClass[] = 'top-bar-fixed';
					}

			//output
			$classes = array_merge( $classes, $bodyClass );

			return $classes;
		}
	} // /wm_body_classes



	/**
	 * WordPress head styles
	 */
	if ( ! function_exists( 'wm_head_styles' ) ) {
		function wm_head_styles() {
			global $post;

			//variables needed
				//post ID
				$postId = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );

			//custom in-header styles
				$inHeaderStyles = '';

				//page background image
					if (
							( isset( $post ) || is_home() )
							&& ! is_search() && ! is_archive()
							&& wm_css_background_meta( 'background-' )
							&& ! wm_meta_option( 'background-bg-img-fit-window', $postId )
						) {
						$inHeaderStyles .= 'body.boxed{background:' . wm_css_background_meta( 'background-' ) . '}' . "\r\n";
					}

				//roundabout slider settings
					if (
							( isset( $post ) || is_home() )
							&& wm_meta_option( 'slider-roundabout-width' )
						) {
						$inHeaderStyles .= 'ul.roundabout-slider{width:' . ( 960 + intval( wm_meta_option( 'slider-roundabout-width' ) ) ) . 'px}' . "\r\n";
					}

			//output
			if ( $inHeaderStyles )
				$inHeaderStyles = "\r\n<!-- Custom header styles -->\r\n" . '<style type="text/css">' . "\r\n" . $inHeaderStyles . '</style>' . "\r\n";

			echo $inHeaderStyles;
		}
	} // /wm_head_styles



	/**
	 * Modify blog page query
	 */
	if ( ! function_exists( 'wm_home_query' ) ) {
		function wm_home_query( $query ) {
			if ( $query->is_home() && $query->is_main_query() ) {
				global $page, $paged;

			 	$articleCount = ( wm_option( 'blog-posts-count' ) ) ? ( wm_option( 'blog-posts-count' ) ) : ( '' );
				$catsAction   = ( wm_option( 'blog-cats-action' ) ) ? ( wm_option( 'blog-cats-action' ) ) : ( 'category__not_in' );
				$cats         = ( wm_option( 'blog-cats' ) ) ? ( array_filter( wm_option( 'blog-cats' ) ) ) : ( array() );
				if ( 0 < count( $cats ) ) {
					$cats = implode( ',', $cats ); /* rearange array keys */
					$cats = explode( ',', $cats ); /* rearange array keys */
				}

				$query->set( 'posts_per_page', absint( $articleCount ) );
				if ( 0 < count( $cats ) )
					$query->set( $catsAction, $cats );
			}
		}
	} // /wm_home_query



	/**
	 * Previous and next post/project links
	 *
	 * @since  2.9
	 */
	if ( ! function_exists( 'wm_prevnext_post' ) ) {
		function wm_prevnext_post() {
			//Helper variables
				$excluded_categories = $output = '';
				$in_same_cat         = true;
				$taxonomy            = apply_filters( 'wmhook_wm_prevnext_post_taxonomy', 'wm-tax-cats-portfolio' );
				$posts               = array(
						get_previous_post( $in_same_cat, $excluded_categories, $taxonomy ),
						get_next_post( $in_same_cat, $excluded_categories, $taxonomy ),
					);

			//Preparing output
				$output .= '<footer class="meta-article">';
				if ( $posts[0] ) {
					$output .= '<span class="meta-item prev"><a href="' . get_permalink( $posts[0]->ID ) . '" title="' . sprintf( __( 'Previous item: %s', 'jaguar_domain' ), esc_attr( strip_tags( get_the_title( $posts[0]->ID ) ) ) ) . '">&laquo; ' . trim( get_the_title( $posts[0]->ID ) ) . '</a> ' . __( '(previous entry)', 'jaguar_domain' ) . '</span>';
				}
				if ( $posts[1] ) {
					$output .= '<span class="meta-item next">' . __( '(next entry)', 'jaguar_domain' ) . ' <a href="' . get_permalink( $posts[1]->ID ) . '" title="' . sprintf( __( 'Next item: %s', 'jaguar_domain' ), esc_attr( strip_tags( get_the_title( $posts[1]->ID ) ) ) ) . '">' . trim( get_the_title( $posts[1]->ID ) ) . ' &raquo;</a></span>';
				}
				$output .= '</footer>';

			//Output
				return apply_filters( 'wmhook_wm_prevnext_post_output', $output );
		}
	} // /wm_prevnext_post



	//Max content width
	if ( ! isset( $content_width ) )
		$content_width = 680;

?>