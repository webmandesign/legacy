<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Shortcodes Generator
*
* CONTENT:
* - 1) Actions and filters
* - 2) Assets
* - 3) TinyMCE integration
*****************************************************
*/





/*
*****************************************************
*      1) ACTIONS AND FILTERS
*****************************************************
*/
	$wmGeneratorIncludes = array( 'post.php', 'post-new.php' );
	if ( in_array( $pagenow, $wmGeneratorIncludes ) ) {
		add_action( 'admin_enqueue_scripts', 'wm_mce_assets', 998 );
		add_action( 'init', 'wm_shortcode_generator_button' );
	}





/*
*****************************************************
*      2) ASSETS
*****************************************************
*/
	/**
	 * Assets files
	 */
	if ( ! function_exists( 'wm_mce_assets' ) ) {
		function wm_mce_assets() {
			$shortcodes = array(
					array(
						'name'  => 'Placeholder',
						'code'  => '[placeholder attribute=""]{{content}}[/placeholder]',
						'class' => 'generator_item_' . 'placeholder',
					),
				);

			include_once( 'a-shortcodes.php' );

			wp_localize_script( 'jquery', 'wmShortcodesArray', $shortcodes );
			wp_localize_script( 'jquery', 'wmShortcodesAssetsURL', WM_ASSETS_ADMIN );
			wp_enqueue_style( 'wm-shortcodes-generator' );
		}
	} // /wm_mce_assets





/*
*****************************************************
*      3) TINYMCE INTEGRATION
*****************************************************
*/
	/**
	 * Register custom visual editor plugin
	 */
	if ( ! function_exists( 'wm_register_tinymce_plugin' ) ) {
		function wm_register_tinymce_plugin( $plugin_array = array() ) {
				$plugin_array['wmShortcodes'] =	WM_ASSETS_ADMIN . 'js/shortcodes/wm-shortcode-generator.js';

				return $plugin_array;
		}
	} // /wm_register_tinymce_plugin



	/**
	 * Register visual editor custom button position
	 */
	if ( ! function_exists( 'wm_register_tinymce_buttons' ) ) {
		function wm_register_tinymce_buttons( $buttons ) {
			$wmButtons = array( '|', 'wm_shortcodes_list' );

			array_push( $buttons, implode( ',', $wmButtons ) );

			return $buttons;
		}
	} // /wm_register_tinymce_buttons



	/**
	 * Adding the button to visual editor
	 */
	if ( ! function_exists( 'wm_shortcode_generator_button' ) ) {
		function wm_shortcode_generator_button() {
			if ( ! ( current_user_can( 'edit_posts' ) || current_user_can( 'edit_pages' ) ) ) {
				return;
			}

			if ( 'true' == get_user_option( 'rich_editing' ) ) {
				add_filter( 'mce_external_plugins', 'wm_register_tinymce_plugin' );
				add_filter( 'mce_buttons_2', 'wm_register_tinymce_buttons' );
			}
		}
	} // /wm_shortcode_generator_button

?>