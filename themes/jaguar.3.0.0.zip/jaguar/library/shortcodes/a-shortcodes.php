<?php
/**
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Shortcodes for WebMan Shortcodes Generator
*****************************************************
*/

/**
 * @version  2.9
 */



/**
 * Shortcodes settings for Shortcode Generator
 */
$shortcodes = array(
		//Accordion
			array(
				'name'  => __( 'Accordion', 'jaguar_domain_adm' ),
				'code'  => '[accordion auto="0/1"][accordion_item title="ACCORDION_TITLE_1"]{{content}}[/accordion_item][accordion_item title="ACCORDION_TITLE_2"]TEXT[/accordion_item][/accordion]',
				'class' => 'generator_item_' . 'accordion',
			),

		//Button
			array(
				'name'  => __( 'Button', 'jaguar_domain_adm' ),
				'code'  => '[button url="#" type="gray/green/blue/orange/red" size="medium/large" color="" background=""]{{content}}[/button]',
				'class' => 'generator_item_' . 'button',
			),

		//Columns
			array(
				'name'  => __( 'Column', 'jaguar_domain_adm' ),
				'code'  => '[column type="1/2" last="0/1" class=""]{{content}}[/column]',
				'class' => 'generator_item_' . 'column',
			),

		//Content Module
			array(
				'name'  => __( 'Content Module', 'jaguar_domain_adm' ),
				'code'  => '[content_module module="MODULE_SLUG" button_text="" layout="center/NONE" no_link="0/1" no_title="0/1" no_thumb="0/1" /]',
				'class' => 'generator_item_' . 'content_module',
			),

		//Divider
			array(
				'name'  => __( 'Divider', 'jaguar_domain_adm' ),
				'code'  => '[divider type="space/top" height="20" no_border="0/1" /]',
				'class' => 'generator_item_' . 'divider',
			),

		//Dropcap
			array(
				'name'  => __( 'Dropcap', 'jaguar_domain_adm' ),
				'code'  => '[dropcap type="round/square"]{{content}}[/dropcap]',
				'class' => 'generator_item_' . 'dropcap',
			),

		//Lists
			array(
				'name'  => __( 'List', 'jaguar_domain_adm' ),
				'code'  => '[list type="arrow/arrow-invert/star/star-invert/check/check-invert/plus/plus-invert"]<ul><li>Item1</li><li>Item2</li><li>Item3</li></ul>[/list]',
				'class' => 'generator_item_' . 'list',
			),

		//Map
			array(
				'name'  => __( 'Map (Google)', 'jaguar_domain_adm' ),
				'code'  => '[map location="ADDRESS, CITY, COUNTRY" width="640" height="360" zoom="14" bubble="0/1" /]',
				'class' => 'generator_item_' . 'map',
			),

		//Markers
			array(
				'name'  => __( 'Marker', 'jaguar_domain_adm' ),
				'code'  => '[marker type="gray/green/blue/orange/red" color="" background=""]{{content}}[/marker]',
				'class' => 'generator_item_' . 'marker',
			),

		//Message/alert box
			array(
				'name'  => __( 'Message Box', 'jaguar_domain_adm' ),
				'code'  => '[msg type="gray/green/blue/orange/red" icon="info/question/check/warning"]{{content}}[/msg]',
				'class' => 'generator_item_' . 'msg',
			),

		//Pullquote
			array(
				'name'  => __( 'Pullquote', 'jaguar_domain_adm' ),
				'code'  => '[pullquote align="left/right"]{{content}}[/pullquote]',
				'class' => 'generator_item_' . 'pullquote',
			),

		//Tabs
			array(
				'name'  => __( 'Tabs', 'jaguar_domain_adm' ),
				'code'  => '[tabs][tab title="TAB_TITLE_1"]{{content}}[/tab][tab title="TAB_TITLE_2"]TEXT[/tab][/tabs]',
				'class' => 'generator_item_' . 'tabs',
			),

		//Toggle
			array(
				'name'  => __( 'Toggle', 'jaguar_domain_adm' ),
				'code'  => '[toggle title="TOGGLE_TITLE" open="0/1"]{{content}}[/toggle]',
				'class' => 'generator_item_' . 'toggle',
			),

		//Widgets
			array(
				'name'  => __( 'Widget Area', 'jaguar_domain_adm' ),
				'code'  => '[widgets area="WIDGET_AREA_ID" /]',
				'class' => 'generator_item_' . 'widgets',
			),
	);

?>