<?php
/*
*****************************************************
*      Jaguar WordPress Theme
*
*      Author: WebMan - www.webmandesign.eu
*      http://www.webmandesign.eu
*****************************************************
*/



/**
 * @version  2.9
 */



//Getting theme data
	$shortname = get_template();

	$themeData     = wp_get_theme( $shortname );
	$themeName     = $themeData->Name;
	$themeVersion  = $themeData->Version;

	if( ! $themeVersion ) {
		$themeVersion = '';
	}

	$options   = $widgetAreas = array();
	$shortname = str_replace( '-v' . $themeVersion, '', $shortname );



//Theme constants
	//Basic constants
		define( 'WM_THEME_NAME',      $themeName );
		define( 'WM_THEME_SHORTNAME', $shortname );
		define( 'WM_THEME_VERSION',   $themeVersion );

		define( 'WM_THEME_SETTINGS_PREFIX', 'wm-' );
		define( 'WM_THEME_SETTINGS',        WM_THEME_SETTINGS_PREFIX . $shortname );
		define( 'WM_THEME_SETTINGS_META',   WM_THEME_SETTINGS . '-meta' );
		define( 'WM_THEME_SETTINGS_STATIC', WM_THEME_SETTINGS . '-static' );

		define( 'WM_ADMIN_LIST_THUMB',         '50x50' ); //thumbnail size (width x height) on post/page/custom post listings
		define( 'WM_CSS_EXPIRATION',           ( WP_DEBUG || 2 > intval( get_option( WM_THEME_SETTINGS . '-installed' ) ) ) ? ( 30 ) : ( 1209600 ) ); //60sec * 60min * 24hours * 14days
		define( 'WM_DEFAULT_EXCERPT_LENGTH',   40 ); //words count
		define( 'WM_SCRIPTS_VERSION',          trim( WM_THEME_VERSION ) );
		define( 'WM_TWITTER_CACHE_EXPIRATION', 900 ); //60sec * 15min
		define( 'WM_WP_COMPATIBILITY',         3.9 );

	//Directories
		define( 'WM_CLASSES',    get_template_directory() . '/library/classes/' );
		define( 'WM_SKINS',      get_template_directory() . '/assets/css/colors/' );
		define( 'WM_CUSTOMS',    get_template_directory() . '/library/custom-posts/' );
		define( 'WM_HELP',       get_template_directory() . '/library/help/' );
		define( 'WM_HOOKS',      get_template_directory() . '/library/hooks/' );
		define( 'WM_LANGUAGES',  get_template_directory() . '/langs' );
		define( 'WM_LIBRARY',    get_template_directory() . '/library/' );
		define( 'WM_META',       get_template_directory() . '/library/meta/' );
		define( 'WM_OPTIONS',    get_template_directory() . '/library/options/' );
		define( 'WM_SHORTCODES', get_template_directory() . '/library/shortcodes/' );
		define( 'WM_SLIDERS',    get_template_directory() . '/library/sliders/' );
		define( 'WM_STYLES',     get_template_directory() . '/library/styles/' );
		define( 'WM_WIDGETS',    get_template_directory() . '/library/widgets/' );

	//URLs
		define( 'WM_ASSETS_THEME',      get_template_directory_uri() . '/assets/' );
		define( 'WM_ASSETS_ADMIN',      get_template_directory_uri() . '/library/assets/' );
		define( 'WM_SHORTCODES_URI',    get_template_directory_uri() . '/library/shortcodes/' );
		define( 'WM_PLACEHOLDER_SLIDE', get_template_directory_uri() . '/assets/img/slide.gif' );
		define( 'WM_ONLINE_MANUAL_URL', 'http://www.webmandesign.eu/manual/' . $shortname . '/' );

	//Theme layout constants
		//slider image size width x height
		define( 'WM_SLIDER_IMAGE_WIDTH',  1200 );
		define( 'WM_SLIDER_IMAGE_HEIGHT', 360 );
		//"left", "right", "none"
		define( 'WM_SIDEBAR_FALLBACK', 'default' ); //fallback sidebar ID
		define( 'WM_SIDEBAR_DEFAULT',  'right' );
		//text color switcher treshold
		define( 'WM_COLOR_TRESHOLD', 140 );
		//default header sections positions
		define( 'WM_HEADER_SECTIONS_POSITIONS', 's-c-h' );



//Global variables
	//Get theme options
		$themeOptions = get_option( WM_THEME_SETTINGS );

	//Skin attributes
		$skinAtts = array(
				'body-bg-color'          => 'HTML',
				'wrap-bg-color'          => '#wrap',
				'wrap-shadow'            => '#wrap shadow',
				'header-bg-color'        => 'Header',
				'slider-bg-color'        => 'Slider',
				'cta-bg-color'           => 'Callout',
				'main-heading-bg-color'  => 'Main heading',
				'clients-bg-color'       => 'Clients',
				'footer-bg-color'        => 'Footer',

				'link-color'             => 'Link color',
				'color-bglight'          => 'Text color on light background',
				'color-bglight-headings' => 'Headings color on light background',
				'color-bgdark'           => 'Text color on dark background',
				'color-bgdark-headings'  => 'Headings color on dark background',

				'type-gray-bg-color'     => 'Gray color',
				'type-gray-color'        => 'Text on gray',
				'type-green-bg-color'    => 'Green color',
				'type-green-color'       => 'Text on green',
				'type-blue-bg-color'     => 'Blue color',
				'type-blue-color'        => 'Text on blue',
				'type-orange-bg-color'   => 'Orange color',
				'type-orange-color'      => 'Text on orange',
				'type-red-bg-color'      => 'Red color',
				'type-red-color'         => 'Text on red',

				'icon-scheme'            => 'Icon scheme',

				'font-custom'            => 'Font embed',
				'font-primary'           => 'Font primary',
				'font-secondary'         => 'Font secondary',
			);
		$skinAttsStatic = array(
				'package'                => 'Package',
				'color-scheme'           => 'Color Scheme',

				'description'            => 'Description',
				'version'                => 'Version',
				'author'                 => 'Author',
			);



//Global functions
require_once( WM_LIBRARY . 'core.php' );
//Theme settings
require_once( WM_LIBRARY . 'setup.php' );
//Admin functions
require_once( WM_LIBRARY . 'admin.php' );

?>