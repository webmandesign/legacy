# Jaguar Changelog

## 3.0

* Added: Update message in admin
* Added: Changelog file
* Updated: Tighten security
* Updated: Using unpacked scripts
* Updated: Replacing `return false;` for `e.preventDefault();` in `scripts.js` file
* Updated: Admin interface styles
* Updated: Scripts: TGM Plugin Activation 2.4.1
* Updated: Plugins: RevSlider 4.6.92
* Updated: Localization

#### Files changed:

	style.css
	changelog.md
	assets/js/scripts.js
	langs/*.*
	library/admin.php
	library/core.php
	library/assets/css/admin-addon.css
	library/assets/css/wm-options/wm-options-panel.css
	library/plugins/plugin-activation/class-tgm-plugin-activation.php.php
	library/plugins/plugin-activation/plugins.php


.
.
.


## 1.0

* Initial release



(C) 2012 WebMan, www.webmandesign.eu