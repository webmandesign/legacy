<?php
/**
 * @version  2.9
 */



global $content_width;

$postId        = get_option( 'page_for_posts' );
$sidebarLayout = ( wm_meta_option( 'layout', $postId ) ) ? ( wm_meta_option( 'layout', $postId ) ) : ( WM_SIDEBAR_DEFAULT );
$mediaURL      = ( has_excerpt() ) ? ( trim( get_the_excerpt() ) ) : ( '' );

if ( $mediaURL ) {

	if ( has_post_thumbnail() ) {
		wm_thumb( null, 'portfolio-no-crop' );
	} else {

		if ( false === strpos( $mediaURL, '[video' ) ) {
			$mediaURL = wp_oembed_get( esc_url( $mediaURL ) );
		}

		$content_width = ( 'none' == $sidebarLayout ) ? ( 960 ) : ( 680 );

		echo '<div class="video-container">' . do_shortcode( $mediaURL ) . '</div>';
	}

} else {

	echo '<div class="msg type-red icon-box icon-warning">' . __( 'Please set the video post properly', 'jaguar_domain' ) . '</div>';

}
?>

<?php
$positions = array(
	'formaticon',
	'date-special',
	'comments',
	'cats',
	'author'
	);

wm_meta( $positions );
?>

<?php wm_heading( 'list' ); ?>

<div class="article-content">
	<?php the_content(); ?>
</div>