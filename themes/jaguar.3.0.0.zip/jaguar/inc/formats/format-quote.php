<?php
$positions = array(
	'formaticon',
	'date-special',
	'cats',
	'author'
	);

wm_meta( $positions );
?>

<div class="article-content">
	<?php
	//quote source
	$sourceName = trim( get_post_meta( get_the_ID(), '_format_quote_source_name', true ) );
	$sourceURL  = trim( get_post_meta( get_the_ID(), '_format_quote_source_url', true ) );
	if ( $sourceURL && $sourceName )
		$sourceName = '<a href="' . esc_url( $sourceURL ) . '" target="_blank">' . $sourceName . '</a>';

	if ( $sourceName ) {
		$excerpt = get_the_content();
		$exc     = apply_filters( 'wptexturize', $excerpt );
		echo '<blockquote>' . $exc . '<div class="quote-source">' . $sourceName . '</div></blockquote>';
	} elseif ( has_excerpt() ) {
		$excerpt = get_the_excerpt();
		$exc     = apply_filters( 'wptexturize', $excerpt );
		echo '<blockquote>' . $exc . '<div class="quote-source">' . get_the_content() . '</div></blockquote>';
	} else {
		echo '<div class="msg type-red icon-box icon-warning">' . __( 'Please set the quote post properly', 'jaguar_domain' ) . '</div>';
	}
	?>
</div>