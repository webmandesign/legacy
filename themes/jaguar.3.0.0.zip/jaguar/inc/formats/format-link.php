<?php
$positions = array(
	'formaticon',
	'date-special',
	'cats',
	'author'
	);

wm_meta( $positions );
?>

<?php
$link = trim( get_post_meta( get_the_ID(), '_format_link_url', true ) );
$link = ( ! $link && has_excerpt() ) ? ( esc_url( get_the_excerpt() ) ) : ( esc_url( $link ) );
?>
<header class="post-title">
	<h2>
		<small><?php _e( 'Link:', 'jaguar_domain' ); ?></small> <a href="<?php echo $link; ?>"><?php the_title(); ?></a>
	</h2>
</header>

<div class="article-content">
	<?php
	if ( ! $link )
		echo '<div class="msg type-red icon-box icon-warning">' . __( 'Please set the link post properly', 'jaguar_domain' ) . '</div>';

	the_content();
	?>
</div>