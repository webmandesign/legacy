<?php
/**
 * @since  2.9
 */



global $content_width;

$postId        = get_option( 'page_for_posts' );
$sidebarLayout = ( wm_meta_option( 'layout', $postId ) ) ? ( wm_meta_option( 'layout', $postId ) ) : ( WM_SIDEBAR_DEFAULT );
$mediaURL      = ( has_excerpt() ) ? ( trim( get_the_excerpt() ) ) : ( '' );

if ( $mediaURL ) {

	if ( false === strpos( $mediaURL, '[audio' ) ) {
		$mediaURL = wp_oembed_get( esc_url( $mediaURL ) );
	} elseif ( has_post_thumbnail() ) {
		wm_thumb( null, 'portfolio-no-crop' );
	}

	$content_width = ( 'none' == $sidebarLayout ) ? ( 960 ) : ( 680 );

	echo '<div class="audio-container">' . do_shortcode( $mediaURL ) . '</div>';

} else {

	echo '<div class="msg type-red icon-box icon-warning">' . __( 'Please set the audio post properly', 'jaguar_domain' ) . '</div>';

}
?>

<?php
$positions = array(
	'formaticon',
	'date',
	'comments',
	'cats',
	'author'
	);

wm_meta( $positions );
?>

<div class="article-content">
	<?php the_content(); ?>
</div>

<?php wm_meta( array( 'tags' ) ); ?>