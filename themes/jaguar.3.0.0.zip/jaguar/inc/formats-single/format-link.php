<?php
$link = trim( get_post_meta( get_the_ID(), '_format_link_url', true ) );
$link = ( ! $link && has_excerpt() ) ? ( esc_url( get_the_excerpt() ) ) : ( esc_url( $link ) );
?>

<?php
$positions = array(
	'formaticon',
	'date',
	'cats',
	'author'
	);

wm_meta( $positions );
?>

<div class="article-content">
	<h2 class="mt0">
		<small><?php _e( 'Link:', 'jaguar_domain' ); ?></small> <a href="<?php echo $link; ?>"><?php the_title(); ?></a>
	</h2>

	<?php
	if ( ! $link )
		echo '<div class="msg type-red icon-box icon-warning">' . __( 'Please set the link post properly', 'jaguar_domain' ) . '</div>';

	the_content();
	?>
</div>

<?php wm_meta( array( 'tags' ) ); ?>