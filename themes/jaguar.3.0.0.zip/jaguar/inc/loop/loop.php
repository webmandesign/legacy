<?php
/**
 * @version  2.9
 */



if ( have_posts() ) {
?>

	<?php wm_before_list(); ?>

	<section class="list-articles">

		<?php
		$odd               = 'odd';
		$thumbPostFormats  = array( 'image', 'standard' );
		$noBodyPostFormats = array( 'link', 'status' );

		while ( have_posts() ) :
		the_post();
		?>
		<article <?php post_class( $odd ); ?>>

		<?php
		get_template_part( 'inc/formats/format', get_post_format() );
		?>

		</article>
		<?php
		if ( 'odd' == $odd )
			$odd = '';
		else
			$odd = 'odd';

		endwhile;
		?>

	</section> <!-- /list-articles -->

	<?php wm_after_list(); ?>

<?php
} else {
	wm_not_found();
}
?>