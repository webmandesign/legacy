<?php
/**
 * @version  2.9
 */



$department = wm_meta_option( 'team-department' );
if ( $department ) {
	if ( is_numeric( $department ) ) {
		$department = absint( $department );
	} else {
		$department = get_term_by( 'slug', sanitize_title( $department ), 'wm-tax-departments-team' );
		$department = ( $department && isset( $department->term_id ) ) ? ( $department->term_id ) : ( null );
	}
}

$queryArgs = array(
		'post_type'      => 'wm_team',
		'posts_per_page' => 100,
		'order'          => 'ASC'
	);
if ( 0 < $department )
	$queryArgs['tax_query'] = array( array(
		'taxonomy' => 'wm-tax-departments-team',
		'field'    => 'id',
		'terms'    => explode( ',', $department )
	) );

$team = new WP_Query( $queryArgs );
if ( $team->have_posts() ) {

$i       = 0;
$last    = '';
$members = $team->post_count;

if ( 4 < $members ) {
	if ( ! ( $members % 4 ) || 2 < ( $members % 4 ) )
		$count = 4;
	else
		$count = 3;
} else {
	$count = $members ;
}

?>
<div class="team<?php if ( 4 >= $count ) echo ' text-small'; ?>">
<div class="members-row row">
<?php
while ( $team->have_posts() ) : $team->the_post();

if ( $last )
	echo '</div><div class="members-row row">';

if ( ++$i % $count == 0 )
	$last = ' last';
else
	$last = '';

$tooltipDescription = preg_replace( '|\[(.+?)\]|s', '', wm_meta_option( 'team-description' ) ); //remove shortcodes from excerpt
$tooltip = ( ! wm_option( 'general-team-description' ) ) ? ( array( ' show-tooltip', ' title="' . esc_attr( strip_tags( $tooltipDescription ) ) . '"' ) ) : ( array( '', '' ) );
?>
	<div id="member-<?php the_ID(); ?>" class="member member-<?php the_ID(); ?> member-<?php echo sanitize_html_class( $post->post_name ); ?> column col-1<?php echo $count . $last . $tooltip[0]; ?>"<?php echo $tooltip[1]; ?>>
		<?php
		if ( has_post_thumbnail() )
			wm_thumb( null, 'medium' );
		else
			echo '<div class="image-container"><img src="' . WM_ASSETS_THEME . 'img/sample-face.png" alt="" /></div>';
		?>

		<h4><?php the_title(); ?></h4>

		<?php
		$terms = get_the_terms( $post->ID , 'wm-tax-positions-team' );

		if ( $terms ) {
			$out = $separator = '';

			foreach ( $terms as $term ) {
				$out .= $separator . $term->name;
				$separator = ', ';
			}

			echo '<h6 class="position border-color">' . $out . '</h6>';
		}
		?>

		<?php
		//if ( get_the_content() )
		//	echo '<div class="description">' . apply_filters( 'the_content', get_the_content() ) . '</div>';
		?>

		<?php
		$out = '';

		if ( wm_meta_option( 'team-facebook' ) )
			$out .= '<a href="' . esc_url( wm_meta_option( 'team-facebook' ) ) . '" title="' . get_the_title() . __( ' on Facebook', 'jaguar_domain' ) . '" class="facebook">Facebook</a>';
		if ( wm_meta_option( 'team-google' ) )
			$out .= '<a href="' . esc_url( wm_meta_option( 'team-google' ) ) . '" title="' . get_the_title() . __( ' on Google+', 'jaguar_domain' ) . '" class="googleplus">Google+</a>';
		if ( wm_meta_option( 'team-twitter' ) )
			$out .= '<a href="' . esc_url( wm_meta_option( 'team-twitter' ) ) . '" title="' . get_the_title() . __( ' on Twitter', 'jaguar_domain' ) . '" class="twitter">Twitter</a>';
		if ( wm_meta_option( 'team-website' ) )
			$out .= '<a href="' . esc_url( wm_meta_option( 'team-website' ) ) . '" title="' . get_the_title() . '" class="website">' . wm_meta_option( 'team-website' ) . '</a>';

		if ( $out )
			echo '<div class="social-small">' . $out . '</div>';
		?>

		<?php echo '<div class="desc">' . do_shortcode( wm_meta_option( 'team-description' ) ) . '</div>'; ?>
	</div>
<?php
endwhile;
?>
</div>
</div> <!-- /team -->
<?php
}
wp_reset_query();
?>