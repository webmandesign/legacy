nuoveXT 2.2
____________________

This is a revamp of my first icon theme nuoveXT for the KDE Desktop.


