<?php
/**
 * WooCommerce plugin integration
 *
 * @package     !LesPaul
 * @subpackage  Theme Setup
 * @copyright   2015 WebMan - Oliver Juhas
 *
 * @since    3.0
 * @version  3.0
 *
 * CONTENT:
 * -  0) Requirements check
 * -  1) Declare support
 * - 10) Actions and filters
 * - 20) Functions
 */





/**
 * 0) Requirements check
 */

	if ( ! class_exists( 'Woocommerce' ) ) {
		return;
	}





/**
 * 1) Declare support
 */

	//Declaring WooCommerce 2.0+ support
		add_theme_support( 'woocommerce' );



			if ( 'no' !== get_option( 'woocommerce_enable_lightbox' ) ) {
				update_option( 'woocommerce_enable_lightbox', 'no' );
			}








/**
 * 10) Actions and filters
 */

	/**
	 * Remove actions
	 */

		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title',     5  );
		remove_action( 'woocommerce_after_shop_loop_item',   'woocommerce_template_loop_add_to_cart', 10 );

	/**
	 * Actions
	 */

		add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_add_to_cart', 20 );



	/**
	 * Filters
	 */

		add_filter( 'woocommerce_show_page_title', '__return_false' );
		add_filter( 'woocommerce_enqueue_styles',  '__return_false' );

		add_filter( 'post_class', 'wm_product_classes' );





/**
 * 20) Functions
 */

	/**
	 * Additional product classes
	 *
	 * @since    3.0
	 * @version  3.0
	 *
	 * @param  array $classes
	 */
	if ( ! function_exists( 'wm_product_classes' ) ) {
		function wm_product_classes( $classes ) {
			//Helper variables
				global $woocommerce_loop;

			//Preparing output
				if (
						isset( $woocommerce_loop )
						&& isset( $woocommerce_loop['columns'] )
					) {
					$classes[] = 'column col-1' . $woocommerce_loop['columns'];
				}

			//Output
				return $classes;
		}
	} // /wm_product_classes

?>