<?php get_header(); ?>
<div class="wrap-inner">

<section class="main twelve pane">

	<?php do_action( 'wm_start_main_content' ); ?>

	<?php get_template_part( 'inc/loop/loop', 'search' ); ?>

</section> <!-- /main -->

</div> <!-- /wrap-inner -->
<?php get_footer(); ?>