# !LesPaul Changelog

## 3.0.2

* Updated: Tightening security
* Updated: Scripts: TGM Plugin Activation 2.4.1
* Updated: Plugins: Revolution Slider 4.6.92, Soliloquy 2.4.1.1
* Updated: Theme update message
* Updtaed: Localization
* Fixed: HTML validation issue

#### Files changed:

	inc/loop/loop-attachment.php
	langs/admin/lespaul_domain_adm.po
	library/admin.php
	library/core.php
	library/assets/css/admin-addon.css
	library/plugins/plugin-activation/class-tgm-plugin-activation.php
	library/plugins/plugin-activation/plugins.php
	library/shortcodes/shortcodes.php


## 3.0.1

* Fixed: Video shortcode issue introduced in version 3.0 update

#### Files changed:

	library/shortcodes/shortcodes.php


## 3.0

* Added: Premium plugins update notice
* Added: Changelog file moved directly into the theme's folder
* Updated: Support for WooCommerce 2.3+
* Updated: Optimized code
* Updated: Separation of WordPress galleries in PrettyPhoto lightbox
* Updated: Added filter to modify slider image size
* Updated: Removed pattern from Clean skin settings
* Updated: Plugins updated: Soliloquy 2.4.0.2, Envato WordPress Toolkit 1.7.2, Revolution Slider 4.6.5
* Updated: Update notifier
* Updated: Localization files
* Fixed: Fixed Formats button for TinyMCE editor variable name
* Fixed: Soundcloud links in audio projects
* Removed: `woocommerce` folder and contained files for better compatibility with future WooCommerce releases

#### Files changed:

	All localization files
	header.php
	assets/css/borders.css
	assets/css/core.css
	assets/css/forms.css
	assets/css/normalize.css
	assets/css/rtl-woocommerce.css
	assets/css/rtl.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/woocommerce.css
	assets/js/scripts.dev.js
	assets/js/scripts.js
	inc/loop/loop-project.php
	library/admin.php
	library/core.php
	library/setup-woocommerce.php
	library/setup.php
	library/plugins/plugin-activation/plugins.php
	library/shortcodes/shortcodes.php
	library/updater/update-notifier.php
	Removed "woocommerce" folder and all containing files


## 2.2.5

* Updated: WooCommerce 2.2.7 support
* Updated: RTL stylesheets are now being enqueued separately
* Updated: Plugins: LayerSlider 5.3.2, Slider Revolution 4.6.3, Soliloquy 2.3.9.3
* Fixed: Firefox images issue

#### Files changed:

	assets/css/normalize.css
	assets/css/style.css.php
	library/core.php
	library/setup.php
	woocommerce/myaccount/form-login.php


## 2.2

* Added: WordPress playlists support in projects
* Added: WordPress media player design
* Added: Fancier Author Box compatibility
* Updated: WooCommerce 2.2 support
* Updated: WordPress 4.0 support
* Updated: Admin updates
* Updated: Constants are redefinable now via a child theme
* Updated: Click events in scripts
* Updated: Minor styles updates
* Updated: Scripts: TGMA, Isotope 2.0.1, ImagesLoaded 3.1.8
* Updated: Plugins: LayerSlider 5.2.0, Slider Revolution 4.6.0, Envato WordPress Toolkit 1.7.0
* Fixed: Duplicate next/prev projects
* Fixed: HTML5 time tag issue
* Fixed: RTL: comment form styling
* Fixed: Separator heading issue on iOS

#### Files changed:

	functions.php
	assets/css/content.css
	assets/css/core.css
	assets/css/high-dpi.css
	assets/css/rtl.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/visual-editor-core.css
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/isotope/jquery.isotope.min.js
	assets/js/scripts.dev.js
	assets/js/scripts.js
	inc/loop/loop-project.php
	inc/loop/loop-project-post.php
	library/admin.php
	library/core.php
	library/setup.php
	library/assets/css/wm-options-panel.css
	library/assets/js/wm-options-panel.js
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php
	woocommerce/checkout/form-coupon.php
	woocommerce/checkout/thankyou.php
	woocommerce/loop/pagination.php
	woocommerce/myaccount/my-address.php
	woocommerce/myaccount/my-orders.php
	woocommerce/order/order-details.php


## 2.1

* Added: Blog posts next/prev post links
* Added: Full WordPress 3.9 compatibility
* Updated: WooCommerce templates
* Updated: Support for native WordPress video and audio shortcodes (also in projects)
* Updated: Enqueueing all stylesheets with wp_enqueue_style() function
* Updated: Better hooks into shortcodes functions
* Updated: Localization texts
* Updated: Scripts: Isotope 2.0.0, ImagesLoaded 3.1.6, bxSlider 4.1.2, Normalize 3.0.1, HTML5 Shiv 3.7.2
* Updated: Plugins: Soliloquy 2.3.0, LayerSlider 5.1.1, Slider Revolution 4.3.8, Envato WordPress Toolkit 1.6.3
* Fixed: Call to action title word wrapping
* Fixed: High DPI display styles
* Fixed: WooCommerce admin page list error
* Fixed: Project widget projects links
* Fixed: Separator heading styles on mobile devices
* Fixed: Social icons markup

#### Files changed:

	Frontend and admin translation file
	header.php
	single-wm_projects.php
	assets/css/content.css
	assets/css/high-dpi.css
	assets/css/normalize.css
	assets/css/responsive.css
	assets/css/rtl.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/js/bxslider/jquery.bxslider.min.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/isotope/jquery.isotope.min.js
	assets/js/html5.js
	assets/js/scripts.dev.js
	assets/js/scripts.js
	inc/loop/loop-project.php
	library/admin.php
	library/core.php
	library/setup.php
	library/assets/css/admin-addons.css
	library/meta/m-cp-projects.php
	library/shortcodes/shortcodes.php
	library/widgets/w-cpprojects.php
	woocommerce/checkout/review-order.php


## 2.0

* Added: WooCommerce 2.1+ support
* Added: Filters added to all of the shortcode functions for easier hooking in and modifying shortcodes outputs
* Added: Filter to modify widget areas registration array
* Added: hAtom microformats for better SEO
* Added: Filters to modify the image sizes and output of Posts and Projects widgets
* Added: [gallery] shortcode class attribute to be applied on each gallery image
* Added: Option to apply custom image URL links on [gallery] shortcode images
* Added: Filters to modify post meta info function (to easily add your custom meta info, such as post views counts, likes,...)
* Updated: Call to Action shortcode styles improved
* Updated: Update plugins (Envato WordPress Toolkit 1.6.2, Revolution Slider 4.1.4, LayerSlider 5.0.2, Soliloquy 1.5.7.1, normalize.css 3.0.0)
* Fixed: Fontello icons issue on Chrome browser
* Fixed: Fixed pagination on blog page template when used as homepage

#### Files changed:

	WooCommerce template files
	home.php
	assets/css/normalize.css
	assets/css/responsive.css
	assets/css/rtl.css
	assets/css/shortcodes.css
	assets/font/fontello/font/[all font files]
	assets/js/scripts.js
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-gallery.php
	inc/format/format-link.php
	inc/format/format-quote.php
	inc/format/format-status.php
	inc/format/format-video.php
	inc/loop/loop-blogpage.php
	inc/loop/loop-portfolio.php
	inc/loop/loop-project-post.php
	inc/loop/loop-search.php
	inc/loop/loop-singular.php
	inc/loop/loop-sitemap.php
	inc/loop/loop-staff.php
	library/core.php
	library/setup.php
	library/sidebars.php
	library/shortcodes/shortcodes.php
	library/widgets/w-cpmodules.php
	library/widgets/w-cppostslist.php
	library/widgets/w-cpprojects.php
	page-template/redirect.php


## 1.9.5

* Added: WordPress 3.8 ready
* Added: Custom CSS class attribute for [column] shortcode
* Added: Fiter to add/modify contact infos in Contact widget
* Updated: Update plugins (Envato WordPress Toolkit 1.6.1, Revolution Slider 4.1.2, LayerSlider 4.6.6, Soliloquy 1.5.6.3)
* Fixed: Header min-height settings

#### Files changed:

	Admin and help localization file
	assets/css/style.css.php
	library/admin.php
	library/core.php
	library/assets/css/admin-addon-38.css
	library/help/a-help.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-contact.php


## 1.9.2

* Added: Logos custom post link relation
* Added: Applied filters on some shortcodes outputs
* Fixed: Logos custom post image upload

#### Files changed:

	Admin localization file
	library/admin.php
	library/meta/m-cp-logos.php
	library/shortcodes/shortcodes.php


## 1.9.1

* Fixed: Pagination coding error
* Fixed: Theme admin PHP error

#### Files changed:

	library/core.php
	library/wm-options-panel.php


## 1.9

* Added: Support for "All In One Schema.org Rich Snippets" and "Schema Creator by Raven" Schema.org snippets plugins
* Added: Option to display related posts with [posts] shortcode
* Added: Option to display replies in Twitter Widget
* Updated: Admin area updates
* Updated: Plugins and scripts updates (TGM Plugin Activation, Revolution Slider 4.0.4, LayerSlider 4.6.5, Soliloquy 1.5.6.1, Envato WordPress Toolkit 1.5)
* Updated: Better shortcodes support with WordPress 3.6+
* Updated: Improved code
* Updated: Minor frontend styles updates
* Updated: WooCommerce templates
* Fixed: Posts widget coding error
* Fixed: Twitter Widget fixes
* Fixed: Blog page pagination fix
* Fixed: RTL style fixes (projects, posts carousel, accordion and toggle headings)

#### Files changed:

	Admin, help translation file
	WooCommerce template files
	comments.php
	header.php
	single-wm_projects.php
	assets/css/core.css
	assets/css/header.css
	assets/css/responsive.css
	assets/css/rtl.css
	assets/css/shortcodes.css
	assets/css/typography.css
	assets/css/skins/default.css
	inc/loop/loop-blogpage.php
	library/core.php
	library/wm-options-panel.php
	library/classes/meta-box-generator.php
	library/help/a-help.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-postslist.php
	library/widgets/w-twitter.php


## 1.8.1

* Updated: Code optimization
* Updated: Admin updates
* Updated: Twitter Widget improved
* Updated: Updated plugins (Soliloquy 1.5.4.5, Revolution Slider 3.0.8)
* Fixed: Minor styles fixes
* Fixed: WordPress 3.6 menu creation issue

#### Files changed:

	assets/css/footer.css
	assets/css/style.css.php
	assets/css/visual-editor.css.php
	library/core.php
	library/wm-options-panel.php
	library/assets/js/wm-options-panel.js
	library/widgets/w-twitter.php


## 1.8

* Added: WordPress 3.6 ready
* Added: Buttons get CSS3 animation
* Added: Applied filters for easier default texts change
* Updated: Project featured image not being listed among project slider images in admin area
* Updated: Scripts and plugins (bxSlider, jQuery ImagesLoaded, jQuery Masonry, Revolution Sider 3.0.5, LayerSlider 4.6.0, Soliloquy 1.5.4.4)
* Updated: Theme admin panel demo settings
* Updated: Navigation walker function
* Updated: Removing WooCommerce PrettyPhoto styling as it is not RTL language compatible and using default theme's lightbox
* Updated: Admin area metaboxes
* Updated: Twitter widget updated to new Twitter API
* Fixed: Navigation and separator headings on iPhones
* Fixed: Retina logo
* Fixed: Page excerpt saving issue

#### Files changed:

	Admin, frontend translation file
	comments.php
	functions.php
	header.php
	nav.php
	single-wm_projects.php
	assets/css/forms.css
	assets/css/responsive.css
	assets/css/sidebar.css
	assets/css/shortcodes.css
	assets/js/scripts.js
	inc/format/format-audio.php
	inc/loop/loop-attachment.php
	inc/loop/loop-sitemap.php
	library/core.php
	library/setup.php
	library/assets/css/admin-addon.css
	library/assets/css/wm-options/wm-options-panel.css
	library/classes/meta-box-generator.php
	library/classes/nav-walker.php
	library/meta/m-cp-logos.php
	library/meta/m-cp-modules.php
	library/meta/m-cp-price.php
	library/meta/m-cp-projects.php
	library/meta/m-cp-staff.php
	library/meta/m-excerpt.php
	library/meta/m-page.php
	library/meta/m-post.php
	library/shortcodes/shortcodes.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php
	library/widgets/w-twitter.php


## 1.7.1

* Fixed: PrettyPhoto lightbox on gallery (issue introduced in 1.7 update)
* Fixed: Fallback color for form buttons
* Fixed: RTL language fixes (search field in Internet Explorer browsers, animated testimonials

#### Files changed:

	assets/css/rtl.css
	assets/css/style.css.php
	assets/js/scripts.js
	library/core.php
	library/assets/css/wm-options/wm-options-panel.css
	library/shortcodes/shortcodes.php


## 1.7

* Added: WordPress 3.6 ready
* Added: Option to make the theme sections transparent
* Added: Option to disable theme's CSS caching
* Added: Relationship option for project custom links
* Updated: Inteligent comment form placement
* Updated: Separator heading HTML rewritten for improved flexibility
* Updated: Major admin area updates
* Updated: Optimized code
* Updated: Accordions and toggles can handle multiline titles
* Updated: Plugins and scripts (normalize.css, Soliloquy 1.5.2)
* Updated: User manual
* Updated: Demo content (added form placeholders for Contact Form 7 sample form)
* Fixed: Fading divider fallback for Internet Explorer 9 browser
* Fixed: Design sections backgrounds removing
* Fixed: Issue with PrettyPhoto lighbox in portfolio lists
* Fixed: Logo description separator issue
* Fixed: Post featured image link on blog page
* Fixed: Minor CSS fixes
* Fixed: RTL languages issues: tour tabs next/prev alignment, testimonials pagination, search field cut off on IE browsers, next/prev project links

#### Files changed:

	Panel, admin translation files
	comments.php
	single-wm_projects.php
	assets/css/content.css
	assets/css/normalize.css
	assets/css/rtl.css
	assets/css/responsive.css
	assets/css/sidebar.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/visual-editor.css.php
	assets/js/scripts.js
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-link.php
	inc/format/format-quote.php
	inc/format/format-video.php
	inc/loop/loop-blogpage.php
	inc/loop/loop-project.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/setup.php
	library/sidebars.php
	library/wm-options-panel.php
	library/assets/css/admin-addon.css
	library/assets/css/rtl-options.css
	library/assets/css/login-addon.css.php
	library/assets/css/wm-options/wm-options-panel.css.css
	library/assets/js/wm-options-panel.js
	library/assets/js/wm-scripts.js
	library/custom-posts/cp-logos.php
	library/custom-posts/cp-modules.php
	library/custom-posts/cp-price.php
	library/custom-posts/cp-projects.php
	library/custom-posts/cp-staff.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/meta/m-cp-logos.php
	library/meta/m-cp-modules.php
	library/meta/m-cp-price.php
	library/meta/m-cp-projects.php
	library/meta/m-cp-staff.php
	library/meta/m-page.php
	library/meta/m-post.php
	library/options/a-blog.php
	library/options/a-design.php
	library/options/a-general.php
	library/plugins/plugin-activation/plugins.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/a-areas.php
	woocommerce/single-product/up-sells.php
	woocommerce/single-product/related.php


## 1.6

* Added: Search field shortcode to use it in Text widget (for example)
* Added: Current menu highlighting
* Added: Option to display a single testimonial with Testimonials shortcode
* Added: Categories added to Posts shortcode (hidden by default)
* Added: Additional projects filtering using tags
* Added: RTL: Option to swith to force LTR in theme admin areas and metaboxes
* Updated: Code improvements
* Updated: PrettyPhoto lightbox working on "lightbox" class too
* Updated: Option to disable PrettyPhoto lightbox
* Updated: Admin area improvements and fixes
* Updated: Better compatibility with WPML plugin
* Updated: Scripts and plugins updates (jQuery ImagesLoaded, HTML5Shiv, Normalize.css, LayerSlider 4.5.5, Slider Revolution 2.3.91)
* Updated: Twitter widget improvements
* Updated: User manual updates
* Fixed: Responsiveness of fixed header layout
* Fixed: Shortcodes removed from "Posts" widget excerpts
* Fixed: Fixed countdown timer shortcode styles when placed in main slider area
* Fixed: Aligned buttons styles
* Fixed: Main heading icon animation on Internet Explorer 10 browsers
* Fixed: Responsive Logos shortcode styles
* Fixed: RTL languages fixes (masonry blog first post alignment, search results numbering styling, next/previous project links styling, PrettyPhoto styling, icons, countdown timer styling, admin area styling, huge horizontal scrol when Testimonials shortcode displayed on the page)
* Fixed: Archive pages sidebar position

#### Files changed:

	All translation files
	404.php
	attachment.php
	footer.php
	functions.php
	header.php
	home.php
	index.php
	page.php
	search.php
	single.php
	single-wm_projects.php
	taxonomy-project-tag.php
	taxonomy-project-type.php
	woocommerce.php
	wpml-config.xml
	assets/css/header.css
	assets/css/rtl.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/slider.css
	assets/css/style.css.php
	assets/css/skins/clean.css
	assets/css/skins/default.css
	assets/js/scripts.js
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-gallery.php
	inc/format/format-video.php
	inc/loop/loop.php
	inc/loop/loop-blogpage.php
	inc/loop/loop-portfolio.php
	inc/loop/loop-project.php
	inc/loop/loop-project-post.php
	inc/loop/loop-search.php
	inc/loop/loop-singular.php
	inc/loop/loop-sitemap.php
	inc/loop/loop-staff.php
	library/admin.php
	library/core.php
	library/setup.php
	library/assets/css/rtl-admin.css
	library/assets/css/rtl-options.css
	library/assets/css/shortcodes/shortcodes.css
	library/assets/css/wm-options/wm-options-panel.css
	library/custom-posts/ct-taxonomies.php
	library/help/a-help.php
	library/options/a-general.php
	library/options/a-custom-posts.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-postslist.php
	library/widgets/w-twitter.php
	page-template/construction.php
	page-template/landing.php
	page-template/map.php
	page-template/portfolio.php
	page-template/sections.php
	page-template/sitemap.php


## 1.5.1

* Added: Styles for WMPL Language Selector in top bar
* Updated: Better de-branding options
* Updated: Comments form texts can be overwritten in child theme
* Fixed: QuickStart Guide not hiding after first theme setup
* Fixed: Staff LinkedIn contact still present even after deleting the URL

#### Files changed:

	comments.php
	footer.php
	assets/css/header.css
	assets/css/rtl.css
	inc/loop/loop-staff.php
	library/meta/m-cp-staff.php
	library/options/a-quickstart.php
	library/shortcodes/shortcodes.php


## 1.5

* Added: Comments count in Posts shortcode
* Added: Theme options can be saved/loaded in/from presets files
* Added: Option to display full posts on blog pages
* Added: Custom contact fields in Staff custom post
* Added: Option to set author for custom posts
* Added: Option to set up the animation time in automatic accordions
* Updated: Mobile menu rebuilt
* Updated: Admin area updated
* Updated: Better possibility to handle archive page titles with CSS
* Updated: Front end styles
* Updated: Plugins updated: LayerSlider 4.5.1, Revolution Slider 2.3.8
* Fixed: Intermittent blog pagination issue
* Fixed: Removed "Blog" from breadcrumbs when viewing custom posts
* Fixed: Masonry blog image sizes and other blog display issues
* Fixed: RSS feed featured images size
* Fixed: RTL login button alignment
* Fixed: Alternative Projects widget layout issue
* Fixed: Form inline text input field placeholder text alignment on Safari

#### Files changed:

	All translation files
	header.php
	home.php
	assets/css/header.css
	assets/css/rtl.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/sidebar.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/js/scripts.js
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-gallery.php
	inc/format/format-video.php
	inc/loop/loop.php
	inc/loop/loop-blogpage.php
	inc/loop/loop-staff.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/setup.php
	library/wm-options-panel.php
	library/assets/css/login-addon.css.php
	library/custom-posts/cp-faq.php
	library/custom-posts/cp-logos.php
	library/custom-posts/cp-modules.php
	library/custom-posts/cp-price.php
	library/custom-posts/cp-projects.php
	library/custom-posts/cp-staff.php
	library/help/a-help.php
	library/meta/m-cp-staff.php
	library/options/a-blog.php
	library/options/a-branding.php
	library/options/a-export.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php


## 1.4.2

* Fixed: Admin area issue introduced in version 1.4.1
* Fixed: Main stylesheet double space in CSS selector causes issue on some browsers
* Fixed: Skype links in [social] shortcode

#### Files changed:

	assets/css/style.css.php
	library/assets/js/wm-options-panel.js
	library/shortcodes/shortcodes.php


## 1.4.1

* Added: Option to change "Zoom/View" text on project mouse hover overlay
* Fixed: Next/prev project link layout issue

#### Files changed:

	langs/admin/lespaul_domain_adm.po
	assets/css/content.css
	library/shortcodes/shortcodes.php


## 1.4

* Added: Right-to-left (RTL) languages support
* Added: Option to swich off the rich Staff pages per staff member
* Added: Navigation left, logo right header layout
* Added: Thirds-based project layout
* Added: Option to open Logos custom link in the same or new window
* Added: Thumbnails navigation for Project image slideshow
* Added: Alternative layout for Projects widget
* Updated: Plugin updates (Soliloquy 1.4.9.1, Revolution Slider 2.3.4 and LayerSlider 3D 4.1.1)
* Updated: Theme updater
* Updated: Admin area styles and functionality
* Updated: Minor front end styling updates
* Fixed: Main heading icon and settings not working for WooCommerce shop page
* Fixed: Redirect page template not working with sub-sub-pages
* Fixed: Border color setup for breadcrumbs section
* Fixed: Admin area JavaScript issue with MapPress plugin
* Fixed: Search pagination when using Client Access functionality
* Fixed: Removing FancyBox lightbox effect
* Fixed: Active tabs color in main content area issue
* Fixed: Admin area issue on Internet Explorer 9
* Fixed: Internet Explorer 8 image display when image height set
* Fixed: Custom icons font alignment
* Fixed: WebKit browsers menu icons animation issue

#### Files changed:

	!LesPaul Child Theme assets added: lespaul-child-theme/assets/css/rtl.css and lespaul-child-theme/assets/css/rtl-woocommerce.css
	langs/admin/lespaul_domain_adm.po
	langs/help/lespaul_domain_help.po
	langs/wm-admin-panel/lespaul_domain_panel.po
	header.php
	nav.php
	asstes/css/skins/clean.css
	assets/css/skins/default.css
	assets/css/borders.css
	assets/css/core.css
	assets/css/footer.css
	assets/css/header.css
	assets/css/icons-font-custom.css
	assets/css/print.css
	assets/css/rtl.css
	assets/css/rtl-woocommerce.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/sidebar.css
	assets/css/slider.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/woocommerce.css
	assets/js/scripts.js
	inc/loop/loop-project.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/setup.php
	library/custom-posts/cp-faq.php
	library/help/a-help.php
	library/meta/m-cp-logos.php
	library/meta/m-cp-staff.php
	library/options/a-header.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/styles/a-layouts.php
	library/updater/update-notifier.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php


## 1.3

* Added: Countdown timer shortcode
* Added: Compatibility with Advanced Page Manager plugin
* Added: Option to choose stack or one-by-one scrolling in Posts, Projects and Logos shortcodes
* Added: Centered logo and navigation header layout
* Added: Option to display Posts, Projects, Staff and Logos shortcodes in 1 column layout
* Added: Option to display posts from author in author bio on single post pages (set up in "Blog" section of theme admin panel)
* Added: Option to change padding on menu items for better header area styling flexibility
* Updated: WooCommerce 2.0 support
* Updated: Some front end CSS
* Updated: PrettyPhoto works wit "rel" attribute
* Updated: Admin area texts and functionality
* Fixed: Fixed website header area issues

#### Files changed:

	All translation files
	All skins CSS files
	WooCommerce template files
	header.php
	footer.php
	assets/css/borders.css
	assets/css/columns-content.css
	assets/css/content.css
	assets/css/core.css
	assets/css/icons-basic.css
	assets/css/header.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/woocommerce.css
	assets/js/scripts.js
	library/core.php
	library/form-generator.php
	library/setup.php
	library/help/a-help.php
	library/options/a-blog.php
	library/options/a-header.php
	library/options/a-security.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	page-template/construction.php


## 1.2

* Added: Full WooCommerce support/integration
* Added: Navigation accent (hover) color
* Added: Global (optional) active color for tabs, accordions and toggles (defaults to global accent color)
* Added: Main heading area padding adjustable per page/post basis
* Added: Automatic theme actualizations (via Envato WordPress Toolkit plugin)
* Added: Option for bouncing map markers animation
* Added: Support to display gallery in slider area
* Updated: Minor CSS fixes
* Updated: Style.css (also a child theme one) inserted at the end of the main dynamic stylesheet file
* Updated: Revolution Slider updated to version 2.3.3
* Updated: JavaScript plugins updated (bxSlider, jQuery.masonry, html5shiv)
* Updated: Scrolling posts/projects/logos by one (instead of full stack)
* Updated: Some patterns images optimization
* Fixed: [devider] shortcode renamed to [divider] (backward compatibility preserved)
* Fixed: Social icons styling issues
* Fixed: Styling blog posts list when using WordPress "More" tag
* Fixed: Pagination color change
* Fixed: Sticky header issue
* Fixed: Workaround for main menu flickering issues caused by CSS3 animation bug in FireFox browsers (mainly on unix systems like Mac OS and Linux)
* Fixed: Batch installation of premium slider plugins
* Fixed: LayerSlider issue when button used in slide on Internet Explorer browsers

#### Files changed:

	All localization files
	WooCommerce template files
	footer.php
	assets/css/borders.css
	assets/css/content.css
	assets/css/core.css
	assets/css/forms.css
	assets/css/header.css
	assets/css/shortcodes.css
	assets/css/slider.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/woocommerce.css
	assets/css/skin/clean.css
	assets/css/skin/default.css
	assets/js/maps.js
	assets/js/scripts.js
	library/core.php
	library/setup.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/meta/m-cp-projects.php
	library/meta/m-cp-staff.php
	library/options/a-design.php
	library/widgets/a-areas.php


## 1.1

* Added: new devider style
* Added: "id" attribute for Separator Heading shortcode
* Added: optional custom CSS textarea in theme admin panel (still recommended to use child themes, though)
* Added: Gravity forms styling
* Added: more options for Screen shortcode (to display content on and above specific screen size)
* Added: "style" attribute for Icon shortcode
* Updated: more speed optimization applied
* Updated: website description into meta title on front page
* Updated: minor updates in styles
* Updated: additional de-branding of admin area
* Fixed: print.css was added into child theme
* Fixed: "flickering" submenu issue
* Fixed: responsive styles of Logos shortcode
* Fixed: portfolio filter word wrapping
* Fixed: zigzag, media left and media right responsive styling

#### Files changed:

	langs/admin/lespaul_domain_adm.po
	langs/help/lespaul_domain_help.po
	langs/wm-admin-panel/lespaul_domain_panel.po
	assets/css/forms.css
	assets/css/forms-gravity.css
	assets/css/forms-wpcf.css
	assets/css/print.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/js/scripts.js
	library/core.php
	library/wm-options-panel.php
	library/help/a-help.php
	library/options/a-design.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-contact.php
	library/widgets/w-cpmodules.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php
	library/widgets/w-subpages.php
	library/widgets/w-twitter.php


## 1.0

* Initial release


(C) 2013 WebMan, www.webmandesign.eu