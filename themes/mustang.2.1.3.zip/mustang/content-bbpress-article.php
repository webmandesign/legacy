<?php
/**
 * bbPress "Article" content
 *
 * User account
 * Topic tags edit
 *
 * @package  Mustang Premium
 *
 * @since    1.0
 * @version  1.7
 */



$schema_type = 'article';

if ( bbp_is_single_user() ) {
	$schema_type = 'person';
}
?>

<article <?php post_class(); echo wm_schema_org( $schema_type ); ?>>

	<?php
	wmhook_entry_top();

	the_content();

	wmhook_entry_bottom();
	?>

</article>
