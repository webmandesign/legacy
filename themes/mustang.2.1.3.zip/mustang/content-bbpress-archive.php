<?php
/**
 * bbPress Archives and Search Results content
 *
 * @package  Mustang Premium
 *
 * @since    1.0
 * @version  1.7
 */
?>

<section <?php post_class(); echo wm_schema_org( 'item_list' ); ?>>

	<?php
	wmhook_entry_top();

	the_content();

	wmhook_entry_bottom();
	?>

</section>
