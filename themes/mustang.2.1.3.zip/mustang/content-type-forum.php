<?php
/**
 * bbPress Forum content
 *
 * @package  Mustang Premium
 *
 * @since    1.0
 * @version  1.7
 */
?>

<section id="post-<?php the_ID(); ?>" <?php post_class(); echo wm_schema_org( 'item_list' ); ?>>

	<?php
	wmhook_entry_top();

	the_content();

	wmhook_entry_bottom();
	?>

</section>
