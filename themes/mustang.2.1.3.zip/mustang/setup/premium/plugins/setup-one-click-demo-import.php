<?php
/**
 * One Click Demo Import Class
 *
 * @package  Mustang Premium
 *
 * @since    1.7.1
 * @version  2.0.0
 *
 * Contents:
 *
 *  0) Init
 * 10) Premium setup
 */
class Mustang_Premium_One_Click_Demo_Import {





	/**
	 * 0) Init
	 */

		private static $instance;



		/**
		 * Constructor
		 *
		 * @since    1.7.1
		 * @version  2.0.0
		 */
		private function __construct() {

			// Processing

				// Hooks

					// Actions

						add_action( 'pt-ocdi/before_content_import', __CLASS__ . '::woocommerce_images' );

						add_action( 'pt-ocdi/after_import', __CLASS__ . '::woocommerce_pages' );

					// Filters

						add_filter( 'pt-ocdi/import_files', __CLASS__ . '::files' );

						add_filter( 'ocdi/register_plugins', __CLASS__ . '::plugins' );

						add_filter( 'pt-ocdi/plugin_intro_text', __CLASS__ . '::info', 5 );

		} // /__construct



		/**
		 * Initialization (get instance)
		 *
		 * @since    1.7.1
		 * @version  1.7.1
		 */
		public static function init() {

			// Processing

				if ( null === self::$instance ) {
					self::$instance = new self;
				}


			// Output

				return self::$instance;

		} // /init





	/**
	 * 10) Premium setup
	 */

		/**
		 * Import files setup.
		 *
		 * @since    1.9.5
		 * @version  1.9.5
		 */
		public static function files() {

			// Output

				return array(

					array(
						'import_file_name'       => esc_html__( 'Theme demo content', 'mustang' ),
						'import_file_url'        => esc_url_raw( 'https://raw.githubusercontent.com/webmandesign/demo-content/master/mustang/demo-content-mustang.xml' ),
						'import_widget_file_url' => esc_url_raw( 'https://raw.githubusercontent.com/webmandesign/demo-content/master/mustang/demo-widgets-mustang.wie' ),
					),

				);

		} // /files

		/**
		 * Recommend plugins.
		 *
		 * @since  2.0.0
		 *
		 * @return  array
		 */
		public static function plugins() {

			// Output

				return array(
					array(
						'name'        => esc_html_x( 'WebMan Amplifier', 'Plugin name.', 'mustang' ),
						'slug'        => 'webman-amplifier',
						'required'    => false,
						'preselected' => true,
					),
					array(
						'name'        => esc_html_x( 'Beaver Builder', 'Plugin name.', 'mustang' ),
						'slug'        => 'beaver-builder-lite-version',
						'required'    => false,
						'preselected' => true,
					),
					array(
						'name'        => esc_html_x( 'WooCommerce', 'Plugin name.', 'mustang' ),
						'slug'        => 'woocommerce',
						'required'    => false,
						'preselected' => true,
					),
					array(
						'name'        => esc_html_x( 'bbPress', 'Plugin name.', 'mustang' ),
						'slug'        => 'bbpress',
						'required'    => false,
						'preselected' => true,
					),
					array(
						'name'        => esc_html_x( 'WooSidebars', 'Plugin name.', 'mustang' ),
						'slug'        => 'woosidebars',
						'required'    => false,
						'preselected' => true,
					),
					array(
						'name'        => esc_html_x( 'Breadcrumb NavXT', 'Plugin name.', 'mustang' ),
						'slug'        => 'breadcrumb-navxt',
						'required'    => false,
						'preselected' => true,
					),
					array(
						'name'        => esc_html_x( 'Classic Widgets', 'Plugin name.', 'mustang' ),
						'slug'        => 'classic-widgets',
						'required'    => false,
						'preselected' => true,
					),
				);

		} // /plugins



		/**
		 * Info texts.
		 *
		 * @since    1.9.5
		 * @version  1.9.5
		 *
		 * @param  string $text  Default intro text.
		 */
		public static function info( $text = '' ) {

			// Processing

				remove_filter( 'pt-ocdi/plugin_intro_text', 'Mustang_One_Click_Demo_Import::info' );

				$text .= '<div class="media-files-quality-info">';

					$text .= '<h3>';
					$text .= esc_html__( 'Media files quality', 'mustang' );
					$text .= '</h3>';

					$text .= '<p>';
					$text .= esc_html__( 'Please note that imported media files (such as images, video and audio files) are of low quality to prevent copyright infringement.', 'mustang' );
					$text .= ' ' . esc_html__( 'Please read "Credits" section of theme documentation for reference where the demo media files were obtained from.', 'mustang' );
					$text .= ' <a href="https://webmandesign.github.io/docs/mustang/#credits">' . esc_html__( 'Get media for your website &raquo;', 'mustang' ) . '</a>';
					$text .= '</p>';

				$text .= '</div>';

				$text .= '<div class="ocdi__demo-import-notice">';

					$text .= '<h3>';
					$text .= esc_html__( 'Install demo required plugins!', 'mustang' );
					$text .= '</h3>';

					$text .= '<p>';
					$text .= esc_html__( 'Please read the information about the theme demo required plugins first.', 'mustang' );
					$text .= ' ' . esc_html__( 'If you do not install and activate demo required plugins, some of the content will not be imported.', 'mustang' );
					$text .= ' <a href="https://github.com/webmandesign/demo-content/blob/master/mustang/readme.md#required-plugins" title="' . esc_attr__( 'Read the information before you run the theme demo content import process.', 'mustang' ) . '"><strong>';
					$text .= esc_html__( 'View the list of required plugins &raquo;', 'mustang' );
					$text .= '</strong></a>';
					$text .= '</p>';

					$text .= '<p>';
					$text .= '<em>';
					$text .= esc_html__( '(Note that this set of plugins may differ from plugins recommended under Appearance &rarr; Install Plugins!)', 'mustang' );
					$text .= '</em>';
					$text .= '</p>';

				$text .= '</div>';


			// Output

				return $text;

		} // /info



		/**
		 * Setup WooCommerce pages
		 *
		 * @since    1.7.1
		 * @version  1.7.1
		 */
		public static function woocommerce_pages() {

			// Requirements check

				if ( ! function_exists( 'wm_is_woocommerce' ) ) {
					return;
				}


			// Processing

				// Shop page

					$page_front = get_page_by_path( 'shop' );

					update_option( 'woocommerce_shop_page_id', $page_front->ID );

				// Cart page

					$page_blog = get_page_by_path( 'shopping-cart' );

					update_option( 'woocommerce_cart_page_id', $page_blog->ID );

				// Checkout page

					$page_blog = get_page_by_path( 'checkout' );

					update_option( 'woocommerce_checkout_page_id', $page_blog->ID );

				// My Account page

					$page = get_page_by_path( 'my-account' );

					update_option( 'woocommerce_myaccount_page_id', $page->ID );

		} // /woocommerce_pages



		/**
		 * Setup WooCommerce image sizes
		 *
		 * Must be set before the images are imported to generate correct sizes.
		 *
		 * @since    1.7.1
		 * @version  1.7.1
		 */
		public static function woocommerce_images() {

			// Requirements check

				if ( ! class_exists( 'WooCommerce' ) ) {
					return;
				}


			// Processing

				// Shop images

					update_option( 'shop_catalog_image_size', array(
							'width'  => 520,
							'height' => 520,
							'crop'   => 1,
						) );
					add_image_size( 'shop_catalog_image_size', 520, 520, true );

					update_option( 'shop_single_image_size', array(
							'width'  => 800,
							'height' => 800,
							'crop'   => 1,
						) );
					add_image_size( 'shop_single_image_size', 800, 800, true );

					update_option( 'shop_thumbnail_image_size', array(
							'width'  => 150,
							'height' => 150,
							'crop'   => 1,
						) );
					add_image_size( 'shop_thumbnail_image_size', 150, 150, true );

		} // /woocommerce_images





} // /Mustang_Premium_One_Click_Demo_Import

add_action( 'after_setup_theme', 'Mustang_Premium_One_Click_Demo_Import::init', 5 );
