<?php
/**
 * Theme Setup - Paid features
 *
 * @package  Mustang Premium
 *
 * @since    1.7
 * @version  1.9.3
 *
 * Contents:
 *
 * 10) Update notifications
 * 20) Functionality
 */





/**
 * 10) Update notifications
 */

	require get_theme_file_path( WM_SETUP_DIR . 'premium/update-notification/class-update-notification.php' );





/**
 * 20) Functionality
 */

	/**
	 * TGMPA: Recommend WooCommerce and bbPress plugin
	 *
	 * @since    1.7
	 * @version  1.7
	 *
	 * @param  array $plugins
	 */
	function wm_recommend_premium_plugins( $plugins = array() ) {

		// Processing

			$plugins['woocommerce'] = array(
					'name'     => esc_html__( 'WooCommerce (eCommerce functionality)', 'mustang' ),
					'slug'     => 'woocommerce',
					'required' => false,
				);

			$plugins['bbpress'] = array(
					'name'     => esc_html__( 'bbPress (forum software)', 'mustang' ),
					'slug'     => 'bbpress',
					'required' => false,
				);


		// Output

			return $plugins;

	} // /wm_recommend_premium_plugins

	add_filter( 'wmhook_wm_register_required_plugins', 'wm_recommend_premium_plugins' );



	/**
	 * bbPress integration
	 */

		// Regenerate CSS when bbPress activated and/or deactivated

			register_activation_hook(   'bbpress/bbpress.php', 'wm_generate_all_css' );
			register_deactivation_hook( 'bbpress/bbpress.php', 'wm_generate_all_css' );

		if ( class_exists( 'bbPress' ) ) {
			require_once WM_SETUP . 'premium/plugins/setup-bbpress.php';
		}



	/**
	 * One Click Demo Import
	 *
	 * @since    1.7.1
	 * @version  1.7.1
	 */

		if ( ( class_exists( 'OCDI_Plugin' ) || class_exists( 'PT_One_Click_Demo_Import' ) ) && is_admin() ) {
			require_once WM_SETUP . 'premium/plugins/setup-one-click-demo-import.php';
		}



	/**
	 * WooCommerce integration
	 */

		// Regenerate CSS when WooCommerce activated and/or deactivated

			register_activation_hook(   'woocommerce/woocommerce.php', 'wm_generate_all_css' );
			register_deactivation_hook( 'woocommerce/woocommerce.php', 'wm_generate_all_css' );

		if ( class_exists( 'WooCommerce' ) ) {
			require_once WM_SETUP . 'premium/plugins/setup-woocommerce.php';
		}
