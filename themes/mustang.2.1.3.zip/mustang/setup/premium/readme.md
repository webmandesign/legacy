# Mustang Theme Premium Features Reference

This file is a reference of premium, paid features of **Mustang** WordPress theme in opposite to free **Mustang Lite** theme:

1. Premium functionality is located in newly added files marked with `@package  Mustang Premium` file header.
2. Localization text domain is set to `mustang` (unlike the `mustang-lite`). Both theme versions contain different localization `.pot` files under `languages` directory.
3. Subtle changes were made to `style.css` file. The file is modified and differs in paid and free theme version.
4. `changelog.md` and `screenshot.jpg` file differs in both versions.

---

## List of added premium files:

* `content-bbpress-archive.php`
* `content-bbpress-article.php`
* `content-type-forum.php`
* `content-type-topic.php`
* **bbpress/** `*.*`
* **setup/premium/** `*.*`
* **webman-amplifier/**
  * `content-shortcode-posts-forum.php`
  * `content-shortcode-posts-product.php`

## List of changed files:

* `style.css` list of changes:
  * **"Theme Name"** header
  * **"Text Domain"** header
* `changelog.md`
* `screenshot.jpg`
* **languages/** `mustang.pot` vs. `mustang-lite.pot`
