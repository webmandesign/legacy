<?php
/**
 * Q'tron WordPress Theme
 *
 * Q'tron WordPress Theme, Copyright 2015 WebMan [http://www.webmandesign.eu/]
 * Q'tron is distributed under the terms of the GNU GPL
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 * @license    GPL-2.0+, http://www.gnu.org/licenses/gpl-2.0.html
 *
 * @since    1.0
 * @version  1.9.0
 *
 * @link  http://www.webmandesign.eu
 *
 * CONTENT:
 * - 0) Constants
 * - 1) Required files
 */





/**
 * 0) Constants
 */

	//Library required
		if ( ! defined( 'WM_WP_COMPATIBILITY' ) ) define( 'WM_WP_COMPATIBILITY', 4.1 );

	//URL constants
		if ( ! defined( 'WM_SUPPORT_URL' ) ) define( 'WM_SUPPORT_URL', 'https://support.webmandesign.eu' );
		if ( ! defined( 'WM_ONLINE_MANUAL_URL' ) ) define( 'WM_ONLINE_MANUAL_URL', 'https://webmandesign.github.io/docs/qtron/' );





/**
 * 1) Required files
 */

	// Global functions
	require_once get_template_directory() . '/lib/core.php';

	// Theme setup
	require_once get_theme_file_path( WM_SETUP_DIR . 'setup.php' );
