<?php
/**
 * Custom Header functionality
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  2.1.5
 *
 * Contents:
 *
 * 10) Custom Header functions
 */





/**
 * 10) Custom Header functions
 */

	/**
	 * Post/page intro title disable
	 *
	 * @since    1.0
	 * @version  1.2.2
	 */
	if ( ! function_exists( 'wm_post_intro_disable' ) ) {
		function wm_post_intro_disable() {
			//Preparing output
				if ( is_singular( 'fl-builder-template' ) ) {
					return true;
				}

				if (
						is_singular()
						&& (
							! get_the_title()
							|| ( function_exists( 'wma_meta_option' ) && wma_meta_option( 'intro-disable' ) )
							|| ( is_page() && get_post_meta( get_the_ID(), 'intro_disable', true ) )
						)
					) {
					return true;
				}

			//Output
				return false;
		}
	} // /wm_post_intro_disable

	add_filter( 'wmhook_wm_post_intro_disable', 'wm_post_intro_disable' );



	/**
	 * Disable featured image display when post intro used
	 *
	 * @since    1.0
	 * @version  1.0
	 */
	if ( ! function_exists( 'wm_disable_featured_image' ) ) {
		function wm_disable_featured_image() {
			//Helper variables
				$post_id = absint( get_the_ID() );

			//Preparing output
				if ( is_single( $post_id ) || is_page( $post_id ) ) {
					return false;
				}

			//Output
				return true;
		}
	} // /wm_disable_featured_image

	add_filter( 'wmhook_entry_featured_image_display', 'wm_disable_featured_image' );



	/**
	 * Post/page intro title
	 *
	 * @since    1.0
	 * @version  1.9.0
	 */
	if ( ! function_exists( 'wm_post_intro' ) ) {
		function wm_post_intro() {
			//Requirements check
				if ( apply_filters( 'wmhook_wm_post_intro_disable', false ) ) {
					return;
				}

			//Helper variables
				$class = 'page-header';

				$title = ( ! wm_paginated_suffix() ) ? ( get_the_title() ) : ( '<a href="' . esc_url( get_permalink() ) . '">' . get_the_title() . '</a>' );
				$title = '<h1 class="entry-title intro-title parallax-multiply">' . $title . wm_paginated_suffix( 'small' ) . '</h1>';

			//Preparing output
				if ( is_home() ) {

					/**
					 * For blog page
					 */

					$post_id = get_option( 'page_for_posts' );

					if ( $title = get_the_title( $post_id ) ) {

						//If no page_for_posts set, use the website tagline
							if ( ! $post_id ) {
								$title = get_bloginfo( 'description', 'display' );
							}

						//Blog page title with subtitle (using Subtitles plugin)
							$title .= wm_paginated_suffix( 'small' );

						$title = '<h1 class="page-title intro-title parallax-multiply">' . $title . '</h1>';

					} else {

						//Default falback blog page title
							$title = '<h1 class="page-title intro-title parallax-multiply">' . _x( 'Blog', 'Default fallback blog page title.', 'qtron' ) . '</h1>';

					}

				} elseif ( is_archive() ) {

					/**
					 * For archive pages
					 */

					$title  = '<div class="intro-title parallax-multiply">';
						$title .= '<h1 class="page-title">' . get_the_archive_title() . wm_paginated_suffix( 'small' ) . '</h1>';
						$title .= '<div class="taxonomy-description">' . get_the_archive_description() . '</div>';
					$title .= '</div>';

				} elseif ( is_search() ) {

					/**
					 * For search results
					 */

					$title = '<h1 class="page-title intro-title parallax-multiply">' . sprintf( __( 'Search Results for: %s', 'qtron' ), '<span>' . get_search_query() . '</span>' ) . wm_paginated_suffix( 'small' ) . '</h1>';

				} elseif ( is_404() ) {

					/**
					 * For 404 error page
					 */

					$title = '<h1 class="page-title intro-title parallax-multiply">' . __( 'Oops! That page can not be found.', 'qtron' ) . '</h1>';

				} else {

					$class = 'entry-header';

				}

			//Output
				echo '<header class="' . esc_attr( $class ) . ' intro-container"><div class="intro" id="intro"><div class="intro-inner">' . $title . '</div></div></header>';
		}
	} // /wm_post_intro

	add_action( 'wmhook_content_top', 'wm_post_intro', 5 );



	/**
	 * Post/page intro title background
	 *
	 * @since    1.0
	 * @version  2.1.5
	 */
	if ( ! function_exists( 'wm_post_intro_background' ) ) {
		function wm_post_intro_background() {
			//Requirements check
				if ( apply_filters( 'wmhook_wm_post_intro_disable', false ) ) {
					return;
				}

			//Helper variables
				$output = $image_url = '';

				$post_id = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );

				$ratio = 2.39;

				//Use featured image when appropriate
					if (
							is_singular()
							&& has_post_thumbnail( $post_id )
						) {

						$image_url = (array) wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'banner' );

						if ( $image_url[2] ) {
							$ratio = $image_url[1] / $image_url[2];
						}

						$image_url = (string) $image_url[0];

					} elseif ( wp_attachment_is_image() ) {

						$image_url = (array) wp_get_attachment_image_src( get_the_ID(), 'banner' );
						$image_url = (string) $image_url[0];

					}

				//Custom Header image fallback
					if ( empty( $image_url ) ) {
						if ( $image_url = get_header_image() ) {
							$ratio = get_custom_header()->width / get_custom_header()->height;
						} else {
							$image_url = wm_get_stylesheet_directory_uri( 'assets/images/header.jpg' );
						}
					}

				//Max ratio of 2:1
					$ratio = max( $ratio, 2 );

				//Force wide ratio
					if (
							is_home()
							|| is_archive()
							|| is_search()
							|| is_404()
							|| is_attachment()
							|| wm_paginated_suffix()
						) {
						$ratio = 4;
					}

				//Ratio percentage calculation
					$ratio = round( 100 / $ratio, 2 );

			//Preparing output
				$output .= '.intro { padding-bottom: ' . $ratio . '%; } .intro-inner { background-image: url(\'' . esc_url( $image_url ) . '\'); }';

			//Output
				if ( $output = apply_filters( 'wmhook_wm_post_intro_background_output', $output . "\r\n" ) ) {
					wp_add_inline_style( 'qtron', apply_filters( 'wmhook_esc_css', $output ) );
				}
		}
	} // /wm_post_intro_background

	add_action( 'wp_enqueue_scripts', 'wm_post_intro_background', 120 );



	/**
	 * Custom header image alt text fix.
	 *
	 * However, this does not always work. If the image URL is overridden
	 * with `self::image()` above, the attachment ID is different, thus
	 * the alt text could not be applied. This has to be fixed in WP core
	 * or completely redone in theme with custom code...
	 *
	 * @link  https://core.trac.wordpress.org/ticket/46124
	 * @todo  Remove with WordPress 5.2?
	 *
	 * @since    1.9.1
	 * @version  1.9.1
	 */
	function wm_header_image_alt_text( $html, $header, $attr ) {

		// Processing

			if ( isset( $header->attachment_id ) ) {
				$image_alt = get_post_meta( $header->attachment_id, '_wp_attachment_image_alt', true );
				if (
					! empty( $image_alt )
					&& wp_get_attachment_url( $header->attachment_id ) === $attr['src']
				) {
					$attr['alt'] = $image_alt;
					$html = '<img';
					foreach ( $attr as $name => $value ) {
						$html .= ' ' . $name . '="' . esc_attr( $value ) . '"';
					}
					$html .= ' />';
				}
			}


		// Output

			return $html;

	} // /wm_header_image_alt_text

	add_filter( 'get_header_image_tag', 'wm_header_image_alt_text', 10, 3 );
