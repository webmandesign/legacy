<?php
/**
 * Plugin integration
 *
 * Jetpack
 *
 * @link  https://wordpress.org/plugins/jetpack/
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.5.1
 *
 * CONTENT:
 * -  1) Requirements check
 * - 10) Actions and filters
 * - 20) Plugin integration
 */





/**
 * 1) Requirements check
 */

	if ( ! class_exists( 'Jetpack' ) ) {
		return;
	}





/**
 * 10) Actions and filters
 */

	/**
	 * Actions
	 */

		//Jetpack
			add_action( 'after_setup_theme', 'wm_jetpack_setup', 30 );



	/**
	 * Filters
	 */

		//Jetpack
			add_filter( 'sharing_show', 'wm_jetpack_sharing', 10, 2 );
			add_filter( 'infinite_scroll_js_settings', 'wm_jetpack_is_js_settings', 10    );





/**
 * 20) Plugin integration
 */

	/**
	 * Jetpack setup
	 *
	 * @since    1.0
	 * @version  1.5
	 */
	if ( ! function_exists( 'wm_jetpack_setup' ) ) {
		function wm_jetpack_setup() {

			// Processing

				add_theme_support( 'jetpack-responsive-videos' );

				add_theme_support( 'infinite-scroll', apply_filters( 'wmhook_wm_jetpack_setup_infinite_scroll', array(
						'container'      => 'posts',
						'footer'         => false,
						'posts_per_page' => 6,
						'render'         => 'wm_jetpack_is_render',
						'type'           => 'scroll',
						'wrapper'        => false,
					) ) );

		}
	} // /wm_jetpack_setup



	/**
	 * Accessibility fixes
	 */

		/**
		 * Level up heading tags
		 *
		 * Levels up the HTML headings in single post/page view.
		 * Transforms H3 to H2 and H4 to H3.
		 *
		 * @since    1.4
		 * @version  1.4
		 *
		 * @param  string $html
		 */
		function wm_headings_level_up( $html ) {

			// Requirements check

				if ( ! is_single( get_the_ID() ) && ! is_page( get_the_ID() ) ) {
					return $html;
				}


			// Processing

				switch ( $html ) {

					case 'h3':
							$html = tag_escape( 'h2' );
						break;

					case 'h4':
							$html = tag_escape( 'h3' );
						break;

					default:
							$html = str_replace(
									array(
										'<h3', '</h3', // 1) H3...
										'<h4', '</h4', // 2) H4...
									),
									array(
										'<h2', '</h2', // 1) ...to H2
										'<h3', '</h3', // 2) ...to H3
									),
									$html
								);
						break;

				} // /switch


			// Output

				return $html;

		} // /wm_headings_level_up

		add_filter( 'jetpack_sharing_display_markup',           'wm_headings_level_up', 999 );
		add_filter( 'jetpack_relatedposts_filter_headline',     'wm_headings_level_up', 999 );
		add_filter( 'jetpack_relatedposts_filter_post_heading', 'wm_headings_level_up', 999 );



	/**
	 * Jetpack sharing buttons
	 */

		/**
		 * Jetpack sharing display
		 *
		 * @since    1.0
		 * @version  1.0
		 *
		 * @param  bool $show
		 * @param  obj  $post
		 */
		if ( ! function_exists( 'wm_jetpack_sharing' ) ) {
			function wm_jetpack_sharing( $show, $post ) {
				//Helper variables
					global $wp_current_filter;

				//Preparing output
					if (
							in_array( 'the_excerpt', (array) $wp_current_filter )
							|| ! is_single( $post->ID )
						) {
						$show = false;
					}

				//Output
					return $show;
			}
		} // /wm_jetpack_sharing



	/**
	 * Jetpack infinite scroll
	 */

		/**
		 * Jetpack infinite scroll JS settings array modifier
		 *
		 * @since    1.0
		 * @version  1.0
		 *
		 * @param  array $settings
		 */
		if ( ! function_exists( 'wm_jetpack_is_js_settings' ) ) {
			function wm_jetpack_is_js_settings( $settings ) {
				//Helper variables
					$settings['text'] = esc_js( __( 'Load more&hellip;', 'qtron' ) );

				//Output
					return $settings;
			}
		} // /wm_jetpack_is_js_settings



		/**
		 * Jetpack infinite scroll posts renderer
		 *
		 * @since    1.0
		 * @version  1.5
		 */
		if ( ! function_exists( 'wm_jetpack_is_render' ) ) {
			function wm_jetpack_is_render() {

				// Processing

					while ( have_posts() ) {

						the_post();

						get_template_part( 'content', get_post_format() );

					}

			}
		} // /wm_jetpack_is_render
