<?php
/**
 * Theme options
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.9.0
 *
 * CONTENT:
 * -  10) Array functions
 * -  20) Customizer setup
 * - 100) Others
 */





/**
 * 10) Array functions
 */

	/**
	 * Set theme options array
	 *
	 * @since    1.0
	 * @version  1.9.0
	 *
	 * @param  array $options
	 */
	if ( ! function_exists( 'wm_theme_options_array' ) ) {
		function wm_theme_options_array( $options = array() ) {

			// Variables

				global $content_width;


			// Processing

				/**
				 * Theme customizer options array
				 */

					$options = array(

						/**
						 * Colors
						 */
						100 . 'colors' => array(
							'id'                   => 'colors',
							'type'                 => 'section',
							'create_section'       => _x( 'Colors', 'Customizer section title.', 'qtron' ),
							'in_panel'             => _x( 'Theme Options', 'Customizer panel title.', 'qtron' ),
							'in_panel-description' => '<h3>' . __( 'Theme Credits', 'qtron' ) . '</h3><p class="description">' . sprintf(
									__( '%1$s is WordPress theme developed by WebMan Design. You can obtain other professional WordPress themes at <strong><a href="%2$s" target="_blank">WebManDesign.eu</a></strong>. Thank you for using this awesome theme!', 'qtron' ),
									'<strong>' . WM_THEME_NAME . '</strong>',
									esc_url( add_query_arg( array( 'utm_source' => WM_THEME_SHORTNAME . '-theme-credits' ), esc_url( WM_THEME_AUTHOR_URI ) ) )
								) . '</p>',
						),

							100 . 'colors' . 100 => array(
								'type'    => 'html',
								'content' => '<h3>' . __( 'Accent color', 'qtron' ) . '</h3>',
							),

								100 . 'colors' . 110 => array(
									'type'          => 'color',
									'id'            => 'color' . '-accent',
									'label'         => __( 'Accent color', 'qtron' ),
									'description'   => __( 'This color affects links, buttons and other elements of the website', 'qtron' ),
									'default'       => '#0aac8e',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),
								100 . 'colors' . 120 => array(
									'type'          => 'color',
									'id'            => 'color' . '-accent-text',
									'label'         => __( 'Accent text color', 'qtron' ),
									'description'   => __( 'Color of text over accent color background', 'qtron' ),
									'default'       => '#ffffff',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),

							100 . 'colors' . 200 => array(
								'type'    => 'html',
								'content' => '<h3>' . __( 'Header', 'qtron' ) . '</h3>',
							),

								100 . 'colors' . 210 => array(
									'type'          => 'color',
									'id'            => 'color' . '-header-background',
									'label'         => __( 'Background color', 'qtron' ),
									'default'       => '#ffffff',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),
								100 . 'colors' . 220 => array(
									'type'          => 'color',
									'id'            => 'color' . '-header-text',
									'label'         => __( 'Text color', 'qtron' ),
									'default'       => '#1a1c1e',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),

								100 . 'colors' . 229 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( 'Navigation', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 230 => array(
										'type'          => 'color',
										'id'            => 'color' . '-navigation-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#1a1c1e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 240 => array(
										'type'          => 'color',
										'id'            => 'color' . '-navigation-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#aaacae',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 250 => array(
										'type'          => 'color',
										'id'            => 'color' . '-navigation-border',
										'label'         => __( 'Borders color', 'qtron' ),
										'default'       => '#2a2c2e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

							100 . 'colors' . 300 => array(
								'type'    => 'html',
								'content' => '<h3>' . __( 'Content', 'qtron' ) . '</h3>',
							),

								100 . 'colors' . 310 => array(
									'type'          => 'color',
									'id'            => 'color' . '-content-background',
									'label'         => __( 'Background color', 'qtron' ),
									'default'       => '#fafcfe',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),
								100 . 'colors' . 320 => array(
									'type'          => 'color',
									'id'            => 'color' . '-content-text',
									'label'         => __( 'Text color', 'qtron' ),
									'default'       => '#6a6c6e',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),
								100 . 'colors' . 330 => array(
									'type'          => 'color',
									'id'            => 'color' . '-content-headings',
									'label'         => __( 'Headings color', 'qtron' ),
									'default'       => '#1a1c1e',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),
								100 . 'colors' . 340 => array(
									'type'          => 'color',
									'id'            => 'color' . '-content-border',
									'label'         => __( 'Borders color', 'qtron' ),
									'default'       => '#dadcde',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),

								100 . 'colors' . 350 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( 'Alternative text color', 'qtron' ) . '</h4><p class="description">' . sprintf( __( 'This text colors will be applied on elements within the %s CSS class container.', 'qtron' ), '<code>color-text-alt</code>' ) . '</p>',
								),

									100 . 'colors' . 360 => array(
										'type'          => 'color',
										'id'            => 'color' . '-content-text-alt',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#9a9c9e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 370 => array(
										'type'          => 'color',
										'id'            => 'color' . '-content-headings-alt',
										'label'         => __( 'Headings color', 'qtron' ),
										'default'       => '#eaecee',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

							100 . 'colors' . 400 => array(
								'type'    => 'html',
								'content' => '<h3>' . __( 'Footer', 'qtron' ) . '</h3>',
							),

								100 . 'colors' . 410 => array(
									'type'          => 'color',
									'id'            => 'color' . '-footer-background',
									'label'         => __( 'Background color', 'qtron' ),
									'default'       => '#1a1c1e',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),
								100 . 'colors' . 420 => array(
									'type'          => 'color',
									'id'            => 'color' . '-footer-text',
									'label'         => __( 'Text color', 'qtron' ),
									'default'       => '#9a9c9e',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),
								100 . 'colors' . 430 => array(
									'type'          => 'color',
									'id'            => 'color' . '-footer-border',
									'label'         => __( 'Borders color', 'qtron' ),
									'default'       => '#3a3c3e',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),

								100 . 'colors' . 439 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( 'Footer menu', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 440 => array(
										'type'          => 'color',
										'id'            => 'color' . '-footer-menu-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#2a2c2e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 450 => array(
										'type'          => 'color',
										'id'            => 'color' . '-footer-menu-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#9a9c9e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

								100 . 'colors' . 459 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( 'Footer credits', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 460 => array(
										'type'          => 'color',
										'id'            => 'color' . '-footer-credits-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#1a1c1e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 470 => array(
										'type'          => 'color',
										'id'            => 'color' . '-footer-credits-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#9a9c9e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

							100 . 'colors' . 500 => array(
								'type'    => 'html',
								'content' => '<h3>' . __( 'Predefined colors', 'qtron' ) . '</h3>',
							),

								100 . 'colors' . 510 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( '"Error" color', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 511 => array(
										'type'          => 'color',
										'id'            => 'color' . '-error-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#c66a53',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 512 => array(
										'type'          => 'color',
										'id'            => 'color' . '-error-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#ffffff',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

								100 . 'colors' . 520 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( '"Info" color', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 521 => array(
										'type'          => 'color',
										'id'            => 'color' . '-info-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#3b89af',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 522 => array(
										'type'          => 'color',
										'id'            => 'color' . '-info-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#ffffff',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

								100 . 'colors' . 530 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( '"Neutral" color', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 531 => array(
										'type'          => 'color',
										'id'            => 'color' . '-neutral-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#dadcde',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 532 => array(
										'type'          => 'color',
										'id'            => 'color' . '-neutral-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#6a6c6e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

								100 . 'colors' . 540 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( '"Success" color', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 541 => array(
										'type'          => 'color',
										'id'            => 'color' . '-success-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#0aac8e',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 542 => array(
										'type'          => 'color',
										'id'            => 'color' . '-success-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#ffffff',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

								100 . 'colors' . 550 => array(
									'type'    => 'html',
									'content' => '<h4>' . __( '"Warning" color', 'qtron' ) . '</h4>',
								),

									100 . 'colors' . 551 => array(
										'type'          => 'color',
										'id'            => 'color' . '-warning-background',
										'label'         => __( 'Background color', 'qtron' ),
										'default'       => '#bfa950',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),
									100 . 'colors' . 552 => array(
										'type'          => 'color',
										'id'            => 'color' . '-warning-text',
										'label'         => __( 'Text color', 'qtron' ),
										'default'       => '#ffffff',
										'css_var'       => 'maybe_hash_hex_color',
										'customizer_js' => array(
											'css' => array(
												':root' => array( '--[[id]]' ),
											),
										),
									),

							100 . 'colors' . 900 => array(
								'type'    => 'html',
								'content' => '<h3>' . __( 'Others', 'qtron' ) . '</h3>',
							),

								100 . 'colors' . 910 => array(
									'type'          => 'color',
									'id'            => 'color' . '-posts-background',
									'label'         => __( 'Posts background color', 'qtron' ),
									'default'       => '#ffffff',
									'css_var'       => 'maybe_hash_hex_color',
									'customizer_js' => array(
										'css' => array(
											':root' => array( '--[[id]]' ),
										),
									),
								),



						/**
						 * Fonts
						 */
						200 . 'fonts' => array(
							'id'             => 'fonts',
							'type'           => 'section',
							'create_section' => _x( 'Fonts', 'Customizer section title.', 'qtron' ),
							'in_panel'       => _x( 'Theme Options', 'Customizer panel title.', 'qtron' ),
						),

							200 . 'fonts' . 100 => array(
								'type'    => 'html',
								'content' => '<p>' . __( 'Set a Google Font used for website logo, headings and general text.', 'qtron' ) . '<br />' . sprintf( __( 'Font matches recommendations have been taken from <a%s>Google Web Fonts Typographic Project</a>.', 'qtron' ), ' href="http://femmebot.github.io/google-type/" target="_blank"' ) . '</p>',
							),

								200 . 'fonts' . 110 => array(
									'type'    => 'select',
									'id'      => 'font' . '-logo',
									'label'   => __( 'Logo (site title) font', 'qtron' ),
									'default' => 'Josefin Slab:400,300',
									'options' => wm_helper_var( 'google-fonts' ),
									'css_var' => 'wm_css_font_family',
								),
								200 . 'fonts' . 120 => array(
									'type'    => 'select',
									'id'      => 'font' . '-headings',
									'label'   => __( 'Headings font', 'qtron' ),
									'default' => 'Source Sans Pro:400,300',
									'options' => wm_helper_var( 'google-fonts' ),
									'css_var' => 'wm_css_font_family',
								),
								200 . 'fonts' . 130 => array(
									'type'    => 'select',
									'id'      => 'font' . '-html',
									'label'   => __( 'General text font', 'qtron' ),
									'default' => 'Source Sans Pro:400,300',
									'options' => wm_helper_var( 'google-fonts' ),
									'css_var' => 'wm_css_font_family',
								),

								200 . 'fonts' . 140 => array(
									'type'            => 'multiselect',
									'id'              => 'font' . '-subset',
									'label'           => __( 'Font subset', 'qtron' ),
									'default'         => 'latin',
									'options'         => wm_helper_var( 'google-fonts-subset' ),
									'active_callback' => 'wm_active_callback_font_subset',
								),

								200 . 'fonts' . 150 => array(
									'type'          => 'range',
									'id'            => 'font' . '-size-html',
									'label'         => __( 'Basic font size', 'qtron' ),
									'description'   => __( 'All other font sizes are calculated automatically from this basic font size', 'qtron' ),
									'default'       => 16,
									'min'           => 12,
									'max'           => 20,
									'step'          => 1,
									'validate'      => 'absint',
									'css_var'       => '[[value]]px',
									'customizer_js' => array(
										'css' => array(
											':root' => array( array( '--[[id]]', 'px' ) ),
										),
									),
								),



						/**
						 * Texts
						 */
						300 . 'text' => array(
							'id'             => 'texts',
							'type'           => 'section',
							'create_section' => _x( 'Texts', 'Customizer section title.', 'qtron' ),
							'in_panel'       => _x( 'Theme Options', 'Customizer panel title.', 'qtron' ),
						),

							300 . 'text' . 110 => array(
								'type'     => 'textarea',
								'id'       => 'text' . '-credits',
								'label'    => __( 'Footer credits (copyright)', 'qtron' ),
								'default'  => '',
								'validate' => 'wp_kses_post',
							),



						/**
						 * Layout
						 */
						400 . 'layout' => array(
							'id'             => 'layout',
							'type'           => 'section',
							'create_section' => _x( 'Layout', 'Customizer section title.', 'qtron' ),
							'in_panel'       => _x( 'Theme Options', 'Customizer panel title.', 'qtron' ),
						),

							400 . 'layout' . 100 => array(
								'type'    => 'html',
								'content' => '<h3>' . _x( 'Container', 'A website container.', 'qtron' ) . '</h3><p>' . sprintf( __( 'Please note that the maximum content width is defined as 88&percnt; of website width (the current value is set to %d).', 'qtron' ), $content_width ) . '</p>',
							),

								400 . 'layout' . 110 => array(
									'type'    => 'select',
									'id'      => 'layout',
									'label'   => __( 'Website layout', 'qtron' ),
									'default' => 'boxed',
									'options' => array(
										'boxed'     => __( 'Boxed', 'qtron' ),
										'fullwidth' => __( 'Fullwidth', 'qtron' ),
									),
								),

								400 . 'layout' . 120 => array(
									'type'          => 'range',
									'id'            => 'layout-width-site',
									'label'         => __( 'Website max width', 'qtron' ),
									'description'   => __( 'For boxed website layout.', 'qtron' ) . '<br>' . __( 'Default value: 1720', 'qtron' ),
									'default'       => 1720,
									'min'           => 1000,
									'max'           => 1920,
									'step'          => 20,
									'validate'      => 'absint',
									'css_var'       => '[[value]]px',
									'customizer_js' => array(
										'css' => array(
											':root' => array( array( '--[[id]]', 'px' ) ),
										),
									),
									'active_callback' => 'wm_active_callback_layout_width_site',
								),
								400 . 'layout' . 130 => array(
									'type'          => 'range',
									'id'            => 'layout-width-content',
									'label'         => __( 'Content width', 'qtron' ),
									'description'   => __( 'Default value: 1060', 'qtron' ),
									'default'       => 1060,
									'min'           => 900,
									'max'           => 1920,
									'step'          => 20,
									'validate'      => 'absint',
									'css_var'       => '[[value]]px',
									'customizer_js' => array(
										'css' => array(
											':root' => array( array( '--[[id]]', 'px' ) ),
										),
									),
								),

							400 . 'layout' . 200 => array(
								'type'    => 'html',
								'content' => '<h3>' . __( 'Header', 'qtron' ) . '</h3>',
							),

								400 . 'layout' . 210 => array(
									'type'    => 'select',
									'id'      => 'layout' . '-header',
									'label'   => __( 'Header appearance', 'qtron' ),
									'default' => '',
									'options' => array(
											''       => __( 'Overlay', 'qtron' ),
											'normal' => __( 'Do not overlay', 'qtron' ),
										),
								),
								400 . 'layout' . 220 => array(
									'type'    => 'checkbox',
									'id'      => 'layout' . '-header-sticky',
									'label'   => __( 'Sticky header', 'qtron' ),
									'default' => 1,
								),



						/**
						 * Others
						 */
						800 . 'others' => array(
							'id'             => 'others',
							'type'           => 'section',
							'create_section' => esc_html_x( 'Others', 'Customizer section title.', 'qtron' ),
							'in_panel'       => esc_html_x( 'Theme Options', 'Customizer panel title.', 'qtron' ),
						),

							800 . 'others' . 110 => array(
								'type'          => 'checkbox',
								'id'            => 'others_welcome_page',
								'label'         => esc_html__( 'Show "Welcome" page', 'qtron' ),
								'description'   => esc_html__( 'Under "Appearance" WordPress dashboard menu', 'qtron' ),
								'default'       => true,
								'customizer_js' => false, // This is to prevent customizer preview reload
							),

					);


			// Output

				return apply_filters( 'wmhook_wm_theme_options_array_output', $options );

		}
	} // /wm_theme_options_array

	add_filter( 'wmhook_theme_options', 'wm_theme_options_array' );



		/**
		 * Active callbacks
		 */

			/**
			 * Show layout width conditionally
			 *
			 * @since    1.2
			 * @version  1.2
			 *
			 * @param  object $control
			 */
			if ( ! function_exists( 'wm_active_callback_font_subset' ) ) {
				function wm_active_callback_font_subset( $control ) {
					//Helper variables
						$font_logo     = trim( $control->manager->get_setting( WM_OPTION_CUSTOMIZER . '[' . 'font-logo' . ']' )->value() );
						$font_headings = trim( $control->manager->get_setting( WM_OPTION_CUSTOMIZER . '[' . 'font-headings' . ']' )->value() );
						$font_html     = trim( $control->manager->get_setting( WM_OPTION_CUSTOMIZER . '[' . 'font-html' . ']' )->value() );

					//Output
						return ( $font_logo || $font_headings || $font_html );
				}
			} // /wm_active_callback_font_subset



			/**
			 * Show layout width conditionally
			 *
			 * @since    1.2
			 * @version  1.9.0
			 *
			 * @param  object $control
			 */
			if ( ! function_exists( 'wm_active_callback_layout_width_site' ) ) {
				function wm_active_callback_layout_width_site( $control ) {

					// Helper variables

						$layout = $control->manager->get_setting( WM_OPTION_CUSTOMIZER . '[' . 'layout' . ']' );


					// Output

						return ( 'boxed' === $layout->value() );

				}
			} // /wm_active_callback_layout_width_site





/**
 * 20) Customizer setup
 */

	/**
	 * Customizer setup
	 *
	 * @since    1.6.0
	 * @version  1.6.0
	 *
	 * @param  object $wp_customize  WP customizer object.
	 */
	function wm_customize_setup( $wp_customize ) {

		// Processing

			// Partial refresh

				// Option pointers only

					$wp_customize->selective_refresh->add_partial( 'theme_mods_qtron[text-credits]', array(
						'selector' => '.site-info',
					) );

	} // /wm_customize_setup

	add_action( 'customize_register', 'wm_customize_setup' );





/**
 * 100) Others
 */

	/**
	 * Theme option font value to CSS font-family value.
	 *
	 * @since    1.9.0
	 * @version  1.9.0
	 *
	 * @param  string $font
	 */
	if ( ! function_exists( 'wm_css_font_family' ) ) {
		function wm_css_font_family( $font = '' ) {

			// Variables

				$output = 'sans-serif';


			// Processing

				if ( $font ) {
					$google_fonts = wm_helper_var( 'google-fonts' );
					if ( isset( $google_fonts[ $font ] ) ) {
						$output = "'" . $google_fonts[ $font ] . "'";
					}
				}


			// Output

				return $output;

		}
	} // /wm_css_font_family

