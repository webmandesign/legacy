<?php
/**
 * Plugin integration
 *
 * Breadcrumb NavXT
 *
 * @link  https://wordpress.org/plugins/breadcrumb-navxt/
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.5
 *
 * CONTENT:
 * -  1) Requirements check
 * - 10) Actions and filters
 * - 20) Plugin integration
 */





/**
 * 1) Requirements check
 */

	if ( ! function_exists( 'bcn_display' ) ) {
		return;
	}





/**
 * 10) Actions and filters
 */

	/**
	 * Actions
	 */

		//Breadcrumbs
			add_action( 'wmhook_content_top', 'wm_bcn_breadcrumbs', 20 );



	/**
	 * Filters
	 */

		//Breadcrumbs NavXT modifications
			add_filter( 'bcn_show_cpt_private', 'wm_bcn_admin', 10, 2 );





/**
 * 20) Plugin integration
 */

	/**
	 * Define to pick the plugin settings from single site when
	 * using WordPress Multisite setup.
	 */
	define( 'BCN_SETTINGS_FAVOR_LOCAL', true );



	/**
	 * Plugin setup admin page modification
	 *
	 * Don't display breadcrumbs settings for posts with no single view.
	 *
	 * @since    1.0
	 * @version  1.0
	 *
	 * @param  boolean $display
	 * @param  string  $post_type
	 */
	if ( ! function_exists( 'wm_bcn_admin' ) ) {
		function wm_bcn_admin( $display = true, $post_type = '' ) {
			//Helper variables
				$redirects = apply_filters( 'wmhook_custom_post_redirects', array(
						'wm_logos'        => home_url(),
						'wm_modules'      => home_url(),
						'wm_staff'        => home_url(),
						'wm_testimonials' => home_url(),
					) );

			//Preparing output
				if ( in_array( $post_type, array_keys( $redirects ) ) ) {
					$display = false;
				}

			//Output
				return $display;
		}
	} // /wm_bcn_admin



	/**
	 * Breadcrumbs
	 *
	 * @since    1.0
	 * @version  1.0
	 */
	if ( ! function_exists( 'wm_bcn_breadcrumbs' ) ) {
		function wm_bcn_breadcrumbs() {
			if (
					function_exists( 'bcn_display' )
					&& ! is_front_page()
					&& ( function_exists( 'wm_bb_is_active' ) && ! wm_bb_is_active() )
				) {
				echo '<div class="breadcrumbs-container"><nav class="breadcrumbs" itemprop="breadcrumbs">' . bcn_display( true ) . '</nav></div>';
			}
		}
	} // /wm_bcn_breadcrumbs
