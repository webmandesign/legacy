<?php
/**
 * Theme setup
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  2.5.6
 *
 * CONTENT:
 * -  10) Actions and filters
 * -  20) Global variables
 * -  30) Theme setup
 * -  40) Assets and design
 * -  50) Site global markup
 * - 100) Other functions
 * - 200) Pluggable
 * - 999) Plugins integration
 */





/**
 * 10) Actions and filters
 */

	/**
	 * Actions
	 */

		//Styles and scripts
			add_action( 'wp_enqueue_scripts',     'wm_register_assets',                     10 );
			add_action( 'wp_enqueue_scripts',     'wm_enqueue_assets',                     100 );
			add_action( 'comment_form_before',    'wm_enqueue_comments_reply',              10 );
			add_action( 'wp_footer',              'wm_footer_custom_scripts',             9998 );
			add_action( 'customize_preview_init', 'wm_customizer_preview_enqueue_assets',   10 );
		//Theme setup
			add_action( 'after_setup_theme', 'wm_setup' );
		//Register widget areas
			add_action( 'widgets_init', 'wm_register_widget_areas', 1 );
		//Pagination
			add_action( 'wmhook_postslist_after', 'wm_pagination', 10 );
		//Visual Editor addons
			add_action( 'init', 'wm_visual_editor', 999 );
			add_filter( 'wmhook_wm_custom_mce_format_style_formats', 'wm_visual_editor_custom_mce_format' );
		//Display Settings > Media recommended images sizes notice
			add_action( 'admin_init', 'wm_image_size_notice' );
		//Website sections
			//DOCTYPE
				add_action( 'wmhook_html_before',    'wm_doctype',         10 );
			//Body
				add_action( 'wmhook_body_top',       'wm_site_top',        10 );
				add_action( 'wmhook_body_bottom',    'wm_site_bottom',    100 );
			//Header
				add_action( 'wmhook_header_top',     'wm_header_top',      10 );
				add_action( 'wmhook_header',         'wm_logo',            10, 0 );
				add_action( 'wmhook_header',         'wm_navigation',      20 );
				add_action( 'wmhook_header',         'wm_menu_social',     30 );
				add_action( 'wmhook_header_bottom',  'wm_header_bottom',   10 );
			//Content
				add_action( 'wmhook_content_top',    'wm_content_top',     10 );
				add_action( 'wmhook_entry_top',      'wm_post_title',      10 );
				add_action( 'wmhook_entry_top',      'wm_entry_top',       20 );
				add_action( 'wmhook_entry_bottom',   'wm_entry_bottom',    10 );
				add_action( 'wmhook_content_bottom', 'wm_content_bottom', 100 );
			//Footer
				add_action( 'wmhook_footer_top',     'wm_footer_top',     100 );
				add_action( 'wmhook_footer',         'wm_footer',         100 );
				add_action( 'wmhook_footer_bottom',  'wm_footer_bottom',  100 );



	/**
	 * Filters
	 */

		//Set up image sizes
			add_filter( 'wmhook_wm_setup_image_sizes', 'wm_image_sizes' );
		//Set required Google Fonts
			add_filter( 'wmhook_wm_google_fonts_url_fonts_setup', 'wm_google_fonts' );
		//BODY classes
			add_filter( 'body_class', 'wm_body_classes', 98 );
		//Post classes
			add_filter( 'post_class', 'wm_post_classes', 98 );
		//Logo
			add_filter( 'wmhook_wm_logo_args',  'wm_logo_args'  );
			add_filter( 'wmhook_wm_logo_class', 'wm_logo_class' );
		//Navigation improvements
			add_filter( 'nav_menu_css_class',       'wm_nav_item_classes', 10, 4 );
			add_filter( 'walker_nav_menu_start_el', 'wm_nav_item_process', 10, 4 );
		//Excerpt modifications
			add_filter( 'the_excerpt', 'wm_remove_shortcodes', 10 );
			add_filter( 'the_excerpt', 'wm_excerpt', 20 );
			add_filter( 'get_the_excerpt', 'wm_wrap_excerpt', 20 );
			add_filter( 'get_the_excerpt', 'wm_excerpt_continue_reading', 30, 2 );
			add_filter( 'excerpt_length', 'wm_excerpt_length', 10 );
			add_filter( 'excerpt_more', 'wm_excerpt_more', 10 );
		//Disable post title
			add_filter( 'wmhook_wm_post_title_disable', 'wm_disable_post_title', 98 );
		//Post thumbnail display size
			add_filter( 'wmhook_entry_featured_image_size', 'wm_post_thumbnail_size' );





/**
 * 20) Globals
 */

	/**
	 * Max content width
	 *
	 * Required here, because we don't set it up in functions.php.
	 * The $content_width is calculated as golden ratio of the site container width.
	 */

		if ( ! isset( $content_width ) || ! $content_width ) {
			global $content_width;

			$content_width = absint( wm_option( 'layout-width-content', 1060 ) );
			$site_width    = absint( wm_option( 'layout-width-site', 1920 ) );

			if ( $content_width > absint( $site_width * .88 ) ) {
				$content_width = absint( $site_width * .88 );
			}

			if ( empty( $content_width ) ) {
				$content_width = 1060;
			}
		}




	/**
	 * Theme helper variables
	 *
	 * @since    1.0
	 * @version  1.8.0
	 *
	 * @param  string $variable Helper variables array key to return
	 * @param  string $key      Additional key if the variable is array
	 */
	if ( ! function_exists( 'wm_helper_var' ) ) {
		function wm_helper_var( $variable, $key = '' ) {
			//Helper variables
				$output = array();

				//Background CSS settings
					$output['bg-css'] = array(
							'position' => array(
									'0 0'       => '<span class="position-option">' . __( 'Top left', 'qtron' ) . '</span>',
									'50% 0'     => '<span class="position-option">' . __( 'Top center', 'qtron' ) . '</span>',
									'100% 0'    => '<span class="position-option">' . __( 'Top right', 'qtron' ) . '</span>',
									'0 50%'     => '<span class="position-option">' . __( 'Left center', 'qtron' ) . '</span>',
									'50% 50%'   => '<span class="position-option">' . __( 'Center', 'qtron' ) . '</span>',
									'100% 50%'  => '<span class="position-option">' . __( 'Right center', 'qtron' ) . '</span>',
									'0 100%'    => '<span class="position-option">' . __( 'Bottom left', 'qtron' ) . '</span>',
									'50% 100%'  => '<span class="position-option">' . __( 'Bottom center', 'qtron' ) . '</span>',
									'100% 100%' => '<span class="position-option">' . __( 'Bottom right', 'qtron' ) . '</span>',
								),
							'repeat'   => array(
									'no-repeat' => '<img alt="' . esc_attr__( 'Do not repeat', 'qtron' ) . '" src="' . wm_get_stylesheet_directory_uri( 'assets/images/options/no-repeat.png' ) . '" class="repeat-image" /><span class="repeat-option">' . __( 'Do not repeat', 'qtron' ) . '</span>',
									'repeat-x'  => '<img alt="' . esc_attr__( 'Repeat horizontally', 'qtron' ) . '" src="' . wm_get_stylesheet_directory_uri( 'assets/images/options/repeat-x.png' ) . '" class="repeat-image" /><span class="repeat-option">' . __( 'Repeat horizontally', 'qtron' ) . '</span>',
									'repeat-y'  => '<img alt="' . esc_attr__( 'Repeat vertically', 'qtron' ) . '" src="' . wm_get_stylesheet_directory_uri( 'assets/images/options/repeat-y.png' ) . '" class="repeat-image" /><span class="repeat-option">' . __( 'Repeat vertically', 'qtron' ) . '</span>',
									'repeat'    => '<img alt="' . esc_attr__( 'Tile', 'qtron' ) . '" src="' . wm_get_stylesheet_directory_uri( 'assets/images/options/repeat.png' ) . '" class="repeat-image" /><span class="repeat-option">' . __( 'Tile', 'qtron' ) . '</span>',
								),
							'scroll'   => array(
									'scroll' => '<span class="scroll-option">' . __( 'Move on scrolling', 'qtron' ) . '</span>',
									'fixed'  => '<span class="scroll-option">' . __( 'Fixed position', 'qtron' ) . '</span>',
								),
							'size'     => array(
									''        => '<img alt="' . esc_attr_x( 'Default', 'Background size value.', 'qtron' ) . '" src="' . wm_get_stylesheet_directory_uri( 'assets/images/options/default.png' ) . '" class="size-image" /><span class="size-option">' . _x( 'Default', 'Background size value.', 'qtron' ) . '</span>',
									'cover'   => '<img alt="' . esc_attr_x( 'Cover', 'Background size value.', 'qtron' ) . '" src="' . wm_get_stylesheet_directory_uri( 'assets/images/options/cover.png' ) . '" class="size-image" /><span class="size-option">' . _x( 'Cover', 'Background size value.', 'qtron' ) . '</span>',
									'contain' => '<img alt="' . esc_attr_x( 'Contain', 'Background size value.', 'qtron' ) . '" src="' . wm_get_stylesheet_directory_uri( 'assets/images/options/contain.png' ) . '" class="size-image" /><span class="size-option">' . _x( 'Contain', 'Background size value.', 'qtron' ) . '</span>',
								),
						);

				//Google Fonts
					$i = 0;
					$output['google-fonts'] = array(
							//No Google Font
								' ' => __( ' - do not use Google Font', 'qtron' ),

							//Default theme font
								'optgroup' . $i => _x( 'Theme default', 'Google Font default setup options group title.', 'qtron' ),
									'Josefin Slab:400,300'    => 'Josefin Slab',
									'Source Sans Pro:400,300' => 'Source Sans Pro',
								'/optgroup' . $i => '',

							//Insipration from http://femmebot.github.io/google-type/
								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Playfair Display' => 'Playfair Display',
									'Fauna One'        => 'Fauna One',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Fugaz One'   => 'Fugaz One',
									'Oleo Script' => 'Oleo Script',
									'Monda'       => 'Monda',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Unica One' => 'Unica One',
									'Vollkorn'  => 'Vollkorn',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Megrim'                  => 'Megrim',
									'Roboto Slab:400,300,100' => 'Roboto Slab',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Open Sans:400,300' => 'Open Sans',
									'Gentium Basic'     => 'Gentium Basic',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Ovo'          => 'Ovo',
									'Muli:300,400' => 'Muli',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Neuton:200,300,400' => 'Neuton',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Quando' => 'Quando',
									'Judson' => 'Judson',
									'Montserrat' => 'Montserrat',
								'/optgroup' . $i => '',

								'optgroup' . ++$i => sprintf( _x( 'Recommendation #%d', 'Google Font setup recommendation (numbered) group title.', 'qtron' ), $i ),
									'Ultra'                => 'Ultra',
									'Stint Ultra Expanded' => 'Stint Ultra Expanded',
									'Slabo 13px'           => 'Slabo 13px',
								'/optgroup' . $i => '',

							//Google Fonts selection
								'optgroup' . ++$i => _x( 'Fonts selection', 'Title for selection of fonts picked from Google Fontss', 'qtron' ),
									'Abril Fatface'             => 'Abril Fatface',
									'Arbutus Slab'              => 'Arbutus Slab',
									'Arvo'                      => 'Arvo',
									'Domine'                    => 'Domine',
									'Droid Sans'                => 'Droid Sans',
									'Droid Serif'               => 'Droid Serif',
									'Duru Sans'                 => 'Duru Sans',
									'Gentium Basic'             => 'Gentium Basic',
									'Hind:400,300'              => 'Hind',
									'Inconsolata'               => 'Inconsolata',
									'Lato:400,300,100'          => 'Lato',
									'Lobster'                   => 'Lobster',
									'Merriweather:400,300'      => 'Merriweather',
									'Merriweather Sans:400,300' => 'Merriweather Sans',
									'Metamorphous'              => 'Metamorphous',
									'Michroma'                  => 'Michroma',
									'Nixie One'                 => 'Nixie One',
									'Noto Sans'                 => 'Noto Sans',
									'Numans'                    => 'Numans',
									'Nunito:400,300'            => 'Nunito',
									'Old Standard TT'           => 'Old Standard TT',
									'Open Sans Condensed:300'   => 'Open Sans Condensed',
									'Oswald:400,300'            => 'Oswald',
									'PT Sans'                   => 'PT Sans',
									'PT Serif'                  => 'PT Serif',
									'Quicksand:400,300'         => 'Quicksand',
									'Raleway:400,300,200'       => 'Raleway',
									'Roboto:400,300'            => 'Roboto',
									'Rokkitt'                   => 'Rokkitt',
									'Tenor Sans'                => 'Tenor Sans',
									'Ubuntu:400,300'            => 'Ubuntu',
									'Ubuntu Condensed'          => 'Ubuntu Condensed',
									'Yanone Kaffeesatz:400,300' => 'Yanone Kaffeesatz',
								'/optgroup' . $i => '',
						);

				//Google Fonts subsets
					$output['google-fonts-subset'] = array(
							'latin'        => 'Latin',
							'latin-ext'    => 'Latin Extended',
							'cyrillic'     => 'Cyrillic',
							'cyrillic-ext' => 'Cyrillic Extended',
							'greek'        => 'Greek',
							'greek-ext'    => 'Greek Extended',
							'vietnamese'   => 'Vietnamese',
						);

				//Widget areas
					$output['widget-areas'] = array(
							'sidebar' => array(
								'name'        => __( 'Sidebar', 'qtron' ),
								'description' => '',
							),
							'footer'  => array(
								'name'        => __( 'Footer Widgets', 'qtron' ),
								'description' => '',
							),
						);

			//Output
				$output = apply_filters( 'wmhook_wm_helper_var_output', $output );

				if ( isset( $output[ $variable ] ) ) {
					$output = $output[ $variable ];
					if ( isset( $output[ $key ] ) ) {
						$output = $output[ $key ];
					}
				} else {
					$output = '';
				}

				return $output;
		}
	} // /wm_helper_var





/**
 * 30) Theme setup
 */

	/**
	 * Theme setup
	 *
	 * @since    1.0
	 * @version  2.1.0
	 */
	if ( ! function_exists( 'wm_setup' ) ) {
		function wm_setup() {

			// Helper variables

				$image_sizes = array_filter( apply_filters( 'wmhook_wm_setup_image_sizes', array() ) );

				// Banner (Custom Header) image size

					$banner_width = absint( wm_option( 'layout-width-site' ) );

					if ( empty( $banner_width ) ) {
						$banner_width = 1720;
					}

					$banner_height = absint( round( $banner_width / 2.39 ) );

				// WordPress visual editor CSS stylesheets

					$visual_editor_css = array();

					if ( $load_google_fonts = wm_google_fonts_url() ) {
						$visual_editor_css[] = str_replace( ',', '%2C', $load_google_fonts );
					}

					$editor_stylesheets = array(
						'starter',
						'main',
						'editor-style',
						'custom-editor',
					);
					foreach ( $editor_stylesheets as $stylesheet ) {
						$visual_editor_css[] = esc_url_raw( add_query_arg(
							array( 'ver' => WM_THEME_VERSION ),
							wm_get_stylesheet_directory_uri( 'assets/css/' . $stylesheet . '.css' )
						) );
					}

					$visual_editor_css = array_filter( (array) apply_filters( 'wmhook_wm_setup_visual_editor_css', $visual_editor_css ) );


			// Processing

				// Localization

					/**
					 * Note: the first-loaded translation file overrides any following ones if the same translation is present.
					 */

					// wp-content/languages/themes/qtron/en_GB.mo

						load_theme_textdomain( 'qtron', trailingslashit( WP_LANG_DIR ) . 'themes/' . WM_THEME_SHORTNAME );

					// wp-content/themes/child-theme/languages/en_GB.mo

						load_theme_textdomain( 'qtron', get_stylesheet_directory() . '/languages' );

					// wp-content/themes/qtron/languages/en_GB.mo

						load_theme_textdomain( 'qtron', get_template_directory() . '/languages' );

				// Indicate widget sidebars can use selective refresh in the Customizer

					/**
					 * You can't use this due to footer masonry widgets layout
					 */
					// add_theme_support( 'customize-selective-refresh-widgets' );

				// Declare support for child theme stylesheet automatic enqueuing

					add_theme_support( 'child-theme-stylesheet' );

				// Add editor stylesheets

					add_editor_style( $visual_editor_css );

				// Custom menus

					register_nav_menus( apply_filters( 'wmhook_wm_setup_menus', array(
						'primary' => __( 'Primary Menu', 'qtron' ),
						'footer'  => __( 'Footer Menu', 'qtron' ),
						'social'  => __( 'Social Links Menu', 'qtron' ),
					) ) );

				// Title tag

					/**
					 * @link  https://codex.wordpress.org/Function_Reference/add_theme_support#Title_Tag
					 */
					add_theme_support( 'title-tag' );

				// Site logo

					/**
					 * @link  https://codex.wordpress.org/Theme_Logo
					 */
					add_theme_support( 'custom-logo' );

				// Feed links

					/**
					 * @link  https://codex.wordpress.org/Function_Reference/add_theme_support#Feed_Links
					 */
					add_theme_support( 'automatic-feed-links' );

				// Enable HTML5 markup

					/**
					 * @link  https://codex.wordpress.org/Function_Reference/add_theme_support#HTML5
					 */
					add_theme_support( 'html5', array(
						'caption',
						'comment-form',
						'comment-list',
						'gallery',
						'navigation-widgets',
						'search-form',
						'script',
						'style',
					) );

				// Custom header

					add_theme_support( 'custom-header', apply_filters( 'wmhook_wm_setup_custom_header_args', array(
							'default-image' => wm_get_stylesheet_directory_uri( 'assets/images/header.jpg' ),
							'header-text'   => false,
							'width'         => $banner_width,
							'height'        => $banner_height,
							'flex-height'   => true,
							'flex-width'    => false,
						) ) );

				// Custom background

					add_theme_support( 'custom-background', apply_filters( 'wmhook_wm_setup_custom_background_args', array(
						'default-color'    => 'dadcde',
					) ) );

				// Post formats

					add_theme_support( 'post-formats', array(
							'audio',
							'gallery',
							'image',
							'link',
							'quote',
							'status',
							'video',
						) );

				// Post types supports

					add_post_type_support( 'attachment', 'custom-fields' );

					add_post_type_support( 'attachment:audio', 'thumbnail' );
					add_post_type_support( 'attachment:video', 'thumbnail' );

				// Thumbnails support

					/**
					 * @link  https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
					 */
					add_theme_support( 'post-thumbnails', array( 'attachment:audio', 'attachment:video' ) );
					add_theme_support( 'post-thumbnails' );

					// Image sizes (x, y, crop)

						if ( ! empty( $image_sizes ) ) {
							foreach ( $image_sizes as $size => $setup ) {
								if ( ! in_array( $size, array( 'thumbnail', 'medium', 'large' ) ) ) {
									add_image_size(
										$size,
										$image_sizes[ $size ]['width'],
										$image_sizes[ $size ]['height'],
										$image_sizes[ $size ]['crop']
									);
								}
							}
						}

		}
	} // /wm_setup



	/**
	 * Set images: default image sizes
	 *
	 * @since    1.2
	 * @version  2.1.0
	 *
	 * @param  array $image_sizes
	 */
	if ( ! function_exists( 'wm_image_sizes' ) ) {
		function wm_image_sizes( $image_sizes ) {

			// Helper variables

				global $content_width;

				// Banner (Custom Header) image size
					$banner_width = absint( wm_option( 'layout-width-site', 1920 ) );

					if ( empty( $banner_width ) ) {
						$banner_width = 1720;
					}

					$banner_height = absint( round( $banner_width / 2.39 ) );


			// Preparing output

				$image_sizes = array(

					'thumbnail' => array(
						'name'        => esc_html_x( 'Thumbnail size', 'WordPress predefined image size name.', 'qtron' ),
						'description' => esc_html__( 'In posts list.', 'qtron' ),
						'width'       => 420,
						'height'      => 280,
						'crop'        => true,
					),

					'medium' => array(
						'name'        => esc_html_x( 'Medium size', 'WordPress predefined image size name.', 'qtron' ),
						'description' => esc_html__( 'Not used by the theme.', 'qtron' ),
						'width'       => absint( $content_width * .62 ),
						'height'      => 9999,
						'crop'        => false
					),

					'large' => array(
						'name'        => esc_html_x( 'Large size', 'WordPress predefined image size name.', 'qtron' ),
						'description' => esc_html__( 'In single post page.', 'qtron' ),
						'width'       => absint( $content_width ),
						'height'      => 9999,
						'crop'        => false,
					),

					'banner' => array(
						'name'        => esc_html__( 'Banner size', 'qtron' ),
						'description' => esc_html__( 'In post/page intro title.', 'qtron' ),
						'width'       => $banner_width,
						'height'      => $banner_height,
						'crop'        => true,
					),

					'square' => array(
						'name'        => esc_html__( 'Square size', 'qtron' ),
						'description' => esc_html__( 'In cubic projects display, staff list and special content module layout (with featured image and icon).', 'qtron' ),
						'width'       => 420,
						'height'      => 420,
						'crop'        => true,
					),

				);


			// Output

				return $image_sizes;

		}
	} // /wm_image_sizes



		/**
		 * Set images: register recommended image sizes notice
		 *
		 * @since    1.2
		 * @version  1.2
		 */
		if ( ! function_exists( 'wm_image_size_notice' ) ) {
			function wm_image_size_notice() {
				add_settings_field(
						//$id
						'recommended-image-sizes',
						//$title
						'',
						//$callback
						'wm_image_size_notice_html',
						//$page
						'media',
						//$section
						'default',
						//$args
						array()
					);

				register_setting(
						//$option_group
						'media',
						//$option_name
						'recommended-image-sizes',
						//$sanitize_callback
						'esc_attr'
					);
			}
		} // /wm_image_size_notice



		/**
		 * Set images: display recommended image sizes notice
		 *
		 * @since    1.2
		 * @version  2.1.0
		 */
		if ( ! function_exists( 'wm_image_size_notice_html' ) ) {
			function wm_image_size_notice_html() {

				// Processing

					get_template_part( 'templates/parts/admin/media', 'image-sizes' );

			}
		} // /wm_image_size_notice_html



	/**
	 * Set typography: Google Fonts
	 *
	 * @since    1.3
	 * @version  1.3
	 *
	 * @param  array $fonts_setup
	 */
	if ( ! function_exists( 'wm_google_fonts' ) ) {
		function wm_google_fonts( $fonts_setup ) {
			//Helper variables
				$fonts_setup = array_unique( array_filter( array( wm_option( 'font-html' ), wm_option( 'font-headings' ) ) ) );

				if (
						! is_admin()
						&& ! wm_option( 'logo' )
						&& wm_option( 'font-logo' )
					)  {
					$fonts_setup[] = wm_option( 'font-logo' );
				}

				if ( empty( $fonts_setup ) ) {
					$fonts_setup = array( 'Josefin Slab:400,300', 'Source Sans Pro:400,300' );
				}

			//Output
				return $fonts_setup;
		}
	} // /wm_google_fonts





/**
 * 40) Assets and design
 */

	/**
	 * Registering theme styles and scripts
	 *
	 * @since    1.0
	 * @version  2.1.0
	 */
	if ( ! function_exists( 'wm_register_assets' ) ) {
		function wm_register_assets() {

			/**
			 * Styles
			 */

				$register_styles = apply_filters( 'wmhook_wm_register_assets_register_styles', array(

					'qtron' => array( 'src' => '' ), // For wp_add_inline_style().

					'wm-google-fonts' => array( 'src' => wm_google_fonts_url() ),

					'wm-stylesheet-starter'    => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/css/starter.css' ) ),
					'wm-stylesheet-main'       => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/css/main.css' ) ),
					'wm-stylesheet-shortcodes' => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/css/shortcodes.css' ) ),
					'wm-stylesheet-responsive' => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/css/responsive.css' ) ),
					'wm-stylesheet-custom'     => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/css/custom.css' ) ),

					'wm-stylesheet-global' => array(
						'src'  => '',
						'deps' => array(
							'wm-stylesheet-starter',
							'wm-stylesheet-main',
							'wm-stylesheet-shortcodes',
							'wm-stylesheet-responsive',
							'wm-stylesheet-custom',
						)
					),

					'wm-stylesheet-print' => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/css/print.css' ), 'media' => 'print' ),

					'wm-stylesheet' => array( 'src' => get_stylesheet_uri(), 'deps' => array( 'wm-stylesheet-global', 'qtron' ) ),

				) );

				foreach ( $register_styles as $handle => $atts ) {
					$src   = ( isset( $atts['src'] )   ) ? ( $atts['src']   ) : ( $atts[0]           );
					$deps  = ( isset( $atts['deps'] )  ) ? ( $atts['deps']  ) : ( false              );
					$ver   = ( isset( $atts['ver'] )   ) ? ( $atts['ver']   ) : ( WM_SCRIPTS_VERSION );
					$media = ( isset( $atts['media'] ) ) ? ( $atts['media'] ) : ( 'all'              );

					wp_register_style( $handle, $src, $deps, $ver, $media );
				}

			/**
			 * Scripts
			 */

				$register_scripts = array(
					'background-check'       => array( wm_get_stylesheet_directory_uri( 'assets/js/plugins/background-check/background-check.min.js' ) ),
					'jquery-hoverdir'        => array( wm_get_stylesheet_directory_uri( 'assets/js/plugins/jquery-hoverdir/jquery.hoverdir.min.js' ) ),
					'wm-skip-link-focus-fix' => array( wm_get_stylesheet_directory_uri( 'assets/js/skip-link-focus-fix.js' )  ),
					'wm-scripts-global'      => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/js/scripts-global.js' ), 'deps' => array( 'jquery', 'imagesloaded', 'background-check', 'wm-scripts-navigation' ) ),
					'wm-scripts-masonry'     => array( 'src' => wm_get_stylesheet_directory_uri( 'assets/js/scripts-masonry.js' ), 'deps' => array( 'jquery-masonry', 'imagesloaded' ) ),
					'wm-scripts-navigation'  => array( wm_get_stylesheet_directory_uri( 'assets/js/scripts-navigation.js' ) ),
					'wm-scripts-parallax'    => array( wm_get_stylesheet_directory_uri( 'assets/js/scripts-parallax.js' ) ),
					'wm-scripts-sticky'      => array( wm_get_stylesheet_directory_uri( 'assets/js/scripts-sticky.js' ) ),
				);

				if ( ! wp_script_is( 'slick', 'registered' ) ) {
					$register_scripts['slick'] = array( wm_get_stylesheet_directory_uri( 'assets/js/plugins/slick/slick.min.js' ) );
				}

				$register_scripts = apply_filters( 'wmhook_wm_register_assets_register_scripts', $register_scripts );

				foreach ( $register_scripts as $handle => $atts ) {
					$src       = ( isset( $atts['src'] )       ) ? ( $atts['src']       ) : ( $atts[0]           );
					$deps      = ( isset( $atts['deps'] )      ) ? ( $atts['deps']      ) : ( array( 'jquery' )  );
					$ver       = ( isset( $atts['ver'] )       ) ? ( $atts['ver']       ) : ( WM_SCRIPTS_VERSION );
					$in_footer = ( isset( $atts['in_footer'] ) ) ? ( $atts['in_footer'] ) : ( true               );

					wp_register_script( $handle, $src, $deps, $ver, $in_footer );
				}

		}
	} // /wm_register_assets



	/**
	 * Frontend HTML head assets enqueue
	 *
	 * @since    1.0
	 * @version  1.9.0
	 */
	if ( ! function_exists( 'wm_enqueue_assets' ) ) {
		function wm_enqueue_assets() {

			// Variables

				$enqueue_styles = $enqueue_scripts = array();

				$body_classes   = (array) apply_filters( 'body_class', array() );
				$footer_widgets = (array) wp_get_sidebars_widgets();


			/**
			 * Styles
			 */

				if ( wm_google_fonts_url() ) {
					$enqueue_styles[] = 'wm-google-fonts';
				}

				$enqueue_styles[] = 'wm-stylesheet';

				$enqueue_styles[] = 'wm-stylesheet-print';

				$enqueue_styles = apply_filters( 'wmhook_wm_enqueue_assets_enqueue_styles', $enqueue_styles );

				foreach ( $enqueue_styles as $handle ) {
					wp_enqueue_style( $handle );
				}


			/**
			 * Scripts
			 */

				// Not enqueued when building page with Beaver Builder
				if ( ! class_exists( 'FLBuilderModel' ) || ! FLBuilderModel::is_builder_active() ) {

					// Parallax
					if ( in_array( 'do-parallax-intro', $body_classes ) ) {
						$enqueue_scripts[] = 'wm-scripts-parallax';
					}

					// Sticky
					if ( in_array( 'do-sticky-header', $body_classes ) ) {
						$enqueue_scripts[] = 'wm-scripts-sticky';
					}

				}

				// Masonry
				if (
					isset( $footer_widgets['footer'] )
					&& count( $footer_widgets['footer'] ) > absint( apply_filters( 'wmhook_widgets_columns', 4, 'footer' ) )
				) {
					$enqueue_scripts[] = 'wm-scripts-masonry';
				}

				// Posts lists scripts
				if (
					is_home()
					|| is_archive()
					|| is_search()
				) {
					$enqueue_scripts[] = 'slick';
					$enqueue_scripts[] = 'wm-scripts-masonry';
				}

				// Global theme scripts
				$enqueue_scripts[] = 'wm-scripts-global';

				// Skip link focus fix
				$enqueue_scripts[] = 'wm-skip-link-focus-fix';

				$enqueue_scripts = apply_filters( 'wmhook_wm_enqueue_assets_enqueue_scripts', $enqueue_scripts );

				foreach ( $enqueue_scripts as $handle ) {
					wp_enqueue_script( $handle );
				}

		}
	} // /wm_enqueue_assets



	/**
	 * Enqueue `comment-reply.js` the right way
	 *
	 * @link  http://wpengineer.com/2358/enqueue-comment-reply-js-the-right-way/
	 *
	 * @since    1.3.2
	 * @version  1.3.2
	 */
	function wm_enqueue_comments_reply() {

		// Processing

			if ( get_option( 'thread_comments' ) ) {
				wp_enqueue_script( 'comment-reply' );
			}

	} // /wm_enqueue_comments_reply



	/**
	 * Customizer preview assets enqueue
	 *
	 * @since    1.0
	 * @version  1.9.0
	 */
	if ( ! function_exists( 'wm_customizer_preview_enqueue_assets' ) ) {
		function wm_customizer_preview_enqueue_assets() {

			// Styles

				if ( file_exists( get_template_directory() . '/assets/css/customize-preview.css' ) ) {

					wp_enqueue_style(
						'qtron-customize-preview',
						get_theme_file_uri( 'assets/css/customize-preview.css' ),
						array(),
						WM_SCRIPTS_VERSION,
						'screen'
					);

				}

			// Scripts

				wp_enqueue_script(
					'qtron-customizer-preview',
					wm_get_stylesheet_directory_uri( 'assets/js/customizer-preview.js' ),
					array( 'jquery', 'customize-preview' ),
					WM_SCRIPTS_VERSION,
					true
				);

		}
	} // /wm_customizer_preview_enqueue_assets



	/**
	 * Get Google Fonts link
	 *
	 * Returns a string such as:
	 * http://fonts.googleapis.com/css?family=Alegreya+Sans:300,400|Exo+2:400,700|Allan&subset=latin,latin-ext
	 *
	 * @since    1.0
	 * @version  1.8.2
	 *
	 * @param  array $fonts Fallback fonts.
	 */
	if ( ! function_exists( 'wm_google_fonts_url' ) ) {
		function wm_google_fonts_url( $fonts = array() ) {

			// Helper variables

				$output = '';
				$family = array();
				$subset = wm_option( 'font-subset' );

				if ( empty( $subset ) ) {
					$subset = 'latin';
				}

				$fonts_setup = array_unique( array_filter( (array) apply_filters( 'wmhook_wm_google_fonts_url_fonts_setup', array() ) ) );

				if ( empty( $fonts_setup ) && ! empty( $fonts ) ) {
					$fonts_setup = (array) $fonts;
				}

				$url_base = wm_fix_ssl_urls( 'http://fonts.googleapis.com/css' );


			// Requirements check

				if ( empty( $fonts_setup ) ) {
					return apply_filters( 'wmhook_wm_google_fonts_url_output', $output );
				}


			// Processing

				foreach ( $fonts_setup as $section ) {
					$font = trim( $section );
					if ( $font ) {
						$family[] = str_replace( ' ', '+', $font );
					}
				}

				if ( ! empty( $family ) ) {
					$output = esc_url_raw( add_query_arg( array(
							'family' => implode( '|', (array) array_unique( $family ) ),
							'subset' => implode( ',', (array) $subset ), //Subset can be array if multiselect Customizer input field used
						), $url_base ) );
				}


			// Output

				return apply_filters( 'wmhook_wm_google_fonts_url_output', $output );

		}
	} // /wm_google_fonts_url



	/**
	 * HTML Body classes
	 *
	 * @since    1.0
	 * @version  1.9.2
	 *
	 * @param  array $classes
	 */
	if ( ! function_exists( 'wm_body_classes' ) ) {
		function wm_body_classes( $classes ) {

			// Helper variables

				$body_classes = array();

				$i = 0;


			// Processing

				// Is not front page?

					if ( ! is_front_page() ) {
						$body_classes['not-front-page'] = ++$i;
					}

				// Sintular?

					if ( is_singular() ) {
						$body_classes['is-singular'] = ++$i;
					}

				// Has featured image?

					if ( is_singular() && has_post_thumbnail() ) {
						$body_classes['has-post-thumbnail'] = ++$i;
					}

				// Is posts list?

					if ( is_home() || is_archive() || is_search() ) {
						$body_classes['is-posts-list'] = ++$i;
					}

				// Enable parallax intro

					$body_classes['do-parallax-intro'] = ++$i;

				// Disabled intro title

					if ( apply_filters( 'wmhook_wm_post_intro_disable', false ) ) {
						$body_classes['intro-title-disabled'] = ++$i;
					}

				// Enable sticky header

					if ( wm_option( 'layout-header-sticky', true ) ) {
						$body_classes['do-sticky-header'] = ++$i;
					}

				// Header layout

					if (
						function_exists( 'wma_meta_option' )
						&& $header_layout = wma_meta_option( 'header' )
					) {
						$body_classes['header-layout-' . sanitize_html_class( $header_layout ) ] = ++$i;
					} else {
						$body_classes['header-layout-' . sanitize_html_class( wm_option( 'layout-header', '' ), 'default' ) ] = ++$i;
					}

				// Internet Explorer class needed to fix equal height CSS

					if ( $GLOBALS['is_IE'] ) {
						$body_classes['is-ie'] = ++$i;
					}

				// Website layout

					$body_classes[ 'site-layout-' . sanitize_html_class( wm_option( 'layout', 'boxed' ) ) ] = ++$i;


			// Output

				$body_classes = array_filter( (array) apply_filters( 'wmhook_wm_body_classes_output', $body_classes ) );
				$classes      = array_merge( $classes, array_flip( $body_classes ) );

				asort( $classes );

				return $classes;

		}
	} // /wm_body_classes



	/**
	 * Post classes
	 *
	 * @since    1.0
	 * @version  1.5
	 *
	 * @param  array $classes
	 */
	if ( ! function_exists( 'wm_post_classes' ) ) {
		function wm_post_classes( $classes ) {

			// Processing

				$classes[] = 'entry';

				// Sticky post

					/**
					 * On paginated posts list the sticky class is not
					 * being applied, so, we need to compensate.
					 */
					if ( is_sticky() ) {
						$classes[] = 'is-sticky';
					}

				// Featured post

					if (
							class_exists( 'NS_Featured_Posts' )
							&& get_post_meta( get_the_ID(), '_is_ns_featured_post', true )
						) {
						$classes[] = 'is-featured';

						if ( 'gallery' == get_post_format() ) {
							$classes[] = 'slide-1-item';
						}

					}


			// Output

				return $classes;

		}
	} // /wm_post_classes





/**
 * 50) Site global markup
 */

	/**
	 * Website DOCTYPE
	 *
	 * @since    1.0
	 * @version  1.0
	 */
	if ( ! function_exists( 'wm_doctype' ) ) {
		function wm_doctype() {
			echo '<!doctype html>';
		}
	} // /wm_doctype



	/**
	 * Website HEAD
	 *
	 * @since    1.0
	 * @version  2.1.0
	 */
	if ( ! function_exists( 'wm_head' ) ) {
		function wm_head() {

			// Output

				echo '<meta charset="' . esc_attr( get_bloginfo( 'charset' ) ) . '">' . PHP_EOL;
				echo '<meta name="viewport" content="width=device-width, initial-scale=1">' . PHP_EOL;
				echo '<link rel="profile" href="http://gmpg.org/xfn/11">' . PHP_EOL;

		}
	} // /wm_head

	add_action( 'wp_head', 'wm_head', 0 );



	/**
	 * Add a pingback url auto-discovery header for singularly identifiable articles.
	 *
	 * @since  2.0.0
	 */
	if ( ! function_exists( 'wm_head_pingback' ) ) {
		function wm_head_pingback() {

			// Output

				if ( is_singular() && pings_open() ) {
					echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
				}

		}
	} // /wm_head_pingback

	add_action( 'wp_head', 'wm_head_pingback', 1 );



	/**
	 * Body top
	 *
	 * @since    1.0
	 * @version  1.9.0
	 */
	if ( ! function_exists( 'wm_site_top' ) ) {
		function wm_site_top() {

			// Output

				echo '<div id="page" class="hfeed site">' . "\r\n";
				echo "\t" . '<div class="site-inner">' . "\r\n";

		}
	} // /wm_site_top



		/**
		 * Body bottom
		 *
		 * @since    1.0
		 * @version  1.9.0
		 */
		if ( ! function_exists( 'wm_site_bottom' ) ) {
			function wm_site_bottom() {

				// Output

					echo "\r\n\t" . '</div><!-- /.site-inner -->';
					echo "\r\n" . '</div><!-- /#page -->' . "\r\n\r\n";

			}
		} // /wm_site_bottom



	/**
	 * Header top
	 *
	 * @since    1.0
	 * @version  1.8.1
	 */
	if ( ! function_exists( 'wm_header_top' ) ) {
		function wm_header_top() {

			// Helper variable

				$class = 'site-header';

				$forced_class = '';

				if (
						function_exists( 'wma_meta_option' )
						&& $forced_class = wma_meta_option( 'header' )
					) {
					$class .= ' ' . $forced_class;
				}

				if ( ! $forced_class ) {
					$class .= ' ' . wm_option( 'layout-header', '' );
				}


			// Output

				echo "\r\n\r\n" . '<header id="masthead" class="' . esc_attr( trim( $class ) ) . '"><div class="inner-wrapper clearfix">' . "\r\n\r\n";

		}
	} // /wm_header_top



		/**
		 * Header bottom
		 *
		 * @since    1.0
		 * @version  1.9.0
		 */
		if ( ! function_exists( 'wm_header_bottom' ) ) {
			function wm_header_bottom() {

				// Output

					echo "\r\n\r\n" . '</div></header>' . "\r\n\r\n";

			}
		} // /wm_header_bottom



		/**
		 * Logo setup attributes modifications
		 *
		 * @since    1.0
		 * @version  1.0
		 *
		 * @param  array $args
		 */
		if ( ! function_exists( 'wm_logo_args' ) ) {
			function wm_logo_args( $args ) {
				//Helper variables
					$post_id = ( is_home() ) ? ( get_option( 'page_for_posts' ) ) : ( null );

				//Preparing output
					//Logo for alternative header
						if (
								function_exists( 'wma_meta_option' )
								&& (
										'alt' === wma_meta_option( 'header', $post_id )
										|| 'transparent-alt' === wma_meta_option( 'header', $post_id )
									)
							) {
							$args['logo_image'] = array( wm_option( 'logo-alt' ), wm_option( 'logo-hidpi-alt' ) );
						}

				//Output
					return $args;
			}
		} // /wm_logo_args



			/**
			 * Logo class
			 *
			 * Apply `theme-default` logo class to style the theme logo for theme demo.
			 *
			 * @since    1.0
			 * @version  1.0
			 *
			 * @param  array $class
			 */
			if ( ! function_exists( 'wm_logo_class' ) ) {
				function wm_logo_class( $class ) {
					if (
							'Q’tron' === get_bloginfo( 'name' )
							&& 'Josefin Slab:400,300' === wm_option( 'font-logo' )
						) {
						return $class . ' demo-logo';
					} else {
						return $class;
					}
				}
			} // /wm_logo_class



		/**
		 * Logo image attributes
		 *
		 * @since    1.0
		 * @version  1.0
		 */
		if ( ! function_exists( 'wm_logo_image_attributes' ) ) {
			function wm_logo_image_attributes( $atts ) {
				//Helper variables
					$transparent_header_logo = array_filter( array( wm_option( 'logo-alt' ), wm_option( 'logo-hidpi-alt' ) ) );

				//Preparing output
					if ( ! empty( $transparent_header_logo ) ) {
						$atts['data-alt'] = esc_url( $transparent_header_logo[0] );

						if ( isset( $transparent_header_logo[1] ) ) {
							$atts['data-alt-hidpi'] = esc_url( $transparent_header_logo[1] );
						}
					}

				//Output
					return $atts;
			}
		} // /wm_logo_image_attributes



	/**
	 * Navigation
	 *
	 * @since    1.0
	 * @version  1.6.0
	 */
	if ( ! function_exists( 'wm_navigation' ) ) {
		function wm_navigation() {

				// Output

					get_template_part( 'templates/parts/component-menu', 'primary' );

		}
	} // /wm_navigation



		/**
		 * Navigation item classes
		 *
		 * @since    1.0
		 * @version  2.1.0
		 *
		 * @param  array   $classes The CSS classes that are applied to the menu item's `<li>` element.
		 * @param  WP_Post $item    The current menu item.
		 * @param  object  $args    An object of wp_nav_menu() arguments.
		 * @param  int     $depth   Depth of menu item. Used for padding. Since WordPress 4.1.
		 */
		if ( ! function_exists( 'wm_nav_item_classes' ) ) {
			function wm_nav_item_classes( $classes, $item, $args, $depth = 0 ) {

				// Requirements check

					if ( ! isset( $item->title ) ) {
						return $classes;
					}


				// Processing

					// Converting array to string for searching the specific class name parts.
					$classes = implode( ' ', $classes );

					// Fixing blog page ancestry for posts.
					if (
						false !== strpos( $classes, 'current_page_ancestor' )
						|| false !== strpos( $classes, 'current_page_parent' )
					) {
						$classes .= ' current-menu-ancestor';
					}

					// General class for active menu.
					if ( false !== strpos( $classes, 'current-menu' ) ) {
						$classes .= ' active-menu-item';
					}

					// Has menu item description?
					if ( trim( $item->description ) ) {
						$classes .= ' menu-item-has-description';
					}


				// Output

					return explode( ' ', $classes );

			}
		} // /wm_nav_item_classes



		/**
		 * Navigation item improvements
		 *
		 * @since    1.0
		 * @version  1.3.5
		 */
		if ( ! function_exists( 'wm_nav_item_process' ) ) {
			function wm_nav_item_process( $item_output, $item, $depth, $args ) {

				// Processing

					if ( 'primary' == $args->theme_location ) {

						// Description

							if ( trim( $item->description ) ) {

								$item_output = str_replace(
										$args->link_after . '</a>',
										'<span class="menu-item-description">' . trim( $item->description ) . '</span>' . $args->link_after . '</a>',
										$item_output
									);

							}

						// Submenu expander button

							if ( in_array( 'menu-item-has-children', (array) $item->classes ) ) {

								$item_output = str_replace(
										$args->link_after . '</a>',
										$args->link_after . ' <span class="expander"></span></a>',
										$item_output
									);

							}

					}


				// Output

					return $item_output;

			}
		} // /wm_nav_item_process



		/**
		 * Display social links
		 *
		 * @since    1.0
		 * @version  1.0
		 */
		if ( ! function_exists( 'wm_menu_social' ) ) {
			function wm_menu_social() {

				// Output

					get_template_part( 'templates/parts/component-menu', 'social' );

			}
		} // /wm_menu_social



	/**
	 * Post heading (title)
	 *
	 * Does not display on pages.
	 *
	 * @since    1.0
	 * @version  1.8.1
	 *
	 * @param  array $args Heading setup arguments
	 */
	if ( ! function_exists( 'wm_post_title' ) ) {
		function wm_post_title( $args = array() ) {
			//Helper variables
				global $post;

				//Requirements check
					if (
							! ( $title = get_the_title() )
							|| ( is_singular() && wm_paginated_suffix() )
							|| apply_filters( 'wmhook_wm_post_title_disable', false )
						) {
						return;
					}

				$output = '';

				$args = wp_parse_args( $args, apply_filters( 'wmhook_wm_post_title_defaults', array(
						'class'           => 'entry-title',
						'class_container' => 'entry-header',
						'link'            => esc_url( get_permalink() ),
						'output'          => '<header class="{class_container}"><{tag} class="{class}">{title}</{tag}></header>',
						'tag'             => 'h1',
						'title'           => '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $title . '</a>',
					) ) );

			//Preparing output
				//Singular title (no link applied)
					if ( is_single() ) {

						if ( $suffix = wm_paginated_suffix( 'small' ) ) {
							$args['title'] .= $suffix;
						} else {
							$args['title'] = $title;
						}

					}

				//Filter processed $args
					$args = apply_filters( 'wmhook_wm_post_title_args', $args );

				//Generating output HTML
					$replacements = apply_filters( 'wmhook_wm_post_title_replacements', array(
							'{class}'           => esc_attr( $args['class'] ),
							'{class_container}' => esc_attr( $args['class_container'] ),
							'{tag}'             => esc_attr( $args['tag'] ),
							'{title}'           => do_shortcode( $args['title'] ),
						), $args );
					$output = strtr( $args['output'], $replacements );

			//Output
				echo apply_filters( 'wmhook_wm_post_title_output', $output, $args );
		}
	} // /wm_post_title



	/**
	 * Content top
	 *
	 * @since    1.0
	 * @version  1.9.0
	 */
	if ( ! function_exists( 'wm_content_top' ) ) {
		function wm_content_top() {

			// Output

				echo "\r\n\r\n" . '<div id="content" class="site-content">';
				echo "\r\n\t"   . '<div id="primary" class="content-area">';
				echo "\r\n\t\t" . '<main id="main" class="site-main clearfix">' . "\r\n\r\n";

		}
	} // /wm_content_top



		/**
		 * Content bottom
		 *
		 * @since    1.0
		 * @version  1.9.0
		 */
		if ( ! function_exists( 'wm_content_bottom' ) ) {
			function wm_content_bottom() {

				// Output

					echo "\r\n\r\n\t\t" . '</main><!-- /#main -->';
					echo "\r\n\t"       . '</div><!-- /#primary -->';
					echo "\r\n"         . '</div><!-- /#content -->' . "\r\n\r\n";

			}
		} // /wm_content_bottom



		/**
		 * Entry top
		 *
		 * @since    1.0
		 * @version  1.0
		 */
		if ( ! function_exists( 'wm_entry_top' ) ) {
			function wm_entry_top() {
				//Post meta
					if ( in_array( get_post_type(), apply_filters( 'wmhook_wm_entry_top_meta_post_types', array( 'post' ) ) ) ) {

						if ( is_single() ) {

							echo wm_post_meta( apply_filters( 'wmhook_wm_entry_top_meta', array(
									'class' => 'entry-meta entry-meta-top',
									'meta'  => array( 'edit', 'date', 'views', 'likes', 'category', 'author' ),
								) ) );

						}

					}
			}
		} // /wm_entry_top



		/**
		 * Entry bottom
		 *
		 * @since    1.0
		 * @version  1.1
		 */
		if ( ! function_exists( 'wm_entry_bottom' ) ) {
			function wm_entry_bottom() {
				//Helper variables
					$post_id = get_the_ID();

				//Post meta
					if ( in_array( get_post_type(), apply_filters( 'wmhook_wm_entry_bottom_meta_post_types', array( 'post' ) ) ) ) {
						if ( is_single() ) {
							echo wm_post_meta( apply_filters( 'wmhook_wm_entry_bottom_meta', array(
									'class' => 'entry-meta entry-meta-bottom',
									'meta'  => array( 'edit', 'tags' ),
								) ) );
						} else {
							echo wm_post_meta( apply_filters( 'wmhook_wm_entry_bottom_meta', array(
									'class'       => 'entry-meta',
									'meta'        => array( 'date', 'views', 'comments', 'likes' ),
									'date_format' => 'j M Y',
								) ) );
						}
					}

				//Post navigation
					if ( in_array( get_post_type(), apply_filters( 'wmhook_wm_entry_bottom_post_nav', array( 'post' ) ) ) ) {
						wm_post_nav();
					}

				//Comments
					if (
							! ( is_page() && is_front_page() )
							&& ( is_page( $post_id ) || is_single( $post_id ) )
						) {
						comments_template( '', true );
					}
			}
		} // /wm_entry_bottom



		/**
		 * Sticky post label
		 *
		 * @since    1.0
		 * @version  1.5
		 */
		if ( ! function_exists( 'wm_sticky_label' ) ) {
			function wm_sticky_label() {
				if ( is_sticky() ) {
					echo '<div class="label-sticky" title="' . __( 'This is sticky post', 'qtron' ) . '"><span class="genericon genericon-pinned"></span></div>';
				}
			}
		} // /wm_sticky_label



		/**
		 * Post thumbnail (featured image) display size
		 *
		 * @since    1.2
		 * @version  1.2
		 *
		 * @param  string $image_size
		 */
		if ( ! function_exists( 'wm_post_thumbnail_size' ) ) {
			function wm_post_thumbnail_size( $image_size ) {
				//Preparing output
					if (
							is_single( get_the_ID() )
							|| is_attachment()
						) {

						$image_size = 'large';

					} else {

						$image_size = 'thumbnail';

					}

				//Output
					return $image_size;
			}
		} // /wm_post_thumbnail_size



		/**
		 * Excerpt
		 *
		 * Displays the excerpt properly.
		 * If the post is password protected, display a message.
		 * If the post has more tag, display the content appropriately.
		 *
		 * @since    1.0
		 * @version  2.5.6
		 *
		 * @param  string $excerpt
		 */
		if ( ! function_exists( 'wm_excerpt' ) ) {
			function wm_excerpt( $excerpt = '' ) {

				// Variables

					$post_id = get_the_ID();


				// Requirements check

					if ( post_password_required( $post_id ) ) {
						if ( ! is_single( $post_id ) ) {
							return esc_html__( 'This content is password protected.', 'qtron' )
							       . ' <a href="' . esc_url( get_permalink() ) . '">'
							       . esc_html__( 'Enter the password to view it.', 'qtron' )
							       . '</a>';
						}
						return;
					}


				// Processing

					if (
						false === strpos( $excerpt, 'page-summary' )
						&& ! is_single( $post_id )
						&& wm_has_more_tag()
					) {

						if ( has_excerpt( $post_id ) ) {
							$excerpt = str_replace(
								'entry-summary',
								'entry-summary has-more-tag',
								$excerpt
							);
						} else {
							$excerpt = '';
						}

						$excerpt = apply_filters( 'the_content', $excerpt . get_the_content( '' ) . wm_get_continue_reading_html() );

					}


				// Output

					return $excerpt;

			}
		} // /wm_excerpt



			/**
			 * Wrap excerpt within a `div.entry-summary`.
			 *
			 * Line breaks are required for proper functionality of `wpautop()` later on.
			 *
			 * @since    1.9.1
			 * @version  1.9.3
			 *
			 * @param  string $post_excerpt
			 */
			if ( ! function_exists( 'wm_wrap_excerpt' ) ) {
				function wm_wrap_excerpt( $post_excerpt = '' ) {

					// Requirements check

						if ( empty( $post_excerpt ) ) {
							return $post_excerpt;
						}


					// Output

						return '<div class="entry-summary">' . PHP_EOL . $post_excerpt . PHP_EOL . '</div>';

				}
			} // /wm_wrap_excerpt



			/**
			 * Adding "Continue reading" link to excerpt
			 *
			 * @since    1.0.0
			 * @version  1.9.1
			 *
			 * @param  string  $post_excerpt  The post excerpt.
			 * @param  WP_Post $post          Post object.
			 */
			if ( ! function_exists( 'wm_excerpt_continue_reading' ) ) {
				function wm_excerpt_continue_reading( $post_excerpt = '', $post = null ) {

					// Variables

						$post_id = get_the_ID();


					// Processing

						if (
							! post_password_required( $post_id )
							&& ! is_single( $post_id )
							&& ! wm_has_more_tag()
							&& in_array(
								get_post_type( $post_id ),
								(array) apply_filters( 'wmhook_wm_excerpt_continue_reading_post_type', array( 'post', 'page' ) )
							)
						) {
							$post_excerpt .= wm_get_continue_reading_html( $post );
						}


					// Output

						return $post_excerpt;

				}
			} // /wm_excerpt_continue_reading



			/**
			 * Get "Continue reading" HTML.
			 *
			 * @since    1.9.1
			 * @version  1.9.1
			 *
			 * @param  WP_Post $post   Post object.
			 * @param  string  $scope  Optional identification of specific "Continue reading" text for better filtering.
			 */
			if ( ! function_exists( 'wm_get_continue_reading_html' ) ) {
				function wm_get_continue_reading_html( $post = null, $scope = '' ) {

					// Pre

						$pre = apply_filters( 'wmhook_wm_get_continue_reading_html_pre', false, $post, $scope );

						if ( false !== $pre ) {
							return $pre;
						}


					// Variables

						$html     = '';
						$scope    = (string) $scope;
						$template = 'templates/parts/component-link-more';


					// Processing

						ob_start();

						if ( $scope && locate_template( $template . '-' . $scope . '.php' ) ) {
							get_template_part( $template, $scope );
						} else {
							get_template_part( $template, get_post_type() );
						}

						/**
						 * Stripping all new line and tab characters to prevent `wpautop()` messing things up later.
						 *
						 * "\t" - a tab.
						 * "\n" - a new line (line feed).
						 * "\r" - a carriage return.
						 * "\x0B" - a vertical tab.
						 */
						$html = str_replace(
							array( "\t", "\n", "\r", "\x0B" ),
							'',
							ob_get_clean()
						);


					// Output

						return (string) apply_filters( 'wmhook_wm_get_continue_reading_html', $html, $post, $scope );

				}
			} // /wm_get_continue_reading_html



			/**
			 * Excerpt length
			 *
			 * @since    1.0
			 * @version  1.0
			 *
			 * @param  absint $length
			 */
			if ( ! function_exists( 'wm_excerpt_length' ) ) {
				function wm_excerpt_length( $length ) {
					return 12;
				}
			} // /wm_excerpt_length



			/**
			 * Excerpt more
			 *
			 * @since    1.0
			 * @version  1.0
			 *
			 * @param  string $more
			 */
			if ( ! function_exists( 'wm_excerpt_more' ) ) {
				function wm_excerpt_more( $more ) {
					return '&hellip;';
				}
			} // /wm_excerpt_more



		/**
		 * Previous and next post links
		 *
		 * Since WordPress 4.1 you can use the_post_navigation() and/or get_the_post_navigation().
		 * However, you are modifying markup by applying custom classes, so stick with this
		 * cusotm function for now.
		 *
		 * @todo  Transfer to WordPress 4.1+ core functionality.
		 *
		 * @since    1.0
		 * @version  1.8.1
		 */
		if ( ! function_exists( 'wm_post_nav' ) ) {
			function wm_post_nav() {
				//Requirements check
					if ( ! is_singular() || is_page() ) {
						return;
					}

				//Helper variables
					$output = $prev_class = $next_class = '';

					$previous = ( is_attachment() ) ? ( get_post( get_post()->post_parent ) ) : ( get_adjacent_post( false, '', true ) );
					$next     = get_adjacent_post( false, '', false );

				//Requirements check
					if (
							( ! $next && ! $previous )
							|| ( is_attachment() && 'attachment' == $previous->post_type )
						) {
						return;
					}

					$links_count = absint( (bool) $next ) + absint( (bool) $previous );

				//Preparing output
					if ( $previous && has_post_thumbnail( $previous->ID ) ) {
						$prev_class = " has-post-thumbnail";
					}
					if ( $next && has_post_thumbnail( $next->ID ) ) {
						$next_class = " has-post-thumbnail";
					}

					if ( is_attachment() ) {
						$output .= get_previous_post_link( '<div class="nav-previous nav-link' . $prev_class . '">%link</div>', __( '<span class="meta-nav">Published In</span> <span class="post-title">%title</span>', 'qtron' ) );
					} else {
						$output .= get_previous_post_link( '<div class="nav-previous nav-link' . $prev_class . '">%link</div>', __( '<span class="meta-nav">Previous</span> <span class="post-title">%title</span>', 'qtron' ) );
						$output .= get_next_post_link( '<div class="nav-next nav-link' . $next_class . '">%link</div>', __( '<span class="meta-nav">Next</span> <span class="post-title">%title</span>', 'qtron' ) );
					}

					if ( $output ) {
						$output = '<nav class="navigation post-navigation links-count-' . $links_count . '"><h1 class="screen-reader-text">' . __( 'Post navigation', 'qtron' ) . '</h1><div class="nav-links">' . $output . '</div></nav>';
					}

				//Output
					echo apply_filters( 'wmhook_wm_post_nav_output', $output );
			}
		} // /wm_post_nav



		/**
		 * Pagination
		 *
		 * @since    1.0
		 * @version  1.8.0
		 */
		if ( ! function_exists( 'wm_pagination' ) ) {
			function wm_pagination() {

				// Requirements check

					if ( class_exists( 'The_Neverending_Home_Page' ) ) {
						// Don't display pagination if Jetpack Infinite Scroll in use.
						return;
					}


				// Helper variables

					$output = paginate_links( array(
						'prev_text' => '&laquo;',
						'next_text' => '&raquo;',
					) );


				// Output

					if ( ! empty( $output ) ) {
						echo '<div class="pagination">' . $output . '</div>';
					} else {
						return;
					}

			}
		} // /wm_pagination



	/**
	 * Footer
	 *
	 * @since    1.0
	 * @version  1.9.3
	 */
	if ( ! function_exists( 'wm_footer' ) ) {
		function wm_footer() {

			// Requirements check

				$footer_layout = ( function_exists( 'wma_meta_option' ) ) ? ( wma_meta_option( 'footer' ) ) : ( '' );

				if ( 'none' === $footer_layout ) {
					return;
				}


			// Helper variables

				$footer_credits = trim( wm_option( 'text-credits' ) );

				if ( '-' == $footer_credits ) {

					// Make possible to remove credits

						$footer_credits = '';

				} elseif ( empty( $footer_credits ) ) {

					// Default credits text

						$footer_credits  = '&copy; ' . date( 'Y' );
						$footer_credits .= ' ';
						$footer_credits .= '<a href="' . home_url( '/' ) . '" title="' . get_bloginfo( 'name' ) . '">' . get_bloginfo( 'name' ) . '</a>.';
						$footer_credits .= ' ';
						$footer_credits .= sprintf(
							esc_html_x( 'Using %1$s %2$s theme.', '1: theme name, 2: linked "WordPress" word.', 'qtron' ),
							'<a rel="nofollow" href="' . WM_THEME_URI . '"><strong>' . WM_THEME_NAME . '</strong></a>',
							'<a rel="nofollow" href="' . esc_url( __( 'https://wordpress.org/', 'qtron' ) ) . '">WordPress</a>'
						);

						if ( function_exists( 'get_the_privacy_policy_link' ) ) {
							$footer_credits .= get_the_privacy_policy_link( ' ', '.' );
						}

						$footer_credits .= ' ';
						$footer_credits .= '<a href="#top" class="back-to-top">' . __( 'Back to top &uarr;', 'qtron' ) . '</a>';

				}


			// Output

				// Footer widgets

					if ( 'credits' !== $footer_layout ) {
						get_sidebar( 'footer' );
					}

				// Footer menu

					if ( 'widgets' !== $footer_layout ) {
						get_template_part( 'templates/parts/component-menu', 'footer' );
					}

				// Credits

					if (
						'widgets' !== $footer_layout
						&& $footer_credits
					) {
						echo '<div class="site-footer-area footer-area-site-info">';
							echo '<div class="site-footer-area-inner clearfix">';

								echo '<div class="site-info">' . wp_kses_post( $footer_credits ) . '</div>';

								wm_menu_social();

							echo '</div>';
						echo '</div>';
					}

		}
	} // /wm_footer



		/**
		 * Footer top
		 *
		 * @since    1.0
		 * @version  1.9.0
		 */
		if ( ! function_exists( 'wm_footer_top' ) ) {
			function wm_footer_top() {

				// Output

					echo "\r\n\r\n" . '<footer id="colophon" class="site-footer">' . "\r\n\r\n";

			}
		} // /wm_footer_top



		/**
		 * Footer bottom
		 *
		 * @since    1.0
		 * @version  1.9.0
		 */
		if ( ! function_exists( 'wm_footer_bottom' ) ) {
			function wm_footer_bottom() {

				// Output

					echo "\r\n\r\n" . '</footer>' . "\r\n\r\n";

			}
		} // /wm_footer_bottom



		/**
		 * Website footer custom scripts
		 *
		 * Outputs custom scripts set in post/page 'custom_js' custom field.
		 *
		 * @since    1.0
		 * @version  1.0
		 */
		if ( ! function_exists( 'wm_footer_custom_scripts' ) ) {
			function wm_footer_custom_scripts() {
				//Requirements check
					if (
							! is_singular()
							|| ! ( $output = get_post_meta( get_the_ID(), 'custom_js', true ) )
						) {
						return;
					}

				//Helper variables
					$output = "\r\n\r\n<!--Custom singular JS -->\r\n<script type='text/javascript'>\r\n/* <![CDATA[ */\r\n" . wp_unslash( esc_js( str_replace( array( "\r", "\n", "\t" ), '', $output ) ) ) . "\r\n/* ]]> */\r\n</script>\r\n";

				//Output
					echo apply_filters( 'wmhook_wm_footer_custom_scripts_output', $output );
			}
		} // /wm_footer_custom_scripts





/**
 * 100) Other functions
 */

	/**
	 * Register predefined widget areas (sidebars)
	 *
	 * @since    1.0
	 * @version  1.9.0
	 */
	if ( ! function_exists( 'wm_register_widget_areas' ) ) {
		function wm_register_widget_areas() {

			// Processing

				foreach( wm_helper_var( 'widget-areas' ) as $id => $area ) {
					register_sidebar( array(
						'id'            => $id,
						'name'          => $area['name'],
						'description'   => isset( $area['description'] ) ? ( $area['description'] ) : ( '' ),
						'before_widget' => '<section id="%1$s" class="widget %2$s">',
						'after_widget'  => '</section>',
						'before_title'  => '<h3 class="widget-title">',
						'after_title'   => '</h3>'
					) );
				}

		}
	} // /wm_register_widget_areas



	/**
	 * Include Visual Editor (TinyMCE) addons
	 *
	 * @since    1.0
	 * @version  1.8.2
	 */
	if ( ! function_exists( 'wm_visual_editor' ) ) {
		function wm_visual_editor() {
			if ( is_admin() || isset( $_GET['fl_builder'] ) ) {
				require_once get_theme_file_path( WM_LIBRARY_DIR . 'inc/visual-editor.php' );
			}
		}
	} // /wm_visual_editor



		/**
		 * Adding additional formats to TinyMCE editor
		 *
		 * @since    1.0
		 * @version  1.0
		 *
		 * @param  array $formats
		 */
		if ( ! function_exists( 'wm_visual_editor_custom_mce_format' ) ) {
			function wm_visual_editor_custom_mce_format( $formats ) {
				//Preparing output
					$formats[] = array(
							'title' => __( 'Dropcaps', 'qtron' ),
							'items' => array(

								array(
									'title'    => __( 'Dropcap text', 'qtron' ),
									'selector' => 'p',
									'classes'  => 'dropcap-text',
								),

							),
						);

				//Return
					return $formats;
			}
		} // /wm_visual_editor_custom_mce_format



	/**
	 * Disable post title
	 *
	 * @param  bool $disable
	 */
	if ( ! function_exists( 'wm_disable_post_title' ) ) {
		function wm_disable_post_title( $disable ) {
			//Helper variables
				$disabled_post_formats = array( 'link', 'quote', 'status' );
				if ( ! is_single() && has_excerpt() ) {
					$disabled_post_formats[] = 'image';
				}

			//Preparing output
				if (
						in_array( get_post_format(), $disabled_post_formats )
						|| is_page( get_the_ID() )
					) {
					$disable = true;
				}

			//Output
				return $disable;
		}
	} // /wm_disable_post_title



	/**
	 * Get complementary color
	 *
	 * @since    1.0
	 * @version  1.0
	 *
	 * @param  string $hex
	 * @param  string $addons
	 *
	 * @return  string Complementary hex color to $hex.
	 */
	if ( ! function_exists( 'wm_color_complementary' ) ) {
		function wm_color_complementary( $hex, $addons = '' ) {
			//Helper variables
				$output    = '';
				$rgb_array = ( function_exists( 'wma_color_hex_to_rgb' ) ) ? ( wma_color_hex_to_rgb( $hex ) ) : ( array() );

			//Requirements check
				if ( empty( $rgb_array ) ) {
					return;
				}

			//Preparing output
				$rgb_array['r'] = 255 - $rgb_array['r'];
				$rgb_array['g'] = 255 - $rgb_array['g'];
				$rgb_array['b'] = 255 - $rgb_array['b'];

				//@link  http://bavotasan.com/2011/convert-hex-color-to-rgb-using-php/
					$output  = '#';
					$output .= str_pad( dechex( $rgb_array['r'] ), 2, '0', STR_PAD_LEFT );
					$output .= str_pad( dechex( $rgb_array['g'] ), 2, '0', STR_PAD_LEFT );
					$output .= str_pad( dechex( $rgb_array['b'] ), 2, '0', STR_PAD_LEFT );
					$output .= $addons;

			//Output
				return apply_filters( 'wmhook_wm_color_complementary_output', $output, $hex );
		}
	} // /wm_color_complementary





/**
 * 200) Pluggable
 */

	// Welcome page.
	require_once get_theme_file_path( WM_SETUP_DIR . 'welcome/class-welcome.php' );

	// Theme options arrays
	require_once get_theme_file_path( WM_SETUP_DIR . 'setup-theme-options.php' );

	// Custom Header (Banner)
	require_once get_theme_file_path( WM_SETUP_DIR . 'custom-header/custom-header.php' );

	// Post formats support
	require_once get_theme_file_path( WM_SETUP_DIR . 'post-formats/post-formats.php' );

	// Theme update notification functionality
	require_once get_theme_file_path( WM_SETUP_DIR . 'update-notification/class-update-notification.php' );





/**
 * 999) Plugins integration
 */

	// WebMan Amplifier integration
		require_once get_theme_file_path( WM_SETUP_DIR . 'webman-amplifier/webman-amplifier.php' );

	// Jetpack integration
		require_once get_theme_file_path( WM_SETUP_DIR . 'jetpack/jetpack.php' );

	// Beaver Builder integration
		require_once get_theme_file_path( WM_SETUP_DIR . 'beaver-builder/beaver-builder.php' );

	// Breadcrumb NavXT integration
		require_once get_theme_file_path( WM_SETUP_DIR . 'breadcrumb-navxt/breadcrumb-navxt.php' );

	// Subtitles & WP Subtitle integration
		require_once get_theme_file_path( WM_SETUP_DIR . 'subtitles/class-subtitles.php' );

	// WooSidebars integration
		require_once get_theme_file_path( WM_SETUP_DIR . 'woosidebars/woosidebars.php' );

	// One Click Demo Import
	if ( ( class_exists( 'OCDI_Plugin' ) || class_exists( 'PT_One_Click_Demo_Import' ) ) && is_admin() ) {
		require_once get_theme_file_path( WM_SETUP_DIR . 'one-click-demo-import/one-click-demo-import.php' );
	}
