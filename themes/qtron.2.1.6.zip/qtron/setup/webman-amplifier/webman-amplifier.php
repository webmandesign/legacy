<?php
/**
 * Plugin integration
 *
 * WebMan Amplifier
 *
 * @link  https://wordpress.org/plugins/webman-amplifier/
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  2.1.7
 *
 * CONTENT:
 * -  1) Requirements check
 * - 10) Actions and filters
 * - 20) Plugin integration
 */





/**
 * 1) Requirements check
 */

	if ( ! class_exists( 'WM_Amplifier' ) ) {
		return;
	}





/**
 * 10) Actions and filters
 */

	/**
	 * Actions
	 */

		//Plugin setup
			add_action( 'after_setup_theme', 'wm_wmamp_setup' );
		//Custom post types redirects
			add_action( 'template_redirect', 'wm_wmamp_cp_redirects' );



	/**
	 * Filters
	 */

		//Plugin version shortcodes support
			add_filter( 'wmhook_shortcode_supported_version', 'wm_wmamp_supported_shortcode_until_version' );
		//Shortcodes
			add_filter( 'wmhook_shortcode_codes_globals',                  'wm_wmamp_shortcodes_globals'                     );
			add_filter( 'wmhook_shortcode_button_classes',                 'wm_wmamp_button_class'                           );
			add_filter( 'wmhook_shortcode__attributes',                    'wm_wmamp_shortcodes_atts',                 10, 2 );
			add_filter( 'wmhook_shortcode_posts_image_size',               'wm_wmamp_posts_image_size'                       );
			add_filter( 'wmhook_shortcode_posts_helper',                   'wm_wmamp_posts_item_class',                10, 2 );
			add_filter( 'wmhook_shortcode_testimonials_image_size',        'wm_wmamp_testimonials_image_size'                );
			add_filter( 'wmhook_shortcode_testimonials_item_class',        'wm_wmamp_testimonials_item_class',         10, 2 );
			add_filter( 'wmhook_shortcode_content_module_layout_elements', 'wm_wmamp_content_module_layout_elements',  10, 4 );
			add_filter( 'wmhook_shortcode_posts_enqueue_scripts',          'wm_wmamp_shortcode_posts_enqueue_scripts', 10, 2 );
		//Metaboxes
			add_filter( 'wmhook_wmamp_cp_metafields_wm_modules',              'wm_wmamp_content_modules_metafields'       );
			add_filter( 'wmhook_wmamp_cp_metafields_wm_projects',             'wm_wmamp_projects_metafields'              );
			add_filter( 'wmhook_wmamp_cp_metafields_wm_staff_contact_fields', 'wm_wmamp_staff_contact_fields',      10, 2 );
		//Functions modifications
			add_filter( 'wmhook_wmamp_wma_pagination_output', 'wm_wmamp_pagination' );





/**
 * 20) Plugin integration
 */

	/**
	 * Plugin setup
	 *
	 * @since    1.0
	 * @version  1.5
	 */
	if ( ! function_exists( 'wm_wmamp_setup' ) ) {
		function wm_wmamp_setup() {

			// Processing

				add_theme_support( 'webman-amplifier', array(
						'cp-logos',
						'cp-modules',
						'cp-projects',
						'cp-staff',
						'cp-testimonials',

						'widget-contact',
						// 'widget-module',
						// 'widget-posts',
						'widget-subnav',
						// 'widget-tabbed-widgets',
						'widget-twitter',

						'disable-visual-composer-support'
					) );

		}
	} // /wm_wmamp_setup



	/**
	 * Custom posts types redirects
	 *
	 * @since    1.0
	 * @version  1.0
	 */
	if ( ! function_exists( 'wm_wmamp_cp_redirects' ) ) {
		function wm_wmamp_cp_redirects() {
			//Helper variables
				$get_post_type = get_post_type( get_the_ID() );

				$redirects = array(
						'wm_logos'        => home_url(),
						'wm_modules'      => home_url(),
						'wm_staff'        => home_url(),
						'wm_testimonials' => home_url(),
					);

			//Processing
				if ( in_array( $get_post_type, array_keys( $redirects ) ) ) {
					wp_redirect( $redirects[ $get_post_type ], 301 );
					exit;
				}
		}
	} // /wm_wmamp_cp_redirects



	/**
	 * SHORTCODES
	 */

		/**
		 * Supported shortcodes version
		 *
		 * Use this to declare the plugin version that your theme supports.
		 * It is possible that in future versions of the plugin there will be more
		 * shortcodes added and your theme might not suppot them out of the box.
		 * Setting this version number will make sure only the shortcodes included
		 * with the specific plugin version will be available to your theme users.
		 *
		 * @since    1.0
		 * @version  1.5
		 */
		if ( ! function_exists( 'wm_wmamp_supported_shortcode_until_version' ) ) {
			function wm_wmamp_supported_shortcode_until_version() {

				// Output

					return '1.3';

			}
		} // /wm_wmamp_supported_shortcode_until_version



		/**
		 * Modifying shortcodes definitions and removing obsolete shortcodes
		 *
		 * @uses  unset() - no need to check for isset()
		 * @link  http://php.net/manual/en/function.unset.php#72389
		 *
		 * @since    1.0
		 * @version  1.6.1
		 *
		 * @param  array $definitions
		 */
		if ( ! function_exists( 'wm_wmamp_shortcodes_definitions' ) ) {
			function wm_wmamp_shortcodes_definitions( $definitions ) {

				// Helper variables

					$key = '';
					if ( isset( $definitions['posts']['compatibility/beaver-builder'] ) ) {
						$key = 'compatibility/beaver-builder';
					} elseif ( isset( $definitions['posts']['bb_plugin'] ) ) {
						$key = 'bb_plugin'; // Backwards compatibility
					}


				// Requirements check

					if ( empty( $key ) ) {
						return $definitions;
					}


				// Processing

					// Removing obsolete shortcodes

						// WebMan Amplifier native

							unset( $definitions['audio'] );
							unset( $definitions['column'] );
							unset( $definitions['countdown_timer'] );
							unset( $definitions['dropcap'] );
							unset( $definitions['icon'] );
							unset( $definitions['list'] );
							unset( $definitions['pre'] );
							unset( $definitions['price'] );
							unset( $definitions['pricing_table'] );
							unset( $definitions['progress'] );
							unset( $definitions['row'] );
							unset( $definitions['search_form'] );
							unset( $definitions['separator_heading'] );
							unset( $definitions['slideshow'] );
							unset( $definitions['video'] );
							unset( $definitions['widget_area'] );

					// Modifying definitions

						// Content Module

							unset( $definitions['content_module'][ $key ]['form']['general']['sections']['multiple']['fields']['pagination'] );
							unset( $definitions['content_module'][ $key ]['form']['description'] );

						// Posts

							unset( $definitions['posts'][ $key ]['form']['others']['sections']['general']['fields']['related'] );
							unset( $definitions['posts'][ $key ]['form']['others']['sections']['general']['fields']['filter_layout'] );
							unset( $definitions['posts'][ $key ]['form']['description'] );

						// Testimonials

							unset( $definitions['testimonials'][ $key ]['form']['description'] );
							unset( $definitions['testimonials'][ $key ]['form']['others'] );


				// Output

					return $definitions;

			}
		} // /wm_wmamp_shortcodes_definitions

		add_filter( 'wmhook_shortcode_definitions', 'wm_wmamp_shortcodes_definitions' );



		/**
		 * Modifying shortcodes globals
		 *
		 * @since    1.0
		 * @version  1.0
		 */
		if ( ! function_exists( 'wm_wmamp_shortcodes_globals' ) ) {
			function wm_wmamp_shortcodes_globals( $array ) {
				//Preparing output

					//Color names
						$array['colors'] = array(
								'success' => _x( 'Success', 'Generalized, abstract color name.', 'qtron' ),
								'info'    => _x( 'Info', 'Generalized, abstract color name.', 'qtron' ),
								'warning' => _x( 'Warning', 'Generalized, abstract color name.', 'qtron' ),
								'error'   => _x( 'Error', 'Generalized, abstract color name.', 'qtron' ),
								'neutral' => _x( 'Neutral', 'Generalized, abstract color name.', 'qtron' ),
							);

					//Sizes (adding empty size for default value)
						array_unshift( $array['sizes']['options'], '' );

					//Table types
						$array['table_appearance'] = array(
								'basic'   => _x( 'Basic', 'Table appearance.', 'qtron' ),
								'striped' => _x( 'Zebra striping', 'Table appearance.', 'qtron' ),
							);

				//Output
					return $array;
			}
		} // /wm_wmamp_shortcodes_globals



		/**
		 * Button class
		 *
		 * @since    1.0
		 * @version  1.0
		 *
		 * @param  string $classes
		 */
		if ( ! function_exists( 'wm_wmamp_button_class' ) ) {
			function wm_wmamp_button_class( $classes ) {
				//Output
					return $classes . ' button';
			}
		} // /wm_wmamp_button_class



		/**
		 * Shortcodes atts
		 *
		 * @since    1.0
		 * @version  1.5
		 *
		 * @param  array  $atts
		 * @param  string $shortcode
		 */
		if ( ! function_exists( 'wm_wmamp_shortcodes_atts' ) ) {
			function wm_wmamp_shortcodes_atts( $atts, $shortcode ) {
				//Preparing output
					switch ( $shortcode ) {
						case 'call_to_action':

								//Call to action button class
									$atts['button_class'] = 'button';

							break;

						case 'posts':

							//Isotope - force masonry layout (default is `fitRows`)
								$atts['filter_layout'] = 'masonry';

							//Project image size
								if (
										isset( $atts['post_type'] )
										&& 'wm_projects' === $atts['post_type']
										&& isset( $atts['class'] ) && false !== strpos( $atts['class'], 'cubic' )
									) {
									$atts['image_size'] = 'square'; //default is 'thumbnail'
								}

							//Staff image size
								if (
										isset( $atts['post_type'] )
										&& 'wm_staff' === $atts['post_type']
									) {
									$atts['image_size'] = 'square';
								}

							break;

						default:
							break;
					}

				//Output
					return $atts;
			}
		} // /wm_wmamp_shortcodes_atts



		/**
		 * Posts shortcode default image size
		 *
		 * @since    1.0
		 * @version  1.0
		 */
		if ( ! function_exists( 'wm_wmamp_posts_image_size' ) ) {
			function wm_wmamp_posts_image_size() {
				//Output
					return 'thumbnail'; //default is 'medium'
			}
		} // /wm_wmamp_posts_image_size



			/**
			 * Posts shortcode item class and link
			 *
			 * @since    1.0
			 * @version  1.0
			 *
			 * @param  array  $helper
			 * @param  absint $post_id
			 */
			if ( ! function_exists( 'wm_wmamp_posts_item_class' ) ) {
				function wm_wmamp_posts_item_class( $helper, $post_id ) {
					//Preparing output
						//Class
							if ( isset( $helper['item_class'] ) ) {

								if ( has_post_thumbnail( $post_id ) ) {
									$helper['item_class'] .= ' has-thumbnail';
								}

								$contacts = wma_meta_option( 'contacts', $post_id );

								if (
										isset( $contacts[0]['icon'] )
										&& $contacts[0]['icon']
									) {
									$helper['item_class'] .= ' has-contacts';
								}

							}

						//Link
							if ( isset( $helper['link'] ) ) {
								$helper['link'] = str_replace( 'data-target="modal"', 'rel="lightbox"', $helper['link'] );
							}

					//Output
						return $helper;
				}
			} // /wm_wmamp_posts_item_class



		/**
		 * Testimonials shortcode default image size
		 *
		 * @since    1.0
		 * @version  1.5
		 */
		if ( ! function_exists( 'wm_wmamp_testimonials_image_size' ) ) {
			function wm_wmamp_testimonials_image_size() {

				// Output

					return 'square'; //default is 'thumbnail'

			}
		} // /wm_wmamp_testimonials_image_size



			/**
			 * Testimonials shortcode item class
			 *
			 * @since    1.0
			 * @version  1.0
			 *
			 * @param  string $classes
			 * @param  absint $post_id
			 */
			if ( ! function_exists( 'wm_wmamp_testimonials_item_class' ) ) {
				function wm_wmamp_testimonials_item_class( $classes, $post_id ) {
					//Preparing output
						if ( has_post_thumbnail( $post_id ) ) {
							$classes .= ' has-thumbnail';
						}

					//Output
						return $classes;
				}
			} // /wm_wmamp_testimonials_item_class



		/**
		 * Additional shortcode scripts enqueuing
		 *
		 * @since    1.0
		 * @version  1.5
		 *
		 * @param  array $enqueue_scripts
		 * @param  array $atts
		 */
		if ( ! function_exists( 'wm_wmamp_shortcode_posts_enqueue_scripts' ) ) {
			function wm_wmamp_shortcode_posts_enqueue_scripts( $enqueue_scripts, $atts ) {

				// Processing

					// Posts Gallery format slideshow

						if ( isset( $atts['post_type'] ) && 'post' === $atts['post_type'] ) {
							$enqueue_scripts[] = 'slick';
						}

					// Projects Hoverdir

						if (
								isset( $atts['post_type'] ) && 'wm_projects' === $atts['post_type']
								&& isset( $atts['class'] ) && false !== strpos( $atts['class'], 'cubic' )
							) {
							$enqueue_scripts[] = 'jquery-hoverdir';
						}


				// Output

					return $enqueue_scripts;

			}
		} // /wm_wmamp_shortcode_posts_enqueue_scripts



		/**
		 * Content Module shortcode
		 *
		 * @since    1.2
		 * @version  1.5
		 *
		 * @param  array  $layout_elements
		 * @param  absint $post_id
		 * @param  array  $helpers
		 * @param  array  $atts
		 */
		if ( ! function_exists( 'wm_wmamp_content_module_layout_elements' ) ) {
			function wm_wmamp_content_module_layout_elements( $layout_elements, $post_id, $helpers, $atts  ) {
				//Helper variables
					$layout_element_last = '';

				//Preparing output
					//Icon + image
						$image_class = ( has_post_thumbnail( $post_id ) ) ? ( ' has-thumbnail' ) : ( ' has-not-thumbnail' );

						$icon  = array(
								'font'             => wma_meta_option( 'icon-font', $post_id ),
								'color'            => wma_meta_option( 'icon-color', $post_id ),
								'color-background' => wma_meta_option( 'icon-color-background', $post_id ),
							);

						$image_size = ( $atts['image_size'] ) ? ( $atts['image_size'] ) : ( 'medium' );

						if ( $icon['font'] ) {
							$image_size = 'square';
						}

						$image = get_the_post_thumbnail( $post_id, $image_size, array( 'title' => esc_attr( get_the_title( get_post_thumbnail_id( $post_id ) ) ) ) );

						$style_icon = $style_container = '';

						if ( $icon['font'] && $icon['color'] ) {
							$style_icon   = ' style="color: ' . $icon['color'] . '"';
							$image_class .= ' color-text';
						}

						if ( $icon['font'] && $icon['color-background'] ) {
							$style_container = ' style="background-color: ' . $icon['color-background'] . '"';
							$image_class    .= ' color-background';

							if ( $image ) {
								$image .= '<span class="overlay"></span>';
							}
						}

						if ( $icon['font'] ) {
							if (
									$image
									&& ! empty( $atts['layout'] )
									&& is_array( $atts['layout'] )
								) {
								end( $atts['layout'] );
								$layout_element_last = key( $atts['layout'] );
							}

							$image       .= '<span class="' . $icon['font'] . '"' . $style_icon . '></span>';
							$image_class .= ' has-icon';
						}

						if ( $image && $helpers['link'] ) {
							$image = '<a' .  $helpers['link'] . '>' . $image . '</a>';
						}

						if ( $image ) {
							$layout_elements['image'] = '<div class="wm-content-module-element wm-html-element image image-container' . $image_class . '"' . $style_container . '>' . $image . '</div>';

							if ( $layout_element_last ) {
								$layout_elements['image'] .= '<div class="wm-content-module-elements-wrapper"><div class="wm-content-module-elements-wrapper-inner">';
								$layout_elements[ $layout_element_last ] .= '</div></div><!-- /wm-content-module-elements-wrapper -->';
							}
						}

				//Output
					return $layout_elements;
			}
		} // /wm_wmamp_content_module_layout_elements



			/**
			 * Content Module shortcode item class
			 *
			 * @since    1.4.1
			 * @version  1.4.1
			 *
			 * @param  string $class_item
			 * @param  absint $post_id
			 * @param  array  $atts
			 */
			function wm_wmamp_content_module_item_class( $class_item, $post_id, $atts ) {

				// Processing

					if ( wma_meta_option( 'icon-font', $post_id ) ) {
						$class_item .= ' wm-iconbox-module';
					}


				// Output

					return $class_item;

			} // /wm_wmamp_content_module_item_class

			add_filter( 'wmhook_shortcode_content_module_item_class', 'wm_wmamp_content_module_item_class', 10, 3 );



	/**
	 * METABOXES
	 */

		// Using WebMan Amplifier plugin's metabox generator here.
		if ( function_exists( 'wma_add_meta_box' ) ) {

			/**
			 * Page
			 */

				/**
				 * Page metabox metafields
				 *
				 * @since    1.0
				 * @version  1.0
				 *
				 * @param  array $fields
				 */
				if ( ! function_exists( 'wm_wmamp_page_metafields' ) ) {
					function wm_wmamp_page_metafields( $fields = array() ) {

						$fields[100] = array(
								'type'  => 'section-open',
								'id'    => 'page-options-section',
								'title' => _x( 'Settings', 'Metabox section title.', 'qtron' ),
							);

							if ( class_exists( 'FLBuilder' ) ) {

								$fields[110] = array(
										'type'  => 'checkbox',
										'id'    => 'intro-disable',
										'label' => __( 'Disable intro heading', 'qtron' ),
									);

								$fields[111] = array(
										'id'      => 'sections-description',
										'type'    => 'html',
										'content' => '<div class="box blue">' . __( 'You can apply an <code>intro</code> CSS class on the first row of your page builder layout. Once you do that, a parallax effect will be used on the row content.', 'qtron' ) . '</div>',
										'conditional' => array(
												'option'       => array(
														'tag'  => 'input',
														'name' => 'wm-intro-disable',
														'type' => 'checkbox',
													),
												'option_value' => array( '1' ),
												'operand'      => 'IS',
											),
									);
							}

							$fields[120] = array(
									'type'    => 'select',
									'id'      => 'header',
									'label'   => __( 'Header', 'qtron' ),
									'options' => array(
											''                         => __( 'Default', 'qtron' ),
											'forced-background--dark'  => __( 'Overlayed light', 'qtron' ),
											'forced-background--light' => __( 'Overlayed dark', 'qtron' ),
											'normal'                   => __( 'Do not overlay', 'qtron' ),
										),
								);

							$fields[130] = array(
									'type'    => 'select',
									'id'      => 'footer',
									'label'   => __( 'Footer', 'qtron' ),
									'options' => array(
											''        => __( 'Widgets, menu and credits', 'qtron' ),
											'widgets' => __( 'Widgets only', 'qtron' ),
											'credits' => __( 'Menu and credits only', 'qtron' ),
											'none'    => __( 'No footer', 'qtron' ),
										),
								);

						$fields[200] = array(
								'type' => 'section-close',
							);

						/**
						 * For more form fields options please check the PHP files inside
						 * the "wm-amplifier/includes/metabox/fields/" folder.
						 */

						return $fields;
					}
				} // /wm_wmamp_page_metafields

				/**
				 * @since  2.1.7
				 */
				function wm_qtron_add_meta_box() {

					wma_add_meta_box( array(
						// Meta fields function callback (should return array of fields).
						// The function callback is used for to use a WordPress globals
						// available during the metabox rendering, such as $post.
						'fields' => 'wm_wmamp_page_metafields',

						// Meta box id, unique per meta box.
						'id' => 'page-metabox',

						// Post types.
						'pages' => array( 'page' ),

						// Meta box title.
						'title' => __( 'Settings', 'qtron' ),
					) );
				} // /wm_qtron_add_meta_box

				add_action( 'after_setup_theme', 'wm_qtron_add_meta_box' );



			/**
			 * Content Modules metabox
			 */

				/**
				 * Content Modules fields alteration
				 *
				 * @since    1.2
				 * @version  1.2
				 *
				 * @param  array $fields
				 */
				if ( ! function_exists( 'wm_wmamp_content_modules_metafields' ) ) {
					function wm_wmamp_content_modules_metafields( $fields = array() ) {
						//Preparing output
							unset( $fields[1060] ); //removes 'icon-box' option

							//Change labels and set additinal conditionals
								$fields[1240]['label'] = __( 'Icon', 'qtron' );
								$fields[1260]['label'] = __( 'Icon color', 'qtron' );
								$fields[1280]['conditional'] = $fields[1260]['conditional'];

							//Move icon color before the icon selection
								$fields[1200] = $fields[1260]; //also removes icon setup wrapper opening
								$fields[1220] = $fields[1280]; //also removes featured image setup notice
								unset( $fields[1260] ); //remove original icon color setup position
								unset( $fields[1280] ); //remove original icon background color setup position

							unset( $fields[1480] ); //removes icon setup wrapper closing

						//Output
							return $fields;
					}
				} // /wm_wmamp_content_modules_metafields



			/**
			 * Projects metabox
			 */

				/**
				 * Projects metabox fields alteration
				 *
				 * @since    1.0
				 * @version  1.0
				 *
				 * @param  array $fields
				 */
				if ( ! function_exists( 'wm_wmamp_projects_metafields' ) ) {
					function wm_wmamp_projects_metafields( $fields = array() ) {
						//Preparing output
							$fields[1000]['title'] = _x( 'Settings', 'Metabox section title.', 'qtron' );

							if ( class_exists( 'FLBuilder' ) ) {

								$fields[1010] = array(
										'type'  => 'checkbox',
										'id'    => 'intro-disable',
										'label' => __( 'Disable intro heading', 'qtron' ),
									);

								$fields[1011] = array(
										'id'      => 'sections-description',
										'type'    => 'html',
										'content' => '<div class="box blue">' . __( 'You can apply an <code>intro</code> CSS class on the first row of your page builder layout. Once you do that, a parallax effect will be used on the row content.', 'qtron' ) . '</div>',
										'conditional' => array(
												'option'       => array(
														'tag'  => 'input',
														'name' => 'wm-intro-disable',
														'type' => 'checkbox',
													),
												'option_value' => array( '1' ),
												'operand'      => 'IS',
											),
									);

								$fields[1015] = array(
										'type'    => 'select',
										'id'      => 'header',
										'label'   => __( 'Header', 'qtron' ),
										'options' => array(
												''                         => __( 'Default', 'qtron' ),
												'forced-background--dark'  => __( 'Overlayed light', 'qtron' ),
												'forced-background--light' => __( 'Overlayed dark', 'qtron' ),
												'normal'                   => __( 'Do not overlay', 'qtron' ),
											),
									);

							} // /FLBuilder

							unset( $fields[1040]['options']['1OPTGROUP'] );
							unset( $fields[1040]['options']['1/OPTGROUP'] );
							unset( $fields[1040]['options']['2OPTGROUP'] );
							unset( $fields[1040]['options']['2/OPTGROUP'] );
							$fields[1040]['options'][''] = '-';

						//Output
							return $fields;
					}
				} // /wm_wmamp_projects_metafields



			/**
			 * Staff metabox
			 */

				/**
				 * Staff metabox fields alteration
				 *
				 * @since    1.0
				 * @version  1.0
				 *
				 * @param  array $fields
				 * @param  array $fonticons
				 */
				if ( ! function_exists( 'wm_wmamp_staff_contact_fields' ) ) {
					function wm_wmamp_staff_contact_fields( $fields = array(), $fonticons = array() ) {
						//Preparing output
							$fields = array();

							if ( ! empty( $fonticons ) ) {
								$fields[10] = array(
										'type'    => 'select',
										'id'      => 'icon',
										'label'   => __( 'Icon', 'qtron' ),
										'options' => $fonticons,
									);
							}
							$fields[20] = array(
									'type'  => 'text',
									'id'    => 'title',
									'label' => __( 'Hover title', 'qtron' ),
								);
							$fields[30] = array(
									'type'  => 'text',
									'id'    => 'link',
									'label' => __( 'URL link', 'qtron' ),
								);

						//Output
							return $fields;
					}
				} // /wm_wmamp_staff_contact_fields

		} // /wma_add_meta_box function check



	/**
	 * FUNCTIONS MODIFICATIONS
	 */

		/**
		 * Adding `pagination` CSS class
		 *
		 * @since    1.0
		 * @version  1.0
		 *
		 * @param  string $output
		 */
		if ( ! function_exists( 'wm_wmamp_pagination' ) ) {
			function wm_wmamp_pagination( $output ) {
				return str_replace( 'wm-pagination', 'wm-pagination pagination', $output );
			}
		} // /wm_wmamp_pagination
