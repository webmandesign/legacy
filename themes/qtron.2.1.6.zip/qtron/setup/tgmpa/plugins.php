<?php
/**
 * Plugins suggestions
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  2.0.0
 */





/**
 * Register the required plugins for the theme
 *
 * @link  https://github.com/thomasgriffin/TGM-Plugin-Activation/blob/master/example.php
 *
 * @since    1.0.0
 * @version  2.0.0
 */
if ( ! function_exists( 'wm_plugins_suggestions' ) ) {
	function wm_plugins_suggestions() {

		/**
		 * Array of plugin arrays. Required keys are name and slug.
		 * If the source is NOT from the .org repo, then source is also required.
		 */
		$plugins = apply_filters( 'wmhook_wm_plugins_suggestions-plugins', array(

			'webman-amplifier' => array(
				'name'     => esc_html__( 'WebMan Amplifier (adding theme features)', 'qtron' ),
				'slug'     => 'webman-amplifier',
				'required' => false,
			),

			'beaver-builder' => array(
				'name'        => esc_html__( 'Beaver Builder (easy page builder)', 'qtron' ),
				'slug'        => 'beaver-builder-lite-version',
				'required'    => false,
				'is_callable' => 'FLBuilder::init',
			),

			'one-click-demo-import' => array(
				'name'     => esc_html__( 'One Click Demo Import (for installing theme demo content)', 'qtron' ),
				'slug'     => 'one-click-demo-import',
				'required' => false,
			),

			'classic-widgets' => array(
				'name'        => esc_html_x( 'Classic Widgets', 'Plugin name.', 'qtron' ),
				'description' => esc_html__( 'Improves widgets management screen.', 'qtron' ) . ' ' . esc_html__( 'Restores the previous WordPress widgets settings screens.', 'qtron' ) . ' ' . esc_html__( 'Sidebars and widgets are not going to be used in fully block themes in the future, so if your website still uses sidebars, it is better to use this plugin to enable classic user interface.', 'qtron' ),
				'slug'        => 'classic-widgets',
				'required'    => false,
			),

		) );

		$config = apply_filters( 'wmhook_wm_plugins_suggestions-config', array() );

		tgmpa( $plugins, $config );

	}
} // /wm_plugins_suggestions

add_action( 'tgmpa_register', 'wm_plugins_suggestions' );
