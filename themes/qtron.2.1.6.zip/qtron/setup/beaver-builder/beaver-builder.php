<?php
/**
 * Plugin integration
 *
 * Beaver Builder
 *
 * @link  https://www.wpbeaverbuilder.com/
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  2.1.4
 *
 * CONTENT:
 * -  1) Requirements check
 * - 10) Plugin integration
 */





/**
 * 1) Requirements check
 */

	if ( ! class_exists( 'FLBuilder' ) ) {
		return;
	}





/**
 * 10) Plugin integration
 */

	add_action( 'wmhook_theme_upgrade', 'FLBuilderModel::delete_asset_cache_for_all_posts' );



	/**
	 * Upgrade link URL
	 *
	 * @since    1.0
	 * @version  2.1.4
	 *
	 * @param  string $url
	 */
	if ( ! function_exists( 'wm_bb_upgrade_url' ) ) {
		function wm_bb_upgrade_url( $url ) {

			// Output

				return trailingslashit( FL_BUILDER_STORE_URL ) . 'fla/67/';

		}
	} // /wm_bb_upgrade_url

	add_filter( 'fl_builder_upgrade_url', 'wm_bb_upgrade_url' );



	/**
	 * Global settings
	 *
	 * @since    1.0
	 * @version  1.9.3
	 *
	 * @param  array  $defaults
	 * @param  string $form_type
	 */
	if ( ! function_exists( 'wm_bb_global_settings' ) ) {
		function wm_bb_global_settings( $defaults, $form_type ) {

			// Processing

				if ( 'global' === $form_type ) {

					$typography_size_html = wm_option( 'font-size-html', 16 );

					// "Default Page Heading" section

						$defaults->show_default_heading     = '0';
						$defaults->default_heading_selector = '.entry-header-disabled';

					// "Rows" section

						$defaults->row_padding = '';
						$defaults->row_margins = '';
						$defaults->row_width   = $GLOBALS['content_width'];

					// "Columns" section

						$defaults->column_padding = absint( round( $typography_size_html * 3.62 ) );

					// "Modules" section

						$defaults->module_margins = absint( round( $typography_size_html * ( pow( 1.618, 2 ) / 2 ) ) );

					// "Responsive Layout" section

						$defaults->auto_spacing          = 0;
						$defaults->medium_breakpoint     = 960;
						$defaults->responsive_breakpoint = 680;

				}


			// Output

				return $defaults;

		}
	} // /wm_bb_global_settings

	add_filter( 'fl_builder_settings_form_defaults', 'wm_bb_global_settings', 10, 2 );



	/**
	 * Is page builder used on the post?
	 *
	 * @since    1.0
	 * @version  1.8.2
	 */
	if ( ! function_exists( 'wm_bb_is_active' ) ) {
		function wm_bb_is_active() {

			// Variables

				$post_id = get_the_ID();


			// Requirements check

				if (
					! ( is_page( $post_id ) || is_single( $post_id ) )
					|| ! is_callable( 'FLBuilderModel::is_builder_enabled' )
				) {
					return false;
				}


			// Output

				return
					FLBuilderModel::is_builder_active()
					|| get_post_meta( get_the_ID(), '_fl_builder_enabled', true );

		}
	} // /wm_bb_is_active

	add_filter( 'wmhook_wm_post_title_disable',  'wm_bb_is_active', 10 );
	add_filter( 'wmhook_single_sidebar_disable', 'wm_bb_is_active', 10 );



	/**
	 * Load plugin stylesheets after the theme stylesheet
	 *
	 * @since    1.6.3
	 * @version  1.6.3
	 */
	function wm_bb_assets_late_load() {

		// Helper variables

			$priority  = 120;
			$callbacks = (array) apply_filters( 'wmhook_qtron_beaver_builder_assets_late_load_callbacks', array(
				'FLBuilder::enqueue_all_layouts_styles_scripts'     => 10,
				'FLBuilder::enqueue_ui_styles_scripts'              => 11,
				'FLBuilderUISettingsForms::enqueue_settings_config' => 11,
			) );

			$order = 0;


		// Processing

			foreach ( $callbacks as $callback => $default_priority ) {
				if ( is_callable( $callback ) ) {
					remove_action( 'wp_enqueue_scripts', $callback, $default_priority );
					   add_action( 'wp_enqueue_scripts', $callback, $priority + $order++ );
				}
			}

	} // /wm_bb_assets_late_load

	add_action( 'init', 'wm_bb_assets_late_load', 900 );



	/**
	 * Layout stylesheet media
	 *
	 * @since    1.4
	 * @version  1.4
	 */
	function wm_bb_stylesheet_layout_media() {

		// Output

			return 'screen';

	} // /wm_bb_stylesheet_layout_media

	add_filter( 'fl_builder_layout_style_media', 'wm_bb_stylesheet_layout_media' );



	/**
	 * Styles and scripts
	 *
	 * @since    1.0.0
	 * @version  1.6.0
	 */
	if ( ! function_exists( 'wm_bb_assets' ) ) {
		function wm_bb_assets() {

			// Requirements check

				if (
						! is_callable( 'FLBuilderModel::is_builder_active' )
						|| ! FLBuilderModel::is_builder_active()
					) {
					return;
				}


			// Processing

				// Styles

					wp_enqueue_style(
						'qtron-bb-addon',
						wm_get_stylesheet_directory_uri( 'assets/css/beaver-builder-editor.css' ),
						false,
						WM_SCRIPTS_VERSION,
						'screen'
					);

				// Scripts

					wp_enqueue_script(
						'qtron-bb-editor',
						wm_get_stylesheet_directory_uri( 'assets/js/scripts-beaver-builder-editor.js' ),
						'fl-builder',
						WM_SCRIPTS_VERSION,
						true
					);

					if ( function_exists( 'wm_bb_register_settings_form' ) ) {

						$bb_settings = wm_bb_register_settings_form( array(), 'col' );

						wp_localize_script(
								'qtron-bb-editor',
								'$qtronBBPreview',
								array(
									'vertical_alignment' => array_values(
										array_filter(
											array_flip(
												(array) $bb_settings['tabs']['style']['sections']['general']['fields']['vertical_alignment']['options']
											)
										)
									),
								)
							);

					}

		}
	} // /wm_bb_assets

	add_action( 'wp_enqueue_scripts', 'wm_bb_assets' );



	/**
	 * Layout stylesheet media
	 *
	 * @since    1.4
	 * @version  1.9.3
	 *
	 * @param  string $css
	 * @param  array  $nodes
	 * @param  object $global_settings
	 */
	function wm_bb_stylesheet_layout( $css, $nodes, $global_settings ) {

			// Processing

				$css .= PHP_EOL.PHP_EOL;

				// Row width compensation

					$settings = array(
						'module_margins'            => false,
						'module_margins_medium'     => '@media (max-width: ' . absint( $global_settings->medium_breakpoint ) . 'px)',
						'module_margins_responsive' => '@media (max-width: ' . absint( $global_settings->responsive_breakpoint ) . 'px)',
					);

					foreach ( $settings as $setting => $wrapper ) {
						$margin_compensation = ( isset( $global_settings->{ $setting } ) ) ? ( $global_settings->{ $setting } ) : ( false );

						if ( is_numeric( $margin_compensation ) ) {
							$margin_compensation .= ( isset( $global_settings->{ $setting . '_unit' } ) ) ? ( $global_settings->{ $setting . '_unit' } ) : ( 'px' );

							$indent = ( $wrapper ) ? ( "\t" ) : ( '' );

							$css .= ( $wrapper ) ? ( $wrapper . ' {'.PHP_EOL ) : ( '' );
							$css .= $indent . '.fl-row-fixed-width .fl-row-content-wrap,'.PHP_EOL;
							$css .= $indent . '.fl-row-layout-full-fixed .fl-row-fixed-width > .fl-col-group {'.PHP_EOL;
							$css .= $indent . "\t".'width: auto;'.PHP_EOL;
							$css .= $indent . "\t".'max-width: calc(100% + ' . esc_attr( $margin_compensation ) . ' + ' . esc_attr( $margin_compensation ) . ');'.PHP_EOL;
							$css .= $indent . "\t".'margin-left: -' . esc_attr( $margin_compensation ) . ';'.PHP_EOL;
							$css .= $indent . "\t".'margin-right: -' . esc_attr( $margin_compensation ) . ';'.PHP_EOL;
							$css .= $indent . '}'.PHP_EOL;
							$css .= ( $wrapper ) ? ( '}'.PHP_EOL ) : ( '' );
						}
					}

				// Fixing responsive element hiding

					$css .= PHP_EOL.PHP_EOL;

					$css .= '@media (min-width: ' . absint( $global_settings->responsive_breakpoint + 1 ) . 'px) and (max-width: ' . absint( $global_settings->medium_breakpoint ) . 'px) {'.PHP_EOL;
					$css .= "\t".'.fl-col-group .fl-visible-desktop-medium.fl-col,'.PHP_EOL;
					$css .= "\t".'.fl-col-group .fl-visible-medium.fl-col,'.PHP_EOL;
					$css .= "\t".'.fl-col-group .fl-visible-medium-mobile.fl-col {'.PHP_EOL;
					$css .= "\t\t".'display: flex;'.PHP_EOL;
					$css .= "\t".'}'.PHP_EOL;
					$css .= '}'.PHP_EOL;

					$css .= '@media (max-width: ' . absint( $global_settings->responsive_breakpoint ) . 'px) {'.PHP_EOL;
					$css .= "\t".'.fl-col-group .fl-visible-medium-mobile.fl-col,'.PHP_EOL;
					$css .= "\t".'.fl-col-group .fl-visible-mobile.fl-col {'.PHP_EOL;
					$css .= "\t\t".'display: flex;'.PHP_EOL;
					$css .= "\t".'}'.PHP_EOL;
					$css .= '}'.PHP_EOL;

				// Plugin global settings and theme styles compensation

					$css .= PHP_EOL.PHP_EOL;
					$css .= '.fl-col-content { padding-left: 0; padding-right: 0; }'.PHP_EOL;
					$css .= '@media (max-width: 880px) { .fl-col[data-node] > .fl-col-content { padding-left: 0; padding-right: 0; } }'.PHP_EOL;
					$css .= '.fl-module-content { margin-top: 0; margin-bottom: 0; }'.PHP_EOL;


			// Output

				return $css;

	} // /wm_bb_stylesheet_layout

	add_filter( 'fl_builder_render_css', 'wm_bb_stylesheet_layout', 10, 3 );



	/**
	 * Modify row class
	 *
	 * Requires Beaver Builder 1.5.1+
	 *
	 * @since    1.4.0
	 * @version  1.8.2
	 *
	 * @param  string $class
	 * @param  object $node
	 */
	if ( ! function_exists( 'wm_bb_row_class' ) ) {
		function wm_bb_row_class( $class, $node ) {

			// Processing

				// Row layout

					$class .= ' fl-row-layout-' . $node->settings->width . '-' . $node->settings->content_width;

				// Content vertical alignment

					if ( ! empty( $node->settings->vertical_alignment ) ) {
						$class .= ' ' . esc_attr( trim( $node->settings->vertical_alignment ) );
					}

				// Custom background class

					if (
						'none' !== $node->settings->bg_type
						|| stripos( ' ' . $node->settings->class, 'set-colors-' ) // Search for custom colors special class
					) {
						$class .= ' fl-row-custom-background';
					}


			// Output

				return $class;

		}
	} // /wm_bb_row_class

	add_filter( 'fl_builder_row_custom_class', 'wm_bb_row_class', 10, 2 );



	/**
	 * Modify column class
	 *
	 * Requires Beaver Builder 1.5.1+
	 *
	 * @since    1.0.0
	 * @version  1.8.2
	 *
	 * @param  string $class
	 * @param  object $node
	 */
	if ( ! function_exists( 'wm_bb_column_class' ) ) {
		function wm_bb_column_class( $class, $node ) {

			// Processing

				// Content vertical alignment

					if ( ! empty( $node->settings->vertical_alignment ) ) {
						$class .= ' ' . esc_attr( trim( $node->settings->vertical_alignment ) );
					}

				// Custom background class

					if (
						'none' !== $node->settings->bg_type
						|| stripos( ' ' . $node->settings->class, 'set-colors-' ) // Search for custom colors special class
					) {
						// As "color" is default value here, we need to double check if it is set.
						if ( ! ( 'color' === $node->settings->bg_type && empty( $node->settings->bg_color ) ) ) {
							$class .= ' fl-col-custom-background';
						}
					}


			// Output

				return $class;

		}
	} // /wm_bb_column_class

	add_filter( 'fl_builder_column_custom_class', 'wm_bb_column_class', 10, 2 );



	/**
	 * Settings form alterations
	 *
	 * @since    1.6.0
	 * @version  1.6.0
	 *
	 * @param  array  $form
	 * @param  string $id
	 */
	function wm_bb_register_settings_form( $form, $id ) {

		// Processing

			// Row and/or column settings only

				if ( in_array( $id, array( 'col', 'row' ) ) ) {

					// Adding column content vertical centering option

						$form['tabs']['style']['sections']['general']['fields']['vertical_alignment'] = array(
								'type'    => 'select',
								'label'   => esc_html__( 'Content Vertical Alignment', 'qtron' ),
								'help'    => esc_html__( 'As the theme makes all columns in a row equally high automatically, it allows you to set the column content vertical alignment here.', 'qtron' ),
								'default' => '',
								'options' => array(
									''                      => esc_html_x( 'Initial', 'Vertical content alignment value', 'qtron' ),
									'vertical-align-top'    => esc_html_x( 'Top', 'Vertical content alignment value', 'qtron' ),
									'vertical-align-middle' => esc_html_x( 'Middle', 'Vertical content alignment value', 'qtron' ),
									'vertical-align-bottom' => esc_html_x( 'Bottom', 'Vertical content alignment value', 'qtron' ),
								),
								'preview' => array(
									'type' => 'none',
								),
							);

				}


		// Output

			return $form;

	} // /wm_bb_register_settings_form

	add_filter( 'fl_builder_register_settings_form', 'wm_bb_register_settings_form', 10, 2 );
