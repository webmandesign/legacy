<?php
/**
 * Plugin compatibility file.
 *
 * One Click Demo Import
 *
 * @link  https://wordpress.org/plugins/one-click-demo-import/
 *
 * @package    Q'tron
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    1.5
 * @version  1.8.2
 *
 * Contents:
 *
 *  1) Requirements check
 * 10) Plugin integration
 */





/**
 * 1) Requirements check
 */

	if (
			! ( class_exists( 'OCDI_Plugin' ) || class_exists( 'PT_One_Click_Demo_Import' ) )
			|| ! is_admin()
		) {
		return;
	}





/**
 * 20) Plugin integration
 */

	require_once get_theme_file_path( WM_SETUP_DIR . 'one-click-demo-import/class-one-click-demo-import.php' );
