# Q'tron Changelog

## 2.1.7, 20250904

### Fixed
- Localization PHP error

### File updates
	changelog.md
	style.css
	setup/webman-amplifier/webman-amplifier.php


## 2.1.6, 20250903

### Fixed
- Preventing post excerpt bleeding into category description

### File updates
	changelog.md
	style.css
	setup/setup.php


## 2.1.5, 20250425

### Updated
- Improving code

### File updates
	changelog.md
	readme.txt
	style.css
	lib/core.php
	setup/custom-header/custom-header.php
	templates/parts/content-image.php


## 2.1.4, 20250118

### Updated
- Beaver Builder upgrade link

### Fixed
- WooCommerce styles

### File updates
	changelog.md
	readme.txt
	style.css
	setup/beaver-builder/beaver-builder.php
	

## 2.1.3, 20240902

### Updated
- Confirming support with WordPress 6.6

### File updates
	changelog.md
	readme.txt
	style.css


## 2.1.2, 20231113

### Fixed
- Preventing issue with post formats
- Updating TGMPA script to prevent PHP8 error

### File updates
	changelog.md
	readme.txt
	style.css
	lib/inc/class-tgm-plugin-activation.php
	setup/post-formats/post-formats.php


## 2.1.1, 20221215

### Fixed
- Sticky header JavaScript

### File updates
	changelog.md
	style.css
	assets/js/scripts-sticky.js


## 2.1.0, 20221125

### Added
- New `Update URI` theme stylesheet header

### Updated
- Media size info
- Welcome page
- Localization

### Fixed
- HTML head code priority
- Making blog page a current menu ancestor when visiting a blog post

### File updates
	changelog.md
	readme.txt
	style.css
	assets/scss/welcome.scss
	languages/*.*
	lib/admin.php
	setup/setup.php
	setup/welcome/class-welcome.php
	templates/parts/admin/media-image-sizes.php
	templates/parts/admin/notice-welcome.php
	templates/parts/admin/welcome-demo.php
	templates/parts/admin/welcome-footer.php
	templates/parts/admin/welcome-guide.php
	templates/parts/admin/welcome-header.php
	templates/parts/admin/welcome-update.php


## 2.0.0, 20220311

### Updated
- Recommended plugins list
- Improving HTML head code for better compatibility with SEO plugins
- Improving search form and site title styles
- Update notifier functionality
- Localization

### File updates
	changelog.md
	readme.txt
	style.css
	assets/css/custom.css
	assets/css/main.css
	assets/css/responsive.css
	lib/inc/class-tgm-plugin-activation.php
	setup/setup.php
	setup/one-click-demo-import/class-one-click-demo-import.php
	setup/tgmpa/plugins.php
	setup/update-notification/class-update-notification.php


## 1.9.5, 20210119

### Updated
- Updating 3rd party JavaScript

### Fixed
- jQuery code for WordPress 5.6 compatibility

### File updates
	changelog.md
	readme.txt
	style.css
	assets/js/scripts-beaver-builder-editor.js
	assets/js/scripts-masonry.js
	assets/js/plugins/slick/slick.js
	assets/js/plugins/slick/slick.min.js
	lib/customizer.php
	lib/js/customizer.js


## 1.9.4, 20201119

### Update
- Update notifier

### File updates
	changelog.md
	readme.txt
	style.css
	setup/update-notification/class-update-notification.php


## 1.9.3

* **Update**: Adding `nofollow` attribute to default site info links
* **Fix**: Removing post excerpt wrapper when excerpt is empty
* **Fix**: Custom color buttons in Beaver Builder
* **Fix**: Beaver Builder global settings
* **Fix**: Portfolio cubic animation on Safari

### Files changed:

	changelog.md
	readme.txt
	style.css
	assets/css/custom.css
	assets/css/main.css
	assets/css/shortcodes.css
	setup/setup.php
	setup/beaver-builder/beaver-builder.php


## 1.9.2

* **Update**: Implementing WordPress 5.2 code updates

### Files changed:

	changelog.md
	header.php
	readme.txt
	style.css
	setup/setup.php
	templates/parts/component-welcome-quickstart.php


## 1.9.1

* **Update**: Styles
* **Update**: Welcome page and notice
* **Update**: Updating info about demo required plugins
* **Update**: Improving CSS variables functionality for browsers with no support
* **Update**: Navigation touch screen functionality
* **Update**: Improving intro image accessibility
* **Update**: Updating excerpts display
* **Update**: Improving code
* **Update**: Improving security
* **Update**: Localization
* **Fix**: Default theme BODY background color not being applied

### Files changed:

	changelog.md
	footer.php
	header.php
	readme.txt
	style.css
	assets/css/custom-editor.css
	assets/css/custom.css
	assets/css/main.css
	assets/css/shortcodes.css
	assets/css/starter.css
	assets/js/scripts-navigation.js
	languages/*.*
	lib/customizer.php
	lib/inc/controls/class-WM_Customizer_Multiselect.php
	lib/inc/controls/class-WM_Customizer_Radiocustom.php
	lib/inc/controls/class-WM_Customizer_Range.php
	lib/inc/controls/class-WM_Customizer_Select.php
	setup/setup.php
	setup/about/about.php
	setup/custom-header/custom-header.php
	setup/one-click-demo-import/class-one-click-demo-import.php
	setup/tgmpa/plugins.php
	templates/parts/component-link-more.php
	templates/parts/component-welcome-footer.php
	templates/parts/component-welcome-header.php
	templates/parts/content.php
	templates/parts/notice-welcome.php


## 1.9.0

* **Add**: WP Subtitle plugin compatibility
* **Update**: Support URL
* **Update**: Improving code
* **Update**: Improving security
* **Update**: Adding WPCS comments to code
* **Update**: Improving widget areas markup
* **Update**: `.screen-reader-text` CSS class styles
* **Update**: Improving customizer functionality
* **Update**: Using CSS variables instead of generating customized stylesheet
* **Update**: Removing obsolete functionality
* **Update**: Removing media sizes override on theme activation
* **Update**: Updating readme file
* **Update**: Improving theme welcome notice on theme activation
* **Update**: Setting `use strict` in JavaScript
* **Update**: Removing all `locate_template()` function references
* **Update**: Removing CSS minification in favor of plugins
* **Update**: Localization
* **Update**: Documentation
* **Fix**: WooSidebars plugin compatibility

### Files changed:

	changelog.md
	functions.php
	readme.txt
	sidebar-footer.php
	style.css
	assets/css/custom-editor.css
	assets/css/custom.css
	assets/css/main.css
	assets/css/starter.css
	assets/js/customizer-preview.js
	assets/js/scripts-beaver-builder-editor.js
	assets/js/scripts-global.js
	assets/js/scripts-masonry.js
	assets/js/scripts-navigation.js
	assets/js/scripts-parallax.js
	assets/js/scripts-sticky.js
	assets/js/skip-link-focus-fix.js
	languages/*.*
	lib/admin.php
	lib/core.php
	lib/customizer.php
	lib/inc/controls/class-WM_Customizer_HTML.php
	lib/inc/controls/class-WM_Customizer_Multiselect.php
	lib/inc/controls/class-WM_Customizer_Radiocustom.php
	lib/inc/controls/class-WM_Customizer_Range.php
	lib/inc/controls/class-WM_Customizer_Select.php
	lib/js/customizer.js
	lib/js/wm-scripts.js
	setup/setup-theme-options.php
	setup/setup.php
	setup/about/about.php
	setup/beaver-builder/beaver-builder.php
	setup/custom-header/custom-header.php
	setup/subtitles/class-subtitles.php
	setup/woosidebars/woosidebars.php
	templates/parts/component-welcome-quickstart.php
	templates/parts/notice-welcome.php
	webman-amplifier/content-shortcode-posts-wm_projects.php
	webman-amplifier/content-shortcode-posts-wm_staff.php


## 1.8.2

* **Update**: WordPress 5.0 ready
* **Update**: Removing obsolete `locate_template()`
* **Fix**: Compatibility with Beaver Builder 2.2
* **Fix**: Typo of "update-notificaton" to "update-notification"
* **Fix**: SSL URLs

### Files changed:

	changelog.md
	functions.php
	image.php
	page.php
	single.php
	style.css
	assets/css/_generate-css.php
	assets/css/_generate-ve-css.php
	assets/css/beaver-builder-editor.css
	assets/css/main.css
	assets/css/shortcodes.css
	lib/admin.php
	lib/core.php
	lib/customizer.php
	setup/setup.php
	setup/beaver-builder/beaver-builder.php
	setup/one-click-demo-import/one-click-demo-import.php
	setup/update-notification/
	templates/parts/loop.php


## 1.8.1

* **Update**: Removing microformats in favor of plugins
* **Update**: Removing obsolete `role` HTML attributes

### Files changed:

	changelog.md
	comments.php
	image.php
	sidebar.php
	style.css
	lib/core.php
	setup/setup.php
	setup/custom-header/custom-header.php
	setup/webman-amplifier/webman-amplifier.php
	templates/parts/component-menu-primary.php
	templates/parts/content-audio.php
	templates/parts/content-gallery.php
	templates/parts/content-image.php
	templates/parts/content-link.php
	templates/parts/content-page.php
	templates/parts/content-quote.php
	templates/parts/content-status.php
	templates/parts/content-video.php
	templates/parts/content.php
	templates/parts/loop.php
	webman-amplifier/content-shortcode-posts-wm_projects.php
	webman-amplifier/content-shortcode-posts-wm_staff.php


## 1.8.0

* **Add**: New theme update notification functionality
* **Update**: Removing documentation folder in favor of online docs
* **Update**: Localization
* **Fix**: Envato Theme Check plugin test requirements
* **Fix**: NS Theme Check plugin test warnings

### Files changed:

	changelog.md
	comments.php
	style.css
	assets/css/editor-style.css
	languages/*.*
	lib/admin.php
	lib/core.php
	lib/customizer.php
	lib/css/admin.css
	lib/inc/controls/class-WM_Customizer_Multiselect.php
	lib/inc/controls/class-WM_Customizer_Radiocustom.php
	lib/inc/controls/class-WM_Customizer_Range.php
	lib/inc/controls/class-WM_Customizer_Select.php
	setup/setup-theme-options.php
	setup/setup.php
	setup/update-notificaton/class-update-notification.php
	setup/webman-amplifier/webman-amplifier.php
	templates/parts/content-image.php
	templates/parts/content-status.php
	webman-amplifier/content-shortcode-posts-post.php
	webman-amplifier/content-shortcode-posts-wm_projects.php
	webman-amplifier/content-shortcode-posts-wm_staff.php


## 1.7.0

* **Update**: WordPress 4.9.6 compatibility (GDPR)
* **Fix**: Content opening and closing action hooks out of header/footer disabling conditional check
* **Fix**: Beaver Builder row content width

### Files changed:

	changelog.md
	footer.php
	header.php
	style.css
	assets/css/main.css
	assets/css/starter.css
	setup/setup.php


## 1.6.3

* **Fix**: Backwards compatibility with Beaver Builder pre-2.1

### Files changed:

	changelog.md
	style.css
	setup/beaver-builder/beaver-builder.php


## 1.6.2

* **Fix**: Compatibility with Beaver Builder 2.1+
* **Fix**: Back to top button accessibility
* **Fix**: Possible minor horizontal scroll on mobile devices

### Files changed:

	changelog.md
	style.css
	assets/css/main.css
	assets/js/scripts-global.js
	setup/beaver-builder/beaver-builder.php


## 1.6.1

* **Update**: WordPress 4.9 compatible
* **Update**: Improved WebMan Amplifier plugin compatibility
* **Update**: Documentation links
* **Update**: Documentation
* **Update**: Minor style updates

### Files changed:

	changelog.md
	functions.php
	style.css
	assets/css/editor-style.css
	assets/css/main.css
	assets/css/starter.css
	documentation/*.*
	setup/one-click-demo-import/class-one-click-demo-import.php
	setup/webman-amplifier/webman-amplifier.php
	templates/parts/component-welcome-demo.php
	templates/parts/component-welcome-header.php


## 1.6.0

* **Add**: Table of Contents functionality also for parted pages
* **Add**: Beaver Builder content vertical position option
* **Update**: Default theme footer credits message
* **Update**: One Click Demo Import plugin compatibility
* **Update**: Improved compatibility with customizer
* **Update**: Localization
* **Update**: Documentation
* **Update**: Removed outdated code
* **Fix**: iOS styles issue
* **Fix**: IE11 styles issue
* **Fix**: WP4.8+ Text and Tag Cloud widget styles

### Files changed:

	changelog.md
	style.css
	assets/css/_custom.css
	assets/css/colors.css
	assets/css/customize-preview.css
	assets/css/main.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/js/scripts-beaver-builder-editor.js
	documentation/*.*
	languages/*.*
	lib/core.php
	setup/setup-theme-options.php
	setup/setup.php
	setup/beaver-builder/beaver-builder.php
	setup/one-click-demo-import/class-one-click-demo-import.php
	templates/parts/component-menu-footer.php
	templates/parts/component-menu-primary.php


## 1.5.1

* **Update**: Updating links
* **Update**: Removing "End of file" texts
* **Fix**: PHP error about non-existent Jetpack function

### Files changed:

	changelog.md
	style.css
	assets/css/__fallback.css
	assets/css/_custom-ve.css
	assets/css/_custom.css
	assets/css/colors.css
	assets/css/editor-style.css
	assets/css/main.css
	assets/css/print.css
	assets/css/responsive.css
	documentation/documentation.html
	lib/css/admin.css
	lib/css/rtl-admin.css
	setup/setup.php
	setup/jetpack/jetpack.php
	templates/parts/component-welcome-header.php


## 1.5

* **Add**: One-click demo content import
* **Add**: Child theme generator
* **Update**: TGMPA script
* **Update**: Not removing navigation button styles on mobile devices
* **Update**: Replacing OwlCarousel with Slick
* **Update**: Improved compatibility with Beaver Builder
* **Update**: Improved compatibility with WordPress
* **Update**: Removed obsolete code and files
* **Update**: Reorganized code
* **Update**: Improved accessibility
* **Update**: Removed closing PHP tag from the end of files
* **Update**: Not using `.hentry` class
* **Update**: Improved SSL compatibility
* **Update**: Improved child theme compatibility
* **Update**: Normalize.css v5.0.0
* **Update**: Streamlined admin
* **Update**: Theme "Welcome" page
* **Update**: Localization
* **Update**: Documentation
* **Fix**: Possible JavaScript error with intro background image script
* **Fix**: PHP errors in customizer
* **Fix**: Minor style issues
* **Fix**: Content Module icon color in Beaver Builder enabled layouts

### Files changed:

	404.php
	archive.php
	comments.php
	functions.php
	header.php
	image.php
	index.php
	page.php
	search.php
	sidebar-footer.php
	sidebar.php
	single.php
	style.css
	assets/css/_custom.css
	assets/css/_customizer-styles.php
	assets/css/_generate-css.php
	assets/css/_generate-ve-css.php
	assets/css/beaver-builder-editor.css
	assets/css/colors.css
	assets/css/main.css
	assets/css/print.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/starter.css
	assets/js/scripts-global.js
	assets/js/scripts-masonry.js
	documentation/documentation.html
	documentation/css/custom.css
	lib/admin.php
	lib/core.php
	lib/customizer.php
	lib/css/about.css
	lib/css/admin.css
	lib/css/customizer-rtl.css
	lib/css/customizer.css
	lib/css/rtl-about.css
	lib/inc/class-tgm-plugin-activation.php
	lib/inc/hooks.php
	lib/inc/update-notifier.php
	lib/inc/visual-editor.php
	lib/inc/controls/class-WM_Customizer_Hidden.php
	lib/inc/controls/class-WM_Customizer_HTML.php
	lib/inc/controls/class-WM_Customizer_Image.php
	lib/inc/controls/class-WM_Customizer_Multiselect.php
	lib/inc/controls/class-WM_Customizer_Radiocustom.php
	lib/inc/controls/class-WM_Customizer_Range.php
	lib/inc/controls/class-WM_Customizer_Select.php
	lib/inc/use-child-theme/class-use-child-theme.php
	lib/js/customizer.js
	setup/setup-theme-options.php
	setup/setup.php
	setup/about/about.php
	setup/beaver-builder/beaver-builder.php
	setup/breadcrumb-navxt/breadcrumb-navxt.php
	setup/custom-header/custom-header.php
	setup/jetpack/jetpack.php
	setup/one-click-demo-import/class-one-click-demo-import.php
	setup/one-click-demo-import/one-click-demo-import.php
	setup/post-formats/post-formats.php
	setup/subtitles/subtitles.php
	setup/tgmpa/plugins.php
	setup/webman-amplifier/webman-amplifier.php
	setup/woosidebars/woosidebars.php
	templates/parts/component-menu-social.php
	templates/parts/component-welcome-demo.php
	templates/parts/component-welcome-footer.php
	templates/parts/component-welcome-header.php
	templates/parts/loop.php
	webman-amplifier/content-shortcode-posts-post.php


## 1.4.4

* **Update**: Theme tags
* **Fix**: Compatibility with Beaver Builder 1.8.3
* **Fix**: OwlCarousel script styling issue

### Files changed:

	functions.php
	style.css
	assets/css/shortcodes.css
	setup/beaver-builder/beaver-builder.php


## 1.4.3

* **Update**: Beaver Builder 1.7.4+ support
* **Fix**: Content Module inheriting page builder column border color
* **Fix**: Content Module layout when using icon and featured image at the same time

### Files changed:

	assets/css/shortcodes.css
	setup/beaver-builder/beaver-builder.php
	setup/tgmpa/plugins.php


## 1.4.2

* **Fix**: Website layout setup issue (when using narrow website widths)
* **Fix**: TGM Plugin Activation admin notice position

### Files changed:

	assets/css/_customizer-styles.php
	assets/css/main.css
	lib/inc/class-tgm-plugin-activation.php
	setup/setup-theme-options.php
	setup/setup.php


## 1.4.1

* **Update**: Added theme update info into documentation
* **Fix**: Fixing icon box Content Module setup issue

### Files changed:

	documentation/documentation.html
	setup/webman-amplifier/webman-amplifier.php


## 1.4

* **Update**: Support for WebMan Amplifier 1.3
* **Update**: Support for Beaver Builder 1.7
* **Update**: Using CSS flexbox for page builder columns
* **Update**: Improved scripts
* **Update**: Removed debugging info in favor of Debug Info plugin
* **Update**: Improved headings structure
* **Update**: Localization
* **Fix**: BAW Posts Vies Count plugin styling
* **Fix**: Styling issues on IE11
* **Fix**: Multiple elements styles getting overridden when using page builder's custom styling
* **Fix**: Preventing JS issues in page builder editing mode
* **Fix**: More tag excerpt display

### Files changed:

	assets/css/_custom.css
	assets/css/beaver-builder-editor.css
	assets/css/colors.css
	assets/css/main.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/starter.css
	assets/js/scripts-global.js
	languages/sk_SK.mo
	languages/sk_SK.po
	languages/xx_XX.pot
	setup/setup-theme-options.php
	setup/setup.php
	setup/beaver-builder/beaver-builder.php
	setup/jetpack/jetpack.php
	setup/tgmpa/plugins.php
	setup/webman-amplifier/webman-amplifier.php


## 1.3.5

* **Add**: WordPress 4.3 support
* **Add**: Touch enabled navigation, accessible with Tab key
* **Add**: Documentation into theme folder
* **Update**: Updated scripts: TGM Plugin Activation 2.5.2, jQuery.Hoverdir 1.1.2
* **Update**: Licensed under GPLv3
* **Update**: Admin interface
* **Update**: Localization
* **Update**: Documentation (user manual)
* **Fix**: Google Fonts URL function subset issue
* **Fix**: Playlist styles on dark background
* **Fix**: Contact widget styles

### Files changed:

	assets/css/_custom.css
	assets/css/colors.css
	assets/css/main.css
	assets/css/responsive.css
	assets/js/scripts-global.js
	assets/js/scripts-navigation.js
	lib/admin.php
	lib/customizer.php
	lib/css/admin.css
	lib/css/customizer.css
	lib/inc/controls/class-WM_Customizer_Range.php
	languages/sk_SK.mo
	languages/sk_SK.po
	languages/xx_XX.pot
	setup/setup-theme-options.php
	setup/setup.php


## 1.3.2

* **Add**: `no-padding` class (can be used on Beaver Builder columns/rows)
* **Update**: TGM Plugin Activation 2.4.2
* **Update**: Beaver Builder 1.6+ compatibility
* **Update**: Removed Genericons `example.html` file
* **Update**: Improved enqueing of comments reply script
* **Fix**: Paddings for columns with custom background
* **Fix**: Minor style issues
* **Fix**: Fixed typo in theme manual

### Files changed:

	assets/css/beaver-builder-editor.css
	assets/css/main.css
	assets/css/responsive.css
	lib/inc/class-tgm-plugin-activation.php
	setup/setup.php
	setup/beaver-builder/beaver-builder.php
	setup/custom-header/custom-header.php


## 1.3.1

* **Update**: Library (TGM Plugin Activation 2.4.1)
* **Update**: Beaver Builder compatibility
* **Update**: Starter CSS

### Files changed:

	assets/css/starter.css
	lib/*.*
	setup/beaver-builder/beaver-builder.php


## 1.3

* **Update**: Enabled update notifier
* **Update**: Loading of `style.css` file
* **Update**: Improved compatibility with new version of WebMan Amplifier plugin
* **Update**: Security update: escaping `add_query_arg()`
* **Update**: Improved image sizes setup
* **Update**: Improved Google Fonts setup
* **Update**: Starter CSS styles

### Files changed:

	assets/css/responsive.css
	assets/css/starter.css
	languages/sk_SK.mo
	languages/sk_SK.po
	languages/xx_XX.pot
	setup/setup-theme-options.php
	setup/setup.php
	setup/webman-amplifier/webman-amplifier.php


## 1.2

* **Add**: New special classes to manipulate the design and behavior
* **Add**: Sticky mobile navigation button
* **Add**: Additional Content Module styles: split box with icon over image
* **Add**: Submenu, Contact and Twitter widgets
* **Update**: Improved responsive styles
* **Update**: Tabs design
* **Update**: Allowed to change the image size setup
* **Update**: Improved code, removed unnecessary constants
* **Update**: Removed unnecessary styles
* **Update**: Updated library and styles
* **Update**: Improved Customizer functionality
* **Update**: Compatibility with new version of Beaver Builder
* **Update**: Improved JavaScript scripts
* **Update**: Localization files updated
* **Fix**: Minor style bugs
* **Fix**: Comments displaying conditional

### Files changed:

	comments.php
	content-audio.php
	content-gallery.php
	content-image.php
	content-link.php
	content-status.php
	content-video.php
	content.php
	functions.php
	image.php
	assets/css/_custom.css
	assets/css/_customizer-styles.php
	assets/css/beaver-builder-editor.css
	assets/css/colors.css
	assets/css/main.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/starter.css
	assets/js/scripts-global.js
	languages/sk_SK.mo
	languages/sk_SK.po
	languages/xx_XX.pot
	setup/setup-theme-options.php
	setup/setup.php
	setup/beaver-builder/beaver-builder.php
	setup/custom-header/custom-header.php
	setup/webman-amplifier/webman-amplifier.php


## 1.1

* **Add**: Option to use sticky page builder row
* **Add**: Allow buttons in main navigation
* **Add**: Bigger column padding when column background set (requires Beaver Builder 1.5.1+)
* **Update**: Improved code
* **Update**: Framework library updated to version 4.0.1
* **Update**: CSS styles
* **Update**: Updated filter hooks
* **Update**: Demo content XML
* **Update**: Localization strings and files
* **Fix**: Sticky header glitches
* **Fix**: Sub-sub-menu styles
* **Fix**: Fixed hook names
* **Fix**: Fullwidth website layout
* **Fix**: Cubic portfolio perspective
* **Fix**: Page scrolling speed on certain browsers (and operating systems)
* **Fix**: HTML code cleared from errors

### Files changed:

	content-audio.php
	content-gallery.php
	content-image.php
	content-link.php
	content-video.php
	content.php
	menu-social.php
	assets/css/_custom.css
	assets/css/beaver-builder-editor.css
	assets/css/colors.css
	assets/css/editor-style.css
	assets/css/main.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/starter.css
	assets/js/scripts-global.js
	assets/js/scripts-sticky.js
	languages/sk_SK.mo
	languages/sk_SK.po
	languages/xx_XX.pot
	setup/setup.php
	setup/beaver-builder/beaver-builder.php
	setup/custom-header/custom-header.php
	setup/webman-amplifier/webman-amplifier.php


## 1.0

* Initial release.
