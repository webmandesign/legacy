<?php
/**
 * Archives template
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.5
 */



get_header();

	?>

	<section class="archives-listing">

		<?php get_template_part( 'templates/parts/loop', 'archive' ); ?>

	</section>

	<?php

get_footer();
