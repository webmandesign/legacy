<?php
/**
 * Page template
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.8.2
 */



get_header();

	wmhook_entry_before();

	if ( have_posts() ) {

		the_post();

		get_template_part( 'templates/parts/content', 'page' );

	}

	wmhook_entry_after();

get_footer();
