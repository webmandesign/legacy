<?php
/**
 * More link HTML
 *
 * @package    Q'tron
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    1.9.1
 * @version  1.9.1
 */





?>

<div class="link-more">
	<a href="<?php the_permalink(); ?>" class="more-link">
		<?php

		printf(
			esc_html_x( 'Continue reading%s&hellip;', '%s: Name of current post.', 'qtron' ),
			the_title( '<span class="screen-reader-text"> &ldquo;', '&rdquo;</span>', false )
		);

		?>
	</a>
</div>
