<?php
/**
 * Primary menu template
 *
 * @package    Q'tron
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    1.6.0
 * @version  1.8.1
 */





?>

<nav id="site-navigation" class="main-navigation">
	<span class="screen-reader-text"><?php printf( esc_html__( '%s site navigation', 'qtron' ), get_bloginfo( 'name' ) ); ?></span>
	<?php echo wm_accessibility_skip_link( 'to_content' ); ?>
	<div class="main-navigation-inner">
		<?php

		wp_nav_menu( (array) apply_filters( 'wmhook_wm_navigation_args', array(
			'theme_location'  => 'primary',
			'container'       => 'div',
			'container_class' => 'menu',
			'menu_class'      => 'menu', // Fallback for pagelist
			'items_wrap'      => '<ul>%3$s</ul>',
		) ) );

		?>
		<div id="nav-search-form" class="nav-search-form">
			<a href="#" id="search-toggle" class="search-toggle">
				<span class="screen-reader-text">
					<?php echo esc_html_x( 'Search', 'Display search form button title.', 'qtron' ); ?>
				</span>
			</a>
			<?php get_search_form(); ?>
		</div>
	</div>
	<button id="menu-toggle" class="menu-toggle" aria-controls="site-navigation" aria-expanded="false">
		<?php echo esc_html_x( 'Menu', 'Mobile navigation toggle button title.', 'qtron' ); ?>
	</button>
</nav>
