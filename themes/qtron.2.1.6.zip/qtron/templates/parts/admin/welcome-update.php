<?php
/**
 * Admin "Welcome" page content component.
 *
 * Theme update guide.
 *
 * @package    Q'tron
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since  2.1.0
 */

if ( ! class_exists( 'Qtron_Welcome' ) ) {
	return;
}

?>

<div class="welcome__section welcome__section--update" id="welcome-update">

	<h2>
		<span class="welcome__icon dashicons dashicons-update"></span>
		<?php esc_html_e( 'Theme Updates', 'qtron' ); ?>
	</h2>

	<p>
		<?php esc_html_e( 'WordPress can automatically update only themes from WordPress.org repository.', 'qtron' ); ?>
		<?php esc_html_e( 'As you have obtained this premium theme via CreativeMarket.com, you need to update the theme manually once you are notified in admin area about new theme version.', 'qtron' ); ?>
	</p>

	<p><a href="https://webmandesign.github.io/docs/qtron/#update"><?php esc_html_e( 'How to update theme manually &rarr;', 'qtron' ); ?></a></p>

</div>
