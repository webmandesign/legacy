<?php
/**
 * Footer menu template
 *
 * @package    Q'tron
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    1.6.0
 * @version  1.6.0
 */





// Requirements check

	if ( ! has_nav_menu( 'footer' ) ) {
		return;
	}


?>

<div class="site-footer-area footer-area-menu">
	<div class="site-footer-area-inner clearfix">
		<?php

		wp_nav_menu( (array) apply_filters( 'wmhook_wm_navigation_args', array(
			'theme_location'  => 'footer',
			'container'       => 'div',
			'container_class' => 'menu',
			'menu_class'      => 'menu', // Fallback for pagelist
			'depth'           => 1,
			'items_wrap'      => '<ul>%3$s</ul>',
			'fallback_cb'     => '',
		) ) );

		?>
	</div>
</div>
