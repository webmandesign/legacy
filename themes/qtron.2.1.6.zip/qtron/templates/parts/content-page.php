<?php
/**
 * Page content
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.8.1
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php

		echo '<div class="entry-inner">';

			wmhook_entry_top();

			echo '<div class="entry-content">';

				the_content();

			echo '</div>';

			wmhook_entry_bottom();

		echo '</div>';

	?>

</article>
