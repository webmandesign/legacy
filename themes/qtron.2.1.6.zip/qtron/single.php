<?php
/**
 * Post template
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.8.2
 */



get_header();

	wmhook_entry_before();

	if ( have_posts() ) {

		the_post();

		get_template_part( 'templates/parts/content', apply_filters( 'wmhook_single_content_type', get_post_format() ) );

	}

	wmhook_entry_after();

	if ( ! apply_filters( 'wmhook_single_sidebar_disable', false ) ) {

		get_sidebar();

	}

get_footer();
