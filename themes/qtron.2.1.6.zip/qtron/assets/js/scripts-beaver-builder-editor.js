/**
 * Beaver Builder page editor scripts
 *
 * @package    Q'tron
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    1.6.0
 * @version  1.9.5
 */

( function( $ ) {

	'use strict';

	if ( 'undefined' !== typeof $qtronBBPreview ) {





		/**
		 * Helper function to change custom class fields instantly
		 *
		 * @param  object fieldElement  The settings form field element that was changed.
		 */
		function BBPreviewSelectClass( fieldElement ) {

			// Helper variables

				var
					$field  = fieldElement.attr( 'name' ),
					$node   = fieldElement.closest( 'form.fl-builder-settings' ).data( 'node' ),
					$value  = fieldElement.val(),
					$target = $( '.fl-node-' + $node );


			// Processing

				// Remove all existing classes

					$target
						.removeClass( $qtronBBPreview[ $field ].join( ' ' ) );

				// Add selected class

					if ( $value ) {

						$target
							.addClass( $value );

					}

		} // /BBPreviewSelectClass



		$( 'body' )
			/**
			 * Trigger immediate preview: vertical alignment
			 */
			.on( 'change', '#fl-field-' + 'vertical_alignment' + ' select', function() {
				BBPreviewSelectClass( $( this ) );
			} );





	}

} )( jQuery );
