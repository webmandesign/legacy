/**
 * Theme frontend scripts
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.9.0
 *
 * CONTENT:
 * -  10) Basics
 * -  20) Site header
 * -  30) Content
 * - 100) Others
 */

jQuery( function() {

	'use strict';



	/**
	 * 10) Basics
	 */

		/**
		 * Cache
		 */

			var $window      = jQuery( window ),
			    windowHeight = $window.height();



		/**
		 * Tell CSS that JS is enabled...
		 */

			jQuery( '.no-js' ).removeClass( 'no-js' );



		/**
		 * Back to top buttons
		 */

			if ( 960 < document.body.clientWidth ) {

				jQuery( '.back-to-top' )
					.on( 'click', function( e ) {

						// Processing

							// Scroll the page to top.
							jQuery( 'html, body' )
								.animate( {
									scrollTop : 0
								}, 400 );

							// Reset focus on top of the page.
							jQuery( 'body' )
								.attr( 'tabindex', 0 )
								.focus();

							// Do not alter URL in browser.
							return false;

					} );

			}





	/**
	 * 20) Site header
	 */

		/**
		 * Header search form
		 */

			jQuery( '#search-toggle' ).on( 'click', function( e ) {
				e.preventDefault();

				jQuery( this )
					.parent()
						.toggleClass( 'active' )
						.find( '.search-field' )
							.focus();
			} );



		/**
		 * Header and intro title background color class
		 */

			if (
					jQuery( '#intro' ).length
					&& 'none' !== jQuery( '.intro-inner' ).css( 'background-image' )
					&& 'undefined' != typeof( BackgroundCheck )
					&& 1 > window.location.href.search( 'fl_builder' )
				) {

				BackgroundCheck.init( {
					targets : '.site-header:not(.normal), .intro-title',
					images  : '.intro-inner'
				} );

			} // /BackgroundCheck





	/**
	 * 30) Content
	 */

		/**
		 * Gallery post format slideshow
		 */

			if ( jQuery().slick ) {

				jQuery( '.format-gallery:not(.slide-1-item) .entry-media.enable-slider' ).slick( {
						slidesToShow   : 2,
						slidesToScroll : 2,
						autoplay       : false,
						autoplaySpeed  : 3000,
					} );

				jQuery( '.slide-1-item .entry-media.enable-slider' ).slick( {
						autoplay      : true,
						autoplaySpeed : 3000,
					} );

			} // /slick



		/**
		 * Directional hover effect on projects
		 */

			if ( jQuery().hoverdir ) {

				jQuery( '.cubic .wm-posts-item' ).each( function() { jQuery( this ).hoverdir(); } );

			} // /hoverdir





	/**
	 * 100) Others
	 */

		/**
		 * On-page anchor smooth scrolling
		 */

			jQuery( 'body' )
				.on( 'click', 'a[href^="#"]', function( e ) {

					// Requirements check

						// Do nothing when editing page with Beaver Builder

							if ( jQuery( 'html' ).hasClass( 'fl-builder-edit' ) ) {
								e.preventDefault();
								return;
							}


					// Helper variables

						var $this         = jQuery( this ),
						    $anchor       = $this.not( '.add-comment-link, .search-toggle, .back-to-top, .skip-link' ).attr( 'href' ),
						    $scrollObject = jQuery( 'html, body' ),
						    $scrollSpeed  = ( 960 >= window.innerWidth ) ? ( 0 ) : ( 600 );


					// Processing

						if (
								$anchor
								&& '#' !== $anchor
								&& ! $this.parent().parent().hasClass( 'wm-tab-links' )
								&& ! $this.hasClass( 'no-smooth-scroll' )
							) {

							e.preventDefault();

							var $scrollOffset = jQuery( '.do-sticky-header #masthead' ).outerHeight() - 1;

							if ( jQuery( '#wpadminbar' ).length ) {
								$scrollOffset += jQuery( '#wpadminbar' ).outerHeight();
							}
							if ( jQuery( '.fl-row.sticky' ).length ) {
								$scrollOffset += jQuery( '.fl-row.sticky' ).eq( 0 ).outerHeight();
							}

							$scrollObject
								.stop()
								.animate( {
									scrollTop : jQuery( $anchor ).offset().top - $scrollOffset + 'px'
								}, $scrollSpeed );

						}

				} );



		/**
		 * Beaver Builder editor preview refreshed
		 */

			jQuery( '.fl-builder-content' ).on( 'fl-builder.preview-rendered, fl-builder.layout-rendered', function() {

				//re-Masonry
					if ( jQuery().masonry ) {
						jQuery( '.masonry-this' ).masonry();
					} // /masonry

				//re-Isotope
					if ( jQuery().isotope ) {
						jQuery( '.filter-this' ).isotope( { layoutMode : 'masonry' } );
					} // /isotope

			} );



} );
