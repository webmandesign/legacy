/**
 * Parallax
 *
 * Require smooth scrolling JS to fix the parallax
 * glitches in webkit browsers.
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.9.0
 */

jQuery( function() {

	'use strict';



	/**
	 * Intro parallax
	 */

		if (
				jQuery( 'body' ).hasClass( 'do-parallax-intro' )
				&& jQuery( '.intro' ).length
				&& 960 < document.body.clientWidth
			) {

			var $window               = jQuery( window ),
			    windowHeight          = $window.height(),
			    $introParallaxElement = jQuery( '.intro-inner, .intro-title-disabled .fl-row.intro:first-child .fl-row-content-wrap' ),
			    introParallaxSpeed    = .25;

			jQuery( '.intro-container .intro, .intro-title-disabled .fl-row.intro:first-child .fl-row-content-wrap' ).css( 'margin-top', -( $introParallaxElement.offset().top * introParallaxSpeed ) + 'px' );

			function introParallax() {
				var pos    = $window.scrollTop(),
				    top    = $introParallaxElement.offset().top,
				    height = $introParallaxElement.outerHeight( true );
				//Check if totally above or totally below viewport
					if (
							( pos > top + height )
							|| ( top > pos + windowHeight )
						) {
						return;
					}

				$introParallaxElement
					.css( 'transform', 'translateY( ' + ( pos * introParallaxSpeed ) + 'px )' )
					.find( '.parallax-multiply, .fl-row-content' )
						.css( 'transform', 'translateY( ' + ( pos * introParallaxSpeed ) + 'px )' );
			} // /introParallax

			$window.on( 'scroll', introParallax ).resize( introParallax );

			introParallax();

		}



} );
