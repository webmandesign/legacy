/**
 * Sticky header
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  2.1.1
 */

jQuery( function() {

	'use strict';



	if (
		jQuery( 'body' ).hasClass( 'do-sticky-header' )
		&& 960 < document.body.clientWidth
	) {



		/**
		 * Sticky header
		 */

			var $window         = jQuery( window ),
			    $header         = jQuery( '#masthead' ),
			    $headerHeight   = $header.outerHeight(),
			    $headerTop      = $header.offset().top,
			    $adminBarHeight = ( jQuery( '#wpadminbar' ).length ) ? ( jQuery( '#wpadminbar' ).outerHeight() ) : ( 0 );

			$headerTop -= $adminBarHeight;

			function stickyHeader() {

				var $documentScrollTop = $window.scrollTop();

				if ( $documentScrollTop >= ( 3 * $headerHeight ) ) {

					jQuery( 'body' )
						.removeClass( 'hide-sticky-header' )
						.addClass( 'sticky-header' );

				} else if ( $documentScrollTop < ( 3 * $headerHeight ) && $documentScrollTop > ( 2 * $headerHeight ) ) {

					jQuery( 'body.sticky-header' )
						.removeClass( 'sticky-header' )
						.addClass( 'hide-sticky-header' );

				} else {

					jQuery( 'body' )
						.removeClass( 'sticky-header hide-sticky-header' );

				}

			} // /stickyHeader

			stickyHeader();

			$window.on( 'scroll', stickyHeader );



		/**
		 * Sticky row
		 */

			if ( jQuery( '.fl-row.sticky' ).length ) {

				var $page      = jQuery( '#page' ),
				    $sticky    = jQuery( '.fl-row.sticky' ).eq( 0 ),
				    $stickyTop = $sticky.offset().top;

				$stickyTop -= $header.outerHeight() + $adminBarHeight;

				function stickyRow() {

					if ( $window.scrollTop() >= $stickyTop ) {

						$sticky
							.css( 'height', $sticky.outerHeight() + 'px' )
							.addClass( 'sticky-enabled' );

					} else {

						$sticky
							.css( 'height', 'auto' )
							.removeClass( 'sticky-enabled' );

					}

				} // /stickyRow

				stickyRow();

				$window.on( 'scroll', stickyRow );

			}



	}



} );
