/**
 * Masonry layouts
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.9.5
 */

jQuery( function() {

	'use strict';

	if ( jQuery().masonry ) {



		/**
		 * Masonry posts
		 */

			var $postsContainers = jQuery( '.posts' );

			$postsContainers.imagesLoaded( function() {

				$postsContainers.masonry( {
						itemSelector : '.hentry'
					} );

			} );



		/**
		 * Masonry footer
		 */

			var $footerWidgets = jQuery( '#footer-widgets' );

			if ( $footerWidgets.length ) {

				var footerWidgetsColumns = $footerWidgets.data( 'columns' );

				if (
						1 < footerWidgetsColumns
						&& footerWidgetsColumns < $footerWidgets.data( 'widgetsCount' )
					) {
				//Doesn't make sense for 1 column layout

					var $footerWidgets = jQuery( '#footer-widgets-container' );

					$footerWidgets.imagesLoaded( function() {

						$footerWidgets.masonry( {
								itemSelector : '.widget'
							} );

					} );

				}

			} // /if footer widgets displayed



		/**
		 * Jetpack Infinite Scroll posts loading
		 */

			jQuery( document.body ).on( 'post-load', function() {

				/**
				 * Masonry posts list
				 */

					var $postsContainers = jQuery( '.posts' );

					$postsContainers.imagesLoaded( function() {

						$postsContainers.masonry( 'reload' );

					} );

			} );



	} // /masonry

} );
