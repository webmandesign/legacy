<?php
/**
 * General index template
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.5
 */



get_header();

	get_template_part( 'templates/parts/loop', 'index' );

get_footer();
