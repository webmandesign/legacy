<?php
/**
 * Error 404 page template
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.5
 */



get_header();

	?>

	<section id="error-404" class="error-404">

		<p><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'qtron' ); ?></p>

		<?php get_search_form(); ?>

	</section>

	<?php

get_footer();
