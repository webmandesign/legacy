<?php
/**
 * Admin functions
 *
 * @package     WebMan WordPress Theme Framework
 * @subpackage  Admin functions
 * @copyright   2015 WebMan - Oliver Juhas
 *
 * @since    3.0
 * @version  4.0.3
 * @version  2.1.0
 *
 * CONTENT:
 * -  1) Required files
 * - 10) Actions and filters
 * - 20) Assets
 */





/**
 * 1) Required files
 */

	// Child theme generator

		if ( is_admin() ) {
			require_once get_theme_file_path( WM_LIBRARY_DIR . 'inc/use-child-theme/class-use-child-theme.php' );
		}





/**
 * 10) Actions and filters
 */

	/**
	 * Actions
	 */

		//Styles and scripts
			add_action( 'admin_enqueue_scripts', 'wm_assets_admin',        998 );
			add_action( 'admin_enqueue_scripts', 'wm_admin_inline_styles', 998 );





/**
 * 20) Assets
 */

	/**
	 * Admin assets
	 *
	 * @since    3.0
	 * @version  4.0
	 * @version  2.1.0
	 */
	if ( ! function_exists( 'wm_assets_admin' ) ) {
		function wm_assets_admin() {
			/**
			 * Register
			 */

				//Styles
					$register_styles = apply_filters( 'wmhook_wm_assets_admin_register_styles', array(
					//Backend
						'wm-admin' => array( wm_get_stylesheet_directory_uri( WM_LIBRARY_DIR . 'css/admin.css' ) ),
					) );

					foreach ( $register_styles as $handle => $atts ) {
						$src   = ( isset( $atts['src'] ) ) ? ( $atts['src'] ) : ( $atts[0] );
						$deps  = ( isset( $atts['deps'] ) ) ? ( $atts['deps'] ) : ( false );
						$ver   = ( isset( $atts['ver'] ) ) ? ( $atts['ver'] ) : ( WM_SCRIPTS_VERSION );
						$media = ( isset( $atts['media'] ) ) ? ( $atts['media'] ) : ( 'screen' );

						wp_register_style( $handle, $src, $deps, $ver, $media );
					}

				//Scripts
					$register_scripts = apply_filters( 'wmhook_wm_assets_admin_register_scripts', array(
						//Backend
							'wm-wp-admin' => array(
									'src'  => wm_get_stylesheet_directory_uri( WM_LIBRARY_DIR . 'js/wm-scripts.js' ),
									'deps' => array( 'jquery' ),
								),
						) );

					foreach ( $register_scripts as $handle => $atts ) {
						$src       = ( isset( $atts['src'] ) ) ? ( $atts['src'] ) : ( $atts[0] );
						$deps      = ( isset( $atts['deps'] ) ) ? ( $atts['deps'] ) : ( false );
						$ver       = ( isset( $atts['ver'] ) ) ? ( $atts['ver'] ) : ( WM_SCRIPTS_VERSION );
						$in_footer = ( isset( $atts['in_footer'] ) ) ? ( $atts['in_footer'] ) : ( true );

						wp_register_script( $handle, $src, $deps, $ver, $in_footer );
					}

			/**
			 * Enqueue
			 */

				//Styles
					wp_enqueue_style( 'wm-admin' );

				//Scripts
					wp_enqueue_script( 'wm-wp-admin' );
		}
	} // /wm_assets_admin



	/**
	 * Admin inline styles
	 *
	 * @since    3.0
	 * @version  4.0
	 * @version  1.5
	 */
	if ( ! function_exists( 'wm_admin_inline_styles' ) ) {
		function wm_admin_inline_styles() {

			// Helper variables

				global $current_screen;

				$output     = '';
				$no_preview = apply_filters( 'wmhook_wm_admin_inline_styles_no_preview', array( 'wm_logos', 'wm_modules', 'wm_staff', 'wm_testimonials' ) );


			// Processing

				// Removing unnecessary view buttons

					if ( isset( $current_screen->post_type ) && in_array( $current_screen->post_type, $no_preview ) ) {
						$output .= '.row-actions .view, #view-post-btn, #preview-action { display: none; }';
					}


			// Output

				if ( $output = apply_filters( 'wmhook_wm_admin_inline_styles_output', $output ) ) {
					wp_add_inline_style( 'wm-admin', apply_filters( 'wmhook_esc_css', $output ) );
				}

		}
	} // /wm_admin_inline_styles
