<?php
/**
 * WebMan WordPress Theme Framework
 *
 * A set of core functions.
 *
 * @package    WebMan WordPress Theme Framework
 * @copyright  2015 WebMan - Oliver Juhas
 * @license    GPL-2.0+, http://www.gnu.org/licenses/gpl-2.0.html
 *
 * @version  4.0.4
 * @version  2.1.5
 *
 * @link  https://github.com/webmandesign/webman-theme-framework
 * @link  http://www.webmandesign.eu
 *
 * CONTENT:
 * -   0) Constants
 * -   1) Required files
 * -  10) Actions and filters
 * -  20) Branding
 * -  30) Post/page
 * -  40) CSS functions
 * - 100) Other functions
 */





/**
 * 0) Constants
 */

	//Helper variables
		$theme_data = wp_get_theme( 'qtron' );

	//Basic constants
		if ( ! defined( 'WM_THEME_NAME' ) )        define( 'WM_THEME_NAME',        $theme_data->get( 'Name' )                                   );
		if ( ! defined( 'WM_THEME_SHORTNAME' ) )   define( 'WM_THEME_SHORTNAME',   str_replace( array( '-lite', '-plus' ), '', get_template() ) );
		if ( ! defined( 'WM_THEME_VERSION' ) )     define( 'WM_THEME_VERSION',     $theme_data->get( 'Version' )                                );
		if ( ! defined( 'WM_THEME_AUTHOR_URI' ) )  define( 'WM_THEME_AUTHOR_URI',  esc_url( $theme_data->get( 'AuthorURI' ) )                   );
		if ( ! defined( 'WM_THEME_URI' ) )         define( 'WM_THEME_URI',         esc_url( $theme_data->get( 'ThemeURI' ) )                    );

		if ( ! defined( 'WM_SCRIPTS_VERSION' ) )   define( 'WM_SCRIPTS_VERSION',   esc_attr( trim( WM_THEME_VERSION ) )                         );

	//Options constants
		if ( ! defined( 'WM_OPTION_PREFIX' ) ) define( 'WM_OPTION_PREFIX', '' );
		if ( ! defined( 'WM_OPTION_CUSTOMIZER' ) ) define( 'WM_OPTION_CUSTOMIZER', 'theme_mods_' . WM_THEME_SHORTNAME );

	//Dir constants
		if ( ! defined( 'WM_LIBRARY_DIR' ) )       define( 'WM_LIBRARY_DIR',       trailingslashit( 'lib' )                                     );
		if ( ! defined( 'WM_SETUP_DIR' ) )         define( 'WM_SETUP_DIR',         trailingslashit( 'setup' )                                   );
		if ( ! defined( 'WM_SETUP' ) )             define( 'WM_SETUP',             trailingslashit( get_template_directory() ) . WM_SETUP_DIR   );
		if ( ! defined( 'WM_SETUP_CHILD' ) )       define( 'WM_SETUP_CHILD',       trailingslashit( get_stylesheet_directory() ) . WM_SETUP_DIR );

	//Required to set up in the theme's functions.php file
		if ( ! defined( 'WM_WP_COMPATIBILITY' ) )  define( 'WM_WP_COMPATIBILITY',  4.1                                                          );



	/**
	 * Global variables
	 */

		//Get theme options
			$wm_theme_options = get_option( WM_OPTION_CUSTOMIZER );

			if ( empty( $wm_theme_options ) ) {
				$wm_theme_options = array();
			}





/**
 * 1) Required files
 */

	// Main theme action hooks
	require_once get_theme_file_path( WM_LIBRARY_DIR . 'inc/hooks.php' );

	// Customizer (has to be frontend accessible, otherwise it hides theme settings)
	require_once get_theme_file_path( WM_LIBRARY_DIR . 'customizer.php' );

	// Admin required files
	if ( is_admin() ) {

		// WP admin functionality
		require_once get_theme_file_path( WM_LIBRARY_DIR . 'admin.php' );

		// Optional plugins suggestions
		$plugins_suggestions = get_theme_file_path( WM_SETUP_DIR . 'tgmpa/plugins.php' );
		if ( apply_filters( 'wmhook_enable_plugins_integration', file_exists( $plugins_suggestions ) ) ) {
			require_once get_theme_file_path( WM_LIBRARY_DIR . 'inc/class-tgm-plugin-activation.php' );
			require_once $plugins_suggestions;
		}

	}





/**
 * 10) Actions and filters
 */

	/**
	 * Actions
	 */

		//Theme upgrade action
			add_action( 'init', 'wm_theme_upgrade' );
		//Flushing transients
			add_action( 'switch_theme',  'wm_image_ids_transient_flusher'      );
			add_action( 'edit_category', 'wm_all_categories_transient_flusher' );
			add_action( 'save_post',     'wm_all_categories_transient_flusher' );



	/**
	 * Filters
	 */

		//Escape inline CSS
			add_filter( 'wmhook_esc_css', 'wp_strip_all_tags' );
		//Table of contents
			add_filter( 'the_content', 'wm_nextpage_table_of_contents', 10 );





/**
 * 20) Branding
 */

	/**
	 * Logo
	 *
	 * Supports Jetpack Site Logo module.
	 *
	 * @since    3.0
	 * @version  4.0
	 * @version  2.1.5
	 *
	 * @param  string $container_class  If empty, no container will be outputted.
	 */
	if ( ! function_exists( 'wm_logo' ) ) {
		function wm_logo( $container_class = 'site-branding' ) {

			// Helper variables

				$output = array();

				$document_title = wp_get_document_title(); // Since WordPress 4.4

				$custom_logo = get_theme_mod( 'custom_logo' ); // Since WordPress 4.5

				// If we don't get WordPress 4.5+ custom logo, try Jetpack Site Logo

					if ( empty( $custom_logo ) && function_exists( 'jetpack_get_site_logo' ) ) {
						$custom_logo = get_option( 'site_logo', array() );
						$custom_logo = ( isset( $custom_logo['id'] ) && $custom_logo['id'] ) ? ( absint( $custom_logo['id'] ) ) : ( false );
					}

				$blog_info = apply_filters( 'wmhook_wm_logo_blog_info', array(
						'name'        => trim( get_bloginfo( 'name' ) ),
						'description' => trim( get_bloginfo( 'description' ) ),
					), $container_class );

				$args = apply_filters( 'wmhook_wm_logo_args', array(
						'logo_image' => ( ! empty( $custom_logo ) ) ? ( array( $custom_logo ) ) : ( array( wm_option( 'logo' ), wm_option( 'logo-hidpi' ) ) ),
						'logo_type'  => 'text',
						'title_att'  => ( $blog_info['description'] ) ? ( $blog_info['name'] . ' | ' . $blog_info['description'] ) : ( $blog_info['name'] ),
						'url'        => home_url( '/' ),
						'container'  => $container_class,
					) );


			// Processing

				// Logo image

					if ( ! empty( $args['logo_image'] ) && $args['logo_image'][0] ) {

						$img_id = ( is_numeric( $args['logo_image'][0] ) ) ? ( absint( $args['logo_image'][0] ) ) : ( wm_get_image_id_from_url( $args['logo_image'][0] ) );

						// High resolution support

							if ( isset( $args['logo_image'][1] ) && is_numeric( $args['logo_image'][1] ) ) {
								$img_id_hidpi = absint( $args['logo_image'][1] );
							} elseif ( isset( $args['logo_image'][1] ) ) {
								$img_id_hidpi = wm_get_image_id_from_url( $args['logo_image'][1] );
							} else {
								$img_id_hidpi = false;
							}

						if ( $img_id ) {

							$atts = array(
									'alt'   => esc_attr( sprintf( _x( '%s logo', 'Site logo image "alt" HTML attribute text.', 'qtron' ), $blog_info['name'] ) ),
									'title' => esc_attr( $args['title_att'] ),
									'class' => '',
								);

							if ( $img_id_hidpi ) {
								$logo_url_hiDPI     = (array) wp_get_attachment_image_src( $img_id_hidpi, 'full' );
								$atts['data-hidpi'] = (string) $logo_url_hiDPI[0];
							}

							$atts = (array) apply_filters( 'wmhook_wm_logo_image_atts', $atts, $img_id, $img_id_hidpi );

							$args['logo_image'] = wp_get_attachment_image( absint( $img_id ), 'full', false, $atts );

						}

						$args['logo_type'] = 'img';

					}

					$args['logo_image'] = apply_filters( 'wmhook_wm_logo_logo_image', $args['logo_image'] );

				// Logo HTML

					$logo_class = apply_filters( 'wmhook_wm_logo_class', 'site-title logo type-' . $args['logo_type'], $args );

					if ( $args['container'] ) {
						$output[1] = '<div class="' . esc_attr( trim( $args['container'] ) ) . '">';
					}

						if ( is_front_page() ) {
							$output[10] = '<h1 id="site-title" class="' . esc_attr( $logo_class ) . '">';
						} else {
							$output[10] = '<h2 class="screen-reader-text">' . $document_title . '</h2>'; // To provide BODY heading on subpages
							$output[15] = '<a id="site-title" class="' . esc_attr( $logo_class ) . '" href="' . esc_url( $args['url'] ) . '" title="' . esc_attr( $args['title_att'] ) . '" rel="home">';
						}

							if ( 'text' === $args['logo_type'] ) {
								$output[30] = '<span class="text-logo">' . $blog_info['name'] . '</span>';
							} else {
								$output[30] = $args['logo_image'] . '<span class="screen-reader-text">' . $blog_info['name'] . '</span>';
							}

						if ( is_front_page() ) {
							$output[40] = '</h1>';
						} else {
							$output[40] = '</a>';
						}

							if ( $blog_info['description'] ) {
								$output[50] = '<div class="site-description">' . $blog_info['description'] . '</div>';
							}

					if ( $args['container'] ) {
						$output[100] = '</div>';
					}

					// Filter output array

						$output = (array) apply_filters( 'wmhook_wm_logo_output', $output, $args );

						ksort( $output );


			// Output

				echo implode( '', $output );

		}
	} // /wm_logo





/**
 * 30) Post/page
 */

	/**
	 * Table of contents from <!--nextpage--> tag
	 *
	 * Will create a table of content in multipage post from
	 * the first H2 heading in each post part.
	 * Appends the output at the top and bottom of post content.
	 *
	 * @since    3.0
	 * @version  4.0.1
	 * @version  1.6.0
	 *
	 * @param  string $content
	 */
	if ( ! function_exists( 'wm_nextpage_table_of_contents' ) ) {
		function wm_nextpage_table_of_contents( $content ) {
			//Helper variables
				global $page, $numpages, $multipage, $post;

				//translators: %s will be replaced with parted post title. Copy it, do not translate.
				$title_text = apply_filters( 'wmhook_wm_nextpage_table_of_contents_title_text', sprintf( _x( '"%s" table of contents', 'Parted/paginated post table of content title. %s = post title.', 'qtron' ), the_title_attribute( 'echo=0' ) ) );
				$title      = apply_filters( 'wmhook_wm_nextpage_table_of_contents_title', '<h2 class="screen-reader-text">' . $title_text . '</h2>' );

				//Requirements check
					if (
							! $multipage
							|| ! is_singular()
						) {
						return $content;
					}

				$args = apply_filters( 'wmhook_wm_nextpage_table_of_contents_atts', array(
						//If set to TRUE, the first post part will have a title of the post (the part title will not be parsed)
						'disable_first' => true,
						//The output HTML
						'links'         => array(),
						//Get the whole post content
						'post_content'  => ( isset( $post->post_content ) ) ? ( $post->post_content ) : ( '' ),
						//Which HTML heading tag to parse as a post part title
						'tag'           => 'h2',
					) );

				//Post part counter
					$i = 0;

			//Prepare output
				$args['post_content'] = explode( '<!--nextpage-->', $args['post_content'] );

				//Get post parts titles
					foreach ( $args['post_content'] as $part ) {

						//Current post part number
							$i++;

						//Get title for post part
							if ( $args['disable_first'] && 1 === $i ) {

								$part_title = the_title_attribute( 'echo=0' );

							} else {

								preg_match( '/<' . $args['tag'] . '(.*?)>(.*?)<\/' . $args['tag'] . '>/', $part, $matches );

								if ( ! isset( $matches[2] ) || ! $matches[2] ) {
									$part_title = sprintf( __( 'Page %s', 'qtron' ), $i );
								} else {
									$part_title = $matches[2];
								}

							}

						//Set post part class
							if ( $page === $i ) {
								$class = ' class="current"';
							} elseif ( $page > $i ) {
								$class = ' class="passed"';
							} else {
								$class = '';
							}

						//Post part item output
							$args['links'][$i] = apply_filters( 'wmhook_wm_nextpage_table_of_contents_part', '<li' . $class . '>' . _wp_link_page( $i ) . $part_title . '</a></li>', $i, $part_title, $class, $args );

					}

				//Add table of contents into the post/page content
					$args['links'] = implode( '', $args['links'] );

					$links = apply_filters( 'wmhook_wm_nextpage_table_of_contents_links', array(
							//Display table of contents before the post content only in first post part
								'before' => ( 1 === $page ) ? ( '<div class="post-table-of-contents top" title="' . esc_attr( strip_tags( $title_text ) ) . '">' . $title . '<ol>' . $args['links'] . '</ol></div>' ) : ( '' ),
							//Display table of cotnnets after the post cotnent on each post part
								'after'  => '<div class="post-table-of-contents bottom" title="' . esc_attr( strip_tags( $title_text ) ) . '">' . $title . '<ol>' . $args['links'] . '</ol></div>',
						), $args );

					$content = $links['before'] . $content . $links['after'];

			//Output
				return apply_filters( 'wmhook_wm_nextpage_table_of_contents_output', $content, $args );
		}
	} // /wm_nextpage_table_of_contents



	/**
	 * Post/page parts pagination
	 *
	 * @since    3.0
	 * @version  3.0
	 *
	 * @param  boolean $echo
	 */
	if ( ! function_exists( 'wm_post_parts' ) ) {
		function wm_post_parts( $echo = true ) {
			wp_link_pages( array(
				'before'         => '<p class="pagination post-parts">',
				'after'          => '</p>',
				'next_or_number' => 'number',
				'pagelink'       => '<span class="page-numbers">' . __( 'Part %', 'qtron' ) . '</span>',
				'echo'           => $echo,
			) );
		}
	} // /wm_post_parts



	/**
	 * Post meta info
	 *
	 * hAtom microformats compatible. @link http://goo.gl/LHi4Dy
	 * Supports ZillaLikes plugin. @link http://www.themezilla.com/plugins/zillalikes/
	 * Supports Post Views Count plugin. @link https://wordpress.org/plugins/baw-post-views-count/
	 *
	 * @since    3.0
	 * @version  4.0.1
	 * @version  1.8.1
	 *
	 * @param  array $args
	 */
	if ( ! function_exists( 'wm_post_meta' ) ) {
		function wm_post_meta( $args = array() ) {
			//Helper variables
				$output = '';

				$args = wp_parse_args( $args, apply_filters( 'wmhook_wm_post_meta_defaults', array(
						'class'       => 'entry-meta clearfix',
						'date_format' => null,
						'html'        => '<span class="{class}"{attributes}>{content}</span>',
						'html_custom' => array(
								'date' => '<time datetime="{datetime}" class="{class}"{attributes}>{content}</time>',
							),
						'meta'        => array(), //For example: array( 'date', 'author', 'category', 'comments', 'permalink' )
						'post_id'     => null,
						'post'        => null,
					) ) );
				$args = apply_filters( 'wmhook_wm_post_meta_args', $args );

				$args['meta'] = array_filter( (array) $args['meta'] );

				if ( $args['post_id'] ) {
					$args['post_id'] = absint( $args['post_id'] );
					$args['post']    = get_post( $args['post_id'] );
				}

			//Requirements check
				if ( empty( $args['meta'] ) ) {
					return;
				}

			//Preparing output
				foreach ( $args['meta'] as $meta ) {

					//Allow custom metas
						$helper = '';

						$replacements  = (array) apply_filters( 'wmhook_wm_post_meta_replacements', array(), $meta, $args );
						$single_output = apply_filters( 'wmhook_wm_post_meta', '', $meta, $args );
						$output       .= $single_output;

					//Predefined metas
						switch ( $meta ) {
							case 'author':

								if ( apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args ) ) {
									$replacements = array(
											'{attributes}' => '',
											'{class}'      => 'author vcard entry-meta-element',
											'{content}'    => '<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" class="url fn n" rel="author">' . get_the_author() . '</a>',
										);
								}

							break;
							case 'category':

								if (
										apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args )
										&& wm_is_categorized_blog()
										&& ( $helper = get_the_category_list( ', ', '', $args['post_id'] ) )
									) {
									$replacements = array(
											'{attributes}' => '',
											'{class}'      => 'cat-links entry-meta-element',
											'{content}'    => $helper,
										);
								}

							break;
							case 'comments':

								if (
										apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args )
										&& ! post_password_required()
										&& (
											comments_open( $args['post_id'] )
											|| get_comments_number( $args['post_id'] )
										)
									) {
									$helper = get_comments_number( $args['post_id'] ); //Don't know why this can not be in IF condition, but otherwise it won't work...
									$element_id   = ( $helper ) ? ( '#comments' ) : ( '#respond' );
									$replacements = array(
											'{attributes}' => '',
											'{class}'      => 'comments-link entry-meta-element',
											'{content}'    => '<a href="' . esc_url( get_permalink( $args['post_id'] ) ) . $element_id . '" title="' . esc_attr( sprintf( _x( 'Comments: %s', 'Number of comments in post meta.', 'qtron' ), $helper ) ) . '">' . sprintf( _x( '<span class="comments-title">Comments: </span>%s', 'Number of comments in post meta (keep the HTML tags).', 'qtron' ), '<span class="comments-count">' . $helper . '</span>' ) . '</a>',
										);
								}

							break;
							case 'date':

								if ( apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args ) ) {
									$replacements = array(
											'{attributes}' => ' title="' . esc_attr( get_the_date() ) . ' | ' . esc_attr( get_the_time( '', $args['post'] ) ) . '"',
											'{class}'      => 'entry-date entry-meta-element published',
											'{content}'    => esc_html( get_the_date( $args['date_format'] ) ),
											'{datetime}'   => esc_attr( get_the_date( 'c' ) ),
										);
								}

							break;
							case 'edit':

								if (
										apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args )
										&& ( $helper = get_edit_post_link( $args['post_id'] ) )
									) {
									$the_title_attribute_args = array( 'echo' => false );
									if ( $args['post_id'] ) {
										$the_title_attribute_args['post'] = $args['post'];
									}

									$replacements = array(
											'{attributes}' => '',
											'{class}'      => 'entry-edit entry-meta-element',
											'{content}'    => '<a href="' . esc_url( $helper ) . '" title="' . esc_attr( sprintf( __( 'Edit the "%s"', 'qtron' ), the_title_attribute( $the_title_attribute_args ) ) ) . '"><span>' . _x( 'Edit', 'Edit post link.', 'qtron' ) . '</span></a>',
										);
								}

							break;
							case 'likes':

								if (
										apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args )
										&& function_exists( 'zilla_likes' )
									) {
									global $zilla_likes;
									$helper = $zilla_likes->do_likes();

									$replacements = array(
											'{attributes}' => '',
											'{class}'      => 'entry-likes entry-meta-element',
											'{content}'    => $helper,
										);
								}

							break;
							case 'permalink':

								if ( apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args ) ) {
									$the_title_attribute_args = array( 'echo' => false );
									if ( $args['post_id'] ) {
										$the_title_attribute_args['post'] = $args['post'];
									}

									$replacements = array(
											'{attributes}' => '',
											'{class}'      => 'entry-permalink entry-meta-element',
											'{content}'    => '<a href="' . esc_url( get_permalink( $args['post_id'] ) ) . '" title="' . esc_attr( sprintf( __( 'Permalink to "%s"', 'qtron' ), the_title_attribute( $the_title_attribute_args ) ) ) . '" rel="bookmark"><span>' . get_the_title( $args['post_id'] ) . '</span></a>',
										);
								}

							break;
							case 'tags':

								if (
										apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args )
										&& ( $helper = get_the_tag_list( '', ' ', '', $args['post_id'] ) )
									) {
									$replacements = array(
											'{attributes}' => '',
											'{class}'      => 'tags-links entry-meta-element',
											'{content}'    => $helper,
										);
								}

							break;
							case 'views':

								if (
										apply_filters( 'wmhook_wm_post_meta_enable_' . $meta, true, $args )
										&& function_exists( 'bawpvc_views_sc' )
										&& ( $helper = bawpvc_views_sc( array() ) )
									) {
									$replacements = array(
											'{attributes}' => ' title="' . __( 'Views count', 'qtron' ) . '"',
											'{class}'      => 'entry-views entry-meta-element',
											'{content}'    => wp_strip_all_tags( $helper ),
										);
								}

							break;

							default:
							break;
						} // /switch

						//Single meta output
							$replacements = (array) apply_filters( 'wmhook_wm_post_meta_replacements_' . $meta, $replacements, $args );
							if (
									empty( $single_output )
									&& ! empty( $replacements )
								) {
								if ( isset( $args['html_custom'][ $meta ] ) ) {
									$output .= strtr( $args['html_custom'][ $meta ], (array) $replacements );
								} else {
									$output .= strtr( $args['html'], (array) $replacements );
								}
							}

				} // /foreach

				if ( $output ) {
					$output = '<div class="' . esc_attr( $args['class'] ) . '">' . $output . '</div>';
				}

			//Output
				return apply_filters( 'wmhook_wm_post_meta_output', $output, $args );
		}
	} // /wm_post_meta



	/**
	 * Paginated heading suffix
	 *
	 * @since    3.0
	 * @version  1.8.0
	 *
	 * @param  string $tag           Wrapper tag
	 * @param  string $singular_only Display only on singular posts of specific type
	 */
	if ( ! function_exists( 'wm_paginated_suffix' ) ) {
		function wm_paginated_suffix( $tag = '', $singular_only = false ) {

			// Requirements check

				if (
					$singular_only
					&& ! is_singular( $singular_only )
				) {
					return;
				}


			// Helper variables

				global $page, $paged;

				$output    = '';
				$paginated = max( absint( $page ), absint( $paged ) );

				$tag = trim( $tag );
				if ( $tag ) {
					$tag = array( '<' . tag_escape( $tag ) . '>', '</' . tag_escape( $tag ) . '>' );
				} else {
					$tag = array( '', '' );
				}


			// Processing

				if ( 1 < $paginated ) {
					$output = ' ' . $tag[0] . sprintf( esc_html_x( '(page %s)', 'Paginated content title suffix, %s: page number.', 'qtron' ), number_format_i18n( $paginated ) ) . $tag[1];
				}


			// Output

				return apply_filters( 'wmhook_wm_paginated_suffix_output', $output );

		}
	} // /wm_paginated_suffix



	/**
	 * Checks for <!--more--> tag in post content
	 *
	 * @since    4.0
	 * @version  1.8.0
	 *
	 * @param  obj/absint $post
	 */
	if ( ! function_exists( 'wm_has_more_tag' ) ) {
		function wm_has_more_tag( $post = null ) {

			// Helper variables

				$output = false;

				if ( empty( $post ) ) {
					$post = $GLOBALS['post'];
				} elseif ( is_numeric( $post ) ) {
					$post = get_post( $post );
				}


			// Requirements check

				if ( ! $post instanceof WP_Post ) {
					return;
				}


			// Processing

				if ( preg_match( '/<!--more(.*?)?-->/', $post->post_content, $matches ) ) {
					$output = true;
					if ( ! empty( $matches[1] ) ) {
						$output = strip_tags( wp_kses_no_null( trim( $matches[1] ) ) );
					}
				}


			// Output

				return $output;

		}
	} // /wm_has_more_tag





/**
 * 40) CSS functions
 */

	/**
	 * Outputs path to the specific file
	 *
	 * This function looks for the file in the child theme first.
	 * If the file is not located in child theme, output the path from parent theme.
	 *
	 * @since    3.1
	 * @version  3.1
	 *
	 * @param  string $file_relative_path File to look for (insert also the relative path inside the theme)
	 *
	 * @return  string Actual path to the file
	 */
	if ( ! function_exists( 'wm_get_stylesheet_directory' ) ) {
		function wm_get_stylesheet_directory( $file_relative_path ) {
			//Helper variables
				$output = '';

				$file_relative_path = trim( $file_relative_path );

			//Requirements chek
				if ( ! $file_relative_path ) {
					return apply_filters( 'wmhook_wm_get_stylesheet_directory_output', esc_url( $output ), $file_relative_path );
				}

			//Praparing output
				if ( file_exists( trailingslashit( get_stylesheet_directory() ) . $file_relative_path ) ) {
					$output = trailingslashit( get_stylesheet_directory() ) . $file_relative_path;
				} else {
					$output = trailingslashit( get_template_directory() ) . $file_relative_path;
				}

			//Output
				return apply_filters( 'wmhook_wm_get_stylesheet_directory_output', $output, $file_relative_path );
		}
	} // /wm_get_stylesheet_directory



	/**
	 * Outputs URL to the specific file
	 *
	 * This function looks for the file in the child theme first.
	 * If the file is not located in child theme, output the URL from parent theme.
	 *
	 * @since    3.0
	 * @version  3.0
	 *
	 * @param  string $file_relative_path File to look for (insert also the relative path inside the theme)
	 *
	 * @return  string Actual URL to the file
	 */
	if ( ! function_exists( 'wm_get_stylesheet_directory_uri' ) ) {
		function wm_get_stylesheet_directory_uri( $file_relative_path ) {
			//Helper variables
				$output = '';

				$file_relative_path = trim( $file_relative_path );

			//Requirements chek
				if ( ! $file_relative_path ) {
					return apply_filters( 'wmhook_wm_get_stylesheet_directory_uri_output', esc_url( $output ), $file_relative_path );
				}

			//Praparing output
				if ( file_exists( trailingslashit( get_stylesheet_directory() ) . $file_relative_path ) ) {
					$output = trailingslashit( get_stylesheet_directory_uri() ) . $file_relative_path;
				} else {
					$output = trailingslashit( get_template_directory_uri() ) . $file_relative_path;
				}

			//Output
				return apply_filters( 'wmhook_wm_get_stylesheet_directory_uri_output', esc_url( $output ), $file_relative_path );
		}
	} // /wm_get_stylesheet_directory_uri





/**
 * 100) Other functions
 */

	/**
	 * Check WordPress version
	 *
	 * @since    1.0
	 * @version  4.0
	 *
	 * @param  float $version
	 */
	if ( ! function_exists( 'wm_check_wp_version' ) ) {
		function wm_check_wp_version( $version = WM_WP_COMPATIBILITY ) {
			global $wp_version;

			return apply_filters( 'wmhook_wm_check_wp_version_output', version_compare( (float) $wp_version, $version, '>=' ), $version, $wp_version );
		}
	} // /wm_check_wp_version



	/**
	 * Do action on theme version change
	 *
	 * @since    4.0
	 * @version  4.0
	 * @version  1.9.0
	 */
	if ( ! function_exists( 'wm_theme_upgrade' ) ) {
		function wm_theme_upgrade() {

			// Variables

				$new_theme_version = WM_THEME_VERSION;
				$current_theme_version = get_transient( WM_THEME_SHORTNAME . '-version' );

			// Processing

				if (
					empty( $current_theme_version )
					|| $new_theme_version != $current_theme_version
				) {
					do_action( 'wmhook_theme_upgrade', $new_theme_version, $current_theme_version );
					set_transient( WM_THEME_SHORTNAME . '-version', $new_theme_version );
				}

		}
	} // /wm_theme_upgrade



	/**
	 * Remove shortcodes from string
	 *
	 * This function keeps the text between shortcodes,
	 * unlike WordPress native strip_shortcodes() function.
	 *
	 * @since    3.0
	 * @version  3.0
	 *
	 * @param  string $content
	 */
	if ( ! function_exists( 'wm_remove_shortcodes' ) ) {
		function wm_remove_shortcodes( $content ) {
			return apply_filters( 'wmhook_wm_remove_shortcodes_output', preg_replace( '|\[(.+?)\]|s', '', $content ) );
		}
	} // /wm_remove_shortcodes



	/**
	 * Accessibility skip links
	 *
	 * @since    3.0
	 * @version  4.0
	 *
	 * @param  string $type
	 */
	if ( ! function_exists( 'wm_accessibility_skip_link' ) ) {
		function wm_accessibility_skip_link( $type ) {
			//Helper variables
				$links = apply_filters( 'wmhook_wm_accessibility_skip_links', array(
					'to_content'    => '<a class="skip-link screen-reader-text" href="#content">' . __( 'Skip to content', 'qtron' ) . '</a>',
					'to_navigation' => '<a class="skip-link screen-reader-text" href="#site-navigation">' . __( 'Skip to navigation', 'qtron' ) . '</a>',
				) );

			//Output
				if ( ! isset( $links[ $type ] ) ) {
					return;
				}
				return apply_filters( 'wmhook_wm_accessibility_skip_link_output', $links[ $type ] );
		}
	} // /wm_accessibility_skip_link



	/**
	 * Get theme options and files
	 */

		/**
		 * Get the theme option
		 *
		 * Note: Do not use get_theme_mod() as it is not very transferable from "lite" to "pro" themes.
		 *
		 * @since    3.0
		 * @version  4.0
		 * @version  1.5
		 *
		 * @param  string $option_name Option name without WM_OPTION_PREFIX prefix
		 * @param  string $default     Default option value
		 * @param  string $css         CSS to output ["color" = HEX color, "bgimg" = background image styles]
		 * @param  string $suffix      Will be added to the value if the value is not empty
		 *
		 * @return  mixed Option value.
		 */
		if ( ! function_exists( 'wm_option' ) ) {
			function wm_option( $option_name = '', $default = '', $css = '', $suffix = '' ) {

				// Requirements check

					$option_name = trim( $option_name );

					if ( empty( $option_name ) ) {
						return false;
					}


				// Helper variables

					global $wm_theme_options, $wp_customize;

					$output = '';

					if ( ! isset( $wm_theme_options ) ) {
						$wm_theme_options = null;
					}

					$pre = apply_filters( 'wmhook_wm_option_pre_' . $option_name, false, $option_name, $default, $css, $suffix );
					if ( false !== $pre ) {
						return $pre;
					}

					// Alter $wm_theme_options only in Theme Customizer to provide live preview

						if (
								isset( $wp_customize )
								&& $wp_customize->is_preview()
							) {
							$wm_theme_options = (array) get_option( WM_OPTION_CUSTOMIZER );
						}


				// Processing

					$options     = ( $wm_theme_options ) ? ( $wm_theme_options ) : ( (array) get_option( WM_OPTION_CUSTOMIZER ) );
					$option_name = WM_OPTION_PREFIX . $option_name;

					if ( ! isset( $options[ $option_name ] ) ) {
						return $default;
					}

					// CSS output helper

						if ( 'bgimg' === $css ) {
							$output = 'url(\'' . esc_url( stripslashes( $options[ $option_name ] ) ) . '\')';
						} elseif ( 'color' === $css ) {
							$output = '#' . trim( stripslashes( $options[ $option_name ] ), '#' );
						} else {
							$output = ( is_array( $options[ $option_name ] ) ) ? ( $options[ $option_name ] ) : ( stripslashes( $options[ $option_name ] ) );
						}

					// Output suffix

						if ( is_string( $output ) && $output ) {
							$output .= (string) $suffix;
						}


				// Output

					return apply_filters( 'wmhook_wm_option_output', $output, $option_name, $default, $css, $suffix );

			}
		} // /wm_option



	/**
	 * Get image ID from its URL
	 *
	 * @since    3.0
	 * @version  4.0
	 *
	 * @link  http://pippinsplugins.com/retrieve-attachment-id-from-image-url/
	 * @link  http://make.wordpress.org/core/2012/12/12/php-warning-missing-argument-2-for-wpdb-prepare/
	 *
	 * @param  string $url
	 */
	if ( ! function_exists( 'wm_get_image_id_from_url' ) ) {
		function wm_get_image_id_from_url( $url ) {
			//Helper variables
				global $wpdb;

				$output = null;

				$cache = array_filter( (array) get_transient( 'wm-image-ids' ) );

			//Returne cached result if found and relevant
				if (
						! empty( $cache )
						&& isset( $cache[ $url ] )
						&& wp_get_attachment_url( absint( $cache[ $url ] ) )
						&& $url == wp_get_attachment_url( absint( $cache[ $url ] ) )
					) {
					return absint( apply_filters( 'wmhook_wm_get_image_id_from_url_output', $cache[ $url ] ) );
				}

			//Preparing output
				if (
						is_object( $wpdb )
						&& isset( $wpdb->prefix )
					) {
					$prefix     = $wpdb->prefix;
					$attachment = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM " . $prefix . "posts" . " WHERE guid = %s", esc_url( $url ) ) );
					$output     = ( isset( $attachment[0] ) ) ? ( $attachment[0] ) : ( null );
				}

				//Cache the new record
					$cache[ $url ] = $output;
					set_transient( 'wm-image-ids', array_filter( (array) $cache ) );

			//Output
				return absint( apply_filters( 'wmhook_wm_get_image_id_from_url_output', $output ) );
		}
	} // /wm_get_image_id_from_url



		/**
		 * Flush out the transients used in wm_get_image_id_from_url
		 *
		 * @since    4.0
		 * @version  4.0
		 */
		if ( ! function_exists( 'wm_image_ids_transient_flusher' ) ) {
			function wm_image_ids_transient_flusher() {
				delete_transient( 'wm-image-ids' );
			}
		} // /wm_image_ids_transient_flusher



	/**
	 * Returns true if a blog has more than 1 category
	 *
	 * @since    4.0
	 * @version  4.0
	 */
	if ( ! function_exists( 'wm_is_categorized_blog' ) ) {
		function wm_is_categorized_blog() {
			//Preparing output
				if ( false === ( $all_the_cool_cats = get_transient( 'wm-all-categories' ) ) ) {

					//Create an array of all the categories that are attached to posts
						$all_the_cool_cats = get_categories( array(
								'fields'     => 'ids',
								'hide_empty' => 1,
								'number'     => 2, //we only need to know if there is more than one category
							) );

					//Count the number of categories that are attached to the posts
						$all_the_cool_cats = count( $all_the_cool_cats );

					set_transient( 'wm-all-categories', $all_the_cool_cats );

				}

			//Output
				if ( $all_the_cool_cats > 1 ) {
					//This blog has more than 1 category
						return true;
				} else {
					//This blog has only 1 category
						return false;
				}
		}
	} // /wm_is_categorized_blog



		/**
		 * Flush out the transients used in wm_is_categorized_blog
		 *
		 * @since    4.0
		 * @version  4.0
		 */
		if ( ! function_exists( 'wm_all_categories_transient_flusher' ) ) {
			function wm_all_categories_transient_flusher() {
				if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
					return;
				}
				//Like, beat it. Dig?
				delete_transient( 'wm-all-categories' );
			}
		} // /wm_all_categories_transient_flusher



	/**
	 * Cache: Get transient key.
	 *
	 * @since    1.9.0
	 * @version  1.9.0
	 *
	 * @param  string $context
	 */
	if ( ! function_exists( 'wm_get_transient_key' ) ) {
		function wm_get_transient_key( $context = '' ) {

			// Output

				return 'qtron-' . sanitize_title( $context );

		}
	} // /wm_get_transient_key
