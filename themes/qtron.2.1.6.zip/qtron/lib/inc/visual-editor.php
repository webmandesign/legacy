<?php
/**
 * Visual editor addons
 *
 * @package     WebMan WordPress Theme Framework
 * @subpackage  Visual Editor
 * @copyright   2015 WebMan - Oliver Juhas
 *
 * @since    4.0
 * @version  4.0.1
 * @version  1.5
 *
 * CONTENT:
 * - 10) Actions and filters
 * - 20) Visual editor addons
 */





/**
 * 10) Actions and filters
 */

	/**
	 * Filters
	 */

		//Visual Editor addons
			add_filter( 'mce_buttons',          'wm_add_buttons_row1'  );
			add_filter( 'mce_buttons_2',        'wm_add_buttons_row2'  );
			add_filter( 'tiny_mce_before_init', 'wm_custom_mce_format' );





/**
 * 20) Visual editor addons
 */

	/**
	 * Add buttons to visual editor
	 *
	 * First row.
	 *
	 * @since    4.0
	 * @version  4.0
	 *
	 * @param  array $buttons
	 */
	if ( ! function_exists( 'wm_add_buttons_row1' ) ) {
		function wm_add_buttons_row1( $buttons ) {
			//Inserting buttons after "more" button
				$pos = array_search( 'wp_more', $buttons, true );
				if ( false !== $pos ) {
					$add     = array_slice( $buttons, 0, $pos + 1 );
					$add[]   = 'wp_page';
					$buttons = array_merge( $add, array_slice( $buttons, $pos + 1 ) );
				}

			//Output
				return $buttons;
		}
	} // /wm_add_buttons_row1



		/**
		 * Add buttons to visual editor
		 *
		 * Second row.
		 *
		 * @since    4.0
		 * @version  4.0.1
		 *
		 * @param  array $buttons
		 */
		if ( ! function_exists( 'wm_add_buttons_row2' ) ) {
			function wm_add_buttons_row2( $buttons ) {
				//Inserting buttons at the beginning of the row
					array_unshift( $buttons, 'styleselect' );

				//Output
					return $buttons;
			}
		} // /wm_add_buttons_row2



	/**
	 * Customizing format dropdown items
	 *
	 * @link  http://codex.wordpress.org/TinyMCE_Custom_Styles
	 *
	 * @since    4.0
	 * @version  4.0
	 *
	 * @param  array $init
	 */
	if ( ! function_exists( 'wm_custom_mce_format' ) ) {
		function wm_custom_mce_format( $init ) {
			//Preparing output
				//Merge old & new formats
					$init['style_formats_merge'] = true;

				//Add custom formats
					$init['style_formats'] = json_encode( apply_filters( 'wmhook_wm_custom_mce_format_style_formats', array(

							//Group: Quotes
								array(
									'title' => _x( 'Quotes', 'Visual editor blockquote formats group title.', 'qtron' ),
									'items' => array(

										array(
											'title' => __( 'Blockquote', 'qtron' ),
											'block' => 'blockquote',
										),
										array(
											'title'   => __( 'Pullquote - align left', 'qtron' ),
											'block'   => 'blockquote',
											'classes' => 'pullquote alignleft',
										),
										array(
											'title'   => __( 'Pullquote - align right', 'qtron' ),
											'block'   => 'blockquote',
											'classes' => 'pullquote alignright',
										),
										array(
											'title' => _x( 'Cite', 'Visual editor format label for HTML CITE tag used to set the blockquote source.', 'qtron' ),
											'block' => 'cite',
										),

									),
								),

							//Group: Text styles
								array(
									'title' => __( 'Text styles', 'qtron' ),
									'items' => array(

										array(
											'title'    => __( 'Uppercase heading or paragraph', 'qtron' ),
											'selector' => 'h1, h2, h3, h4, h5, h6, p',
											'classes'  => 'uppercase',
										),

										array(
											'title'  => __( 'Highlighted (marked) text', 'qtron' ),
											'inline' => 'mark',
										),

									),
								),

						) ) );

			//Output
				return apply_filters( 'wmhook_wm_custom_mce_format_output', $init );
		}
	} // /wm_custom_mce_format
