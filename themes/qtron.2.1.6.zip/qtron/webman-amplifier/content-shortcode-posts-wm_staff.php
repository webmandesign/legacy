<?php
/**
 * Posts shortcode item template
 *
 * Default wm_staff item template.
 *
 * Content:
 * - image
 * - title
 * - taxonomy:staff_position
 * - contacts
 * - content
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.9.0
 *
 * @uses  array $helper  Contains shortcode $atts array plus additional helper variables.
 */



$link_output = array( '', '' );

if ( $helper['link'] ) {
	/**
	 * HTML attributes are properly escaped in the plugin.
	 * @link  https://git.io/fpFih
	 */
	$link_output = array( '<a' . $helper['link'] . '>', '</a>' );
}
?>

<article class="<?php echo esc_attr( $helper['item_class'] ); ?>">

	<?php
	if ( has_post_thumbnail( $helper['post_id'] ) ) {
		echo '<div class="wm-posts-element wm-html-element image image-container">';

			echo $link_output[0]; // WPCS: XSS OK.

			the_post_thumbnail( $helper['image_size'], array( 'title' => esc_attr( get_the_title( get_post_thumbnail_id( $helper['post_id'] ) ) ) ) );

			echo $link_output[1]; // WPCS: XSS OK.

		echo '</div>';
	}
	?>

	<div class="wm-posts-element wm-html-element title"><?php
		echo '<' . tag_escape( $helper['atts']['heading_tag'] ) . '>';

			echo $link_output[0]; // WPCS: XSS OK.

			the_title();

			echo $link_output[1]; // WPCS: XSS OK.

		echo '</' . tag_escape( $helper['atts']['heading_tag'] ) . '>';
	?></div>

	<?php
		$terms       = get_the_terms( $helper['post_id'], 'staff_position' );
		$terms_array = array();
		if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			foreach( $terms as $term ) {
				$terms_array[] = '<span class="term term-' . sanitize_html_class( $term->slug ) . '">' . esc_html( $term->name ) . '</span>';
			}
			echo '<div class="wm-posts-element wm-html-element taxonomy">' . $link_output[0] . implode( ', ', $terms_array ) . $link_output[1] . '</div>';
		}
	?>

	<?php if ( $staff_bio = get_the_content() ) : ?>
	<div class="wm-posts-element wm-html-element content">
		<?php echo do_shortcode( wpautop( $staff_bio ) ); ?>
	</div>
	<?php endif; ?>

	<?php
		$staff_contacts = wma_meta_option( 'contacts', $helper['post_id'] );
		if ( $staff_contacts && is_array( $staff_contacts ) ) {
			$output_contacts = '';

			foreach ( $staff_contacts as $contact ) {
				if (
						! isset( $contact['icon'] )
						|| ! trim( $contact['icon'] )
					) {
					continue;
				}
				if ( ! isset( $contact['title'] ) ) {
					$contact['title'] = '';
				}
				if ( ! isset( $contact['link'] ) ) {
					$contact['link'] = '';
				}
				$title_attr = ( $contact['title'] ) ? ( ' title="' . esc_attr( strip_tags( $contact['title'] ) ) . '"' ) : ( '' );

				$output_contacts .= '<li class="contacts-item">';
				if ( $contact['link'] ) {
					$output_contacts .= '<a href="' . esc_url( $contact['link'] ) . '" class="' . esc_attr( $contact['icon'] ) . '"' . $title_attr . '><span class="screen-reader-text">' . $contact['title'] . '</span></a>';
				} else {
					$output_contacts .= '<span class="' . esc_attr( $contact['icon'] ) . '"' . $title_attr . '></span><span class="screen-reader-text">' . $contact['title'] . '</span>';
				}
				$output_contacts .= '</li>';
			}

			if ( $output_contacts ) {
				echo '<ul class="wm-posts-element wm-html-element contacts">' . wp_kses_post( $output_contacts ) . '</ul>';
			}
		}
	?>

</article>
