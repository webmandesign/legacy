<?php
/**
 * Posts shortcode item template
 *
 * Default wm_projects item template.
 *
 * Content:
 * - image
 * - title
 * - taxonomy:project_category
 * - excerpt
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.9.0
 *
 * @uses  array $helper  Contains shortcode $atts array plus additional helper variables.
 */

?>

<article class="<?php echo esc_attr( $helper['item_class'] ); ?>">

	<?php if ( has_post_thumbnail( $helper['post_id'] ) ) { ?>
		<div class="wm-posts-element wm-html-element image image-container">
			<?php
			if ( $helper['link'] ) {
				/**
				 * HTML attributes are properly escaped in the plugin.
				 * @link  https://git.io/fpFih
				 */
				echo '<a' . $helper['link'] . '>';
			}
			the_post_thumbnail( $helper['image_size'], array( 'title' => esc_attr( get_the_title( get_post_thumbnail_id( $helper['post_id'] ) ) ) ) );
			if ( $helper['link'] ) {
				echo '</a>';
			}
			?>
		</div>
	<?php } ?>

	<a<?php echo $helper['link']; /* WPCS: XSS OK. */ ?> class="wm-posts-elements-container">

		<div class="wm-posts-element wm-html-element title">
			<<?php echo tag_escape( $helper['atts']['heading_tag'] ); ?>>

				<?php the_title(); ?>

			</<?php echo tag_escape( $helper['atts']['heading_tag'] ); ?>>
		</div>

		<?php
			$terms       = get_the_terms( $helper['post_id'], 'project_category' );
			$terms_array = array();
			if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				foreach( $terms as $term ) {
					$terms_array[] = '<span class="term term-' . sanitize_html_class( $term->slug ) . '">' . esc_html( $term->name ) . '</span>';
				}
				echo '<div class="wm-posts-element wm-html-element taxonomy">' . implode( ', ', $terms_array ) . '</div>' ;
			}
		?>

		<?php
			if ( has_excerpt() ) {
				echo '<div class="wm-posts-element wm-html-element excerpt">' . wp_kses_post( get_the_excerpt() ) . '</div>';
			}
		?>

	</a>

</article>
