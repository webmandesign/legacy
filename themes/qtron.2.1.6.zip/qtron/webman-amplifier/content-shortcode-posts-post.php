<?php
/**
 * Posts shortcode item template
 *
 * Default post item template.
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.8.0
 *
 * @uses  array $helper  Contains shortcode $atts array plus additional helper variables.
 */

?>

<div class="<?php echo esc_attr( $helper['item_class'] ); ?>">

	<?php

	get_template_part( 'templates/parts/content', apply_filters( 'wmhook_shortcode_posts_content_type', get_post_format() ) );

	?>

</div>
