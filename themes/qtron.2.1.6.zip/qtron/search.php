<?php
/**
 * Search results template
 *
 * @package    Q'tron
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.5
 */



get_header();

	?>

	<section id="search-results" class="search-results">

		<?php get_template_part( 'templates/parts/loop', 'search' ); ?>

	</section>

	<?php

get_footer();
