=== Q'tron ===
Contributors: webmandesign
Requires at least: 4.8
Tested up to: 6.8
Requires PHP: 5.6
License: GPL-3.0-or-later
License URI: https://www.gnu.org/licenses/gpl-3.0-standalone.html

Q'tron is responsive, retina-ready business WordPress theme. You can create beautiful pages with help of a Beaver Builder page builder plugin.


== Description ==

Q'tron is responsive, retina-ready business WordPress theme. You can create beautiful pages with help of a Beaver Builder page builder plugin.


== Frequently Asked Questions ==

= Where can I find more information about the theme? =
For more information about the theme please visit https://www.webmandesign.eu/portfolio/qtron-wordpress-theme/

= Where can I preview demo website? =
Demo website can be found at https://themedemos.webmandesign.eu/qtron/

= Where can I find theme documentation? =
Please visit https://webmandesign.github.io/docs/qtron/

= Where can I get theme support? =
Please visit support forum at https://support.webmandesign.eu/


== Changelog ==

Please see `changelog.md` file.


== Copyright ==

* TGM-Plugin-Activation © 2012 Thomas Griffin, GPL v2 or later
* Normalize.css © Nicolas Gallagher and Jonathan Neal, MIT
* background-check.js © 2014 kennethcachia, MIT
* jquery.hoverdir.js © 2012 http://www.codrops.com, MIT
* slick.js © 2014 Ken Wheeler, MIT
* Genericons © Automattic, GPL v2 or later
* Ionicons © 2014 Drifty, MIT
* header.jpg © https://unsplash.com/, CC0
* screenshot.jpg images © https://unsplash.com/, CC0
