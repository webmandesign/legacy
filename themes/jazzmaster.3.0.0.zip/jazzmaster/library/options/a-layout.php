<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Layout
*****************************************************
*/

$prefix = 'layout-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "layout",
	"title" => __( 'Layout', 'jazzmaster_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "layout",
		"list" => array(
			__( 'Basics', 'jazzmaster_domain_panel' ),
			__( 'Header', 'jazzmaster_domain_panel' ),
			__( 'Breadcrums', 'jazzmaster_domain_panel' )
			)
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "layout-1",
		"title" => __( 'Basics', 'jazzmaster_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Main website layout', 'jazzmaster_domain_panel' ),
			"class" => "first"
		),
			array(
				"type" => "layouts",
				"id" => $prefix."boxed",
				"label" => __( 'Layout', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Choose the default website layout', 'jazzmaster_domain_panel' ),
				"options" => $websiteLayout,
				"default" => "fullwidth"
			),
			array(
				"type" => "select",
				"id" => $prefix."width",
				"label" => __( 'Website content', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sets the maximum website content width and responsiveness of the design', 'jazzmaster_domain_panel' ),
				"options" => array(
					'r930'  => __( 'Responsive 930px (1020px website box)', 'jazzmaster_domain_panel' ),
					'r1160' => __( 'Responsive 1160px (1280px website box)', 'jazzmaster_domain_panel' ),
					's930'  => __( 'Static 930px (1020px website box)', 'jazzmaster_domain_panel' ),
					's1160' => __( 'Static 1160px (1280px website box)', 'jazzmaster_domain_panel' ),
					),
				"default" => "r1160"
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Sidebar', 'jazzmaster_domain_panel' )
		),
			array(
				"type" => "select",
				"id" => $prefix."sidebar-width",
				"label" => __( 'Sidebar width', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sets the sidebar width (ratio against the website content width set above)', 'jazzmaster_domain_panel' ),
				"options" => array(
						" three pane" => __( 'Narrow sidebar (1/4)', 'jazzmaster_domain_panel' ),
						" four pane"  => __( 'Normal sidebar (1/3)', 'jazzmaster_domain_panel' ),
						" five pane"  => __( 'Wide sidebar (5/12)', 'jazzmaster_domain_panel' ),
					),
				"default" => " three pane"
			),
			array(
				"type" => "hr"
			),

		array(
			"type" => "heading3",
			"content" => __( 'Project page', 'jazzmaster_domain_panel' )
		),
			array(
				"type" => "checkbox",
				"id" => $prefix."no-related-projects",
				"label" => __( 'Disable related projects', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Globaly disables related projects displayed at the bottom of project pages', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "text",
				"id" => $prefix."related-projects-title",
				"label" => __( 'Related projects section title', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Customize the "Related projects" title if the section is enabled', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "hrtop"
			),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "layout-2",
		"title" => __( 'Header', 'jazzmaster_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Website header', 'jazzmaster_domain_panel' ),
			"class" => "first"
		),
			array(
				"type" => "slider",
				"id" => "design-header-height", //no prefix here to keep compatibility after moving from Design section to Layout
				"label" => __( 'Header height', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Set the header height (leave zero to use the default theme settings)', 'jazzmaster_domain_panel' ),
				"default" => 0,
				"min" => 0,
				"max" => 300,
				"step" => 5,
				"validate" => "int",
				"zero" => true
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."header-position",
				"label" => __( 'Stick header to the top', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sticks website header to the top of the website making it always visible', 'jazzmaster_domain_panel' ),
				"value" => " header-fixed"
			),
			array(
				"type" => "checkbox",
				"id" => "design-top-bar-fixed", //no prefix here to keep compatibility after moving from Design section to Layout
				"label" => __( 'Sticky top bar', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sticks the top bar to the top of the browser window even when scrolling', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "hr",
			),

			array(
				"type" => "select",
				"id" => $prefix."navigation-position",
				"label" => __( 'Navigation position', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Changes website header layout', 'jazzmaster_domain_panel' ),
				"options" => array(
					' nav-bottom' => __( 'Navigation bottom', 'jazzmaster_domain_panel' ),
					' nav-right'  => __( 'Navigation right', 'jazzmaster_domain_panel' ),
					' nav-top'    => __( 'Navigation top', 'jazzmaster_domain_panel' ),
					),
				"default" => " nav-right"
			),
			array(
				"type" => "slider",
				"id" => $prefix."navigation-margin",
				"label" => __( 'Navigation top padding', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sets the top padding size for navigation wrapper', 'jazzmaster_domain_panel' ),
				"default" => -1,
				"min" => -1,
				"max" => 100,
				"step" => 1,
				"validate" => "int",
				"zero" => true
			),
			array(
				"type" => "hr",
			),

			array(
				"type" => "textarea",
				"id" => $prefix."header-right",
				"label" => __( 'Right header area text', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Text in area right from logo in website header. You can use (C) to display &copy; sign, (R) for &reg;, (TM) for &trade;, YEAR for current year or SEARCH to display a search form.', 'jazzmaster_domain_panel' ),
				"default" => '<i class="icon-phone-sign"></i>&nbsp; +123 900 123 456 &nbsp;&nbsp;&nbsp;&nbsp; [social url="#" icon="Facebook" size="s" /][social url="#" icon="Twitter" size="s" /][social url="#" icon="Forrst" size="s" /][social url="#" icon="Dribbble" size="s" /][social url="#" icon="Vimeo" size="s" /][social url="#" icon="Google+" size="s" /][social url="#" icon="RSS" size="s" /]',
				"cols" => 60,
				"rows" => 10,
				"empty" => true
			),
			array(
				"type" => "slider",
				"id" => $prefix."header-right-margin",
				"label" => __( 'Right header area padding', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sets the top padding size for textarea in website header ("-1" sets the default theme value)', 'jazzmaster_domain_panel' ),
				"default" => -1,
				"min" => -1,
				"max" => 100,
				"step" => 1,
				"validate" => "int",
				"zero" => true
			),
			array(
				"type" => "hrtop"
			),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "layout-3",
		"title" => __( 'Breadcrumbs', 'jazzmaster_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Breadcrumbs navigation settings', 'jazzmaster_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "select",
			"id" => $prefix."breadcrumbs",
			"label" => __( 'Breadcrumbs position', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Select whether and where the breadcrumbs navigation should be displayed', 'jazzmaster_domain_panel' ),
			"options" => array(
					'none'   => __( 'No breadcrumbs', 'jazzmaster_domain_panel' ),
					'top'    => __( 'Top breadcrumbs', 'jazzmaster_domain_panel' ),
					'bottom' => __( 'Bottom breadcrumbs', 'jazzmaster_domain_panel' ),
					'both'   => __( 'Top and bottom breadcrumbs', 'jazzmaster_domain_panel' ),
					// 'stick'  => __( 'Sticky breadcrumbs', 'jazzmaster_domain_panel' )
				),
			"default" => "bottom"
		),
		array(
			"type" => "info",
			"content" => __( 'The above option allows you to disable breadcrumbs navigation altogether. However, it is recommended to keep the breadcrumbs displayed as it improves <attr title="Search Engine Optimization">SEO</attr>. Alternatively you can choose to disable breadcrumbs in specific website sections only (see the settings below) or on certain posts and pages (see the post/page settings).', 'jazzmaster_domain_panel' )
		),
		array(
			"type" => "space"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."breadcrumbs-archives",
			"label" => __( 'Disable breadcrumbs on archives', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Disables breadcrumbs navigation on all archive pages', 'jazzmaster_domain_panel' )
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."breadcrumbs-404",
			"label" => __( 'Disable breadcrumbs on Error 404 page', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Disables breadcrumbs navigation on Error 404 page', 'jazzmaster_domain_panel' )
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."breadcrumbs-animate-search",
			"label" => __( 'Animate search form in breadcrumbs area', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Shrinks search input field when not in focus', 'jazzmaster_domain_panel' ),
			"value" => " animated-form",
			"default" => " animated-form"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."breadcrumbs-no-search",
			"label" => __( 'Disable search form', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Hides search form in breadcrumbs bar', 'jazzmaster_domain_panel' )
		),
		array(
			"type" => "space"
		),
		array(
			"type" => "select",
			"id" => $prefix."breadcrumbs-portfolio-page",
			"label" => __( 'Portfolio page', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Select a main projects list page used as base for single project pages', 'jazzmaster_domain_panel' ),
			"options" => wm_pages(),
			"default" => ""
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>