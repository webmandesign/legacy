<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Sharing and feeds
*****************************************************
*/

$prefix = 'social-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "social",
	"title" => __( 'Sharing & feed', 'jazzmaster_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "social",
		"list" => array(
			__( 'Social sharing', 'jazzmaster_domain_panel' ),
			__( 'Feed', 'jazzmaster_domain_panel' )
			)
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "social-1",
		"title" => __( 'Social sharing', 'jazzmaster_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Social share buttons on posts and projects', 'jazzmaster_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-facebook",
			"label" => __( 'Facebook sharing', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Enables this sharing button', 'jazzmaster_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-twitter",
			"label" => __( 'Twitter sharing', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Enables this sharing button', 'jazzmaster_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-googleplus",
			"label" => __( 'Google+ sharing', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Enables this sharing button', 'jazzmaster_domain_panel' ),
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-pinterest",
			"label" => __( 'Pinterest sharing', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Enables this sharing button', 'jazzmaster_domain_panel' ),
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."share-no-projects",
			"label" => __( 'Disable on projects', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Disables sharing buttons on project pages', 'jazzmaster_domain_panel' ),
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "social-2",
		"title" => __( 'Feed', 'jazzmaster_domain_panel' )
	),
		array(
			"type" => "heading3",
			"content" => __( 'Set up custom feed links', 'jazzmaster_domain_panel' ),
			"class" => "first"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."no-auto-feed-link",
			"label" => __( 'Disable WordPress feed links', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Removes WordPress automatic feed links from website HTML head', 'jazzmaster_domain_panel' ),
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "additems",
			"id" => $prefix."feed-array",
			"label" => __( 'Custom feed links', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Press [+] button to add new custom feed link. Enter the type into the first field and full URL into the second one. Use predefined types such as "application/rss+xml" for RSS or "application/atom+xml" for Atom feed. Links will be placed into HTML head of the website.', 'jazzmaster_domain_panel' ),
			"default" => "",
			"field" => "attributes",
			"field-labels" => array( __( 'Type', 'jazzmaster_domain_adm' ), __( 'Feed URL', 'jazzmaster_domain_adm' ) )
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>