<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Blog
*****************************************************
*/

/**
 * @since    1.0
 * @version  3.0
 */



$prefix = 'blog-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "blog",
	"title" => __( 'Blog', 'jazzmaster_domain_panel' )
)

);

if ( ! wm_check_wp_version( '3.6' ) )
	array_push( $options,

		array(
			"type" => "sub-tabs",
			"parent-section-id" => "blog",
			"list" => array(
				__( 'Basics', 'jazzmaster_domain_panel' ),
				__( 'Post formats', 'jazzmaster_domain_panel' )
				)
		)

	);
if ( wm_check_wp_version( '3.6' ) )
	array_push( $options,

		array(
			"type" => "sub-tabs",
			"parent-section-id" => "blog",
			"list" => array(
				__( 'Basics', 'jazzmaster_domain_panel' )
				)
		)

	);

array_push( $options,

	array(
		"type" => "sub-section-open",
		"sub-section-id" => "blog-1",
		"title" => __( 'Basics', 'jazzmaster_domain_panel' )
	),
		array(
			"type" => "slider",
			"id" => $prefix."blog-excerpt-length",
			"label" => __( 'Excerpt length', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Sets the default blog list excerpt length in words', 'jazzmaster_domain_panel' ),
			"default" => 40,
			"min" => 10,
			"max" => 70,
			"step" => 1,
			"validate" => "absint"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."full-posts",
			"label" => __( '...or display full posts?', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Displays full posts on blog pages', 'jazzmaster_domain_panel' )
		),
		array(
			"type" => "hr"
		),

		array(
			"type" => "heading3",
			"content" => __( 'Blog entry meta information', 'jazzmaster_domain_panel' )
		),
			array(
				"type" => "paragraph",
				"content" => __( 'Choose the post meta information to display. By default all the information below are displayed.', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-featured-image",
				"label" => __( 'Disable featured image in a single post view', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides featured image when displaying single post. This can be disabled also per post basis.', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-author",
				"label" => __( 'Disable author name', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides post author name', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-date",
				"label" => __( 'Disable publish date', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides post publish date and time', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-cats",
				"label" => __( 'Disable categories', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides post categories links', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-tags",
				"label" => __( 'Disable tags', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides post tags list', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-comments-count",
				"label" => __( 'Disable comments count', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides post comments count link', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-format",
				"label" => __( 'Disable post format icon', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides post format icon', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "space"
			),
			array(
				"type" => "checkbox",
				"id" => $prefix."disable-bio",
				"label" => __( 'Disable author biography altogether', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Hides author information below all posts (otherwise the information is displayed, but only if author entered Biographical Info in his/her user profile). You can hide this information also on per post basis (see corresponding post settings).', 'jazzmaster_domain_panel' )
			),
			array(
				"type" => "hr"
			),

		/*
			array(
				"type" => "select",
				"id" => $prefix."archive-layout",
				"label" => __( 'Archive posts list layout', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sets the blog archive posts list (such as category page) layout', 'jazzmaster_domain_panel' ),
				"options" => array(
						""                   => __( 'Default', 'jazzmaster_domain_panel' ),
						" masonry-container" => __( 'Masonry', 'jazzmaster_domain_panel' ),
					),
				"default" => ""
			),
			array(
				"type" => "slider",
				"id" => $prefix."archive-masonry-size",
				"label" => __( 'Archive masonry layout columns', 'jazzmaster_domain_panel' ),
				"desc" => __( 'Sets the number of post columns for masonry blog archive (such as category page) layout', 'jazzmaster_domain_panel' ),
				"default" => 3,
				"min" => 2,
				"max" => 4,
				"step" => 1,
				"validate" => "absint"
			),
		*/
		array(
			"type" => "checkbox",
			"id" => $prefix."archive-no-sidebar",
			"label" => __( 'Disable sidebar on archive posts list', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Removes sidebar from archive posts list pages (such as category page)', 'jazzmaster_domain_panel' )
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	)

);

if ( ! wm_check_wp_version( '3.6' ) )
	array_push( $options,

		array(
			"type" => "sub-section-open",
			"sub-section-id" => "blog-2",
			"title" => __( 'Post formats', 'jazzmaster_domain_panel' )
		),
			array(
				"type" => "heading3",
				"content" => __( 'Disable unnecessary post formats', 'jazzmaster_domain_panel' ),
				"class" => "first"
			),
				array(
					"type" => "checkbox",
					"id" => $prefix."no-format-audio",
					"label" => __( 'Disable audio posts', 'jazzmaster_domain_panel' ),
					"desc" => __( 'Disables this post format', 'jazzmaster_domain_panel' )
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."no-format-gallery",
					"label" => __( 'Disable gallery posts', 'jazzmaster_domain_panel' ),
					"desc" => __( 'Disables this post format', 'jazzmaster_domain_panel' )
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."no-format-link",
					"label" => __( 'Disable link posts', 'jazzmaster_domain_panel' ),
					"desc" => __( 'Disables this post format', 'jazzmaster_domain_panel' )
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."no-format-quote",
					"label" => __( 'Disable quote posts', 'jazzmaster_domain_panel' ),
					"desc" => __( 'Disables this post format. However, keep in mind that Quote post format is used to populate the Testimonials shortcode.', 'jazzmaster_domain_panel' )
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."no-format-status",
					"label" => __( 'Disable status posts', 'jazzmaster_domain_panel' ),
					"desc" => __( 'Disables this post format', 'jazzmaster_domain_panel' )
				),
				array(
					"type" => "space"
				),
				array(
					"type" => "checkbox",
					"id" => $prefix."no-format-video",
					"label" => __( 'Disable video posts', 'jazzmaster_domain_panel' ),
					"desc" => __( 'Disables this post format', 'jazzmaster_domain_panel' )
				),
			array(
				"type" => "hrtop"
			),
		array(
			"type" => "sub-section-close"
		)

	);

array_push( $options,

array(
	"type" => "section-close"
)

);

?>