<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Options Panel - Error 404 page
*****************************************************
*/

$prefix = 'p404-';

array_push( $options,

array(
	"type" => "section-open",
	"section-id" => "p404",
	"title" => __( 'Error 404 page', 'jazzmaster_domain_panel' )
),

	array(
		"type" => "sub-tabs",
		"parent-section-id" => "p404",
		"list" => array(
			__( 'Error 404 page', 'jazzmaster_domain_panel' )
			)
	),



	array(
		"type" => "sub-section-open",
		"sub-section-id" => "p404-1",
		"title" => __( 'Error 404 page', 'jazzmaster_domain_panel' )
	),
		array(
			"type" => "text",
			"id" => $prefix."title",
			"label" => __( 'Page title', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Error 404 page title', 'jazzmaster_domain_panel' ),
			"default" => __( 'Web page was not found', 'jazzmaster_domain' )
		),
		array(
			"type" => "textarea",
			"id" => $prefix."text",
			"label" => __( 'Page text', 'jazzmaster_domain_panel' ),
			"desc" => __( 'You can use HTML tags', 'jazzmaster_domain_panel' ),
			"default" => "<h1>" . __( 'Oops', 'jazzmaster_domain' ) . "</h1>
<h2>" . __( 'The page you are looking for was moved, deleted or does not exist.', 'jazzmaster_domain' ) . "</h2>
<p>[button color=\"blue\" icon=\"icon-home\" size=\"xl\" url=\"" . home_url() . "\"]" . __( 'Return to homepage', 'jazzmaster_domain' ) . "[/button]</p>
",
			"cols" => 70,
			"rows" => 7,
			"empty" => true
		),
		array(
			"type" => "image",
			"id" => $prefix."image",
			"label" => __( 'Error 404 image', 'jazzmaster_domain_panel' ),
			"desc" => __( 'To upload a new image, press the [+] button and use the Media Uploader as you would be adding an image into post', 'jazzmaster_domain_panel' ),
			"default" => WM_ASSETS_THEME . "img/404.png",
			"validate" => "url"
		),
		array(
			"type" => "hr"
		),
		array(
			"type" => "checkbox",
			"id" => $prefix."no-above-footer-widgets",
			"label" => __( 'Disable widgets above footer', 'jazzmaster_domain_panel' ),
			"desc" => __( 'Disables Above Footer widgets area on Error 404 page', 'jazzmaster_domain_panel' ),
			"value" => "no"
		),
		array(
			"type" => "hrtop"
		),
	array(
		"type" => "sub-section-close"
	),

array(
	"type" => "section-close"
)

);

?>