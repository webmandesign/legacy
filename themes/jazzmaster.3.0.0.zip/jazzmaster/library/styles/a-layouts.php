<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Layouts
*****************************************************
*/

//Website layout
$websiteLayout = array(

	array(
		'name' => __( 'Full width layout', 'jazzmaster_domain_adm' ),
		'id'   => 'fullwidth',
		'desc' => __( 'Full width - website sections will spread across the whole browser window width', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-full-width.png'
	),

	array(
		'name' => __( 'Boxed layout', 'jazzmaster_domain_adm' ),
		'id'   => 'boxed',
		'desc' => __( 'Boxed - website sections will be contained in a centered box', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-boxed.png'
	),

);

$websiteLayoutEmpty = array(

	array(
		'name' => __( 'Default website layout', 'jazzmaster_domain_adm' ),
		'id'   => 'default',
		'desc' => __( 'Use default website layout', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-default.png'
	),

	array(
		'name' => __( 'Full width layout', 'jazzmaster_domain_adm' ),
		'id'   => 'fullwidth',
		'desc' => __( 'Full width - website sections will spread across the whole browser window width', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-full-width.png'
	),

	array(
		'name' => __( 'Boxed layout', 'jazzmaster_domain_adm' ),
		'id'   => 'boxed',
		'desc' => __( 'Boxed - website sections will be contained in a centered box', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-boxed.png'
	),

);



//Sidebar positions
$sidebarPosition = array(

	array(
		'name' => __( 'Default theme settings', 'jazzmaster_domain_adm' ),
		'id'   => '',
		'desc' => __( 'Use default theme position of the sidebar', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-default.png'
	),

	array(
		'name' => __( 'Sidebar right', 'jazzmaster_domain_adm' ),
		'id'   => 'right',
		'desc' => __( 'Sidebar is aligned right from the page/post content', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-sidebar-right.png'
	),

	array(
		'name' => __( 'Sidebar left', 'jazzmaster_domain_adm' ),
		'id'   => 'left',
		'desc' => __( 'Sidebar is aligned left from the page/post content', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-sidebar-left.png'
	),

	array(
		'name' => __( 'No sidebar, full width', 'jazzmaster_domain_adm' ),
		'id'   => 'none',
		'desc' => __( 'No sidebar is displayed, the page content takes the full width of the website', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-sidebar-none.png'
	)

);



//Project layouts
$projectLayouts = array(
	"1OPTGROUP"  => __( 'Media first', 'jazzmaster_domain_adm' ),
		"me-4"     => __( '3/4 media - 1/4 excerpt, content below', 'jazzmaster_domain_adm' ),
		"me-3"     => __( '2/3 media - 1/3 excerpt, content below', 'jazzmaster_domain_adm' ),
		"me-2"     => __( '1/2 media - 1/2 excerpt, content below', 'jazzmaster_domain_adm' ),
	"1/OPTGROUP" => "",

	"2OPTGROUP"  => __( 'Excerpt first', 'jazzmaster_domain_adm' ),
		"em-4"     => __( '1/4 excerpt - 3/4 media, content below', 'jazzmaster_domain_adm' ),
		"em-3"     => __( '1/3 excerpt - 2/3 media, content below', 'jazzmaster_domain_adm' ),
		"em-2"     => __( '1/2 excerpt - 1/2 media, content below', 'jazzmaster_domain_adm' ),
	"2/OPTGROUP" => "",

	"3OPTGROUP"  => __( 'Post layout', 'jazzmaster_domain_adm' ),
		"plain"    => __( 'Plain post (large media area, content)', 'jazzmaster_domain_adm' ),
	"3/OPTGROUP" => "",
);



//Portfolio layout
$portfolioLayout = array(

	array(
		'name' => __( 'Default theme settings', 'jazzmaster_domain_adm' ),
		'id'   => '',
		'desc' => __( 'Use default theme portfolio layout', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-default.png'
	),

	array(
		'name' => __( 'Two columns', 'jazzmaster_domain_adm' ),
		'id'   => '2',
		'desc' => __( 'Two columns preview with basic info', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-2.png'
	),

	array(
		'name' => __( 'Three columns', 'jazzmaster_domain_adm' ),
		'id'   => '3',
		'desc' => __( 'Three columns preview with basic info', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-3.png'
	),

	array(
		'name' => __( 'Four columns', 'jazzmaster_domain_adm' ),
		'id'   => '4',
		'desc' => __( 'Four columns preview with basic info', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-4.png'
	),

	array(
		'name' => __( 'One column', 'jazzmaster_domain_adm' ),
		'id'   => '5',
		'desc' => __( 'Large preview and item description', 'jazzmaster_domain_adm' ),
		'img'  => WM_ASSETS_ADMIN . 'img/layouts/layout-portfolio-columns-5.png'
	),

);

?>