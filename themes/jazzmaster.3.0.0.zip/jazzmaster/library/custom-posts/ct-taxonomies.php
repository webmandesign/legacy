<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Custom taxonomies for custom posts
*
* CONTENT:
* - 1) Actions and filters
* - 2) Taxonomies function
*****************************************************
*/





/*
*****************************************************
*      1) ACTIONS AND FILTERS
*****************************************************
*/
	//ACTIONS
		//Registering taxonomies
		add_action( 'init', 'wm_create_taxonomies', 0 );
		/*
		The init action occurs after the theme's functions file has been included, so if you're looking for terms directly in the functions file, you're doing so before they've actually been registered.
		*/





/*
*****************************************************
*      2) TAXONOMIES FUNCTION
*****************************************************
*/
	/*
	* Custom taxonomies registration
	*/
	if ( ! function_exists( 'wm_create_taxonomies' ) ) {
		function wm_create_taxonomies() {
			$slugProjectCategory = ( wm_option( 'general-permalink-project-category' ) ) ? ( wm_option( 'general-permalink-project-category' ) ) : ( 'project/category' );
			$slugStaffDepartment = ( wm_option( 'general-permalink-staff-department' ) ) ? ( wm_option( 'general-permalink-staff-department' ) ) : ( 'staff/department' );

			//Projects categories
			if ( 'disable' != wm_option( 'general-role-projects' ) )
				register_taxonomy( 'project-category', 'wm_projects', array(
					'hierarchical'      => true,
					'show_in_nav_menus' => false,
					'show_ui'           => true,
					'query_var'         => 'project-category',
					'rewrite'           => array( 'slug' => $slugProjectCategory ),
					'labels'            => array(
						'name'          => __( 'Project categories', 'jazzmaster_domain_adm' ),
						'singular_name' => __( 'Project category', 'jazzmaster_domain_adm' ),
						'search_items'  => __( 'Search categories', 'jazzmaster_domain_adm' ),
						'all_items'     => __( 'All categories', 'jazzmaster_domain_adm' ),
						'parent_item'   => __( 'Parent category', 'jazzmaster_domain_adm' ),
						'edit_item'     => __( 'Edit category', 'jazzmaster_domain_adm' ),
						'update_item'   => __( 'Update category', 'jazzmaster_domain_adm' ),
						'add_new_item'  => __( 'Add new category', 'jazzmaster_domain_adm' ),
						'new_item_name' => __( 'New category title', 'jazzmaster_domain_adm' )
					)
				) );

			//Staff departments
			if ( 'disable' != wm_option( 'general-role-staff' ) )
				register_taxonomy( 'department', 'wm_staff', array(
					'hierarchical'      => true,
					'show_in_nav_menus' => false,
					'show_ui'           => true,
					'query_var'         => 'department',
					'rewrite'           => array( 'slug' => $slugStaffDepartment ),
					'labels'            => array(
						'name'          => __( 'Departments', 'jazzmaster_domain_adm' ),
						'singular_name' => __( 'Department', 'jazzmaster_domain_adm' ),
						'search_items'  => __( 'Search departments', 'jazzmaster_domain_adm' ),
						'all_items'     => __( 'All departments', 'jazzmaster_domain_adm' ),
						'parent_item'   => __( 'Parent department', 'jazzmaster_domain_adm' ),
						'edit_item'     => __( 'Edit department', 'jazzmaster_domain_adm' ),
						'update_item'   => __( 'Update department', 'jazzmaster_domain_adm' ),
						'add_new_item'  => __( 'Add new department', 'jazzmaster_domain_adm' ),
						'new_item_name' => __( 'New department title', 'jazzmaster_domain_adm' )
					)
				) );

			//Price tables
			if ( 'disable' != wm_option( 'general-role-prices' ) )
				register_taxonomy( 'price-table', 'wm_price', array(
					'hierarchical'      => true,
					'show_in_nav_menus' => false,
					'show_ui'           => true,
					'query_var'         => 'price-table',
					'rewrite'           => array( 'slug' => 'price-table' ),
					'labels'            => array(
						'name'          => __( 'Price tables', 'jazzmaster_domain_adm' ),
						'singular_name' => __( 'Price table', 'jazzmaster_domain_adm' ),
						'search_items'  => __( 'Search price table', 'jazzmaster_domain_adm' ),
						'all_items'     => __( 'All price tables', 'jazzmaster_domain_adm' ),
						'parent_item'   => __( 'Parent price table', 'jazzmaster_domain_adm' ),
						'edit_item'     => __( 'Edit price table', 'jazzmaster_domain_adm' ),
						'update_item'   => __( 'Update price table', 'jazzmaster_domain_adm' ),
						'add_new_item'  => __( 'Add new price table', 'jazzmaster_domain_adm' ),
						'new_item_name' => __( 'New price table title', 'jazzmaster_domain_adm' )
					)
				) );

			//FAQ categories
			if ( 'disable' != wm_option( 'general-role-faq' ) )
				register_taxonomy( 'faq-category', 'wm_faq', array(
					'hierarchical'      => true,
					'show_in_nav_menus' => false,
					'show_ui'           => true,
					'query_var'         => 'faq-category',
					'rewrite'           => array( 'slug' => 'faq-category' ),
					'labels'            => array(
						'name'          => __( 'FAQ categories', 'jazzmaster_domain_adm' ),
						'singular_name' => __( 'FAQ category', 'jazzmaster_domain_adm' ),
						'search_items'  => __( 'Search FAQ category', 'jazzmaster_domain_adm' ),
						'all_items'     => __( 'All FAQ categories', 'jazzmaster_domain_adm' ),
						'parent_item'   => __( 'Parent FAQ category', 'jazzmaster_domain_adm' ),
						'edit_item'     => __( 'Edit FAQ category', 'jazzmaster_domain_adm' ),
						'update_item'   => __( 'Update FAQ category', 'jazzmaster_domain_adm' ),
						'add_new_item'  => __( 'Add new FAQ category', 'jazzmaster_domain_adm' ),
						'new_item_name' => __( 'New FAQ category title', 'jazzmaster_domain_adm' )
					)
				) );

			//Logos categories
			if ( 'disable' != wm_option( 'general-role-logos' ) )
				register_taxonomy( 'logos-category', 'wm_logos', array(
					'hierarchical'      => true,
					'show_in_nav_menus' => false,
					'show_ui'           => true,
					'query_var'         => 'logos-category',
					'rewrite'           => array( 'slug' => 'logo-category' ),
					'labels'            => array(
						'name'          => __( 'Categories', 'jazzmaster_domain_adm' ),
						'singular_name' => __( 'Category', 'jazzmaster_domain_adm' ),
						'search_items'  => __( 'Search category', 'jazzmaster_domain_adm' ),
						'all_items'     => __( 'All categories', 'jazzmaster_domain_adm' ),
						'parent_item'   => __( 'Parent category', 'jazzmaster_domain_adm' ),
						'edit_item'     => __( 'Edit category', 'jazzmaster_domain_adm' ),
						'update_item'   => __( 'Update category', 'jazzmaster_domain_adm' ),
						'add_new_item'  => __( 'Add new category', 'jazzmaster_domain_adm' ),
						'new_item_name' => __( 'New category title', 'jazzmaster_domain_adm' )
					)
				) );

			//Slides categories
			register_taxonomy( 'slide-category', 'wm_slides', array(
				'hierarchical'      => true,
				'show_in_nav_menus' => false,
				'show_ui'           => true,
				'query_var'         => 'slide-category',
				'rewrite'           => array( 'slug' => 'slide-group' ),
				'labels'            => array(
					'name'          => __( 'Slide groups', 'jazzmaster_domain_adm' ),
					'singular_name' => __( 'Slide group', 'jazzmaster_domain_adm' ),
					'search_items'  => __( 'Search groups', 'jazzmaster_domain_adm' ),
					'all_items'     => __( 'All groups', 'jazzmaster_domain_adm' ),
					'parent_item'   => __( 'Parent group', 'jazzmaster_domain_adm' ),
					'edit_item'     => __( 'Edit group', 'jazzmaster_domain_adm' ),
					'update_item'   => __( 'Update group', 'jazzmaster_domain_adm' ),
					'add_new_item'  => __( 'Add new group', 'jazzmaster_domain_adm' ),
					'new_item_name' => __( 'New group title', 'jazzmaster_domain_adm' )
				)
			) );

			//Content module tags
			register_taxonomy( 'content-module-tag', 'wm_modules', array(
				'hierarchical'      => false,
				'show_in_nav_menus' => false,
				'show_ui'           => true,
				'query_var'         => 'cmtag',
				'rewrite'           => array( 'slug' => 'cmtag' ),
				'labels'            => array(
					'name'          => __( 'Tags', 'jazzmaster_domain_adm' ),
					'singular_name' => __( 'Tag', 'jazzmaster_domain_adm' ),
					'search_items'  => __( 'Search tags', 'jazzmaster_domain_adm' ),
					'all_items'     => __( 'All tags', 'jazzmaster_domain_adm' ),
					'edit_item'     => __( 'Edit tag', 'jazzmaster_domain_adm' ),
					'update_item'   => __( 'Update tag', 'jazzmaster_domain_adm' ),
					'add_new_item'  => __( 'Add new tag', 'jazzmaster_domain_adm' ),
					'new_item_name' => __( 'New tag title', 'jazzmaster_domain_adm' )
				)
			) );
		}
	} // /wm_create_taxonomies

?>