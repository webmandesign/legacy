<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* WebMan Shortcodes Generator
*
* CONTENT:
* - 1) Actions and filters
* - 2) Assets needed
* - 3) TinyMCE button registration
* - 4) Shortcodes array
* - 5) Shortcode generator HTML
*****************************************************
*/





/*
*****************************************************
*      1) ACTIONS AND FILTERS
*****************************************************
*/
	//ACTIONS
		$wmGeneratorIncludes = array( 'post.php', 'post-new.php' );
		if ( in_array( $pagenow, $wmGeneratorIncludes ) ) {
			add_action( 'admin_enqueue_scripts', 'wm_mce_assets', 1000 );
			add_action( 'init', 'wm_shortcode_generator_button' );
			add_action( 'admin_footer', 'wm_add_generator_popup', 1000 );
		}





/*
*****************************************************
*      2) ASSETS NEEDED
*****************************************************
*/
	/*
	* Assets files
	*/
	if ( ! function_exists( 'wm_mce_assets' ) ) {
		function wm_mce_assets() {
			global $pagenow;

			$wmGeneratorIncludes = array( 'post.php', 'post-new.php' );

			if ( in_array( $pagenow, $wmGeneratorIncludes ) ) {

				//WP3.9+ required
					if ( wm_check_wp_version( '3.9' ) ) {
						wp_enqueue_style( 'wp-jquery-ui-dialog' );
						wp_enqueue_script( 'wpdialogs' );
					}

				//styles
				wp_enqueue_style( 'wm-buttons' );

				//scripts
				wp_enqueue_script( 'wm-shortcodes' );
			}
		}
	} // /wm_mce_assets





/*
*****************************************************
*      3) TINYMCE BUTTON REGISTRATION
*****************************************************
*/
	/*
	* Register visual editor custom button position
	*/
	if ( ! function_exists( 'wm_register_tinymce_buttons' ) ) {
		function wm_register_tinymce_buttons( $buttons ) {
			$wmButtons = array( '|', 'wm_mce_button_line_above', 'wm_mce_button_line_below', '|', 'wm_mce_button_shortcodes' );

			array_push( $buttons, implode( ',', $wmButtons ) );

			return $buttons;
		}
	} // /wm_register_tinymce_buttons



	/*
	* Register the button functionality script
	*/
	if ( ! function_exists( 'wm_add_tinymce_plugin' ) ) {
		function wm_add_tinymce_plugin( $plugin_array ) {
			$plugin_array['wm_mce_button'] = WM_ASSETS_ADMIN . 'js/shortcodes/wm-mce-button.js?ver=' . WM_SCRIPTS_VERSION;

			return $plugin_array;
		}
	} // /wm_add_tinymce_plugin



	/*
	* Adding the button to visual editor
	*/
	if ( ! function_exists( 'wm_shortcode_generator_button' ) ) {
		function wm_shortcode_generator_button() {
			if ( ! ( current_user_can( 'edit_posts' ) || current_user_can( 'edit_pages' ) ) )
				return;

			if ( 'true' == get_user_option( 'rich_editing' ) ) {
				//filter the tinymce buttons and add custom ones
				add_filter( 'mce_external_plugins', 'wm_add_tinymce_plugin' );
				add_filter( 'mce_buttons_2', 'wm_register_tinymce_buttons' );
			}
		}
	} // /wm_shortcode_generator_button





/*
*****************************************************
*      4) SHORTCODES ARRAY
*****************************************************
*/
	/*
	* Shortcodes settings for Shortcode Generator
	*/
	if ( ! function_exists( 'wm_shortcode_generator_tabs' ) ) {
		function wm_shortcode_generator_tabs() {
			global $socialIconsArray, $fontIcons;

			$socialIcons = array();
			foreach ( $socialIconsArray as $network ) {
				$socialIcons[$network] = $network;
			}

			//Get Content Module posts
			$wm_modules_posts = get_posts( array(
				'post_type'   => 'wm_modules',
				'order'       => 'ASC',
				'orderby'     => 'title',
				'numberposts' => -1,
				) );
			$modulePosts = array( '' => '' );
			foreach ( $wm_modules_posts as $post ) {
				$modulePosts[$post->post_name] = $post->post_title;

				$terms = get_the_terms( $post->ID , 'content-module-tag' );
				if ( $terms ) {
					$moduleTags = array();
					foreach ( $terms as $term ) {
						if ( isset( $term->name ) )
							$moduleTags[] = $term->name;
					}
					$modulePosts[$post->post_name] .= sprintf( __( ' (tags: %s)', 'jazzmaster_domain_adm' ), implode( ', ', $moduleTags ) );
				}
			}

			//Get icons
			$menuIcons = array();
			$menuIconsEmpty = array( '' => '' );
			foreach ( $fontIcons as $icon ) {
				$menuIcons[$icon] = ucwords( str_replace( '-', ' ', substr( $icon, 4 ) ) );
			}

			$wmShortcodeGeneratorTabs = array(

				//Accordion
					array(
						'id' => 'accordion',
						'name' => __( 'Accordion', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Please, copy the <code>[accordion_item title=""][/accordion_item]</code> sub-shortcode as many times as you need. But keep them wrapped in <code>[accordion][/accordion]</code> parent shortcode.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'auto' => array(
								'label' => __( 'Automatic accordion', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select whether the accordion should automatically animate. You can also set the automatic animation speed in miliseconds if you set a number greater than 1000 for this attribute.', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[accordion{{auto}}] [accordion_item title="TEXT"]TEXT[/accordion_item] [/accordion]'
					),

				//Audio
					array(
						'id' => 'audio',
						'name' => __( 'Audio', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Use syntax of <a href="http://codex.wordpress.org/Audio_Shortcode" target="_blank">WordPress Audio shortcode</a>.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'src' => array(
								'label' => __( 'MP3 file URL', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Insert MP3 file URL address', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'album_art' => array(
								'label' => __( 'Album art', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Insert image file URL address', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							),
						'output-shortcode' => '[audio{{src}} /]'
					),

				//Box
					array(
						'id' => 'box',
						'name' => __( 'Box', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'color' => array(
								'label' => __( 'Color', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose box color', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'blue'   => __( 'Blue', 'jazzmaster_domain_adm' ),
									'gray'   => __( 'Gray', 'jazzmaster_domain_adm' ),
									'green'  => __( 'Green', 'jazzmaster_domain_adm' ),
									'orange' => __( 'Orange', 'jazzmaster_domain_adm' ),
									'red'    => __( 'Red', 'jazzmaster_domain_adm' ),
									)
								),
							'icon' => array(
								'label' => __( 'Icon', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose an icon for this box', 'jazzmaster_domain_adm' ),
								'value' => array(
									''         => __( 'No icon', 'jazzmaster_domain_adm' ),
									'cancel'   => __( 'Cancel icon', 'jazzmaster_domain_adm' ),
									'check'    => __( 'Check icon', 'jazzmaster_domain_adm' ),
									'info'     => __( 'Info icon', 'jazzmaster_domain_adm' ),
									'question' => __( 'Question icon', 'jazzmaster_domain_adm' ),
									'warning'  => __( 'Warning icon', 'jazzmaster_domain_adm' ),
									)
								),
							'title' => array(
								'label' => __( 'Optional title', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional box title', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'transparent' => array(
								'label' => __( 'Opacity', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Whether box background is colored or not', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Opaque', 'jazzmaster_domain_adm' ),
									'1' => __( 'Transparent', 'jazzmaster_domain_adm' ),
									)
								),
							'hero' => array(
								'label' => __( 'Hero box', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Specially styled hero box', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Normal box', 'jazzmaster_domain_adm' ),
									'1' => __( 'Hero box', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[box{{color}}{{title}}{{icon}}{{transparent}}{{hero}}]TEXT[/box]'
					),

				//Big text
					array(
						'id' => 'big_text',
						'name' => __( 'Big text', 'jazzmaster_domain_adm' ),
						'desc' => __( 'This shortcode has no settings.', 'jazzmaster_domain_adm' ),
						'settings' => array(),
						'output-shortcode' => '[big_text]TEXT[/big_text]'
					),

				//Button
					array(
						'id' => 'button',
						'name' => __( 'Button', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'url' => array(
								'label' => __( 'Link URL', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Button link URL address', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'color' => array(
								'label' => __( 'Color', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose button color', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'blue'   => __( 'Blue', 'jazzmaster_domain_adm' ),
									'gray'   => __( 'Gray', 'jazzmaster_domain_adm' ),
									'green'  => __( 'Green', 'jazzmaster_domain_adm' ),
									'orange' => __( 'Orange', 'jazzmaster_domain_adm' ),
									'red'    => __( 'Red', 'jazzmaster_domain_adm' ),
									)
								),
							'size' => array(
								'label' => __( 'Size', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Button size', 'jazzmaster_domain_adm' ),
								'value' => array(
									'm'  => __( 'Medium', 'jazzmaster_domain_adm' ),
									's'  => __( 'Small', 'jazzmaster_domain_adm' ),
									'l'  => __( 'Large', 'jazzmaster_domain_adm' ),
									'xl' => __( 'Extra large', 'jazzmaster_domain_adm' ),
									)
								),
							'align' => array(
								'label' => __( 'Align', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''      => '',
									'left'  => __( 'Left', 'jazzmaster_domain_adm' ),
									'right' => __( 'Right', 'jazzmaster_domain_adm' ),
									)
								),
							'new_window' => array(
								'label' => __( 'New window', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Open URL address in new window when button clicked', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							'icon' => array(
								'label' => __( 'Icon image', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select optional button icon image', 'jazzmaster_domain_adm' ),
								'value' => array_merge( $menuIconsEmpty, $menuIcons ),
								'image-before' => true,
								),
							'text_color' => array(
								'label'     => __( 'Text color', 'jazzmaster_domain_adm' ),
								'desc'      => __( 'Custom text color. Use hexadecimal color code without "#".', 'jazzmaster_domain_adm' ),
								'value'     => '',
								'maxlength' => 6
								),
							'background_color' => array(
								'label'     => __( 'Background color', 'jazzmaster_domain_adm' ),
								'desc'      => __( 'Custom background color. Use hexadecimal color code without "#".', 'jazzmaster_domain_adm' ),
								'value'     => '',
								'maxlength' => 6
								),
							),
						'output-shortcode' => '[button{{url}}{{color}}{{size}}{{text_color}}{{background_color}}{{align}}{{new_window}}{{icon}}]TEXT[/button]'
					),

				//Call to action
					array(
						'id' => 'cta',
						'name' => __( 'Call to action', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'title' => array(
								'label' => __( 'Optional title', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional call to action title', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'subtitle' => array(
								'label' => __( 'Optional subtitle', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional call to action subtitle', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'button_url' => array(
								'label' => __( 'Button URL', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Button link URL address', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'button_text' => array(
								'label' => __( 'Button text', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Button text', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'button_color' => array(
								'label' => __( 'Button color', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose button color', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'blue'   => __( 'Blue', 'jazzmaster_domain_adm' ),
									'gray'   => __( 'Gray', 'jazzmaster_domain_adm' ),
									'green'  => __( 'Green', 'jazzmaster_domain_adm' ),
									'orange' => __( 'Orange', 'jazzmaster_domain_adm' ),
									'red'    => __( 'Red', 'jazzmaster_domain_adm' ),
									)
								),
							'new_window' => array(
								'label' => __( 'New window', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Open URL address in new window when button clicked', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							'color' => array(
								'label' => __( 'Area color', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose call to action area color', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Transparent', 'jazzmaster_domain_adm' ),
									'blue'   => __( 'Blue', 'jazzmaster_domain_adm' ),
									'gray'   => __( 'Gray', 'jazzmaster_domain_adm' ),
									'green'  => __( 'Green', 'jazzmaster_domain_adm' ),
									'orange' => __( 'Orange', 'jazzmaster_domain_adm' ),
									'red'    => __( 'Red', 'jazzmaster_domain_adm' ),
									)
								),
							'background_pattern' => array(
								'label' => __( 'Background pattern', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Call to action background pattern', 'jazzmaster_domain_adm' ),
								'value' => array(
									''              => '',
									'stripes-dark'  => __( 'Dark stripes', 'jazzmaster_domain_adm' ),
									'stripes-light' => __( 'Light stripes', 'jazzmaster_domain_adm' ),
									'squares'       => __( 'Squares', 'jazzmaster_domain_adm' ),
									'checker'       => __( 'Checker', 'jazzmaster_domain_adm' ),
									'dots'          => __( 'Dots', 'jazzmaster_domain_adm' ),
									'http://URL'    => __( 'Custom image URL address', 'jazzmaster_domain_adm' ),
									)
								),
							'text_color' => array(
								'label'     => __( 'Text color', 'jazzmaster_domain_adm' ),
								'desc'      => __( 'Custom text color. Use hexadecimal color code without "#".', 'jazzmaster_domain_adm' ),
								'value'     => '',
								'maxlength' => 6
								),
							'background_color' => array(
								'label'     => __( 'Background color', 'jazzmaster_domain_adm' ),
								'desc'      => __( 'Custom background color. Use hexadecimal color code without "#".', 'jazzmaster_domain_adm' ),
								'value'     => '',
								'maxlength' => 6
								),
							),
						'output-shortcode' => '[call_to_action{{title}}{{subtitle}}{{button_text}}{{button_url}}{{button_color}}{{new_window}}{{color}}{{background_color}}{{text_color}}{{background_pattern}}]TEXT[/call_to_action]'
					),

				//Columns
					array(
						'id' => 'columns',
						'name' => __( 'Columns', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'size' => array(
								'label' => __( 'Column size', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select column size', 'jazzmaster_domain_adm' ),
								'value' => array(
									'1OPTGROUP'   =>  __( 'Halfs', 'jazzmaster_domain_adm' ),
										'1/2'      => '1/2',
										'1/2 last' => '1/2' . __( ' last in row', 'jazzmaster_domain_adm' ),
									'1/OPTGROUP'  => '',
									'2OPTGROUP'   =>  __( 'Thirds', 'jazzmaster_domain_adm' ),
										'1/3'      => '1/3',
										'1/3 last' => '1/3' . __( ' last in row', 'jazzmaster_domain_adm' ),
										'2/3'      => '2/3',
										'2/3 last' => '2/3' . __( ' last in row', 'jazzmaster_domain_adm' ),
									'2/OPTGROUP'  => '',
									'3OPTGROUP'   =>  __( 'Quarters', 'jazzmaster_domain_adm' ),
										'1/4'      => '1/4',
										'1/4 last' => '1/4' . __( ' last in row', 'jazzmaster_domain_adm' ),
										'3/4'      => '3/4',
										'3/4 last' => '3/4' . __( ' last in row', 'jazzmaster_domain_adm' ),
									'3/OPTGROUP'  => '',
									'4OPTGROUP'   =>  __( 'Fifths', 'jazzmaster_domain_adm' ),
										'1/5'      => '1/5',
										'1/5 last' => '1/5' . __( ' last in row', 'jazzmaster_domain_adm' ),
										'2/5'      => '2/5',
										'2/5 last' => '2/5' . __( ' last in row', 'jazzmaster_domain_adm' ),
										'3/5'      => '3/5',
										'3/5 last' => '3/5' . __( ' last in row', 'jazzmaster_domain_adm' ),
										'4/5'      => '4/5',
										'4/5 last' => '4/5' . __( ' last in row', 'jazzmaster_domain_adm' ),
									'4/OPTGROUP'  => '',
									'5OPTGROUP'   =>  __( 'Sixths', 'jazzmaster_domain_adm' ),
										'1/6'      => '1/6',
										'1/6 last' => '1/6' . __( ' last in row', 'jazzmaster_domain_adm' ),
										'5/6'      => '5/6',
										'5/6 last' => '5/6' . __( ' last in row', 'jazzmaster_domain_adm' ),
									'5/OPTGROUP'  => '',
									)
								),
							'class' => array(
								'label' => __( 'Custom CSS class', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Insert optional custom CSS class', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							),
						'output-shortcode' => '[column{{size}}{{class}}]TEXT[/column]'
					),

				//Content Modules
					array(
						'id' => 'content_module',
						'name' => __( 'Content Module', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'id' => array(
								'label' => __( 'Content Module', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select Content Module to display', 'jazzmaster_domain_adm' ),
								'value' => $modulePosts
								),
							'randomize' => array(
								'label' => __( 'Or randomize from', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a tag from where random content module will be chosen', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array(
										'allCountPost' => '',
										'allText'      => __( 'Select tag', 'jazzmaster_domain_adm' ),
										'hierarchical' => '0',
										'tax'          => 'content-module-tag',
									) )
								),
							'no_thumb' => array(
								'label' => __( 'Thumb', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select whether you want the thumbnail image to be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Show', 'jazzmaster_domain_adm' ),
									'1' => __( 'Hide', 'jazzmaster_domain_adm' )
									)
								),
							'no_title' => array(
								'label' => __( 'Title', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select whether you want the module title to be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Show', 'jazzmaster_domain_adm' ),
									'1' => __( 'Hide', 'jazzmaster_domain_adm' )
									)
								),
							'layout' => array(
								'label' => __( 'Layout', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose which layout to use', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'center' => __( 'Centered', 'jazzmaster_domain_adm' )
									)
								),
							),
						'output-shortcode' => '[content_module{{id}}{{randomize}}{{no_thumb}}{{no_title}}{{layout}} /]'
					),

				//Countdown timer
					array(
						'id' => 'countdown',
						'name' => __( 'Countdown timer', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'time' => array(
								'label' => __( 'Time <small>YYYY-MM-DD HH:mm</small>', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Insert the time in "YYYY-MM-DD HH:mm" format (Y = year, M = month, D = day, H = hours, m = minutes)', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'size' => array(
								'label' => __( 'Timer size', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select timer size', 'jazzmaster_domain_adm' ),
								'value' => array(
									'xl' => __( 'Extra large', 'jazzmaster_domain_adm' ),
									'l'  => __( 'Large', 'jazzmaster_domain_adm' ),
									'm'  => __( 'Medium', 'jazzmaster_domain_adm' ),
									's'  => __( 'Small', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[countdown{{time}}{{size}} /]'
					),

				//Divider
					array(
						'id' => 'divider',
						'name' => __( 'Divider', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'type' => array(
								'label' => __( 'Type of divider', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''              => __( 'Spacer', 'jazzmaster_domain_adm' ),
									'dots'          => __( 'Dotted border', 'jazzmaster_domain_adm' ),
									'dashes'        => __( 'Dashed border', 'jazzmaster_domain_adm' ),
									'shadow-top'    => __( 'Shadow top', 'jazzmaster_domain_adm' ),
									'shadow-bottom' => __( 'Shadow bottom', 'jazzmaster_domain_adm' ),
									)
								),
							'top_link' => array(
								'label' => __( 'Display top link', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							'height' => array(
								'label' => __( 'Space height', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Height of empty space after divider (in pixels). If border is visible, there will be also 30px top margin applied.', 'jazzmaster_domain_adm' ),
								'value' => array(
									''    => __( 'Default', 'jazzmaster_domain_adm' ),
									'10'  => 10,
									'20'  => 20,
									'30'  => 30,
									'40'  => 40,
									'50'  => 50,
									'60'  => 60,
									'70'  => 70,
									'80'  => 80,
									'90'  => 90,
									'100' => 100,
									'110' => 110,
									'120' => 120,
									'130' => 130,
									'140' => 140,
									'150' => 150,
									'160' => 160,
									'170' => 170,
									'180' => 180,
									'190' => 190,
									'200' => 200,
									'210' => 210,
									'220' => 220,
									'230' => 230,
									'240' => 240,
									'250' => 250,
									'260' => 260,
									'270' => 270,
									'280' => 280,
									'290' => 290,
									'300' => 300,
									'300' => 300,
									'310' => 310,
									'320' => 320,
									'330' => 330,
									'340' => 340,
									'350' => 350,
									'360' => 360,
									'370' => 370,
									'380' => 380,
									'390' => 390,
									'400' => 400
									)
								),
							'no_border' => array(
								'label' => __( 'Border', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select whether you want to display or hide the border. Only for spacers.', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Yes', 'jazzmaster_domain_adm' ),
									'1' => __( 'No', 'jazzmaster_domain_adm' )
									)
								),
							'opacity' => array(
								'label' => __( 'Shadow opacity', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Percentual value of shadow opacity - 0 = transparent, 100 = opaque', 'jazzmaster_domain_adm' ),
								'value' => array(
									''    => __( 'Default', 'jazzmaster_domain_adm' ),
									'5'  => 5,
									'10' => 10,
									'15' => 15,
									'20' => 20,
									'25' => 25,
									'30' => 30,
									'35' => 35,
									'40' => 40,
									'45' => 45,
									'50' => 50,
									'55' => 55,
									'60' => 60,
									'65' => 65,
									'70' => 70,
									'75' => 75,
									'80' => 80,
									'85' => 85,
									'90' => 90,
									'95' => 95,
									)
								),
							),
						'output-shortcode' => '[divider{{type}}{{top_link}}{{height}}{{no_border}}{{opacity}} /]'
					),

				//Dropcaps
					array(
						'id' => 'dropcaps',
						'name' => __( 'Dropcaps', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'type' => array(
								'label' => __( 'Dropcap type', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select prefered dropcap styling', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Basic dropcap', 'jazzmaster_domain_adm' ),
									'round'  => __( 'Rounded dropcap', 'jazzmaster_domain_adm' ),
									'square' => __( 'Squared dropcap', 'jazzmaster_domain_adm' ),
									'leaf'   => __( 'Leaf dropcap', 'jazzmaster_domain_adm' ),
									)
								)
							),
						'output-shortcode' => '[dropcap{{type}}]A[/dropcap]'
					),

				//FAQ
					'faq' => array(
						'id' => 'faq',
						'name' => __( 'FAQ', 'jazzmaster_domain_adm' ),
						'desc' => __( 'You can include a description of the list created with the shortcode. Just place the text between opening and closing shortcode tag. However, note that this will disable the filter. FAQ shortcode can not be on the same page with the Projects shortcode when animation (filter) used.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'category' => array(
								'label' => __( 'FAQ category', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a category from where the list will be populated', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array(
										'allCountPost' => 'wm_faq',
										'allText'      => __( 'All FAQs', 'jazzmaster_domain_adm' ),
										'tax'          => 'faq-category',
									) )
								),
							'filter' => array(
								'label' => __( 'Filter', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Whether to display filter and where to place it', 'jazzmaster_domain_adm' ),
								'value' => array(
									''      => __( 'No filter', 'jazzmaster_domain_adm' ),
									'above' => __( 'Filter above the FAQ list', 'jazzmaster_domain_adm' ),
									'left'  => __( 'Filter left from FAQ list', 'jazzmaster_domain_adm' ),
									'right' => __( 'Filter right from FAQ list', 'jazzmaster_domain_adm' ),
									)
								),
							'order' => array(
								'label' => __( 'Order', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select order in which items will be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'name'   => __( 'By name', 'jazzmaster_domain_adm' ),
									'new'    => __( 'Newest first', 'jazzmaster_domain_adm' ),
									'old'    => __( 'Oldest first', 'jazzmaster_domain_adm' ),
									'random' => __( 'Randomly', 'jazzmaster_domain_adm' ),
									)
								),
							'filter_color' => array(
								'label' => __( 'Filter color', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose filter color', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'blue'   => __( 'Blue', 'jazzmaster_domain_adm' ),
									'gray'   => __( 'Gray', 'jazzmaster_domain_adm' ),
									'green'  => __( 'Green', 'jazzmaster_domain_adm' ),
									'orange' => __( 'Orange', 'jazzmaster_domain_adm' ),
									'red'    => __( 'Red', 'jazzmaster_domain_adm' ),
									)
								),
							'align' => array(
								'label' => __( 'Description align', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Description text alignement (when used - it will disable the filter)', 'jazzmaster_domain_adm' ),
								'value' => array(
									''      => '',
									'left'  => __( 'Description text on the left', 'jazzmaster_domain_adm' ),
									'right' => __( 'Description text on the right', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[faq{{category}}{{filter}}{{order}}{{filter_color}}{{align}}][/faq]'
					),

				//Gallery
					array(
						'id' => 'gallery',
						'name' => __( 'Gallery', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Please upload images for the post/page gallery via "Add Media" button above visual editor.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'columns' => array(
								'label' => __( 'Columns', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Number of gallery columns', 'jazzmaster_domain_adm' ),
								'value' => array(
									1 => 1,
									2 => 2,
									3 => 3,
									4 => 4,
									5 => 5,
									6 => 6,
									)
								),
							'flexible' => array(
								'label' => __( 'Flexibile layout', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Preserves images aspect ratio and uses masonry display', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							'frame' => array(
								'label' => __( 'Framed', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Display frame around images', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							'remove' => array(
								'label' => __( 'Remove', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Image order numbers separated with commas (like "1,2,5" will remove first, second and fifth image from gallery)', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'sardine' => array(
								'label' => __( 'Sardine', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Removes margins around images', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[gallery{{columns}}{{flexible}}{{frame}}{{remove}}{{sardine}} /]'
					),

				//Huge text
					array(
						'id' => 'huge_text',
						'name' => __( 'Huge text', 'jazzmaster_domain_adm' ),
						'desc' => __( 'This shortcode has no settings.', 'jazzmaster_domain_adm' ),
						'settings' => array(),
						'output-shortcode' => '[huge_text]TEXT[/huge_text]'
					),

				//Icons
					array(
						'id' => 'icon',
						'name' => __( 'Icons', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Only predefined icons of Font Awesome can be displayed with this shortcode.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'type' => array(
								'label' => __( 'Icon type', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select one of predefined icons', 'jazzmaster_domain_adm' ),
								'value' => $menuIcons,
								'image-before' => true,
								),
							'size' => array(
								'label' => __( 'Icon size', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Set the "font-size" CSS rule compatible values', 'jazzmaster_domain_adm' ),
								'value' => '',
								)
							),
						'output-shortcode' => '[icon{{type}}{{size}} /]'
					),

				//Lists
					array(
						'id' => 'lists',
						'name' => __( 'Lists', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'icon' => array(
								'label' => __( 'Bullet image', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select list bullet image', 'jazzmaster_domain_adm' ),
								'value' => $menuIcons,
								'image-before' => true,
								),
							),
						'output-shortcode' => '[list{{icon}}]' . __( 'Unordered list goes here', 'jazzmaster_domain_adm' ) . '[/list]'
					),

				//Last update
					array(
						'id' => 'lastupdate',
						'name' => __( 'Last update', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Displays the date when most recent blog post or project was added.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'item' => array(
								'label' => __( 'Items to watch', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'What item group will be watched for last update date', 'jazzmaster_domain_adm' ),
								'value' => array(
									''        => __( 'Blog posts', 'jazzmaster_domain_adm' ),
									'project' => __( 'Projects', 'jazzmaster_domain_adm' ),
									)
								),
							'format' => array(
								'label' => __( 'Date format', 'jazzmaster_domain_adm' ),
								'desc'  => "",
								'value' => array(
									get_option( 'date_format' ) => date( get_option( 'date_format' ) ),
									'F j, Y'                    => date( 'F j, Y' ),
									'M j, Y'                    => date( 'M j, Y' ),
									'jS F Y'                    => date( 'jS F Y' ),
									'jS M Y'                    => date( 'jS M Y' ),
									'j F Y'                     => date( 'j F Y' ),
									'j M Y'                     => date( 'j M Y' ),
									'j. n. Y'                   => date( 'j. n. Y' ),
									'j. F Y'                    => date( 'j. F Y' ),
									'j. M Y'                    => date( 'j. M Y' ),
									'Y/m/d'                     => date( 'Y/m/d' ),
									'm/d/Y'                     => date( 'm/d/Y' ),
									'd/m/Y'                     => date( 'd/m/Y' ),
									)
								),
							),
						'output-shortcode' => '[last_update{{format}}{{item}} /]'
					),

				//Login form
					array(
						'id' => 'login',
						'name' => __( 'Login form', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'stay' => array(
								'label' => __( 'Redirection', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Where the user will be redirected to after successful log in', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Go to homepage', 'jazzmaster_domain_adm' ),
									'1' => __( 'Stay here', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[login{{stay}} /]'
					),

				//Logos
					'logos' => array(
						'id' => 'logos',
						'name' => __( 'Logos', 'jazzmaster_domain_adm' ),
						'desc' => __( 'You can include a description of the list created with the shortcode. Just place the text between opening and closing shortcode tag.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'category' => array(
								'label' => __( 'Logos category', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a category from where the list will be populated', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array(
										'allCountPost' => 'wm_logos',
										'allText'      => __( 'All logos', 'jazzmaster_domain_adm' ),
										'tax'          => 'logos-category',
									) )
								),
							'columns' => array(
								'label' => __( 'Layout', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select number of columns to lay out the list', 'jazzmaster_domain_adm' ),
								'value' => array(
									'2' => __( '2 columns', 'jazzmaster_domain_adm' ),
									'3' => __( '3 columns', 'jazzmaster_domain_adm' ),
									'4' => __( '4 columns', 'jazzmaster_domain_adm' ),
									'5' => __( '5 columns', 'jazzmaster_domain_adm' ),
									'6' => __( '6 columns', 'jazzmaster_domain_adm' ),
									)
								),
							'count' => array(
								'label' => __( 'Logo count', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Number of items to display', 'jazzmaster_domain_adm' ),
								'value' => array(
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									)
								),
							'order' => array(
								'label' => __( 'Order', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select order in which items will be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'name'   => __( 'By name', 'jazzmaster_domain_adm' ),
									'new'    => __( 'Newest first', 'jazzmaster_domain_adm' ),
									'old'    => __( 'Oldest first', 'jazzmaster_domain_adm' ),
									'random' => __( 'Randomly', 'jazzmaster_domain_adm' ),
									)
								),
							'align' => array(
								'label' => __( 'Description align', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional list description alignement', 'jazzmaster_domain_adm' ),
								'value' => array(
									''      => '',
									'left'  => __( 'Description text on the left', 'jazzmaster_domain_adm' ),
									'right' => __( 'Description text on the right', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[logos{{category}}{{columns}}{{count}}{{order}}{{align}}][/logos]'
					),

				//Marker
					array(
						'id' => 'marker',
						'name' => __( 'Marker', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'color' => array(
								'label' => __( 'Color', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose marker color', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'blue'   => __( 'Blue', 'jazzmaster_domain_adm' ),
									'gray'   => __( 'Gray', 'jazzmaster_domain_adm' ),
									'green'  => __( 'Green', 'jazzmaster_domain_adm' ),
									'orange' => __( 'Orange', 'jazzmaster_domain_adm' ),
									'red'    => __( 'Red', 'jazzmaster_domain_adm' ),
									)
								),
							'text_color' => array(
								'label'     => __( 'Text color', 'jazzmaster_domain_adm' ),
								'desc'      => __( 'Custom text color. Use hexadecimal color code without "#".', 'jazzmaster_domain_adm' ),
								'value'     => '',
								'maxlength' => 6
								),
							'background_color' => array(
								'label'     => __( 'Background color', 'jazzmaster_domain_adm' ),
								'desc'      => __( 'Custom background color. Use hexadecimal color code without "#".', 'jazzmaster_domain_adm' ),
								'value'     => '',
								'maxlength' => 6
								),
							),
						'output-shortcode' => '[marker{{color}}{{text_color}}{{background_color}}]TEXT[/marker]'
					),

				//Posts
					array(
						'id' => 'posts',
						'name' => __( 'Posts', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Does not display Quote and Status posts. You can include a description of the list created with the shortcode. Just place the text between opening and closing shortcode tag.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'category' => array(
								'label' => __( 'Posts category', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a category from where the list will be populated', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array()
								),
							'columns' => array(
								'label' => __( 'Layout', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select number of columns to lay out the list', 'jazzmaster_domain_adm' ),
								'value' => array(
									'2' => __( '2 columns', 'jazzmaster_domain_adm' ),
									'3' => __( '3 columns', 'jazzmaster_domain_adm' ),
									'4' => __( '4 columns', 'jazzmaster_domain_adm' ),
									'5' => __( '5 columns', 'jazzmaster_domain_adm' ),
									'6' => __( '6 columns', 'jazzmaster_domain_adm' ),
									)
								),
							'count' => array(
								'label' => __( 'Posts count', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Number of items to display', 'jazzmaster_domain_adm' ),
								'value' => array(
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									)
								),
							'excerpt_length' => array(
								'label' => __( 'Excerpt length', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'In words', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => '',
									'0' => 0,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									'16' => 16,
									'17' => 17,
									'18' => 18,
									'19' => 19,
									'20' => 20,
									)
								),
							'order' => array(
								'label' => __( 'Order', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select order in which items will be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'name'   => __( 'By name', 'jazzmaster_domain_adm' ),
									'new'    => __( 'Newest first', 'jazzmaster_domain_adm' ),
									'old'    => __( 'Oldest first', 'jazzmaster_domain_adm' ),
									'random' => __( 'Randomly', 'jazzmaster_domain_adm' ),
									)
								),
							'align' => array(
								'label' => __( 'Description align', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional list description alignement', 'jazzmaster_domain_adm' ),
								'value' => array(
									''      => '',
									'left'  => __( 'Description text on the left', 'jazzmaster_domain_adm' ),
									'right' => __( 'Description text on the right', 'jazzmaster_domain_adm' ),
									)
								),
							'thumb' => array(
								'label' => __( 'Thumbnail image', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Yes', 'jazzmaster_domain_adm' ),
									'0' => __( 'No', 'jazzmaster_domain_adm' ),
									)
								),
							'related' => array(
								'label' => __( 'Display related posts?', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Displays related posts to the current post upon its category and tags settings.', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[posts{{category}}{{columns}}{{count}}{{excerpt_length}}{{order}}{{align}}{{thumb}}{{related}}][/posts]'
					),

				//Price table
					'prices' => array(
						'id' => 'price_table',
						'name' => __( 'Price Table', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'table' => array(
								'label' => __( 'Select table', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select price table to display', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array(
										'allCountPost' => '',
										'allText'      => __( 'Select price table', 'jazzmaster_domain_adm' ),
										'hierarchical' => '0',
										'tax'          => 'price-table',
									) )
								),
							),
						'output-shortcode' => '[prices{{table}} /]'
					),

				//Projects
					'projects' => array(
						'id' => 'projects',
						'name' => __( 'Projects', 'jazzmaster_domain_adm' ),
						'desc' => __( 'You can include a description of the list created with the shortcode. Just place the text between opening and closing shortcode tag. Can not be on the same page with the FAQ shortcode when animation (filter) used.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'category' => array(
								'label' => __( 'Projects category', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a category from where the list will be populated', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array(
										'allCountPost' => 'wm_projects',
										'allText'      => __( 'All projects', 'jazzmaster_domain_adm' ),
										'parentsOnly'  => true,
										'tax'          => 'project-category',
									) )
								),
							'columns' => array(
								'label' => __( 'Layout', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select number of columns to lay out the list', 'jazzmaster_domain_adm' ),
								'value' => array(
									'2' => __( '2 columns', 'jazzmaster_domain_adm' ),
									'3' => __( '3 columns', 'jazzmaster_domain_adm' ),
									'4' => __( '4 columns', 'jazzmaster_domain_adm' ),
									'5' => __( '5 columns', 'jazzmaster_domain_adm' ),
									'6' => __( '6 columns', 'jazzmaster_domain_adm' ),
									)
								),
							'count' => array(
								'label' => __( 'Projects count', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Number of items to display', 'jazzmaster_domain_adm' ),
								'value' => array(
									'' => __( 'All projects (in category)', 'jazzmaster_domain_adm' ),
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									)
								),
							'order' => array(
								'label' => __( 'Order', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select order in which items will be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'name'   => __( 'By name', 'jazzmaster_domain_adm' ),
									'new'    => __( 'Newest first', 'jazzmaster_domain_adm' ),
									'old'    => __( 'Oldest first', 'jazzmaster_domain_adm' ),
									'random' => __( 'Randomly', 'jazzmaster_domain_adm' ),
									)
								),
							'align' => array(
								'label' => __( 'Description align', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional list description alignement', 'jazzmaster_domain_adm' ),
								'value' => array(
									''      => '',
									'left'  => __( 'Description text on the left', 'jazzmaster_domain_adm' ),
									'right' => __( 'Description text on the right', 'jazzmaster_domain_adm' ),
									)
								),
							'filter' => array(
								'label' => __( 'Projects filter', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional projects filter', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'No filter', 'jazzmaster_domain_adm' ),
									'1' => __( 'Animated filtering', 'jazzmaster_domain_adm' ),
									)
								),
							'thumb' => array(
								'label' => __( 'Thumbnail image', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Yes', 'jazzmaster_domain_adm' ),
									'0' => __( 'No', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[projects{{align}}{{filter}}{{columns}}{{count}}{{category}}{{order}}{{thumb}}][/projects]'
					),

				//Project attributes
					'projectAtts' => array(
						'id' => 'project_attributes',
						'name' => __( 'Project attributes', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Use on project page only. Displays table of project attributes.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'title' => array(
								'label' => __( 'Title', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Attributes table title', 'jazzmaster_domain_adm' ),
								'value' => ''
								)
							),
						'output-shortcode' => '[project_attributes{{title}} /]'
					),

				//Pullquote
					array(
						'id' => 'pullquote',
						'name' => __( 'Pullquote', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'align' => array(
								'label' => __( 'Align', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose pullquote alignment', 'jazzmaster_domain_adm' ),
								'value' => array(
									'left'  => __( 'Left', 'jazzmaster_domain_adm' ),
									'right' => __( 'Right', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[pullquote{{align}}]TEXT[/pullquote]'
					),

				//Raw / pre
					array(
						'id' => 'raw',
						'name' => __( 'Raw preformated text', 'jazzmaster_domain_adm' ),
						'desc' => __( 'This shortcode has no settings.', 'jazzmaster_domain_adm' ),
						'settings' => array(),
						'output-shortcode' => '[raw]TEXT[/raw]'
					),

				//Section
					array(
						'id' => 'section',
						'name' => __( 'Section', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Use on "Sections" page template only! This will split the page into sections. You can set a custom CSS class and then style the sections individually. You can use "alt" class for alternative section styling.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'class' => array(
								'label' => __( 'Class', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional CSS class name', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							),
						'output-shortcode' => '[section{{class}}]TEXT[/section]'
					),

				//Slideshow
					array(
						'id' => 'slideshow',
						'name' => __( 'Slideshow', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'group' => array(
								'label' => __( 'Slides group', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Choose which Slides custom post group should be displayed', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array(
										'allCountPost' => 'wm_slides',
										'allText'      => __( 'Select group of slides', 'jazzmaster_domain_adm' ),
										'parentsOnly'  => true,
										'tax'          => 'slide-category',
									) )
								),
							'images' => array(
								'label' => __( 'Image URLs', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Insert image URL addresses separated with commas or type in "gallery" to display post image gallery in slideshow', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'links' => array(
								'label' => __( 'Image links', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'If image URLs set, you can set also links that will be applied on those images. Keep the structure (number) the same as for Image URLs, separate each link (even empty) with comma.', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'time' => array(
								'label' => __( 'Time in seconds', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Time to display one slide in seconds', 'jazzmaster_domain_adm' ),
								'value' => array(
									'1'  => 1,
									'2'  => 2,
									'3'  => 3,
									'4'  => 4,
									'5'  => 5,
									'6'  => 6,
									'7'  => 7,
									'8'  => 8,
									'9'  => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									'16' => 16,
									'17' => 17,
									'18' => 18,
									'19' => 19,
									'20' => 20,
									)
								),
							),
						'output-shortcode' => '[slideshow{{group}}{{images}}{{links}}{{time}} /]'
					),

				//Small text
					array(
						'id' => 'small_text',
						'name' => __( 'Small text', 'jazzmaster_domain_adm' ),
						'desc' => __( 'This shortcode has no settings.', 'jazzmaster_domain_adm' ),
						'settings' => array(),
						'output-shortcode' => '[small_text]TEXT[/small_text]'
					),

				//Social icons
					array(
						'id' => 'social',
						'name' => __( 'Social', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'url' => array(
								'label' => __( 'Link URL', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Social icon link URL address', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'icon' => array(
								'label' => __( 'Icon', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select icon to be displayed', 'jazzmaster_domain_adm' ),
								'value' => $socialIcons
								),
							'title' => array(
								'label' => __( 'Title text', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'This text will be displayed when mouse hovers over the icon', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'size' => array(
								'label' => __( 'Icon size', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select icon size', 'jazzmaster_domain_adm' ),
								'value' => array(
									's'  => __( 'Small', 'jazzmaster_domain_adm' ),
									'm'  => __( 'Medium', 'jazzmaster_domain_adm' ),
									'l'  => __( 'Large', 'jazzmaster_domain_adm' ),
									'xl' => __( 'Extra large', 'jazzmaster_domain_adm' ),
									)
								),
							'rel' => array(
								'label' => __( 'Optional link relation', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'This will set up the link "rel" HTML attribute', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							),
						'output-shortcode' => '[social{{url}}{{icon}}{{title}}{{size}}{{rel}} /]'
					),

				//Staff
					'staff' => array(
						'id' => 'staff',
						'name' => __( 'Staff', 'jazzmaster_domain_adm' ),
						'desc' => __( 'You can include a description of the list created with the shortcode. Just place the text between opening and closing shortcode tag.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'department' => array(
								'label' => __( 'Department', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a department from where the list will be populated', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array(
										'allCountPost' => 'wm_staff',
										'allText'      => __( 'All staff', 'jazzmaster_domain_adm' ),
										'tax'          => 'department',
									) )
								),
							'columns' => array(
								'label' => __( 'Layout', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select number of columns to lay out the list', 'jazzmaster_domain_adm' ),
								'value' => array(
									'2' => __( '2 columns', 'jazzmaster_domain_adm' ),
									'3' => __( '3 columns', 'jazzmaster_domain_adm' ),
									'4' => __( '4 columns', 'jazzmaster_domain_adm' ),
									'5' => __( '5 columns', 'jazzmaster_domain_adm' ),
									'6' => __( '6 columns', 'jazzmaster_domain_adm' ),
									)
								),
							'count' => array(
								'label' => __( 'Staff count', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Number of items to display', 'jazzmaster_domain_adm' ),
								'value' => array(
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									'16' => 16,
									'17' => 17,
									'18' => 18,
									'19' => 19,
									'20' => 20,
									)
								),
							'order' => array(
								'label' => __( 'Order', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select order in which items will be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Default', 'jazzmaster_domain_adm' ),
									'name'   => __( 'By name', 'jazzmaster_domain_adm' ),
									'new'    => __( 'Newest first', 'jazzmaster_domain_adm' ),
									'old'    => __( 'Oldest first', 'jazzmaster_domain_adm' ),
									'random' => __( 'Randomly', 'jazzmaster_domain_adm' ),
									)
								),
							'align' => array(
								'label' => __( 'Description align', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional list description alignement', 'jazzmaster_domain_adm' ),
								'value' => array(
									''      => '',
									'left'  => __( 'Description text on the left', 'jazzmaster_domain_adm' ),
									'right' => __( 'Description text on the right', 'jazzmaster_domain_adm' ),
									)
								),
							'thumb' => array(
								'label' => __( 'Thumbnail image', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => __( 'Yes', 'jazzmaster_domain_adm' ),
									'0' => __( 'No', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[staff{{department}}{{columns}}{{count}}{{order}}{{align}}{{thumb}}][/staff]'
					),

				//Statuses
					'status' => array(
						'id' => 'status',
						'name' => __( 'Status', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'date' => array(
								'label' => __( 'Display date', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								),
							'count' => array(
								'label' => __( 'Statuses count', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Number of items to display', 'jazzmaster_domain_adm' ),
								'value' => array(
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									)
								),
							'speed' => array(
								'label' => __( 'Speed in seconds', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'If set, statuses will be animated. This sets the time to display one status in seconds', 'jazzmaster_domain_adm' ),
								'value' => array(
									''   => '',
									'1'  => 1,
									'2'  => 2,
									'3'  => 3,
									'4'  => 4,
									'5'  => 5,
									'6'  => 6,
									'7'  => 7,
									'8'  => 8,
									'9'  => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									'16' => 16,
									'17' => 17,
									'18' => 18,
									'19' => 19,
									'20' => 20,
									)
								),
							'layout' => array(
								'label' => __( 'Layout', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''      => __( 'Normal', 'jazzmaster_domain_adm' ),
									'large' => __( 'Large', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[status{{date}}{{count}}{{speed}}{{layout}} /]'
					),

				//Subpages
					array(
						'id' => 'subpages',
						'name' => __( 'Subpages', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'depth' => array(
								'label' => __( 'Hierarchy levels', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select the depth of page hierarchy to display', 'jazzmaster_domain_adm' ),
								'value' => array(
									'0' => __( 'All levels', 'jazzmaster_domain_adm' ),
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									)
								),
							'order' => array(
								'label' => __( 'Order', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''      => '',
									'menu'  => __( 'By menu order', 'jazzmaster_domain_adm' ),
									'title' => __( 'By title', 'jazzmaster_domain_adm' ),
									)
								),
							'parents' => array(
								'label' => __( 'Display parents?', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''      => '',
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								)
							),
						'output-shortcode' => '[subpages{{depth}}{{order}}{{parents}} /]'
					),

				//Table
					array(
						'id' => 'table',
						'name' => __( 'Table', 'jazzmaster_domain_adm' ),
						'desc' => __( 'For simple data tables use the shortcode below.', 'jazzmaster_domain_adm' ) . '<br />' . __( 'However, if you require more control over your table you can use sub-shortcodes for table row (<code>[trow][/trow]</code> or <code>[trow_alt][/trow_alt]</code> for alternatively styled table row), table cell (<code>[tcell][/tcell]</code>) and table heading cell (<code>[tcell_heading][/tcell_heading]</code>). All wrapped in <code>[table][/table]</code> parent shortcode.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'cols' => array(
								'label' => __( 'Heading row', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Titles of columns, separated with separator character. This is required to determine the number of columns for the table.', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'data' => array(
								'label' => __( 'Table data', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Table cells data separated with separator character. Will be automatically aligned into columns (depending on "Heading row" setting).', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							'separator' => array(
								'label' => __( 'Separator character', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Individual table cell data separator used in previous input fields', 'jazzmaster_domain_adm' ),
								'value' => ';'
								),
							'heading_col' => array(
								'label' => __( 'Heading column', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'If you wish to display a whole column of the table as a heading, set its order number here', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => '',
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10
									)
								),
							'class' => array(
								'label' => __( 'CSS class', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Optional custom css class applied on the table HTML tag', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							),
						'output-shortcode' => '[table{{class}}{{cols}}{{data}}{{separator}}{{heading_col}} /]'
					),

				//Tabs
					array(
						'id' => 'tabs',
						'name' => __( 'Tabs', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Please, copy the <code>[tab title=""][/tab]</code> sub-shortcode as many times as you need. But keep them wrapped in <code>[tabs][/tabs]</code> parent shortcode.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'type' => array(
								'label' => __( 'Tabs type', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select tabs styling', 'jazzmaster_domain_adm' ),
								'value' => array(
									''              => __( 'Normal tabs', 'jazzmaster_domain_adm' ),
									'fullwidth'     => __( 'Full width tabs', 'jazzmaster_domain_adm' ),
									'vertical'      => __( 'Vertical tabs', 'jazzmaster_domain_adm' ),
									'vertical tour' => __( 'Vertical tabs - tour', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[tabs{{type}}] [tab title="TEXT"]TEXT[/tab] [/tabs]'
					),

				//Testimonials
					'testimonials' => array(
						'id' => 'testimonials',
						'name' => __( 'Testimonials', 'jazzmaster_domain_adm' ),
						'desc' => __( 'This shortcode will display Quote posts. If featured image of the post set, it will be used as quoted person photo (please upload square images only).', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'category' => array(
								'label' => __( 'Category (required)', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a category from where the list will be populated', 'jazzmaster_domain_adm' ),
								'value' => wm_tax_array( array( 'all' => false ) )
								),
							'count' => array(
								'label' => __( 'Testimonials count', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Number of items to display', 'jazzmaster_domain_adm' ),
								'value' => array(
									'1' => 1,
									'2' => 2,
									'3' => 3,
									'4' => 4,
									'5' => 5,
									'6' => 6,
									'7' => 7,
									'8' => 8,
									'9' => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									)
								),
							'order' => array(
								'label' => __( 'Order', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select order in which items will be displayed', 'jazzmaster_domain_adm' ),
								'value' => array(
									''       => __( 'Newest first', 'jazzmaster_domain_adm' ),
									'old'    => __( 'Oldest first', 'jazzmaster_domain_adm' ),
									'random' => __( 'Randomly', 'jazzmaster_domain_adm' ),
									)
								),
							'speed' => array(
								'label' => __( 'Speed in seconds', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Time to display one testimonial in seconds', 'jazzmaster_domain_adm' ),
								'value' => array(
									''  => '',
									'3'  => 3,
									'4'  => 4,
									'5'  => 5,
									'6'  => 6,
									'7'  => 7,
									'8'  => 8,
									'9'  => 9,
									'10' => 10,
									'11' => 11,
									'12' => 12,
									'13' => 13,
									'14' => 14,
									'15' => 15,
									'16' => 16,
									'17' => 17,
									'18' => 18,
									'19' => 19,
									'20' => 20,
									)
								),
							'layout' => array(
								'label' => __( 'Layout', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''      => __( 'Normal', 'jazzmaster_domain_adm' ),
									'large' => __( 'Large', 'jazzmaster_domain_adm' ),
									)
								),
							'private' => array(
								'label' => __( 'Display private posts?', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''      => '',
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								)
							),
						'output-shortcode' => '[testimonials{{category}}{{count}}{{order}}{{speed}}{{layout}}{{private}} /]'
					),

				//Toggles
					array(
						'id' => 'toggles',
						'name' => __( 'Toggles', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'title' => array(
								'label' => __( 'Toggle title', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => ''
								),
							'open' => array(
								'label' => __( 'Open by default?', 'jazzmaster_domain_adm' ),
								'desc'  => '',
								'value' => array(
									''      => '',
									''  => __( 'No', 'jazzmaster_domain_adm' ),
									'1' => __( 'Yes', 'jazzmaster_domain_adm' ),
									)
								)
							),
						'output-shortcode' => '[toggle{{title}}{{open}}]TEXT[/toggle]'
					),

				//Uppercase text
					array(
						'id' => 'uppercase',
						'name' => __( 'Uppercase text', 'jazzmaster_domain_adm' ),
						'desc' => __( 'This shortcode has no settings.', 'jazzmaster_domain_adm' ),
						'settings' => array(),
						'output-shortcode' => '[uppercase]TEXT[/uppercase]'
					),

				//Videos
					array(
						'id' => 'video',
						'name' => __( 'Video', 'jazzmaster_domain_adm' ),
						'desc' => __( 'Use syntax of <a href="http://codex.wordpress.org/Video_Shortcode" target="_blank">WordPress Video shortcode</a>.', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'src' => array(
								'label' => __( 'Video URL', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Insert YouTube, Vimeo, Screenr or self-hosted video URL address', 'jazzmaster_domain_adm' ),
								'value' => ''
								),
							),
						'output-shortcode' => '[video{{src}} /]'
					),

				//Widget areas
					array(
						'id' => 'widgetarea',
						'name' => __( 'Widget area', 'jazzmaster_domain_adm' ),
						'settings' => array(
							'area' => array(
								'label' => __( 'Area to display', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Select a widget area from dropdown menu', 'jazzmaster_domain_adm' ),
								'value' => wm_widget_areas()
								),
							'style' => array(
								'label' => __( 'Style', 'jazzmaster_domain_adm' ),
								'desc'  => __( 'Widgets layout of the widget area', 'jazzmaster_domain_adm' ),
								'value' => array(
									''              => __( 'Horizontal', 'jazzmaster_domain_adm' ),
									'vertical'      => __( 'Vertical', 'jazzmaster_domain_adm' ),
									'sidebar-left'  => __( 'Sidebar left', 'jazzmaster_domain_adm' ),
									'sidebar-right' => __( 'Sidebar right', 'jazzmaster_domain_adm' ),
									)
								),
							),
						'output-shortcode' => '[widgets{{area}}{{style}} /]'
					)

			);

			//remove shortcodes from array if Custom Posts or Post Formats disabled
				if ( 'disable' === wm_option( 'general-role-faq' ) )
					unset( $wmShortcodeGeneratorTabs['faq'] );
				if ( 'disable' === wm_option( 'general-role-logos' ) )
					unset( $wmShortcodeGeneratorTabs['logos'] );
				if ( 'disable' === wm_option( 'general-role-prices' ) )
					unset( $wmShortcodeGeneratorTabs['prices'] );
				if ( 'disable' === wm_option( 'general-role-projects' ) ) {
					unset( $wmShortcodeGeneratorTabs['projects'] );
					unset( $wmShortcodeGeneratorTabs['projectAtts'] );
				}
				if ( 'disable' === wm_option( 'general-role-staff' ) )
					unset( $wmShortcodeGeneratorTabs['staff'] );
				if ( wm_option( 'blog-no-format-status' ) )
					unset( $wmShortcodeGeneratorTabs['status'] );
				if ( wm_option( 'blog-no-format-quote' ) )
					unset( $wmShortcodeGeneratorTabs['testimonials'] );

			return $wmShortcodeGeneratorTabs;
		}
	} // /wm_shortcode_generator_tabs





/*
*****************************************************
*      5) SHORTCODE GENERATOR HTML
*****************************************************
*/
	/*
	* Shortcode generator popup form
	*/
	if ( ! function_exists( 'wm_add_generator_popup' ) ) {
		function wm_add_generator_popup() {
			$shortcodes = wm_shortcode_generator_tabs();

			$out = '
				<div id="wm-shortcode-generator" class="selectable">
				<div id="wm-shortcode-form">
				';

			if ( ! empty( $shortcodes ) ) {

				//tabs
				/*
				$out .= '<ul class="wm-tabs">';
				foreach ( $shortcodes as $shortcode ) {
					$shortcodeId = 'wm-generate-' . $shortcode['id'];
					$out .= '<li><a href="#' . $shortcodeId . '">' . $shortcode['name'] . '</a></li>';
				}
				$out .= '</ul>';
				*/

				//select
				$out .= '<div class="wm-select-wrap"><label for="select-shortcode">' . __( 'Select a shortcode:', 'jazzmaster_domain_adm' ) . '</label><select id="select-shortcode" class="wm-select">';
				foreach ( $shortcodes as $shortcode ) {
					$shortcodeId = 'wm-generate-' . $shortcode['id'];
					$out .= '<option value="#' . $shortcodeId . '">' . $shortcode['name'] . '</option>';
				}
				$out .= '</select></div>';

				//content
				$out .= '<div class="wm-tabs-content">';
				foreach ( $shortcodes as $shortcode ) {

					$shortcodeId     = 'wm-generate-' . $shortcode['id'];
					$settings        = ( isset( $shortcode['settings'] ) ) ? ( $shortcode['settings'] ) : ( null );
					$shortcodeOutput = ( isset( $shortcode['output-shortcode'] ) ) ? ( $shortcode['output-shortcode'] ) : ( null );
					$close           = ( isset( $shortcode['close'] ) ) ? ( ' ' . $shortcode['close'] ) : ( null );
					$settingsCount   = count( $settings );

					$out .= '
						<div id="' . $shortcodeId . '" class="tab-content">
						<p class="shortcode-title"><strong>' . $shortcode['name'] . '</strong> ' . __( 'shortcode', 'jazzmaster_domain_adm' ) . '</p>
						';

					if ( isset( $shortcode['desc'] ) && $shortcode['desc'] )
						$out .= '<p class="shortcode-desc">' . $shortcode['desc'] . '</p>';

					$out .= '
						<div class="form-wrap">
						<form method="get" action="">
						<table class="items-' . $settingsCount . '">
						';

					if ( $settings ) {
						$i = 0;
						foreach ( $settings as $id => $labelValue ) {
							$i++;
							$desc      = ( isset( $labelValue['desc'] ) ) ? ( esc_attr( $labelValue['desc'] ) ) : ( '' );
							$maxlength = ( isset( $labelValue['maxlength'] ) ) ? ( ' maxlength="' . absint( $labelValue['maxlength'] ) . '"' ) : ( '' );

							$out .= '<tr class="item-' . $i . '"><td>';
							$out .= '<label for="' . $shortcodeId . '-' . $id . '" title="' . $desc . '">' . $labelValue['label'] . '</label></td><td>';
							if ( is_array( $labelValue['value'] ) ) {
								$imageBefore  = ( isset( $labelValue['image-before'] ) && $labelValue['image-before'] ) ? ( '<div class="image-before"></div>' ) : ( '' );
								$shorterClass = ( $imageBefore ) ? ( ' class="shorter set-image"' ) : ( '' );

								$out .= $imageBefore . '<select name="' . $shortcodeId . '-' . $id . '" id="' . $shortcodeId . '-' . $id . '" title="' . $desc . '" data-attribute="' . $id . '"' . $shorterClass . '>';
								foreach ( $labelValue['value'] as $value => $valueName ) {
									if ( 'OPTGROUP' === substr( $value, 1 ) )
										$out .= '<optgroup label="' . $valueName . '">';
									elseif ( '/OPTGROUP' === substr( $value, 1 ) )
										$out .= '</optgroup>';
									else
										$out .= '<option value="' . $value . '">' . $valueName . '</option>';
								}
								$out .= '</select>';

							} else {

								$out .= '<input type="text" name="' . $shortcodeId . '-' . $id . '" value="' . $labelValue['value'] . '" id="' . $shortcodeId . '-' . $id . '" class="widefat" title="' . $desc . '"' . $maxlength . ' data-attribute="' . $id . '" /><img src="' . WM_ASSETS_ADMIN . 'img/shortcodes/add16.png" alt="' . __( 'Apply changes', 'jazzmaster_domain_adm' ) . '" title="' . __( 'Apply changes', 'jazzmaster_domain_adm' ) . '" class="ico-apply" />';

							}
							$out .= '</td></tr>';
						}
					}

					$out .= '<tr><td>&nbsp;</td><td><p><a data-parent="' . $shortcodeId . '" class="send-to-generator button-primary">' . __( 'Insert into editor', 'jazzmaster_domain_adm' ) . '</a></p></td></tr>';
					$out .= '
						</table>
						</form>
						';
					$out .= '<p><strong>' . __( 'Or copy and paste in this shortcode:', 'jazzmaster_domain_adm' ) . '</strong></p>';
					$out .= '<form><textarea class="wm-shortcode-output' . $close . '" cols="30" rows="2" readonly="readonly" onfocus="this.select();" data-reference="' . esc_attr( $shortcodeOutput ) . '">' . esc_attr( $shortcodeOutput ) . '</textarea></form>';
					$out .= '<!-- /form-wrap --></div>';
					$out .= '<!-- /tab-content --></div>';

				}
				$out .= '<!-- /wm-tabs-content --></div>';

			}

			$out .= '
				<!-- /wm-shortcode-form --></div>
				<p class="credits"><small>&copy; <a href="http://www.webmandesign.eu" target="_blank">WebMan</a></small></p>
				<!-- /wm-shortcode-generator --></div>
				';

			echo $out;
		}
	} // /wm_add_generator_popup

?>