# JazzMaster Changelog

## 3.0

* Added: Update message in admin
* Added: Prepared for removing from distibution
* Updated: Font Awesome 4.3
* Updated: Tighten security
* Updated: Using unpacked scripts
* Updated: Removed obsolete theme options
* Updated: Admin interface styles
* Updated: Scripts: TGM Plugin Activation 2.4.1, jQuery FlexSlider 2.4.0, ImagesLoaded 3.1.8, Isotope 2.2.0
* Updated: Plugins: RevSlider 4.6.92
* Updated: Improved coding
* Updated: Added filter hooks for sliders
* Updated: Added and modified hooks for shortcodes
* Updated: Improved shortcodes
* Updated: Localization
* Fixed: Rokkitt Google Font display issue
* Fixed: Align left/right responsive styles
* Fixed: HTML validation issues
* Fixed: Issues with sliders

#### Files changed:

	functions.php
	style.css
	changelog.md
	assets/css/icons.css
	assets/css/responsive.css
	assets/css/skins/dark-gray.css
	assets/css/skins/dark-green.css
	assets/css/skins/dark-orange.css
	assets/css/skins/dark-pink.css
	assets/css/skins/dark-purple.css
	assets/css/skins/dark.css
	assets/css/skins/default.css
	assets/css/skins/gray.css
	assets/css/skins/green.css
	assets/css/skins/orange.css
	assets/css/skins/pink.css
	assets/css/skins/purple.css
	assets/font/font-awesome/*.*
	assets/js/scripts.js
	assets/js/flex/jquery.flexslider-min.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/isotope/jquery.isotope.min.js
	langs/*.*
	library/admin.php
	library/core.php
	library/setup.php
	library/assets/css/admin-addon.css
	library/assets/css/wm-options/wm-options-panel.css
	library/options/a-blog.php
	library/plugins/plugin-activation/plugins.php
	library/shortcodes/shortcodes.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-roundabout.php
	library/updater/update-notifier.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php


## 2.7.2

* Updated: Plugins: Slider Revolution 4.5.7
* Updated: Audio shortcode album_art attribute added into shortcode generator and contextual help
* Fixed: Video URL display in [video] shortcode

#### Files changed:

	Admin localization file
	library/help/a-help.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcode-generator.php


## 2.7.1

* Updated: Removed Refineslide slider for script incompatibility and end of development
* Updated: Plugins: Slider Revolution 4.5.6
* Fixed: Caption shortcode throwing PHP error

#### Files changed:

	Admin and panel localization files
	library/core.php
	library/meta/a-meta-page.php
	library/options/a-slider.php


## 2.7

* Added: Full WordPress 3.9 support
* Added: FlexSlider keyboard navigation for projects sliders
* Added: Zooming images in projects sliders (besides custom links applied on images)
* Added: Filter hooks for shortcodes, widgets, sliders and others
* Added: Next/previous post/project section
* Added: Support for Jetpack plugin's sharing feature
* Added: Font icons support for Content Modules
* Updated: Font Awesome v4.1.0
* Updated: Admin fields and texts
* Updated: Admin interface
* Updated: Theme stylesheet being included with wp_enqueue_style() function
* Updated: Scripts: Isotope 2.0, FlexSlider 2.2.2, ImagesLoaded 3.1.6, Normalize.css 3.0.1, HTML5 Shiv 3.7.2
* Updated: Plugins: Slider Revolution 4.3.8, Envato WordPress Toolkit 1.6.3
* Updated: Support for native WordPress video and audio shortcodes
* Updated: Logic of video/audio projects and post formats
* Fixed: Slideshow shortcode inside Content Module shortcode styling
* Fixed: Call to action title word wrapping
* Fixed: Project widget custom projects links
* Fixed: Missing localization strings

#### Files changed:

	All localization files
	Icon font files
	functions.php
	header.php
	single-wm_projects.php
	assets/css/borders.css
	assets/css/content.css
	assets/css/icons.css
	assets/css/normalize.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/wp-styles.css
	assets/css/flex/flex.css
	assets/js/flex/jquery.flexslider-min.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/isotope/jquery.isotope.min.js
	assets/js/html5.js
	assets/js/scripts.dev.js
	assets/js/scripts.js
	inc/formats/format.php
	inc/formats/format-audio.php
	inc/formats/format-gallery.php
	inc/formats/format-link.php
	inc/formats/format-video.php
	inc/loop/loop-project.php
	library/admin.php
	library/core.php
	library/setup.php
	library/wm-options-panel.php
	library/assets/css/admin-addon.css
	library/assets/css/wm-options/wm-options-panel.css
	library/assets/js/wm-options-panel.js
	library/help/a-help.php
	library/hooks/hooks.php
	library/meta/m-cp-modules.php
	library/options/a-general.php
	library/shortcodes/shortcodes.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/sliders/s-roundabout.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php


## 2.6.5

* Added: WordPress 3.8 ready
* Added: Custom CSS class attribute for [column] shortcode
* Added: Fiter to add/modify contact infos in Contact widget
* Updated: Update plugins (Envato WordPress Toolkit 1.6.1, Revolution Slider 4.1.2)
* Fixed: Header min-height settings
* Fixed: Mobile menu "Menu" text is translatable

#### Files changed:

	Admin and help localization file
	library/admin.php
	library/core.php
	library/setup.php
	library/assets/css/admin-addon-38.css
	library/assets/js/scripts.js
	library/help/a-help.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-contact.php


## 2.6.2

* Added: Logos custom post link relation
* Added: Applied filters on some shortcodes outputs
* Updated: Font Awesome 4.0.3 icons
* Fixed: Logos custom post image upload
* Fixed: Image title attribute

#### Files changed:

	Admin localization file
	functions.php
	assets/css/icons.css
	library/core.php
	library/admin.php
	library/meta/m-cp-logos.php
	library/shortcodes/shortcodes.php


## 2.6.1

* Fixed: Pagination coding error
* Fixed: Theme admin PHP error

#### Files changed:

	library/core.php
	library/wm-options-panel.php


## 2.6

* Added: Support for "All In One Schema.org Rich Snippets" and "Schema Creator by Raven" Schema.org snippets plugins
* Added: Option to display related posts with [posts] shortcode
* Added: Option to display replies in Twitter Widget
* Added: Compatibility with WP PageNavi plugin
* Added: Option to disable sharing buttons per post basis
* Updated: Admin area updates
* Updated: Plugins and scripts updates (TGM Plugin Activation, Revolution Slider 4.0.4, Envato WordPress Toolkit 1.5)
* Updated: Better shortcodes support with WordPress 3.6+
* Updated: Improved code
* Updated: Minor frontend styles updates
* Fixed: Posts widget coding error
* Fixed: Twitter Widget fixes
* Fixed: Blog page pagination fix

#### Files changed:

	Admin, help translation file
	comments.php
	single-wm_projects.php
	assets/css/core.css
	assets/css/responsive.css
	inc/loop/loop-blogpage.php
	library/core.php
	library/wm-options-panel.php
	library/classes/meta-box-generator.php
	library/help/a-help.php
	library/meta/a-meta-post.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/sliders/s-roundabout.php
	library/widgets/w-postslist.php
	library/widgets/w-twitter.php


## 2.5.1

* Updated: Admin updates
* Updated: Twitter Widget improved
* Updated: Updated plugins (Revolution Slider 3.0.8)
* Fixed: Attachment loop apply_filters function error
* Fixed: Minor styles fixes
* Fixed: Slides group selection issue on page edit screen
* Fixed: WordPress 3.6 menu creation issue

#### Files changed:

	Admin translation file
	assets/css/footer.css
	assets/css/visual-editor.css.php
	inc/loop/loop-attachment.php
	library/assets/js/wm-scripts.js
	library/meta/a-meta-page.php
	library/meta/m-cp-projects.php
	library/widgets/w-twitter.php


## 2.5

* Added: Improved WordPress 3.6 compatibility
* Added: New Projects widget layout
* Added: New WebMan metabox interface
* Added: Option to make theme sections transparent by default
* Added: Countdown timer shortcode
* Added: Option to restrict tracking scripts not to track logged in users
* Added: Filters applied on frontend texts for more flexible overriding
* Added: Added "Continue reading" links to posts
* Updated: Twitter widget updated to new Twitter API v1.1
* Updated: Logos responsive layout
* Updated: Frontend styles
* Updated: Admin area styles and functionality
* Updated: Better WPML plugin support
* Updated: Improved codes
* Updated: Font Awesome 3.2.1
* Updated: Scripts and plugins (jquery.imagesloaded, jquery.jplayer, jquery.masonry, html5shiv, Revolution Slider 3.0.5)
* Fixed: PrettyPhoto lightbox on projects lists
* Fixed: Saving page excerpt

#### Files changed:

	All translation files
	All skin files
	comments.php
	footer.php
	functions.php
	header.php
	nav.php
	single-wm_projects.php
	tpl-construction.php
	wpml-config.xml
	assets/css/content.css
	assets/css/icons.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/sidebar.css
	assets/css/slider.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/font/font-awesome/FontAwesome.otf
	assets/font/font-awesome/fontawesome-webfont.eot
	assets/font/font-awesome/fontawesome-webfont.svg
	assets/font/font-awesome/fontawesome-webfont.ttf
	assets/font/font-awesome/fontawesome-webfont.woff
	assets/js/html5.js
	assets/js/scripts.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/jplayer/Jplayer.swf
	assets/js/jplayer/jquery.jplayer.min.js
	assets/js/masonry/jquery.masonry.min.js
	assets/js/refineslide/apply-refineslide.js.php
	classes/nav-walker.php
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-gallery.php
	inc/format/format-link.php
	inc/format/format-video.php
	inc/loop/loop-attachment.php
	inc/loop/loop-sitemap.php
	inc/loop/loop-staff.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/setup.php
	library/wm-options-panel.php
	library/assets/css/wm-options/wm-options-panel.css
	library/assets/js/wm-options-panel.js
	library/assets/js/wm-scripts.js
	library/custom-posts/cp-modules.php
	library/custom-posts/cp-price.php
	library/custom-posts/cp-slides.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/meta/m-cp-logos.php
	library/meta/m-cp-modules.php
	library/meta/m-cp-price.php
	library/meta/m-cp-projects.php
	library/meta/m-cp-slides.php
	library/meta/m-cp-staff.php
	library/meta/m-excerpt.php
	library/meta/m-page.php
	library/meta/m-post.php
	library/options/a-design.php
	library/options/a-seo.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postlist.php
	library/widgets/w-twitter.php


## 2.4

* Added: WordPress 3.6 ready
* Added: Option to disable PrettyPhoto lightbox
* Added: Option to disable theme's CSS caching
* Added: Link relationship option for project custom link
* Updated: Custom image link (set in "slider" section of the image) applies on gallery images in slider
* Updated: Admin area updates
* Updated: PrettyPhoto works with "lightbox" CSS class
* Updated: Removed shortcodes from post widget excerpts
* Updated: Twitter widget
* Updated: Inteligent comment form placement
* Updated: Multirow toggle/accordion titles
* Updated: Better WPML plugin support
* Updated: Updated scripts, plugins (normalize.css, jquery.imagesloaded, jquery.jplayer, Revolution Slider 2.3.91)
* Updated: User manual updates
* Fixed: Paginated page slider display
* Fixed: Slider display on blog page
* Fixed: Fading effect not working on gallery in slider area
* Fixed: Current page ancestor not active in menu
* Fixed: Logo separator displayed even when no description set
* Fixed: Posts featured images links on blog pages
* Fixed: Admin area styling issues

#### Files changed:

	All translation files
	All skin files
	comments.php
	footer.php
	header.php
	wpml-config.xml
	assets/css/normalize.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/visual-editor.css.php
	assets/js/scripts.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/flex/apply-flex.js.php
	assets/js/jplayer/Jplayer.swf
	assets/js/jplayer/jquery.jplayer.min.js
	assets/js/nivo/apply-nivo.js.php
	assets/js/roundabout/apply-roundabout.js.php
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-link.php
	inc/format/format-quote.php
	inc/format/format-video.php
	inc/loop/loop-blogpage.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/setup.php
	library/wm-options-panel.php
	library/assets/css/admin-addons.css
	library/assets/css/login-addon.css.php
	library/assets/css/wm-options/wm-options-panel.css
	library/assets/js/wm-options-panel.js
	library/meta/m-cp-projects.php
	library/meta/a-meta-post.php
	library/options/a-blog.php
	library/options/a-general.php
	library/options/a-quickstart.php
	library/shortcodes/shortcodes.php
	library/widgets/w-postlist.php
	library/widgets/w-twitter.php


## 2.3

* Added: Theme options can be saved into presets
* Added: Option to add custom contact field into Staff posts
* Added: Author editing for custom post types
* Added: Automatic accordion shortcode animation speed setup
* Added: WMPL plugin language selector styles for top bar
* Added: Option to display full blog posts on blog pages
* Added: Using more tag in author biographical info
* Updated: Admin interface and functionality
* Updated: Option for better control of archive page titles via CSS
* Updated: Better de-branding options
* Updated: Comments form texts can be redefined in child theme
* Updated: Using smaller images for masonry blog layout
* Updated: Blog loops were rebuilt for making pagination work all the time
* Fixed: Theme options export/import issue
* Fixed: "Blog" in breadcrumbs when on Staff page
* Fixed: Form text field placeholder text alignment issue on Safari browser
* Fixed: Static image slider on blog page doesn't stretch
* Fixed: Staff LinkedIn contact is not being removed when empty field set

#### Files changed:

	All translation files
	comments.php
	footer.php
	header.php
	home.php
	assets/css/content.css
	assets/css/header.css
	assets/css/shortcodes.css
	assets/css/typography.css
	assets/js/scripts.js
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-gallery.php
	inc/format/format-link.php
	inc/format/format-video.php
	inc/loop/loop.php
	inc/loop/loop-blogpage.php
	inc/loop/loop-staff.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/wm-options-panel.php
	library/custom-posts/cp-faq.php
	library/custom-posts/cp-logos.php
	library/custom-posts/cp-modules.php
	library/custom-posts/cp-price.php
	library/custom-posts/cp-projects.php
	library/custom-posts/cp-slides.php
	library/custom-posts/cp-staff.php
	library/help/a-help.php
	library/meta/m-cp-staff.php
	library/options/a-blog.php
	library/options/a-export.php
	library/options/a-quickstart.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php


## 2.2.1

* Fixed: Admin panels options issue

#### Files changed:

	library/assets/js/wm-options-panel.js


## 2.2

* Added: Envato WordPress Toolkit plugin integration (automatic theme updates)
* Added: Option to open Logos custom link in the same or new window
* Added: Option to disable rich Staff profile page per staff member
* Added: Sample child theme
* Updated: Admin area styles and functionality
* Updated: Minor front end styling
* Updated: Hiding antispam enabled emails when JavaScript not enabled
* Updated: Theme updater
* Updated: Scripts and plugins (Revolution Slider 2.3.4, HTML5Shiv, jQuery.jPlayer, jQuery.Masonry, Isotope, Normalize.css and Nivo Slider)
* Fixed: Redirect page template not working with sub-sub-pages
* Fixed: Admin area JavaScript issue (coliding with some plugins) on post/page edit screen
* Fixed: Search pagination when Client Access functionality enabled
* Fixed: Image deformation in Internet Explorer 8 when image height set
* Fixed: Custom image field issue on Internet Explorer 9
* Fixed: PrettyPhoto styling issue

#### Files changed:

	langs/admin/jazzmaster_domain_adm.po
	langs/wm-admin-panel/jazzmaster_domain_panel.po
	single-wm_projects.php
	assets/css/core.css
	assets/css/responsive.css
	assets/css/prettyphoto/prettyphoto.css
	assets/js/scripts.js
	library/admin.php
	library/core.php
	library/custom-posts/cp-faq.php
	library/meta/m-cp-logos.php
	library/meta/m-cp-staff.php
	library/options/a-design.php
	library/options/a-security.php
	library/shortcodes/shortcodes.php
	library/updater/update-notifier.php
	library/widgets/w-postslist.php


## 2.1

* Added: Enabled custom fields metabox for Projects
* Added: Better compatibility with JetPack plugin
* Added: Option to disable website name in SEO meta title
* Updated: Admin area updates
* Updated: Improved code
* Updated: Improved SEO meta title
* Fixed: Font Awesome 3.0 classes
* Fixed: Removed audio player looping
* Fixed: Front page contains only one H1 tag
* Fixed: Some typos
* Fixed: Better ID generation for [section] shortcode

#### Files changed:

	all skin CSS files
	langs/admin/jazzmaster_domain_adm.po
	langs/help/jazzmaster_domain_help.po
	langs/wm-admin-panel/jazzmaster_domain_panel.po
	functions.php
	assets/css/core.css
	assets/css/typography.css
	assets/css/styles.css.php
	inc/formats/format.php
	inc/formats/format-audio.php
	inc/formats/format-gallery.php
	inc/formats/format-link.php
	inc/formats/format-quote.php
	inc/formats/format-status.php
	inc/formats/format-video.php
	inc/loop/loop-project.php
	inc/loop/loop-search.php
	library/admin.php
	library/core.php
	library/setup.php
	library/custom-posts/cp-projects.php
	library/options/a-seo.php
	library/shortcodes/shortcodes.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/widgets/w-contact.php


## 2.0

* Added: Project custom link actions
* Added: Option to add Projects to RSS feed (by default they are being removed from now on)
* Updated: Demo content
* Updated: Slider Revolution updated to version 2.2.4
* Updated: Font Awesome updated to version 3.0
* Updated: PrettyPhoto updated to version 3.1.5
* Updated: Several frontend CSS styles
* Updated: Improved functionality
* Updated: Improved compatibility with SEO plugins
* Updated: PrettyPhoto works with rel="prettyphoto" parameter
* Updated: Admin area texts
* Updated: Update notifier
* Fixed: Masonry blog styling issue

#### Files changed:

	langs/admin/jazzmaster_domain_adm.po
	langs/wm-admin-panel/jazzmaster_domain_panel.po
	header.php
	single-wm_projects.php
	assets/css/footer.css
	assets/css/icons.css
	assets/css/shortcodes.css
	assets/css/wp-styles.css
	assets/js/maps.js
	assets/js/scripts.js
	inc/formats/format.php
	inc/formats/format-gallery.php
	inc/formats/format-link.php
	inc/formats/format-quote.php
	inc/formats/format-status.php
	inc/loop/loop-staff.php
	library/core.php
	library/meta/m-cp-projects.php
	library/options/a-design.php
	library/options/a-general.php
	library/options/a-security.php
	library/shortcodes/shortcodes.php


## 1.9.5

* Updated: Content Module shortcode functionality
* Fixed: Minor menu issue when restricted access to a page
* Fixed: Displaying alt parameter for slider images
* Fixed: Login logo stretching on Safari browsers

#### Files changed:

	inc/loop/loop-project.php
	library/core.php
	library/assets/css/login-addon.css.php
	library/classes/nav-walker.php
	library/shortcodes/shortcodes.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/sliders/s-roundabout.php


## 1.9

* Added: New simpler GPS coordinates finder
* Added: Google Authorship support via Yoast WordPress SEO plugin
* Added: Plugin installation notifier
* Updated: Revolution Slider updated to version 2.1.7
* Updated: Admin area improvements
* Updated: Theme update notifier
* Updated: Code optimizatons
* Fixed: Nivo slider links
* Fixed: Facebook button overflow
* Fixed: Twitter button link
* Fixed: Minor menu issue when restricted access to a page
* Fixed: Client area (restricted access) uppercase letters in user name
* Fixed: Pagination for multiword search
* Fixed: Minor styling issues
* Fixed: Content images positioning

#### Files changed:

	Translation files
	header.php
	home.php
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/js/scripts.js
	library/core.php
	library/admin.php
	library/form-generator.php
	library/classes/nav-walker.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/m-page.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/sliders/s-nivo.php
	library/updater/update-notifier.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php


## 1.8

* Added: Better support for child themes
* Added: Custom posts counts in "Right Now" dashboard widget
* Added: New [icon] shortcode
* Updated: Styles for social icons in top bar
* Updated: Admin styles
* Updated: Revolution Slider updated to version 2.1.6
* Updated: User manual
* Fixed: Search form placeholder text displaying on Internet Explorer browsers
* Fixed: "Custom" map style title is translatable now
* Fixed: Posts (blog) page main heading settings

#### Files changed:

	Translation files
	header.php
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/js/maps.js
	assets/js/scripts.js
	library/core.php
	library/admin.php
	library/help/a-help.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php


## 1.7

* Added: WordPress 3.5 support
* Updated: Revolution Slider updated to newest version supporting WordPress 3.5
* Updated: Removing gallery images from slider on gallery posts
* Updated: Administration updates
* Updated: Buttons styles
* Fixed: Nivo slider caption issues

#### Files changed:

	assets/css/forms.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	inc/formats/format-gallery.php
	library/core.php
	library/form-generator.php
	library/sliders/s-nivo.php


## 1.6

* Added: Option to set the default map styling on Contact page
* Updated: Admin area styling
* Fixed: Display of "underline" button in visual editor
* Fixed: Audio and video player styling issues
* Fixed: FAQ filter default color set to accent color
* Fixed: Staff info page content issue when theme SEO disabled

#### Files changed:

	assets/css/style.css.php
	assets/css/jplayer/jplayer.css
	assets/js/maps.js
	inc/loop/loop-staff.php
	langs/admin/jazzmaster_domain_adm.po
	library/admin.php
	library/core.php
	library/meta/a-meta-page.php
	library/shortcodes/shortcodes.php


## 1.5

* Added: Option to order Prices posts inside price tables
* Added: Testimonials shortcode can display private posts (so they can be further more hidden from blog page)
* Updated: Updated Revolution Slider, Nivo and Flex slider
* Updated: Much improved support for 3rd party SEO plugins
* Updated: User manual
* Fixed: Styling issue when slider is turned off but slider under website header option is still set
* Fixed: Skype contact links in staff list/pages
* Fixed: Author archive author info social links
* Fixed: Issue with HTTPS protocol used on Vimeo videos
* Fixed: Page main heading icon issue when page set as a "Posts page" in WordPress Settings > Reading
* Fixed: Broken testimonials featured image when HTML and/or shortcodes used in quote author name field
* Fixed: Issue with custom comments introduction text
* Fixed: "Pin it" button made valid HTML

#### Files changed:

	Updated JavaScript files of Nivo and Flex slider
	Updated Revolution Slider plugin
	All translation PO files
	functions.php
	header.php
	inc/loop/loop-staff.php
	library/core.php
	library/form-generator.php
	library/meta/m-cp-price.php
	library/options/a-comments-form.php
	library/options/a-seo.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php


## 1.4

* Added: Option to disable images in posts, projects and staff shortcode
* Added: Levitate effect in Revolution slider
* Added: Option to disable WordPress admin menu items repositioning
* Added: Easier repositioning of custom post menu items in admin
* Added: Option to change "Related projects" text
* Updated: Responsive Flex, Nivo and Refineslide slider caption
* Updated: Theme admin area styling
* Updated: User manual updates
* Updated: Map styles
* Updated: Revolution slider admin styles
* Fixed: Tour tabs bug (when displaying unordered list inside tabs)
* Fixed: Accordion in tabs bug
* Fixed: Improved theme administration for WordPress site network

#### Files changed:

	All translation PO files
	All skin CSS files
	functions.php
	single-wm_projects.php
	assets/css/content.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/slider.css
	assets/css/style.css.php
	assets/js/maps.js
	assets/js/scripts.js
	library/admin.php
	library/setup.php
	library/custom-posts/cp-faq.php
	library/custom-posts/cp-logos.php
	library/custom-posts/cp-modules.php
	library/custom-posts/cp-price.php
	library/custom-posts/cp-projects.php
	library/custom-posts/cp-slides.php
	library/custom-posts/cp-staff.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/meta/m-cp-projects.php
	library/meta/m-cp-staff.php
	library/options/a-general.php
	library/options/a-layout.php
	library/options/a-seo.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php


## 1.3

* Added: Awesome Revolution Slider added!
* Added: Opening project images/videos in "lightbox" effect in projects list
* Added: Blog archive pages masonry layout option
* Added: Option to set up top padding on main theme navigation
* Added: Very basic WooCommerce plugin integration
* Added: Support for any slider plugin that integrates with shortcodes
* Updated: Theme front-end styling
* Updated: Theme admin area styling
* Updated: Theme options reorganization (some options moved from "Design" to "Layout" section)
* Updated: User manual updated
* Fixed: Some styling issues (like buttons in Nivo slider caption viewed on Internet Explorer browsers)

#### Files changed:

	functions.php
	index.php
	search.php
	woocommerce.php
	assets/css/content.css
	assets/css/core.css
	assets/css/footer.css
	assets/css/forms.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/slider.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/nivo/nivo.css
	assets/js/scripts.js
	inc/loop/loop.php
	langs/admin/jazzmaster_domain_adm.po
	langs/wm-admin-panel/jazzmaster_domain_panel.po
	library/core.php
	library/setup.php
	library/meta/a-meta-page.php
	library/options/a-blog.php
	library/options/a-design.php
	library/options/a-layout.php
	library/options/a-slider.php
	library/shortcodes/shortcodes.php


## 1.2

* Added: Print stylesheet
* Added: Hover over menu items
* Updated: Shortcodes in [raw] shortcode output issue
* Updated: GZIP turned off by default, option to enable it in theme admin panel
* Updated: Admin user experience
* Updated: Theme admin panel texts
* Fixed: ID parameter applied on sections of Sections page template
* Fixed: Improved responsiveness of submenus in right navigation menu
* Fixed: 1 column gallery image sizes and logic

#### Files changed:

	header.php
	functions.php
	assets/css/columns-print.css
	assets/css/print.css
	assets/css/responsive.css
	assets/css/style.css.php
	langs/wm-admin-panel/jazzmaster_domain_panel.po
	library/core.php
	library/form-generator.php
	library/options/a-404.php
	library/options/a-branding.php
	library/options/a-design.php
	library/options/a-general.php
	library/options/a-layout.php
	library/shortcodes/shortcodes.php


## 1.1

* Added: Masonry blog layout
* Added: Project comments
* Added: Gzip compression
* Added: Changed alignemt on submenu of main menu item with class of "subright" (also updated Contextual Help about this)
* Updated: Main stylesheet cache expiration prolonged to 7 days
* Updated: Some minor styling on front-end
* Updated: Styles of admin
* Updated: Some texts (see translation file changes in changelog filelist)
* Fixed: iPhone styling issues
* Fixed: Login form shortcode styling made responsive
* Fixed: Broken layout for certain search terms

#### Files changed:

	header.php
	home.php
	functions.php
	assets/css/borders.css
	assets/css/content.css
	assets/css/comments.css
	assets/css/footer.css
	assets/css/header.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/visual-editor.css.php
	assets/js/scripts.js
	inc/loop/loop.php
	inc/loop/loop-project.php
	langs/admin/jazzmaster_domain_adm.po
	langs/help/jazzmaster_domain_help.po
	library/admin.php
	library/core.php
	library/setup.php
	library/custom-posts/cp-projects.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/options/a-general.php
	library/shortcodes/shortcodes.php
	library/widgets/w-contact.php
	all skin stylesheets


## 1.0

* Initial release



(C) 2012 WebMan, www.webmandesign.eu