<?php get_header(); ?>
<div class="wrap-inner">

<?php
$sidebar = WM_SIDEBAR_FALLBACK;

if ( is_active_sidebar( $sidebar ) ) {
	$sidebarPanes = ( wm_option( 'layout-sidebar-width' ) ) ? ( esc_attr( wm_option( 'layout-sidebar-width' ) ) ) : ( WM_SIDEBAR_WIDTH );

	if ( ' four pane' === $sidebarPanes )
		$mainPanes = ' eight pane';
	elseif ( ' three pane' === $sidebarPanes )
		$mainPanes = ' nine pane';
	else
		$mainPanes = ' seven pane';
} else {
	$mainPanes    = ' twelve pane';
	$sidebarPanes = '';
}
?>

<article class="main<?php echo $mainPanes; ?>">

	<?php wm_start_main_content(); ?>

	<?php woocommerce_content(); ?>

</article> <!-- /main -->

<?php
$class = 'sidebar clearfix sidebar-right' . $sidebarPanes;
wm_sidebar( $sidebar, $class );
?>

</div> <!-- /wrap-inner -->
<?php get_footer(); ?>