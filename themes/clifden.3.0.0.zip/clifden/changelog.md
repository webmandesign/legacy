# Clifden Changelog

## 3.0

* Added: Update message in admin
* Added: Prepared for removing from distibution
* Updated: Font Awesome 4.3
* Updated: Tighten security
* Updated: Using unpacked scripts
* Updated: Admin interface styles
* Updated: Scripts: TGM Plugin Activation 2.4.1, jQuery FlexSlider 2.4.0, ImagesLoaded 3.1.8, Isotope 2.2.0
* Updated: Plugins: RevSlider 4.6.92
* Updated: Improved coding
* Updated: Added filter hooks for sliders
* Updated: Added and modified hooks for shortcodes
* Updated: Improved shortcodes
* Updated: Localization
* Fixed: Align left/right responsive styles
* Fixed: HTML validation issues
* Fixed: Issues with sliders

#### Files changed:

	functions.php
	style.css
	changelog.md
	assets/css/icons.css
	assets/css/responsive.css
	assets/font/font-awesome/*.*
	assets/js/scripts.js
	assets/js/flex/jquery.flexslider-min.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/isotope/jquery.isotope.min.js
	langs/*.*
	library/admin.php
	library/core.php
	library/assets/css/admin-addon.css
	library/assets/css/wm-options/wm-options-panel.css
	library/plugins/plugin-activation/class-tgm-plugin-activation.php
	library/plugins/plugin-activation/plugins.php
	library/shortcodes/shortcodes.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-roundabout.php
	library/updater/update-notifier.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php


## 1.9

* Added: Full WordPress 3.9 support
* Added: FlexSlider keyboard navigation for projects sliders
* Added: Zooming images in projects sliders (besides custom links applied on images)
* Added: Filter hooks for shortcodes, widgets, sliders and others
* Added: Next/previous post/project section
* Added: Support for Jetpack plugin's sharing feature
* Added: Font icons support for Content Modules
* Updated: Removed Refineslide slider for script incompatibility and end of development
* Updated: Font Awesome v4.1.0
* Updated: Admin fields and texts
* Updated: Admin interface
* Updated: Theme stylesheet being included with wp_enqueue_style() function
* Updated: Scripts: Isotope 2.0, FlexSlider 2.2.2, ImagesLoaded 3.1.6, Normalize.css 3.0.1, HTML5 Shiv 3.7.2
* Updated: Plugins: Slider Revolution 4.3.8
* Updated: Support for native WordPress video and audio shortcodes
* Updated: Logic of video/audio projects and post formats
* Fixed: Slideshow shortcode inside Content Module shortcode styling
* Fixed: Call to action title word wrapping
* Fixed: Project widget custom projects links
* Fixed: Missing localization strings
* Fixed: Caption shortcode throwing PHP error

#### Files changed:

	All localization files
	Icon font files
	functions.php
	header.php
	single-wm_projects.php
	assets/css/borders.css
	assets/css/content.css
	assets/css/icons.css
	assets/css/normalize.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/wp-styles.css
	assets/css/flex/flex.css
	assets/js/flex/jquery.flexslider-min.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/isotope/jquery.isotope.min.js
	assets/js/html5.js
	assets/js/scripts.dev.js
	assets/js/scripts.js
	inc/formats/format.php
	inc/formats/format-audio.php
	inc/formats/format-gallery.php
	inc/formats/format-link.php
	inc/formats/format-video.php
	inc/loop/loop-project.php
	library/admin.php
	library/core.php
	library/setup.php
	library/wm-options-panel.php
	library/assets/css/admin-addon.css
	library/assets/css/wm-options/wm-options-panel.css
	library/assets/js/wm-options-panel.js
	library/help/a-help.php
	library/hooks/hooks.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/meta/m-cp-modules.php
	library/meta/m-cp-projects.php
	library/options/a-general.php
	library/options/a-slider.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/sliders/s-roundabout.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php


## 1.8.5

* Added: WordPress 3.8 ready
* Added: Custom CSS class attribute for [column] shortcode
* Added: Fiter to add/modify contact infos in Contact widget
* Updated: Update plugins (Revolution Slider 4.1.2)
* Fixed: Header min-height settings
* Fixed: Mobile menu "Menu" text is translatable

#### Files changed:

	Admin, front-end and help localization file
	library/admin.php
	library/core.php
	library/setup.php
	library/assets/css/admin-addon-38.css
	library/assets/js/scripts.js
	library/help/a-help.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-contact.php


## 1.8.1

* Added: Logos custom post link relation
* Added: Applied filters on some shortcodes outputs
* Updated: Font Awesome 4.0.3 icons
* Fixed: Logos custom post image upload
* Fixed: Image title attribute

#### Files changed:

	Admin localization file
	functions.php
	assets/css/icons.css
	library/core.php
	library/admin.php
	library/meta/m-cp-logos.php
	library/shortcodes/shortcodes.php


## 1.8

* Added: Support for "All In One Schema.org Rich Snippets" and "Schema Creator by Raven" Schema.org snippets plugins
* Added: Option to display related posts with [posts] shortcode
* Added: Option to display replies in Twitter Widget
* Added: Option to disable sharing buttons per post/page basis
* Added: WP-PageNavi pagination plugin support
* Updated: Admin area updates
* Updated: Plugins and scripts updates (TGM Plugin Activation, Revolution Slider 4.0.4)
* Updated: Better shortcodes support with WordPress 3.6+
* Updated: Improved code
* Updated: Minor frontend styles updates
* Fixed: Posts widget coding error
* Fixed: Twitter Widget fixes
* Fixed: Blog page pagination fix

#### Files changed:

	Admin, help translation file
	comments.php
	single-wm_projects.php
	assets/css/core.css
	assets/css/responsive.css
	inc/loop/loop-blogpage.php
	library/core.php
	library/wm-options-panel.php
	library/assets/css/admin-addons.css
	library/classes/meta-box-generator.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/sliders/s-roundabout.php
	library/widgets/w-postslist.php
	library/widgets/w-twitter.php


## 1.7.1

* Added: Countdown timer shortcode
* Added: Option not to track logged in users
* Updated: Optimized code
* Updated: Admin updates
* Updated: Twitter Widget improved
* Updated: Updated plugins (Revolution Slider 3.0.8)
* Fixed: Attachment loop apply_filters function error
* Fixed: Minor styles fixes
* Fixed: Slides group selection issue on page edit screen
* Fixed: WordPress 3.6 menu creation issue
* Fixed: Attachment page apply_filters issue

#### Files changed:

	Admin, options panel, contextual help translation files
	footer.php
	tpl-construction.php
	assets/css/footer.css
	assets/css/content.css
	assets/css/responsive.css
	assets/css/slider.css
	assets/css/shortcodes.css
	assets/css/typography.css
	assets/css/visual-editor.css.php
	inc/loop/loop-attachment.php
	library/core.php
	library/setup.php
	library/assets/js/wm-options-panel.js
	library/assets/js/wm-scripts.js
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/m-cp-projects.php
	library/options/a-seo.php
	library/shortcodes/shortcodes-generator.php
	library/shortcodes/shortcodes.php
	library/widgets/w-twitter.php


## 1.7

* Added: WordPress 3.6 compatible
* Added: Logos custom link target setup
* Added: Print stylesheet
* Added: Filters for more flexible frontend texts updates
* Added: Option to disable rich staff pages per staff basis
* Added: Option to backup/restore theme settings in/from file
* Added: Custom Staff post contact options
* Added: Option to edit custom posts author
* Added: Automatic accordion shortcode time setup
* Added: Option to display full blog posts on blog pages
* Added: Option to disable PrettyPhoto lightbox
* Added: Intelligent comments form positioning
* Added: Option to disable CSS and scripts caching
* Added: Option to set up a "rel" attribute for project custom link
* Added: Added "Continue reading" link on blog pages
* Added: Sample child theme included in theme package
* Updated: Frontend styles
* Updated: Admin interface (new awesome WebMan metaboxes) and functionality
* Updated: Navigation menu walker
* Updated: Twitter widget updated to new API 1.1
* Updated: Responsive Logos display
* Updated: Font Awesome 3.2.1
* Updated: Search pagination when using Client Access functionality
* Updated: Added additional HTML into archives headings for better styling possibilities
* Updated: Improved compatibility with WPML plugin
* Updated: Improved theme code
* Updated: PrettyPhoto lightbox works for ".lightbox" CSS class too
* Updated: Posts widget removes shortcodes from post excerpts now
* Updated: Scripts and plugins updates (normalize.css, jquery.imagesloaded, jquery.jplayer, jquery.masonry, html5shiv, Revolution Slider 3.0.5)
* Updated: Theme user manual updates
* Fixed: Bottom navigation wrapper overlaying issue
* Fixed: PrettyPhoto lightbox image duplication on projects list
* Fixed: Redirect page template subpage setup issue
* Fixed: Breadcrumbs showing "Blog" on staff pages
* Fixed: Slider below header styling issue on paninated pages
* Fixed: Custom link on gallery images in slider area

#### Files changed:

	All translation files
	comments.php
	footer.php
	functions.php
	header.php
	home.php
	single-wm_projects.php
	wpml-config.xml
	assets/css/content.css
	assets/css/core.css
	assets/css/header.css
	assets/css/icons.css
	assets/css/normalize.css
	assets/css/print.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/visual-editor.css.php
	assets/css/prettyphoto/prettyphoto.css
	assets/font/font-awesome/FontAwesome.otf
	assets/font/font-awesome/fontawesome-webfont.eot
	assets/font/font-awesome/fontawesome-webfont.svg
	assets/font/font-awesome/fontawesome-webfont.ttf
	assets/font/font-awesome/fontawesome-webfont.woff
	assets/js/html5.js
	assets/js/scripts.js
	assets/js/imagesloaded/jquery.imagesloaded.min.js
	assets/js/flex/apply-flex.js.php
	assets/js/jplayer/Jplayer.swf
	assets/js/jplayer/jquery.jplayer.min.js
	assets/js/masonry/jquery.masonry.min.js
	assets/js/nivo/apply-nivo.js.php
	assets/js/refineslide/apply-refineslide.js.php
	assets/js/roundabout/apply-roundabout.js.php
	classes/nav-walker.php
	inc/format/format.php
	inc/format/format-audio.php
	inc/format/format-gallery.php
	inc/format/format-link.php
	inc/format/format-quote.php
	inc/format/format-status.php
	inc/format/format-video.php
	inc/loop/loop.php
	inc/loop/loop-blogpage.php
	inc/loop/loop-staff.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/setup.php
	library/wm-options-panel.php
	library/assets/css/admin-addons.css
	library/assets/css/login-addon.css.php
	library/assets/css/wm-options/wm-options-panel.css
	library/assets/js/wm-options-panel.js
	library/assets/js/wm-scripts.js
	library/custom-posts/cp-faq.php
	library/custom-posts/cp-logos.php
	library/custom-posts/cp-modules.php
	library/custom-posts/cp-price.php
	library/custom-posts/cp-projects.php
	library/custom-posts/cp-slides.php
	library/custom-posts/cp-staff.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/meta/m-cp-logos.php
	library/meta/m-cp-modules.php
	library/meta/m-cp-price.php
	library/meta/m-cp-projects.php
	library/meta/m-cp-slides.php
	library/meta/m-cp-staff.php
	library/meta/m-excerpt.php
	library/meta/m-page.php
	library/meta/m-post.php
	library/options/a-blog.php
	library/options/a-export.php
	library/options/a-general.php
	library/options/a-quickstart.php
	library/options/a-seo.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/updater/update-notifier.php
	library/widgets/w-postlist.php
	library/widgets/w-twitter.php


## 1.6

* Added: Custom fields metabox for projects
* Added: Option to add projects into RSS feed (disabled by default from now on)
* Added: Optional social sharing for pages
* Added: Several actions with custom project links
* Updated: Revolution Slider updated to version 2.3.3
* Updated: Minor styling updates
* Updated: Admin area updates
* Updated: Font Awesome 3.0
* Updated: Shortcodes processing
* Updated: Better compatibility with Jetpack plugin
* Updated: Code improvements
* Updated: Robots meta removed when theme SEO is off
* Updated: Update notifier
* Updated: Better ID generation for [section] shortcode
* Updated: PrettyPhoto, Nivo slider, jPlayer, Masonry, Isotope, HTML5Shiv scripts updated to most recent versions
* Updated: Normalize CSS updated to most recent version
* Fixed: Widget titles border in custom widget areas
* Fixed: Removed audio player looping
* Fixed: Some texts typos
* Fixed: Slider beneath header on blog page
* Fixed: Header right text area on Landing Page when no menu set
* Fixed: Top bar on archive pages issue
* Fixed: PrettyPhoto lightbox working with "rel" attribute on link
* Fixed: Double H1 heading issue on homepage

#### Files changed:

	All skin CSS files
	langs/admin/clifden_domain_adm.po
	langs/help/clifden_domain_help.po
	langs/wm-admin-panel/clifden_domain_panel.po
	functions.php
	header.php
	page.php
	single-wm_projects.php
	tpl-landing.php
	tpl-map.php
	assets/css/content.css
	assets/css/core.css
	assets/css/footer.css
	assets/css/icons.css
	assets/css/normalize.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/sidebar.css
	assets/css/styles.css.php
	assets/css/typography.css
	assets/css/wp-styles.css
	assets/js/maps.js
	assets/js/html5.js
	assets/js/isotope/jquery.isotope.min.js
	assets/js/jplayer/jquery.jplayer.min.js
	assets/js/masonry/jquery.masonry.min.js
	assets/js/nivo/jquery.nivo.slider.pack.js
	assets/js/prettyphoto/jquery.prettyPhoto.js
	inc/formats/format.php
	inc/formats/format-audio.php
	inc/formats/format-gallery.php
	inc/formats/format-link.php
	inc/formats/format-quote.php
	inc/formats/format-status.php
	inc/formats/format-video.php
	inc/loop/loop-project.php
	inc/loop/loop-search.php
	inc/loop/loop-staff.php
	library/admin.php
	library/core.php
	library/setup.php
	library/sidebars.php
	library/custom-posts/cp-projects.php
	library/meta/a-meta-page.php
	library/meta/m-cp-projects.php
	library/options/a-design.php
	library/options/a-social.php
	library/options/a-security.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/updater/update-notifier.php
	library/widgets/w-contact.php


## 1.5.5

* Updated: Revolution Slider updated to version 2.2
* Fixed: Error on post edit pages

#### Files changed:

	library/meta/a-meta-post.php
	library/meta/m-post.php


## 1.5

* Added: Google Authorship support via Yoast WordPress SEO plugin
* Added: Plugin installation notifier
* Added: New simpler GPS coordinates finder
* Added: Using simple HTML in tab titles (for icons for example)
* Updated: Revolution Slider updated to version 2.1.7
* Updated: Admin area improvements
* Updated: Theme update notifier
* Updated: Code optimizatons
* Updated: Theme demo content
* Updated: Content Module shortcode functionality
* Fixed: Safari browser login screen logo stretching
* Fixed: Nivo slider links
* Fixed: Blog page settings
* Fixed: Facebook and Twitter share buttons
* Fixed: Minor menu issue when restricted access to a page
* Fixed: Client area (restricted access) uppercase letters in user name
* Fixed: Pagination on multiword search
* Fixed: Minor styling issues
* Fixed: Content images positioning
* Fixed: Slider images alt and title parameters

#### Files changed:

	Translation files
	header.php
	home.php
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/js/scripts.js
	library/core.php
	library/admin.php
	library/form-generator.php
	library/assets/css/login-addon.css.php
	library/classes/nav-walker.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/m-page.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/sliders/s-flex.php
	library/sliders/s-nivo.php
	library/sliders/s-refineslide.php
	library/sliders/s-roundabout.php
	library/updater/update-notifier.php
	library/widgets/w-cpprojects.php
	library/widgets/w-postslist.php


## 1.4

* Added: Better support for child themes
* Added: Custom posts counts in "Right Now" dashboard widget
* Added: New [icon] shortcode
* Added: Using inline HTML in tab titles
* Updated: Styles for social icons in top bar
* Updated: Admin styles
* Updated: Revolution Slider updated to version 2.1.6
* Updated: User manual
* Fixed: Search form placeholder text displaying on Internet Explorer browsers
* Fixed: "Custom" map style title is translatable now
* Fixed: Posts (blog) page main heading settings
* Fixed: Clifden Projects widget category selection fixed

#### Files changed:

	Translation files
	header.php
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/js/maps.js
	assets/js/scripts.js
	library/core.php
	library/admin.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/m-cp-clients.php
	library/meta/m-cp-modules.php
	library/meta/m-cp-portfolio.php
	library/meta/m-cp-slides.php
	library/meta/m-cp-team.php
	library/meta/m-excerpt.php
	library/meta/m-page.php
	library/meta/m-post.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php
	library/widgets/w-cpprojects.php


## 1.3

* Added: WordPress 3.5 support
* Updated: Revolution Slider updated to newest version 2.1 supporting WordPress 3.5
* Updated: Administration updates
* Updated: Buttons styles

#### Files changed:

	assets/css/forms.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	inc/formats/format-gallery.php
	library/core.php
	library/form-generator.php


## 1.2

* Added: Amazing Slider Revolution
* Added: Hugely improved support for SEO plugins, option to switch the theme SEO functionality off
* Added: Sorting option for price table columns
* Added: Testimonials shortcode displays private posts too
* Added: Easier control of admin menu items positions added by the theme
* Added: Option to disable thumbnails on Posts, Projects and Staff shortcodes
* Added: Option to change "Related projects" text
* Added: Option for lightbox effect on projects lists
* Added: Option to use any slider plugin (has to support insertion with shortcodes)
* Added: Option to enable/disable GZIP compression
* Added: Comments on projects
* Updated: Admin area funcionality and styling
* Updated: Tabs, accordions and toggles styling
* Updated: FAQ filter default color to link color
* Updated: Skype links in staff list and pages
* Updated: Nivo and Flex slider upgraded
* Updated: Alt parameter for "Pin it" button
* Updated: Contact page map styling and functionality
* Updated: Better support for WordPress site network
* Updated: Theme styles
* Updated: GZIP compression on main theme stylesheet
* Updated: Gallery styling and functionality
* Updated: Translation texts
* Updated: Theme user manual and contextual help
* Fixed: Removing images from slideshow when removed on "Gallery" tab of "Post settings" metabox
* Fixed: Button styling in Nivo slider caption
* Fixed: Nivo slider caption issue
* Fixed: Website background styling issues
* Fixed: Navigation menu active item styling
* Fixed: "Underline" button in visual editor issue
* Fixed: Audio and video player styling inside a box element
* Fixed: Website header styling issues when slider disabled, yet still set to be displayed below the website header
* Fixed: Display Vimeo video when HTTPS link set
* Fixed: Issue with main heading icon on blog page
* Fixed: Author archive social links
* Fixed: HTML and shortcodes output/styling in quote author on quote posts
* Fixed: Comments introduction text display

#### Files changed:

	Updated JavaScript files of Nivo and FlexSlider
	All translation PO files
	footer.php
	functions.php
	header.php
	index.php
	search.php
	single-wm_projects.php
	taxonomy-project-category.php
	tpl-redirect.php
	assets/css/content.css
	assets/css/core.css
	assets/css/forms.css
	assets/css/responsive.css
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/typography.css
	assets/css/jplayer/jplayer.css
	assets/css/nivo/nivo.css
	assets/js/maps.css
	assets/js/scripts.css
	inc/format/format-gallery.php
	inc/loop/loop-project.php
	inc/loop/loop-staff.php
	library/admin.php
	library/core.php
	library/form-generator.php
	library/setup.php
	library/wm-options-panel.php
	library/custom-posts/cp-faq.php
	library/custom-posts/cp-logos.php
	library/custom-posts/cp-modules.php
	library/custom-posts/cp-price.php
	library/custom-posts/cp-projects.php
	library/custom-posts/cp-slides.php
	library/custom-posts/cp-staff.php
	library/help/a-help.php
	library/meta/a-meta-page.php
	library/meta/a-meta-post.php
	library/meta/m-cp-price.php
	library/meta/m-cp-projects.php
	library/meta/m-cp-staff.php
	library/options/a-blog.php
	library/options/a-comments-form.php
	library/options/a-design.php
	library/options/a-general.php
	library/options/a-layout.php
	library/options/a-seo.php
	library/options/a-slider.php
	library/sliders/s-nivo.php
	library/shortcodes/shortcodes.php
	library/shortcodes/shortcodes-generator.php


## 1.1

* Added: Gzip compression
* Updated: Main stylesheet cache expiration prolonged to 7 days
* Updated: Some minor styling on front-end
* Updated: Styles of admin
* Updated: Some texts (see translation file changes in changelog filelist)
* Fixed: Login form shortcode styling made responsive
* Fixed: Broken layout for certain search terms

#### Files changed:

	footer.php
	header.php
	functions.php
	assets/css/shortcodes.css
	assets/css/style.css.php
	assets/css/visual-editor.css.php
	langs/admin/clifden_domain_adm.po
	library/core.php
	library/help/a-help.php
	library/shortcodes/shortcodes.php


## 1.0

* Initial release


(C) 2012 WebMan, www.webmandesign.eu