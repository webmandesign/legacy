<?php
/*
*****************************************************
* WEBMAN'S WORDPRESS THEME FRAMEWORK
* Created by WebMan - www.webmandesign.eu
*
* Static settings
*****************************************************
*/

$prefix = 'static-';
$staticOptions = array(

array(
	"id" => $prefix."webdesigner",
	"default" => 'This WordPress theme was created by WebMan - www.webmandesign.eu, http://www.webmandesign.eu'
)

);

?>