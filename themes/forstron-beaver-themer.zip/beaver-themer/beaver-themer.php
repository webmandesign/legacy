<?php
/**
 * Plugin compatibility file
 *
 * Beaver Themer
 *
 * @link  https://www.wpbeaverbuilder.com/beaver-themer/
 *
 * @package    Forstron
 * @copyright  WebMan Design, Oliver Juhas
 *
 * @since    1.7.0
 * @version  1.7.0
 *
 * Contents:
 *
 *  1) Requirements check
 * 10) Plugin integration
 */





/**
 * 1) Requirements check
 */

	if ( ! class_exists( 'FLThemeBuilder' ) ) {
		return;
	}





/**
 * 10) Plugin integration
 */

	locate_template( WM_SETUP_DIR . 'beaver-themer/class-beaver-themer.php', true );
